#!/usr/bin/env python3
from __future__ import print_function
import os
import sys
import argparse
import concurrent.futures
import threading
from infra.extract import extract_data_collection, get_dc_info
from infra.utils import validate_time_str_format, get_my_logger, TOOL_OUTPUT_FOLDER, TOOL_TMP_FOLDER, system
from infra.process_journal import process_journals, export_error_and_critical_logs, generate_timeline, run_cp_datacollection_triage, split_exported_journal_logs, parse_datapath_dependency_sequencer_log
from infra.process_metrics_data import process_metrics_data
from infra.process_mel_log import process_mel_log
from infra.process_sel_log import process_sel_log
from infra.process_xtrace import dump_volatile_xtrace_to_text, dump_persistent_xtrace_to_text
from infra.dump_files_check import find_dump_files
from infra.dump_analyzer import analyze_dump
from parser.run_parser import run_parsers
from text_report.text_report import generate_text_report
from excel_report.excel_report import generate_excel_report
from log_filter.log_filter import filter_log
from health_check.health_check import run_health_check

#------------------------------------------------------------------------#
# Copyright (C) 2020 Dell Inc. and its subsidiaries. All Rights reserved #
#------------------------------------------------------------------------#
#--------------------------------------#
# Henry.An@dell.com                    #
# NGMR Engineering Technical Services  #
#--------------------------------------#

# This script can be run from the folder where the compressed data collection file is located or from the extracted data
# collection folder.
program = os.path.basename(sys.argv[0])
version = "1.1.0"

if __name__ == "__main__":
    parser = argparse.ArgumentParser(formatter_class=argparse.RawTextHelpFormatter)
    parser.add_argument('--version', action='version', version=version, help='show script version')
    parser.add_argument("--debug", dest="debug", action="store_true", required=False,
                        help='increase console output verbosity')
    parser.add_argument("--report-only", dest="report_only", action="store_true", required=False,
                        help='For test only. Generate cluster configuration report only, skip exporting journal logs')
    parser.add_argument("--dc", dest="dc_full_path", action="store", required=False,
                        help='Full path to the Data Collection.')
    parser.add_argument("--since", dest="since", action="store", required=False,
                        help='Date specifications should be of the format of "YYYY-MM-DD HH:MM:SS",e.g. "2018-12-03 10:00:00"')
    parser.add_argument("--until", dest="until", action="store", required=False,
                        help='Date specifications should be of the format of "YYYY-MM-DD HH:MM:SS",e.g. "2018-12-03 23:00:00"')
    args = parser.parse_args()

    from_time = args.since
    to_time = args.until
    if from_time:
        validate_time_str_format(from_time)
    if to_time:
        validate_time_str_format(to_time)

    dc_full_path = args.dc_full_path
    if dc_full_path and " " in dc_full_path:
        sys.exit("This script doesn't support folder name or file name with space in it.")
    work_space_folder, dc_file_name = get_dc_info(dc_full_path)
    if " " in work_space_folder:
        sys.exit("This script doesn't support folder name or file name with space in it.")
    logger = get_my_logger(args.debug, log_folder=os.path.dirname(work_space_folder))
    logger.info("powerstore_triage version: %s" % version)
    extract_data_collection(work_space_folder, dc_file_name)
    find_dump_files(work_space_folder)
    tool_output_folder_abs = os.path.join(work_space_folder, TOOL_OUTPUT_FOLDER)
    tool_output_tmp_folder_abs = os.path.join(work_space_folder, TOOL_OUTPUT_FOLDER, TOOL_TMP_FOLDER)
    if not args.report_only:
        if os.path.exists(tool_output_folder_abs):
            stdout, stderr, ret_code = system(r'rm -rf {0}'.format(tool_output_folder_abs))
            if ret_code != 0:
                logger.error(stderr)
        os.mkdir(tool_output_folder_abs)
        os.mkdir(tool_output_tmp_folder_abs)
        process_journals(work_space_folder, from_time, to_time)
        run_parsers(work_space_folder)
        generate_text_report(work_space_folder)
        generate_excel_report(work_space_folder)
        # process_metrics_data(work_space_folder)
        run_health_check(work_space_folder)
        persistent_xtrace_exists = os.path.join(work_space_folder, 'node_a', 'cyc_datalogs') or os.path.join(work_space_folder, 'node_b', 'cyc_datalogs')
        dump_persist_xtrace_threads = list()
        if persistent_xtrace_exists:
            for node_name in ['node_a', 'node_b']:
                dump_persist_xtrace_thread = threading.Thread(target=dump_persistent_xtrace_to_text, args=(work_space_folder, node_name,))
                dump_persist_xtrace_threads.append(dump_persist_xtrace_thread)
                dump_persist_xtrace_thread.start()

        logger.info("Running analyzing tasks in parallel...")
        # executor inside a executor doesn't seem to work
        with concurrent.futures.ThreadPoolExecutor(max_workers=4) as executor:
            futures = list()
            futures.append(executor.submit(split_exported_journal_logs, work_space_folder))
            futures.append(executor.submit(parse_datapath_dependency_sequencer_log, work_space_folder))
            futures.append(executor.submit(process_metrics_data, work_space_folder))
            futures.append(executor.submit(process_mel_log, work_space_folder))
            futures.append(executor.submit(process_sel_log, work_space_folder))
            futures.append(executor.submit(export_error_and_critical_logs, work_space_folder, from_time, to_time))
            futures.append(executor.submit(generate_timeline, work_space_folder))
            futures.append(executor.submit(run_cp_datacollection_triage, work_space_folder))
            futures.append(executor.submit(dump_volatile_xtrace_to_text, work_space_folder))
            futures.append(executor.submit(dump_persistent_xtrace_to_text, work_space_folder))
            futures.append(executor.submit(filter_log, work_space_folder, from_time, to_time))
            futures.append(executor.submit(analyze_dump, work_space_folder, dc_file_name))
            for future in concurrent.futures.as_completed(futures):
                logger.debug(future.done())
        logger.info("Finished all analyzing tasks")

        if persistent_xtrace_exists:
            for thread in dump_persist_xtrace_threads:
                thread.join()
    else:
        # for report_only option, the following is to avoid deleting the exported journal files.
        if not os.path.exists(tool_output_folder_abs):
            os.mkdir(tool_output_folder_abs)
        if os.path.exists(tool_output_tmp_folder_abs):
            system("rm -rf {0}".format(tool_output_tmp_folder_abs))
        os.mkdir(tool_output_tmp_folder_abs)
        run_parsers(work_space_folder)
        generate_text_report(work_space_folder)
        generate_excel_report(work_space_folder)
        run_health_check(work_space_folder)
        process_metrics_data(work_space_folder)
        process_mel_log(work_space_folder)
        process_sel_log(work_space_folder)
        parse_datapath_dependency_sequencer_log(work_space_folder)
        split_exported_journal_logs(work_space_folder)
        filter_log(work_space_folder,from_time, to_time)
    system("rm -rf {0}".format(tool_output_tmp_folder_abs))
    logger.info("Completed!")