from text_report.common import generate_report_from_list_of_dict
from data_normalizer.appliance_space_stats_normalizer import normalize_applaince_space_stats_info


def report_applaince_space_stats_info(dc_folder, output_fp):
    header, list_of_appliance_space_stats = normalize_applaince_space_stats_info(dc_folder)
    report_name_str = "This Appliance Capacity Information"
    generate_report_from_list_of_dict(output_fp, report_name_str, list_of_appliance_space_stats, header, vertical=False, sort_func=None)
