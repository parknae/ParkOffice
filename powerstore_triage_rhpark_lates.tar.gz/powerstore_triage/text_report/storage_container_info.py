from text_report.common import generate_report_from_list_of_dict
from data_normalizer.storage_container_info_normalizer import normalize_storage_container_info


def report_storage_container_info(dc_folder, output_fp):
    report_name_str = "Storage Container Information"
    header, list_of_dict = normalize_storage_container_info(dc_folder)
    generate_report_from_list_of_dict(output_fp, report_name_str, list_of_dict, header, vertical=False)
