from data_normalizer.host_virtual_volume_mapping_info_normalizer import normalize_virtual_volume_mapping_info
from text_report.common import generate_report_from_list_of_dict


def sort_host_virtual_volume_mapping(a_dict):
    return [a_dict['host_name'], a_dict['volume'], a_dict["vvoltype"]]


def report_host_virtual_volume_mapping_info(dc_folder, output_fp):
    report_name_str = "Host-VVol Mapping Information"
    header, list_of_dict = normalize_virtual_volume_mapping_info(dc_folder)
    generate_report_from_list_of_dict(output_fp, report_name_str, list_of_dict, header, vertical=False, sort_func=sort_host_virtual_volume_mapping)
