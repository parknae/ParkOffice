from infra.utils import TOOL_NAME, get_mgmt_data_file_path
from text_report.common import generate_report_from_list_of_dict
import os
import json
import logging

logger = logging.getLogger('.'.join([TOOL_NAME, __name__]))


def report_local_and_remote_system_info(dc_folder, output_fp):
    report_name_str = "Local And Remote System Information"
    header = ["name", "serial_number", "type", "state", "management_address", "user_name", "data_network_latency", "data_connection_state", "iscsi_addresses", "description"]
    remote_system_json_file_path = get_mgmt_data_file_path(dc_folder, 'remote_system.json')
    if remote_system_json_file_path:
        logger.debug(remote_system_json_file_path)

        with open(remote_system_json_file_path, 'r') as f:
            data = json.load(f)
            logger.debug(data)
            list_of_dict = data['data']
            for i, record in enumerate(data['data']):
                list_of_dict[i]["iscsi_addresses"] = ", ".join(record["iscsi_addresses"])

            generate_report_from_list_of_dict(output_fp, report_name_str, list_of_dict, header, vertical=False)