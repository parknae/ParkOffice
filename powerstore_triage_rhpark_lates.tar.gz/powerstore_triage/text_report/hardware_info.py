from text_report.common import generate_report_from_list_of_dict


def sort_by_appliance_id_then_drive_name(a_dict):
    temp_list = list()
    temp_list.append(int(a_dict["appliance_id"][1]))
    temp_list.extend([int(y) for y in a_dict["name"].split("_")[1:]])
    return temp_list


def sort_dimm_name(a_dict):
    # logger.debug(a_dict)
    # "BaseEnclosure-NodeA-DIMM13"
    a, b = a_dict["name"].split("DIMM")
    return [a_dict["appliance_id"], a, int(b)]


# define several functions so that the sequence of the report for different hardware can be easily arranged.
def report_data_drive_info(list_of_data_drive, output_fp):
    data_drive_header = ["name", "appliance_id", "slot", "A_device_name", "B_device_name", 
                         "lifecycle_state", "drive_type", "size", "firmware_version",
                         "encryption_status", "fips_status",
                         "part_number", "serial_number", "status_led_state", "is_marked"]

    generate_report_from_list_of_dict(output_fp, "Drive Information", list_of_data_drive,
                                      data_drive_header, vertical=False, sort_func=sort_by_appliance_id_then_drive_name)


def report_m2_drive_info(list_of_m2_drive, output_fp):
    m2_drive_header = ["name", "appliance_id", "slot", "lifecycle_state", "model_name", "part_number", "serial_number"]
    generate_report_from_list_of_dict(output_fp, "M2 Drive Information", list_of_m2_drive,
                                      m2_drive_header, vertical=False)


def report_io_module_info(list_of_io_module, output_fp):
    io_module_header = ["name", "appliance_id", "slot", "lifecycle_state", "model_name", "part_number", "serial_number", "status_led_state"]
    generate_report_from_list_of_dict(output_fp, "IO Module Information", list_of_io_module, io_module_header, vertical=False)


def report_sfp_info(list_of_sfp, output_fp):
    sfp_header = ["name", "appliance_id", "slot", "lifecycle_state", "connector_type", "parent_model_name", "supported_speeds", "part_number", "serial_number"]
    generate_report_from_list_of_dict(output_fp, "SFP Information", list_of_sfp, sfp_header, vertical=False)


def report_dimm_info(list_of_dimm, output_fp):
    dimm_header = ["name", "appliance_id", "slot", "lifecycle_state", "part_number", "serial_number"]
    generate_report_from_list_of_dict(output_fp, "DIMM Information", list_of_dimm, dimm_header, vertical=False, sort_func=sort_dimm_name)


def report_base_enclosure_info(list_of_base_enclosure, output_fp):
    base_enclosure_header = ["name", "appliance_id", "lifecycle_state", "part_number", "serial_number", "status_led_state", "dell_service_tag", "express_service_code"]
    generate_report_from_list_of_dict(output_fp, "Base Enclosure Information", list_of_base_enclosure, base_enclosure_header, vertical=False)


def report_node_info(list_of_node, output_fp):
    header = ["name", "appliance_id", "lifecycle_state", "part_number", "serial_number", "status_led_state", "cpu_sockets", "cpu_cores", "cpu_speed_mhz", "physical_memory_size_gb"]
    generate_report_from_list_of_dict(output_fp, "Node Information", list_of_node, header, vertical=False)


def report_battery_info(list_of_battery, output_fp):
    battery_header = ["name", "appliance_id", "slot", "lifecycle_state", "part_number", "serial_number"]
    generate_report_from_list_of_dict(output_fp, "Battery Information", list_of_battery, battery_header, vertical=False)


def report_fan_info(list_of_fan, output_fp):
    # fan's serial number is None
    fan_header = ["name", "appliance_id", "slot", "lifecycle_state", "part_number"]
    generate_report_from_list_of_dict(output_fp, "Fan Information", list_of_fan, fan_header, vertical=False)


def report_power_supply_info(list_of_power_supply, output_fp):
    power_supply_header = ["name", "appliance_id", "slot", "lifecycle_state", "part_number", "serial_number", "status_led_state"]
    generate_report_from_list_of_dict(output_fp, "PowerSupply Information", list_of_power_supply, power_supply_header, vertical=False)


def report_expansion_enclosure_info(list_of_expansion_enclosure, output_fp):
    expansion_enclosure_header = ["name", "appliance_id", "slot", "lifecycle_state", "part_number", "serial_number", "status_led_state"]
    generate_report_from_list_of_dict(output_fp, "Expansion Enclosure Information", list_of_expansion_enclosure, expansion_enclosure_header, vertical=False)


def report_lcc_info(list_of_lcc, output_fp):
    lcc_header = ["name", "appliance_id", "slot", "lifecycle_state", "part_number", "serial_number", "status_led_state"]
    generate_report_from_list_of_dict(output_fp, "LCC Information", list_of_lcc, lcc_header, vertical=False)