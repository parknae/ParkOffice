from infra.utils import TOOL_NAME, get_mgmt_data_file_path
from text_report.common import generate_report_from_list_of_dict
import os
import json
import logging

logger = logging.getLogger('.'.join([TOOL_NAME, __name__]))
# TODO: replicated policy


def report_protection_policy_info(dc_folder, output_fp):
    report_name_str = "Protection Policy Information"
    header = ["name", "snapshot-rules", "replication-rules"]
    policy_file_path = get_mgmt_data_file_path(dc_folder, 'policy.json')
    if policy_file_path:
        policy_id2name = dict()
        with open(policy_file_path, 'r') as f:
            data = json.load(f)
            for record in data['data']:
                if record["type"] == "Protection":
                    policy_id2name[record["id"]] = record["name"]

        snap_rule_id2name = dict()
        snap_rule_file_path = get_mgmt_data_file_path(dc_folder, 'snapshot_rule.json')
        if snap_rule_file_path:
            with open(snap_rule_file_path, 'r') as f:
                data = json.load(f)
                for record in data['data']:
                    snap_rule_id2name[record["id"]] = record["name"]

        replication_rule_id2name = dict()
        replication_rule_file_path = get_mgmt_data_file_path(dc_folder, 'replication_rule.json')
        if replication_rule_file_path:
            with open(replication_rule_file_path, 'r') as f:
                data = json.load(f)
                for record in data['data']:
                    replication_rule_id2name[record["id"]] = record["name"]

        policy_id_assoc_snap_rule_ids = dict()
        policy_snapshot_rule_association_file_path = get_mgmt_data_file_path(dc_folder, 'policy_snapshot_rule_association.json')
        if policy_snapshot_rule_association_file_path:
            with open(policy_snapshot_rule_association_file_path, 'r') as f:
                data = json.load(f)
                for record in data['data']:
                    policy_id_assoc_snap_rule_ids.setdefault(record['policy_id'], []).append(record['snapshot_rule_id'])

        policy_id_assoc_replication_rule_ids = dict()
        policy_replication_rule_association_file_path = get_mgmt_data_file_path(dc_folder, 'policy_replication_rule_association.json')
        if policy_replication_rule_association_file_path:
            with open(policy_replication_rule_association_file_path, 'r') as f:
                data = json.load(f)
                for record in data['data']:
                    policy_id_assoc_replication_rule_ids.setdefault(record['policy_id'], []).append(record['replication_rule_id'])

        list_of_protection_dict = list()
        for policy_id in policy_id2name.keys():
            name = policy_id2name[policy_id]
            if policy_id in policy_id_assoc_snap_rule_ids:
                snapshot_rules = ",".join([snap_rule_id2name[snap_rule_id] for snap_rule_id in policy_id_assoc_snap_rule_ids[policy_id]])
            else:
                snapshot_rules = None
            if policy_id in policy_id_assoc_replication_rule_ids:
                protection_rules = ",".join([replication_rule_id2name[replication_rule_id] for replication_rule_id in policy_id_assoc_replication_rule_ids[policy_id]])
            else:
                protection_rules = None
            list_of_protection_dict.append({"name": name, "snapshot-rules": snapshot_rules, "replication-rules": protection_rules})

        generate_report_from_list_of_dict(output_fp, report_name_str, list_of_protection_dict, header, vertical=False)


def report_snap_rule_info(dc_folder, output_fp):
    report_name_str = "Snap Rule Information"
    header = ["name", "Days", "interval", "time_of_day", "desired_retention"]
    snapshot_rule_file_path = get_mgmt_data_file_path(dc_folder, 'snapshot_rule.json')
    if snapshot_rule_file_path:
        logger.debug(snapshot_rule_file_path)
        with open(snapshot_rule_file_path, 'r') as f:
            data = json.load(f)
            logger.debug(data)
            list_of_dict = data['data']
            for i, record in enumerate(list_of_dict):
                list_of_dict[i]["Days"] = ",".join([s[0:3] for s in record["days_of_week"]])
            generate_report_from_list_of_dict(output_fp, report_name_str, list_of_dict, header, vertical=False)


def report_replication_rule_info(dc_folder, output_fp):
    report_name_str = "Replication Rule Information"
    header = ["name", "rpo", "io_priority", "remote_system_name", "remote_system_type", "remote_system_management_address"]
    remote_system_file_path = get_mgmt_data_file_path(dc_folder, 'remote_system.json')
    if remote_system_file_path:
        logger.debug(remote_system_file_path)
        remote_system_dict = dict()
        with open(remote_system_file_path, 'r') as f:
            data = json.load(f)
            logger.debug(data)
            for i, record in enumerate(data['data']):
                remote_system_dict[record['id']] = record

        replication_rule_json_file_path = get_mgmt_data_file_path(dc_folder, 'replication_rule.json')
        logger.debug(replication_rule_json_file_path)
        if replication_rule_json_file_path:
            with open(replication_rule_json_file_path, 'r') as f:
                data = json.load(f)
                logger.debug(data)
                list_of_dict = data['data']
                if list_of_dict and "io_priority" not in list_of_dict[0].keys():
                    header.remove("io_priority")
                for i, record in enumerate(list_of_dict):
                    list_of_dict[i]["remote_system_name"] = remote_system_dict[record["remote_system_id"]]["name"]
                    list_of_dict[i]["remote_system_type"] = remote_system_dict[record["remote_system_id"]]["type"]
                    list_of_dict[i]["remote_system_management_address"] = remote_system_dict[record["remote_system_id"]]["management_address"]
                generate_report_from_list_of_dict(output_fp, report_name_str, list_of_dict, header, vertical=False)