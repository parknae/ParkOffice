import os
import json
import logging
from infra.utils import TOOL_NAME, TOOL_OUTPUT_FOLDER, get_mgmt_data_file_path, handle_exceptions

logger = logging.getLogger('.'.join([TOOL_NAME, __name__]))

@handle_exceptions
def generate_audit_log(dc_folder):
    output_file_path = os.path.join(dc_folder, TOOL_OUTPUT_FOLDER, "audit.txt")
    audit_event_file_path = get_mgmt_data_file_path(dc_folder, 'audit_event.json')
    if audit_event_file_path:
        logger.debug(audit_event_file_path)
        with open(audit_event_file_path, 'r') as f:
            data = json.load(f)
            list_of_dict = data['data']
            list_of_dict.sort(key=lambda record: record['timestamp'])

        with open(output_file_path, 'w+') as f:
            for record in list_of_dict:
                record['"message_arguments'] = ",".join(record['message_arguments'])
                message =  "{timestamp} username:{username} client_address:{client_address} appliance_id:{appliance_id} message_code:{message_code} message_arguments:{message_arguments} is_successful:{is_successful} job_id:{job_id}".format(**record)
                f.write("{0}\n".format(message))
    else:
        with open(output_file_path, 'w+') as f:
            f.write("audit_event.json is not found.\n")