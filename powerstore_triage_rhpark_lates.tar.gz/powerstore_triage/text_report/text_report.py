import os
import logging
import traceback
from infra.utils import TOOL_NAME, TOOL_OUTPUT_FOLDER, handle_exceptions
from data_normalizer.hardware_info_normalizer import normalize_hardware_info
from text_report.event import generate_event_log
from text_report.alert import generate_alert_log
from text_report.audit_event import generate_audit_log
from text_report.dc_info import report_dc_info
from text_report.appliance_info import report_applaince_info
from text_report.cluster_info import report_cluster_info
from text_report.appliance_dare_status_info import report_appliance_dare_status_info
from text_report.infra_service_info import report_infra_service_info
from text_report.datapath_state_info import report_datapath_state_info
from text_report.host_info import report_host_info
from text_report.storage_container_info import report_storage_container_info
from text_report.volume_info import report_volume_info
from text_report.virtual_volume_info import report_virtual_volume_info
from text_report.nas_volume_info import report_nas_volume_info
from text_report.file_interface_info import report_file_interface_info
from text_report.policy_info import report_protection_policy_info, report_snap_rule_info, report_replication_rule_info
from text_report.fc_eth_port_info import report_fc_eth_port_info
from text_report.cyc_net_discovery_info import report_cyc_net_discovery_info
from text_report.remote_support_info import report_remote_support_info
from text_report.hardware_info import report_data_drive_info, report_m2_drive_info, \
    report_io_module_info, report_sfp_info, report_fan_info, report_dimm_info, report_power_supply_info, \
    report_base_enclosure_info, report_node_info, report_battery_info, report_expansion_enclosure_info, report_lcc_info
from text_report.local_and_remote_system_info import report_local_and_remote_system_info
from text_report.networking_info import report_network_info
from text_report.host_volume_mapping_info import report_host_volume_mapping_info
from text_report.host_virtual_volume_mapping_info import report_host_virtual_volume_mapping_info
from text_report.volume_snap_info import report_volume_snap_info
from text_report.initator_info import report_initiator_info
from text_report.nas_server_info import report_nas_server_info
from text_report.appliance_space_stats import report_applaince_space_stats_info
from text_report.snap_group_space_accounting_info import report_snapgroup_space_accounting_info
from text_report.datacollection_info import report_datacollection_info
from text_report.nvme_slot_status import report_nvme_slot_status
#----------------------------------------------------------#
# 2020 Dell Inc. and its subsidiaries. All Rights reserved #
#----------------------------------------------------------#
#---------------------------------#
# Henry.An@dell.com               #
# Engineering Technical Services  #
#---------------------------------#
# ++++++++++++++++++++++++++++++++++++++#
#         Report in text format        #
# ++++++++++++++++++++++++++++++++++++++#
logger = logging.getLogger('.'.join([TOOL_NAME, __name__]))
text_report_file_name = 'powerstore-triage_analysis.txt'


@handle_exceptions
def generate_text_report(dc_folder):
    logger.info("Exporting event, alert, audit logs...")
    generate_event_log(dc_folder)
    generate_alert_log(dc_folder)
    generate_audit_log(dc_folder)
    logger.info("Generating array configuration information...")
    with open(os.path.join(dc_folder, TOOL_OUTPUT_FOLDER, text_report_file_name), 'w+') as f:
        report_dc_info(dc_folder,f)
        report_cluster_info(dc_folder, f)
        report_applaince_info(dc_folder, f)
        report_appliance_dare_status_info(dc_folder, f)
        report_infra_service_info(dc_folder, f)
        report_datapath_state_info(dc_folder, f)
        logger.info("Please see {0} for the complete array configuration information.".format(os.path.join(dc_folder, TOOL_OUTPUT_FOLDER, text_report_file_name)))
        report_applaince_space_stats_info(dc_folder, f)
        # f.write("Tenant 5: for volumes\n\n")
        report_network_info(dc_folder, f)
        list_of_m2_drive, list_of_data_drive, list_of_io_module, list_of_sfp,\
            list_of_dimm, list_of_power_supply, list_of_fan, list_of_base_enclosure, list_of_node, \
            list_of_battery, list_of_expansion_enclosure, list_of_lcc = normalize_hardware_info(dc_folder)
        report_base_enclosure_info(list_of_base_enclosure, f)
        report_node_info(list_of_node, f)
        report_battery_info(list_of_battery, f)
        report_io_module_info(list_of_io_module, f)
        report_sfp_info(list_of_sfp, f)
        report_fc_eth_port_info(dc_folder, f)
        report_cyc_net_discovery_info(dc_folder, f)
        report_power_supply_info(list_of_power_supply, f)
        report_fan_info(list_of_fan, f)
        report_expansion_enclosure_info(list_of_expansion_enclosure, f)
        report_lcc_info(list_of_lcc, f)
        report_dimm_info(list_of_dimm, f)
        report_host_info(dc_folder, f)
        report_initiator_info(dc_folder, f)
        report_host_volume_mapping_info(dc_folder, f)
        report_host_virtual_volume_mapping_info(dc_folder, f)
        report_storage_container_info(dc_folder, f)
        report_protection_policy_info(dc_folder, f)
        report_snap_rule_info(dc_folder, f)
        report_replication_rule_info(dc_folder, f)
        report_local_and_remote_system_info(dc_folder, f)
        report_remote_support_info(dc_folder, f)
        report_virtual_volume_info(dc_folder, f)
        report_volume_info(dc_folder, f)
        report_nas_server_info(dc_folder, f)
        report_file_interface_info(dc_folder, f)
        report_nas_volume_info(dc_folder, f)
        report_snapgroup_space_accounting_info(dc_folder, f)
        f.write("Snap Group Id corresonds to the datapath_family_id\n\n")
        report_volume_snap_info(dc_folder, f)
        report_m2_drive_info(list_of_m2_drive, f)
        report_data_drive_info(list_of_data_drive, f)
        report_nvme_slot_status(dc_folder, f)
        report_datacollection_info(dc_folder, f)