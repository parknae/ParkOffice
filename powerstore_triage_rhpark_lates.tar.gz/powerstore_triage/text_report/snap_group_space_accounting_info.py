from text_report.common import generate_report_from_list_of_dict
from data_normalizer.ns_sa_snapgroups_normalizer import normalize_ns_sa_snapgroups_info

def sort_by_id(a_dict):
    return int(a_dict['Snap Group Id'])

def report_snapgroup_space_accounting_info(dc_folder, output_fp):
    header, list_of_dict = normalize_ns_sa_snapgroups_info(dc_folder)
    report_name_str = "SnapGroup Space Accounting Information"
    generate_report_from_list_of_dict(output_fp, report_name_str, list_of_dict, header, vertical=False, sort_func=sort_by_id)
