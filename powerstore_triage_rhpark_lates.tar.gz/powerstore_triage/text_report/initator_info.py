from text_report.common import generate_report_from_list_of_dict
from data_normalizer.initiator_info_normalizer import normalize_initiator_info


def sort_initiator(a_dict):
    return [a_dict['appliance_id'], a_dict['host_name_cp'], a_dict['WWN/IQN']]


def report_initiator_info(dc_folder, output_fp):
    report_name_str = "Initiator Information"
    header, initiator_list = normalize_initiator_info(dc_folder)
    generate_report_from_list_of_dict(output_fp, report_name_str, initiator_list, header, vertical=False, sort_func=sort_initiator)
