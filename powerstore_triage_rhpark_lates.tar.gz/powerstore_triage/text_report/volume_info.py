from data_normalizer.volume_info_normalizer import normalize_volume_info
from text_report.common import generate_report_from_list_of_dict


def report_volume_info(dc_folder, output_fp):
    report_name_str = "Volume Information"
    # header = ["name", "wwn", "logical_provisioned", "logical_used", "performance_rule_io_priority",
    #           "node_affinity", "type", "state", "datapath_volume_id", "protection-policy",
    #           "creation_timestamp", "appliance_id", "parent_volume", "volume_group_name", "id", "family_id"]
    header, list_of_dict = normalize_volume_info(dc_folder)
    generate_report_from_list_of_dict(output_fp, report_name_str, list_of_dict, header, vertical=False)

# cma_view
# "app_group_id", "app_group_membership_tag", "app_group_name", "app_group_protection_policy_id",
# "app_group_protection_policy_is_replica", "app_group_protection_policy_name", "appliance_id",
# "appliance_name", "appliance_serial_number", "appliance_type", "avg_latency", "copy_signature",
# "created_by_rule_id", "creation_timestamp", "creator_type", "datapath_volume_id", "description",
# "expiration_timestamp", "family_id", "id", "import_metadata", "is_importing", "is_read_only",
# "is_replication_destination", "logical_provisioned", "logical_used", "mapped_host_count",
# "migration_session_id", "migration_session_state", "name", "node_affinity", "parent_id",
# "perf_metrics_timestamp", "performance_policy_id", "performance_policy_name",
# "performance_rule_id", "performance_rule_io_priority", "performance_rule_name",
# "platform_volume_id", "protection_policy_id", "protection_policy_is_replica",
# "protection_policy_name", "replication_rule_id", "size", "snap_clone_logical_used",
# "snap_count", "snapshot_savings", "source_id", "source_timestamp", "state",
# "thin_savings", "total_bandwidth", "total_iops", "type", "unique_physical_used",
# "volume_group_id", "volume_group_membership_tag", "volume_group_name",
# "volume_group_protection_policy_id", "volume_group_protection_policy_is_replica",
# "volume_group_protection_policy_name", "wwn"
