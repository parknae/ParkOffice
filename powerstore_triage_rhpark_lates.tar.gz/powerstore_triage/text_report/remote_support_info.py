from text_report.common import generate_report_from_config_capture_file
from infra.utils import TOOL_NAME, get_tmp_file_path, get_mgmt_data_file_path
import logging

logger = logging.getLogger('.'.join([TOOL_NAME, __name__]))

def report_remote_support_info(dc_folder, output_fp):
    report_name_str = "Remote Support Information"
    header = ["type", "is_cloudiq_enabled", "policy_manager_address", "policy_manager_port",
              "proxy_address", "proxy_port", "proxy_username"]
    remote_support_file_path = get_mgmt_data_file_path(dc_folder, 'remote_support.json')
    if remote_support_file_path:
        generate_report_from_config_capture_file(dc_folder, output_fp,
                                        report_name_str, 'remote_support.json', header, vertical=True)