#!/usr/bin/env python3
############################################################################
# 
#  Copyright (C) 2019 Dell Inc. or its subsidiaries.  All Rights Reserved.
#
#  Script parses the journal log and prints out the various DepSeq sequences that have run.
#  It points out incomplete operations that may need to be looked at more closely.
# 
############################################################################

import re
from datetime import datetime
import argparse

timestamp_str = "%b %d %H:%M:%S.%f"
initial_datetime = datetime(1, 1, 1, 0, 0)
logInAscendingOrder = True 

class Seq:
    def __init__(self, seqName, timestamp, isStart):
        self.start = initial_datetime
        self.end = initial_datetime
        if isStart:
            self.start = timestamp
        else:
            self.end = timestamp
        self.seqName = seqName
        self.opList = {}
        self.success = True
        
    def getOp(self, opName):
        return self.opList.get(opName)
        
    def addOp(self, op):
        self.opList[op.opName] = op

    def addStartTime(self, startTime):
        self.start = startTime
            
    def addEndTime(self, endTime):
        self.end = endTime

    def addResult(self, result):
        self.success = result
    
    def printSeq(self):
        print('%-45s  %18s %18s' % ("Operation", "Start Time", "Duration"))
        printSeparator()
        for key, value in sorted(self.opList.items(), key=lambda t: (t[1].start,t[0])):
            if value.end > initial_datetime and value.start > initial_datetime:
                if value.success:
                    print('%-45s  %20s %18s' % (value.opName, value.start.strftime(timestamp_str), value.end - value.start))
                else:
                    print('%-45s  %20s %18s (Failed)' % (value.opName, value.start.strftime(timestamp_str), value.end - value.start))
            elif value.start > initial_datetime:
                #
                # There is a start record but no completion record for the operation
                #
                if self.end > initial_datetime:
                    #
                    # The sequence itself completed, so the operation completed but we just don't have the log
                    #
                    print('%-45s  %20s %18s*' % (value.opName, value.start.strftime(timestamp_str), "Completion trace lost"))
                else:
                    print('%-45s  %20s %18s*' % (value.opName, value.start.strftime(timestamp_str), "Did not complete"))
            elif value.end > initial_datetime:
                print('%-45s  Start not found - Ended at  %20s*' % (value.opName, value.end.strftime(timestamp_str)))
        printSeparator()
        if self.end > initial_datetime:
            if self.success:
                print('Sequence {name} started at {start} and took {delta}'.format(name=self.seqName, start=self.start.strftime(timestamp_str), delta=self.end - self.start))
            else:
                print('Sequence {name} started at {start} but failed after {delta}'.format(name=self.seqName, start=self.start.strftime(timestamp_str), delta=self.end - self.start))
        else:
            print('Sequence {name} started at {start} but did not complete'.format(name=self.seqName, start=self.start.strftime(timestamp_str)))
        printSeparator()
        print("\n")

class Op:
    def __init__(self, opName, timestamp, isStart):
        self.start = initial_datetime
        self.end = initial_datetime      
        if isStart:
            self.start = timestamp
        else:
            self.end = timestamp
        self.opName = opName
        self.success = True

    def addStartTime(self, startTime):
        self.start = startTime

    def addEndTime(self, endTime):
        self.end = endTime

    def addResult(self, result):
        self.success = result

    def printOp(self):
        print('Operation {name} started at {start} and ended at {end}'.format(name=self.opName, start=self.start.strftime(timestamp_str), end=self.end.strftime(timestamp_str)))

    def __hash__(self):
        return hash(self.opName)

def getLogOrder(logfile):
    line = logfile.readline()
    initialTimestamp = getTimestamp(line)
    ascendingOrder = True
    #
    # Logs may begin with lines that don't match the timestamp format
    # we are looking for. Skip till we can find one that matches
    for line in logfile:
        if initialTimestamp is None:
            initialTimestamp = getTimestamp(line)
        else:
            break
            
    for line in logfile:
        currentTime = getTimestamp(line)
        if currentTime is not None:
            if currentTime == initialTimestamp:
                #
                # Timestamp in the log hasn't changed, skip to the next line
                #
                continue
            elif currentTime > initialTimestamp:
                print("Log in ascending order")
                ascendingOrder = True
                break
            else:
                print("Log not in ascending order")
                ascendingOrder = False
                break
    logfile.seek(0)
    return ascendingOrder

def printSeparator():
    print("-----------------------------------------------------------------------------------------")

def checkForSeqStart(line):
    #
    # Looking for the following string to locate the start of the sequence
    #    Dependency Sequence ".*" Starting
    #
    m = re.search(r'Dependency Sequence "(?P<seq>.*)" Starting', line)
    if m is not None:
        return m.group('seq') 
    else:
        return None

def checkForSeqEnd(line):
    #
    # Looking for the following string to locate the start of the sequence
    #    CompleteOperation:615: Dependency Sequence "STARTUP" Completed (ran for 40.184672463 seconds)
    #
    m = re.search(r'Dependency Sequence "(?P<seq>.*)" (?P<result>.*) \(', line)
    if m is not None:
        if m.group('result') == 'FAILED':
            return m.group('seq'), False
        else:
            return m.group('seq'), True
    else:
        return None, None

def determineSeqFromOpName(opName):
    #
    # Looking for seqName from opName. Assumes opNames have a format of
    # "DEPSEQ_SEQNAME_XXXXXX"
    #   Example:
    #        DEPSEQ_STARTUP_COMPRESSION
    #
    m = re.search(r'DEPSEQ_(?P<seq>.*)_', opName)
    if m is not None:
        return m.group('seq')
    else:
        return None

def checkForOpStart(line):
    #
    # Looking for the following string to locate the start of the operation
    #   Example:
    #        MarkRunning:107: "STARTUP" Operation "DEPSEQ_STARTUP_COMPRESSION" is now Running (was Ready for 0.000160021)
    #
    m = re.search(r'MarkRunning:.*: "(?P<seq>.*)" Operation "(?P<op>.*)" is now Running', line)
    if m is not None:
        opName = m.group('op')
        seqName = m.group('seq')
        return seqName, opName
    else:
        return None, None

def checkForOpEnd(line):
    #
    # Looking for the following string to locate the start of the operation
    #    Example:
    #        MarkDone:135: "STARTUP" Operation "DEPSEQ_STARTUP_COMPRESSION" is now Finished (was Running for 0.000134988)
    #
    m = re.search(r'MarkDone:.*: "(?P<seq>.*)" Operation "(?P<op>.*)" is now (?P<result>.*) \(was Running', line)
    if m is not None:
        opName = m.group('op')
        seqName = m.group('seq')
        if m.group('result') == 'Failed':
            return seqName, opName, False
        else:
            return seqName, opName, True
    else:
        return None, None, None
        
def getTimestamp(line):
    #
    # Looking for the initial timestamp string. Note that if there are 2 timestamps the first one with microseconds is matched
    # Sample log:
    # Jan 04 19:44:24 FNM00175100039-A xtremapp[18319]: Jan 04 19:44:24.936533 X10 [log_id:0][2972(3011 nb_truck_6
    #
    m = re.search(r'(?P<timestamp>\w\w\w \d\d \d\d:\d\d:\d\d.\d\d\d\d\d\d)', line)
    if m is not None:
        timestamp = datetime.strptime(m.group('timestamp'), timestamp_str)
        return timestamp
    else:
#        print("Timestamp format has changed. Cannot proceed")
        return None

def main():
    
    parser = argparse.ArgumentParser(description='Parses journal logs for DepSeq events')
    parser.add_argument('logfile', help='Path to the log file', type=argparse.FileType('r'))
    args = parser.parse_args()

    seqs = {}
    logInAscendingOrder = getLogOrder(args.logfile)
    
    for line in args.logfile:
        #
        # Look for starting of a sequence. Note that we might 
        # get 2 starts before a completion in 2 cases:
        # 1. Seq 2 was started before Seq 1 was completed
        # 2. Node panicked before the sequence completed
        #
        seqName = checkForSeqStart(line)
        if seqName is not None:
            timestamp = getTimestamp(line)
            if timestamp is None:
                return
            # print seqName, "started at", timestamp.strftime(timestamp_str)
            if logInAscendingOrder:
                #
                # If the log is in ascending order, occurence of a start
                # is the first sign of the sequence and therefore we create 
                # the sequence object at that time
                #
                if seqName in seqs:
                    #
                    # This is a new instance of an already running sequence.
                    # Complete the running sequence and start a new one
                    #
                    seq = seqs.pop(seqName)
                    seq.printSeq()
                seq = Seq(seqName, timestamp, True)                        
                seqs[seqName] = seq
            else:
                #
                # If the log is not in ascending order, occurence of a start
                # is the last sign of the sequence and therefore we print and purge 
                # the sequence object
                #
                seq = seqs.pop(seqName)
                seq.addStartTime(timestamp)
                seq.printSeq()
            
            #
            # Done processing this line
            #
            continue
        #
        # Look for completion of a sequence
        #
        seqName, result = checkForSeqEnd(line)
        if seqName is not None:
            timestamp = getTimestamp(line)
            if timestamp is None:
                return
            #  print seqName, "completed at", timestamp.strftime(timestamp_str)
            if logInAscendingOrder:
                #
                # If the log is not in ascending order, occurence of a completion
                # is the last sign of the sequence and therefore we print and purge 
                # the sequence object
                #
                seq = seqs.pop(seqName)                    
                seq.addEndTime(timestamp)
                seq.addResult(result)
                seq.printSeq()
            else:
                #
                # If the log is in ascending order, occurence of a completion
                # is the first sign of the sequence and therefore we create 
                # the sequence object at that time
                #
                if seqName in seqs:
                    #
                    # This is a new instance of an already running sequence.
                    # Complete the running sequence and start a new one
                    #
                    seq = seqs.pop(seqName)
                    seq.addStartTime(timestamp)
                    seq.printSeq()
                seq = Seq(seqName, timestamp, False)
                seq.addResult(result)
                seqs[seqName] = seq
            continue
            
        if seqs:
            #
            # If sequence is not in progress, don't bother looking for operations
            #
            opSeqName, opName = checkForOpStart(line)
            if opName is not None and opSeqName is not None:
                timestamp = getTimestamp(line)
                if timestamp is None:
                    return

                if logInAscendingOrder:
                    op = Op(opName, timestamp, True)
                    seqs[opSeqName].addOp(op)
                    #                    print opName, 'started at', timestamp.strftime(timestamp_str)
                    continue
                else:
                    seqs[opSeqName].getOp(opName).addStartTime(timestamp)
                    
            opSeqName, opName, result  = checkForOpEnd(line)
            if opName is not None and opSeqName is not None:
                timestamp = getTimestamp(line)
                if timestamp is None:
                    return

                if logInAscendingOrder:
                    op = seqs[opSeqName].getOp(opName)
                    if op is None:
                        #
                        # This is the case where the log message for starting a operation is missing, but
                        # we have the log message for the completion
                        #
                        op = Op(opName, timestamp, False)
                        seqs[opSeqName].addOp(op)
                    op.addEndTime(timestamp)
                    op.addResult(result)
                else:
                    op = Op(opName, timestamp, False)                    
                    op.addResult(result)
                    seqs[opSeqName].addOp(op)
                    #                    print opName, 'completed at', timestamp.strftime(timestamp_str) 
                continue

    #
    # Handle the case where there is only one sequence in the entire log and it did not complete. 
    #
    for seqName in seqs:
        seqs[seqName].printSeq()

main()
#cyc_core/cyc_app/cyclone/tools/scripts/src/DepSeqLogParser.py