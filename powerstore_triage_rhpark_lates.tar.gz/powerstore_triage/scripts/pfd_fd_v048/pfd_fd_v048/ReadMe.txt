-------------------------------------------------------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------------------------------------------------------
                                                            Powerstore Fault Detection Tool
-------------------------------------------------------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------------------------------------------------------

Purpose
-------
Powerstore Fault Detection Tool was created for a quick initial analysis both broad and targeted covering a short time frame (1-48 hours).
Though it can be run on Data Collects, its primary benifit is on live Powerstore systems where it can quickly eliminate known issues and do a targeted
symptom based analysis and extract relivant logs/outputs to be analized while Data Collects are being uploaded.

Requirements
-------------
OS
Linux OS or Windows Subsystem for Linux (optimized for Powerstore and STG-TOOLS)

Python version
Python 2.0 and above

Python Libraries
sudo pip3 install parimiko
sudo pip3 install pickle



Usage
-----
$ python pst_fd.py --help

-------------------------------------------------------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------------------------------------------------------
                                                              Powerstore Fault Detection
-------------------------------------------------------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------------------------------------------------------

#######################################################################################################################################################

        HELP:

        -h, --help                             Displays help on Powerstore Fault Detection commands and usage.
        -s, --settings                         Displays saved configuaration settings stored in ./settings file.
        -b, --bypass                           Bypass general checks for Known Issues.
        -i, --ignore_oe                        Check all known issues, even if not applicable to OE
        -u, --upload <file_name>|dc            Upload file to registered ftp link
                                               -u <file_name>  File name or path and filename, if not in working directory. eg. -u log.txt
                                               -u dc           Selects newest Data Collect on current node, then uploads.
        -d, --download <file_name>|dc          Download file(s) from registered ftp link to current working directory
                                               -d <file_name>  File name or path and filename, if not in working directory. eg. -d log.txt
                                               -d dc           Selects newest Data Collect on ftp link, then downloads it.


        TARGETED TROUBLESHOOTING:

        --connectivity_block                   Host connectivity troubleshooting-block level.
        --connectivity_file                    Host connectivity troubleshooting-file level.
        --ndu                                  Non Disruptive Upgrade (NDU) troubleshooting.

        SETTINGS:


        --hours                                Sets the default range in hours to search journal logs.
        --save on|off                          Save PFD Analysis to text file in working directory.
        --logs on|off                          Extract associated logs with selected TARGETED TROUBLESHOOTING.
        --ftp "<ftp_link>"                     Register a Dell-EMC ftp link to upload files to. Remember to encase link in quotation marks.
        --ftp_auto on|off                      Automatically uploads logs from TARGETED TROUBLESHOOTING to registered FTP link.


#######################################################################################################################################################

Running Powerstore Fault Detection tool 
----------------------------------------

On live system
1. Put the script and IssueDB under "/home/service/user" (svc container)
2. chmod 777 pst_fd.py IssueDB (Option)
 
On Data Collect
1. Put script and IssueDB in the unpacked DC folder which has the "cyc_triage.pl" script

Run script, by default it will perform a check for known issues in previous 6 hours.
python pst_fd.py

SETTINGS: Change settings to preferred time frame, save analysis to file, extract logs and use FTP feature.
------------------------------------------------------------------------------------------------------------

Example: Change settings to check last 24 hours of logs, save analysis and extract relavant logs for troubleshooting.
python pst_fd.py --hours 24 --save on --logs on

Example: Register an ftp link in settings and enable automatic upload of extracted logs.
python pst_fd.py --ftp_auto on --ftp "https://ftp.emc.com/action/login?domain=ftp.emc.com&username=NAwCw7bwbl&password=j1jcEAE1EB"

FTP FEATURE: Allows for quick tranfer of logs helping supports time to resolve
-----------------------------------------------------------------------------

Example: Upload the most recent data collect to ftp
python pst_fd.py -u dc

Example: Download the most recent data collect from ftp
python pst_fd.py -d dc

Example: Upload specific file
python pst_fd.py -u log.txt

Example: Download specific file
python pst_fd.py -d log.txt

TARGETED TROUBLESHOOTING: Symptom based analysis and log extraction
--------------------------------------------------------------------

Example:
$ python pst_fd.py --connectivity_block
######################################################################################################################################################################################

--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
                                                                              Powerstore Fault Detection
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
                                                    NOTE: For HELP with commands run script with -h switch ie. python pst_fd.py -h

                                                                       Detected Data Collect in local directory
                                                                               Initiating OFFLINE mode
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

                                                                       Appliance Name:             spfsc02-appliance-1
                                                                       Service Tag:                FN4W163
                                                                       Model No:                   PowerStore 3000T 900-564-101
                                                                       Software Rev:               1.0.2.0.5.003
                                                                       MGMT IP:                    172.20.13.100
                                                                       Ssh Enabled:                True
                                                                       D@RE:                       Enabled
                                                                       Log range:                  48 hour(s) prior

######################################################################################################################################################################################
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
                                                                              Checking For Known Issues
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

        Searching kernel logs......

        Searching cyc_pacemaker_proxy logs......

        Searching cyc_upgrade logs......

        Searching cyc_eve logs......

        Searching xtremapp-pm logs......

        Searching xtremapp logs......

        Searching bsc-fail_handler logs......

        Searching cyc_bsc logs......

        Searching control-path logs......

        Searching panic_log logs......

        Searching dc_engine logs......

        Searching debuc_client logs......

        Searching ha_monitor_bsc logs......

        Searching cyc_puhc logs......

        Searching cyc_postgres_ha logs......

        Searching nas_preinstall logs......

        Searching cyc-cluster-master logs......

--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
                                                                              Known Issue Search Results
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------


        Match found for I/O Errors with status=0x7d1 against the cache drives. No Action is required, do we need this check? Reference: LKB#131576
             - Count for keyword "status=0x7d1" is 2897 in last 48 hour(s) of logs

        Match found for Detailed DC results in 0 GB with SUCCESS Reference: LKB#126689: TEE-404 MDT-181078
             - Count for keyword "Unable to run cmd" is 2 in last 48 hour(s) of logs


                                                                           Check for known issues Complete
######################################################################################################################################################################################

--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
                                                                           Checking Host Block Connectivity
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------


        Preparing connectivity logs and objects ......

        Searching kernel logs......

        Searching xtremapp logs......

--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
                                                                           Host Block Connectivity Results
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
                                                                                Powerstore Initiators
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

        BaseEnclosure-NodeA-fc1 fc 58:cc:f0:90:4a:60:01:31
            State = ok
        BaseEnclosure-NodeA-fc2 fc 58:cc:f0:90:4a:61:01:31
            State = ok
        BaseEnclosure-NodeA-fc3 fc 58:cc:f0:90:4a:62:01:31
            State = ok
        BaseEnclosure-NodeA-fc4 fc 58:cc:f0:90:4a:63:01:31
            State = ok
        BaseEnclosure-NodeA-iscsi1 iscsi iqn.2015-10.com.dell:dellemc-powerstore-de402203457826-a-4e6797b9
            State = ok
        BaseEnclosure-NodeA-iscsi2 iscsi iqn.2015-10.com.dell:dellemc-powerstore-de402203457826-a-0c997d92
            State = ok
        BaseEnclosure-NodeA-iscsi3 iscsi iqn.2015-10.com.dell:dellemc-powerstore-de402203457826-a-784fc148
            State = ok
        BaseEnclosure-NodeB-fc1 fc 58:cc:f0:98:4a:60:01:31
            State = ok
        BaseEnclosure-NodeB-fc2 fc 58:cc:f0:98:4a:61:01:31
            State = ok
        BaseEnclosure-NodeB-fc3 fc 58:cc:f0:98:4a:62:01:31
            State = ok
        BaseEnclosure-NodeB-fc4 fc 58:cc:f0:98:4a:63:01:31
            State = ok
        BaseEnclosure-NodeB-iscsi1 iscsi iqn.2015-10.com.dell:dellemc-powerstore-de402203457826-b-5a75eab6
            State = ok
        BaseEnclosure-NodeB-iscsi2 iscsi iqn.2015-10.com.dell:dellemc-powerstore-de402203457826-b-282ae47d
            State = ok
        BaseEnclosure-NodeB-iscsi3 iscsi iqn.2015-10.com.dell:dellemc-powerstore-de402203457826-b-1dd62959
            State = ok

--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
                                                                                   Host Initiators
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------


        HOST:OAALNX34   OS:Linux   HOST_GROUP:N/A

        A2:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        A4:fc    ----------------------------------------------------LoggedIn:Yes |__________Type:fc   PathCount:4   State:ok
                                                                                  |          Initiator: 10:00:00:10:9b:8c:24:4f
        B2:fc    ----------------------------------------------------LoggedIn:Yes |          Check Condition:06/29/00 [2]
                                                                                  |
        B4:fc    ----------------------------------------------------LoggedIn:Yes |

        A1:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        A3:fc    ----------------------------------------------------LoggedIn:Yes |__________Type:fc   PathCount:4   State:ok
                                                                                  |          Initiator: 10:00:00:10:9b:8c:24:4e
        B1:fc    ----------------------------------------------------LoggedIn:Yes |          Aborts/Timeouts: [2]   Check Condition:06/29/00 [2]
                                                                                  |
        B3:fc    ----------------------------------------------------LoggedIn:Yes |


        HOST:OAALNX35   OS:Linux   HOST_GROUP:N/A

        A2:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        A4:fc    ----------------------------------------------------LoggedIn:Yes |__________Type:fc   PathCount:4   State:ok
                                                                                  |          Initiator: 10:00:00:10:9b:95:30:be
        B2:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        B4:fc    ----------------------------------------------------LoggedIn:Yes |

        A1:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        A3:fc    ----------------------------------------------------LoggedIn:Yes |__________Type:fc   PathCount:4   State:ok
                                                                                  |          Initiator: 10:00:00:10:9b:95:30:bd
        B1:fc    ----------------------------------------------------LoggedIn:Yes |          Aborts/Timeouts: [5]
                                                                                  |
        B3:fc    ----------------------------------------------------LoggedIn:Yes |


        HOST:OAALNX36   OS:Linux   HOST_GROUP:N/A

        A2:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        A4:fc    ----------------------------------------------------LoggedIn:Yes |__________Type:fc   PathCount:4   State:ok
                                                                                  |          Initiator: 10:00:00:10:9b:95:30:fa
        B2:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        B4:fc    ----------------------------------------------------LoggedIn:Yes |

        A1:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        A3:fc    ----------------------------------------------------LoggedIn:Yes |__________Type:fc   PathCount:4   State:ok
                                                                                  |          Initiator: 10:00:00:10:9b:95:30:f9
        B1:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        B3:fc    ----------------------------------------------------LoggedIn:Yes |


        HOST:OAALNX37   OS:Linux   HOST_GROUP:N/A

        A2:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        A4:fc    ----------------------------------------------------LoggedIn:Yes |__________Type:fc   PathCount:4   State:ok
                                                                                  |          Initiator: 10:00:00:10:9b:95:30:f7
        B2:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        B4:fc    ----------------------------------------------------LoggedIn:Yes |

        A1:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        A3:fc    ----------------------------------------------------LoggedIn:Yes |__________Type:fc   PathCount:4   State:ok
                                                                                  |          Initiator: 10:00:00:10:9b:95:30:f6
        B1:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        B3:fc    ----------------------------------------------------LoggedIn:Yes |


        HOST:OAALNX38   OS:Linux   HOST_GROUP:N/A

        A2:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        A4:fc    ----------------------------------------------------LoggedIn:Yes |__________Type:fc   PathCount:4   State:ok
                                                                                  |          Initiator: 10:00:00:10:9b:95:30:ac
        B2:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        B4:fc    ----------------------------------------------------LoggedIn:Yes |

        A1:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        A3:fc    ----------------------------------------------------LoggedIn:Yes |__________Type:fc   PathCount:4   State:ok
                                                                                  |          Initiator: 10:00:00:10:9b:95:30:ab
        B1:fc    ----------------------------------------------------LoggedIn:Yes |          Aborts/Timeouts: [14]
                                                                                  |
        B3:fc    --- Aborts/Timeouts:[2]-----------------------------LoggedIn:Yes |


        HOST:OAALNX39   OS:Linux   HOST_GROUP:N/A

        A2:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        A4:fc    ----------------------------------------------------LoggedIn:Yes |__________Type:fc   PathCount:4   State:ok
                                                                                  |          Initiator: 10:00:00:10:9b:95:32:34
        B2:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        B4:fc    ----------------------------------------------------LoggedIn:Yes |

        A1:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        A3:fc    ----------------------------------------------------LoggedIn:Yes |__________Type:fc   PathCount:4   State:ok
                                                                                  |          Initiator: 10:00:00:10:9b:95:32:33
        B1:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        B3:fc    ----------------------------------------------------LoggedIn:Yes |


        HOST:OAALNX40   OS:Linux   HOST_GROUP:N/A

        A2:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        A4:fc    ----------------------------------------------------LoggedIn:Yes |__________Type:fc   PathCount:4   State:ok
                                                                                  |          Initiator: 10:00:00:10:9b:95:2b:76
        B2:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        B4:fc    ----------------------------------------------------LoggedIn:Yes |

        A1:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        A3:fc    ----------------------------------------------------LoggedIn:Yes |__________Type:fc   PathCount:4   State:ok
                                                                                  |          Initiator: 10:00:00:10:9b:95:2b:75
        B1:fc    ----------------------------------------------------LoggedIn:Yes |          Aborts/Timeouts: [33]   Check Condition:06/29/00 [1]
                                                                                  |
        B3:fc    --- Aborts/Timeouts:[4]-----------------------------LoggedIn:Yes |


        HOST:OAALNX41   OS:Linux   HOST_GROUP:N/A

        A1:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        A3:fc    ----------------------------------------------------LoggedIn:Yes |__________Type:fc   PathCount:4   State:ok
                                                                                  |          Initiator: 10:00:00:10:9b:95:33:c9
        B1:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        B3:fc    ----------------------------------------------------LoggedIn:Yes |

        A2:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        A4:fc    ----------------------------------------------------LoggedIn:Yes |__________Type:fc   PathCount:4   State:ok
                                                                                  |          Initiator: 10:00:00:10:9b:95:33:ca
        B2:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        B4:fc    ----------------------------------------------------LoggedIn:Yes |


        HOST:OAALNX42   OS:Linux   HOST_GROUP:N/A

        A2:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        A4:fc    ----------------------------------------------------LoggedIn:Yes |__________Type:fc   PathCount:4   State:ok
                                                                                  |          Initiator: 10:00:00:10:9b:8f:52:7f
        B2:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        B4:fc    ----------------------------------------------------LoggedIn:Yes |

        A1:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        A3:fc    ----------------------------------------------------LoggedIn:Yes |__________Type:fc   PathCount:4   State:ok
                                                                                  |          Initiator: 10:00:00:10:9b:8f:52:7e
        B1:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        B3:fc    ----------------------------------------------------LoggedIn:Yes |


        HOST:OAALNX43   OS:Linux   HOST_GROUP:N/A

        A1:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        A3:fc    ----------------------------------------------------LoggedIn:Yes |__________Type:fc   PathCount:4   State:ok
                                                                                  |          Initiator: 10:00:00:10:9b:95:30:cf
        B1:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        B3:fc    ----------------------------------------------------LoggedIn:Yes |

        A2:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        A4:fc    ----------------------------------------------------LoggedIn:Yes |__________Type:fc   PathCount:4   State:ok
                                                                                  |          Initiator: 10:00:00:10:9b:95:30:d0
        B2:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        B4:fc    ----------------------------------------------------LoggedIn:Yes |


        HOST:OAALNX44   OS:Linux   HOST_GROUP:N/A

        A1:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        A3:fc    ----------------------------------------------------LoggedIn:Yes |__________Type:fc   PathCount:4   State:ok
                                                                                  |          Initiator: 10:00:00:10:9b:95:72:15
        B1:fc    ----------------------------------------------------LoggedIn:Yes |          Aborts/Timeouts: [6]   Check Condition:06/29/00 [3]
                                                                                  |
        B3:fc    ----------------------------------------------------LoggedIn:Yes |

        A2:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        A4:fc    ----------------------------------------------------LoggedIn:Yes |__________Type:fc   PathCount:4   State:ok
                                                                                  |          Initiator: 10:00:00:10:9b:95:72:16
        B2:fc    ----------------------------------------------------LoggedIn:Yes |          Check Condition:06/29/00 [4]
                                                                                  |
        B4:fc    ----------------------------------------------------LoggedIn:Yes |


        HOST:OAALNX45   OS:Linux   HOST_GROUP:N/A

        A2:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        A4:fc    ----------------------------------------------------LoggedIn:Yes |__________Type:fc   PathCount:4   State:ok
                                                                                  |          Initiator: 10:00:00:10:9b:95:71:a0
        B2:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        B4:fc    ----------------------------------------------------LoggedIn:Yes |

        A1:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        A3:fc    ----------------------------------------------------LoggedIn:Yes |__________Type:fc   PathCount:4   State:ok
                                                                                  |          Initiator: 10:00:00:10:9b:95:71:9f
        B1:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        B3:fc    ----------------------------------------------------LoggedIn:Yes |


        HOST:OAALNX46   OS:Linux   HOST_GROUP:N/A

        A1:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        A3:fc    ----------------------------------------------------LoggedIn:Yes |__________Type:fc   PathCount:4   State:ok
                                                                                  |          Initiator: 10:00:00:10:9b:95:70:9f
        B1:fc    ----------------------------------------------------LoggedIn:Yes |          Aborts/Timeouts: [17]   Check Condition:06/29/00 [2]
                                                                                  |
        B3:fc    --- Aborts/Timeouts:[1]-----------------------------LoggedIn:Yes |

        A2:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        A4:fc    ----------------------------------------------------LoggedIn:Yes |__________Type:fc   PathCount:4   State:ok
                                                                                  |          Initiator: 10:00:00:10:9b:95:70:a0
        B2:fc    ----------------------------------------------------LoggedIn:Yes |          Check Condition:06/29/00 [3]
                                                                                  |
        B4:fc    ----------------------------------------------------LoggedIn:Yes |


        HOST:OAALNX47   OS:Linux   HOST_GROUP:N/A

        A2:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        A4:fc    ----------------------------------------------------LoggedIn:Yes |__________Type:fc   PathCount:4   State:ok
                                                                                  |          Initiator: 10:00:00:10:9b:95:70:5b
        B2:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        B4:fc    ----------------------------------------------------LoggedIn:Yes |

        A1:fc    ----- Disconnects:[7]-------------------------------LoggedIn:Yes |
                                                                                  |
        A3:fc    ----------------------------------------------------LoggedIn:Yes |__________Type:fc   PathCount:4   State:ok
                                                                                  |          Initiator: 10:00:00:10:9b:95:70:5a
        B1:fc    ----- Disconnects:[7]-------------------------------LoggedIn:Yes |          Check Condition:06/29/00 [13]
                                                                                  |
        B3:fc    ----------------------------------------------------LoggedIn:Yes |


        HOST:OAALNX48   OS:Linux   HOST_GROUP:N/A

        A2:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        A4:fc    ----------------------------------------------------LoggedIn:Yes |__________Type:fc   PathCount:4   State:ok
                                                                                  |          Initiator: 10:00:00:10:9b:95:70:43
        B2:fc    ----------------------------------------------------LoggedIn:Yes |          Check Condition:06/2a/09 [4]
                                                                                  |
        B4:fc    ----------------------------------------------------LoggedIn:Yes |

        A1:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        A3:fc    ----------------------------------------------------LoggedIn:Yes |__________Type:fc   PathCount:4   State:ok
                                                                                  |          Initiator: 10:00:00:10:9b:95:70:42
        B1:fc    ----------------------------------------------------LoggedIn:Yes |          Check Condition:06/2a/09 [4]
                                                                                  |
        B3:fc    ----------------------------------------------------LoggedIn:Yes |


        HOST:OAALNX11   OS:Linux   HOST_GROUP:N/A

        A2:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        A4:fc    ----------------------------------------------------LoggedIn:Yes |__________Type:fc   PathCount:4   State:ok
                                                                                  |          Initiator: 21:00:34:80:0d:72:e5:d1
        B2:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        B4:fc    ----------------------------------------------------LoggedIn:Yes |

        A1:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        A3:fc    ----------------------------------------------------LoggedIn:Yes |__________Type:fc   PathCount:4   State:ok
                                                                                  |          Initiator: 21:00:34:80:0d:72:e5:d0
        B1:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        B3:fc    ----------------------------------------------------LoggedIn:Yes |


        HOST:OAALNX12   OS:Linux   HOST_GROUP:N/A

        A1:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        A3:fc    ----------------------------------------------------LoggedIn:Yes |__________Type:fc   PathCount:4   State:ok
                                                                                  |          Initiator: 21:00:34:80:0d:72:e4:94
        B1:fc    --- Aborts/Timeouts:[1]-----------------------------LoggedIn:Yes |          Aborts/Timeouts: [4]
                                                                                  |
        B3:fc    --- Aborts/Timeouts:[3]-----------------------------LoggedIn:Yes |

        A2:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        A4:fc    ----------------------------------------------------LoggedIn:Yes |__________Type:fc   PathCount:4   State:ok
                                                                                  |          Initiator: 21:00:34:80:0d:72:e4:95
        B2:fc    ----------------------------------------------------LoggedIn:Yes |          Aborts/Timeouts: [1]
                                                                                  |
        B4:fc    --- Aborts/Timeouts:[1]-----------------------------LoggedIn:Yes |


        HOST:OAALNX15   OS:Linux   HOST_GROUP:N/A

        A2:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        A4:fc    ----------------------------------------------------LoggedIn:Yes |__________Type:fc   PathCount:4   State:ok
                                                                                  |          Initiator: 21:00:34:80:0d:72:e5:cb
        B2:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        B4:fc    ----------------------------------------------------LoggedIn:Yes |

        A1:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        A3:fc    ----------------------------------------------------LoggedIn:Yes |__________Type:fc   PathCount:4   State:ok
                                                                                  |          Initiator: 21:00:34:80:0d:72:e5:ca
        B1:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        B3:fc    ----------------------------------------------------LoggedIn:Yes |


        HOST:OAALNX16   OS:Linux   HOST_GROUP:N/A

        A1:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        A3:fc    ----------------------------------------------------LoggedIn:Yes |__________Type:fc   PathCount:4   State:ok
                                                                                  |          Initiator: 21:00:34:80:0d:72:e5:80
        B1:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        B3:fc    ----------------------------------------------------LoggedIn:Yes |

        A2:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        A4:fc    ----------------------------------------------------LoggedIn:Yes |__________Type:fc   PathCount:4   State:ok
                                                                                  |          Initiator: 21:00:34:80:0d:72:e5:81
        B2:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        B4:fc    ----------------------------------------------------LoggedIn:Yes |


        HOST:OAALNX17   OS:Linux   HOST_GROUP:N/A

        A2:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        A4:fc    ----------------------------------------------------LoggedIn:Yes |__________Type:fc   PathCount:4   State:ok
                                                                                  |          Initiator: 21:00:34:80:0d:72:e5:fb
        B2:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        B4:fc    ----------------------------------------------------LoggedIn:Yes |

        A1:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        A3:fc    ----------------------------------------------------LoggedIn:Yes |__________Type:fc   PathCount:4   State:ok
                                                                                  |          Initiator: 21:00:34:80:0d:72:e5:fa
        B1:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        B3:fc    ----------------------------------------------------LoggedIn:Yes |


        HOST:OAALNX18   OS:Linux   HOST_GROUP:N/A

        A1:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        A3:fc    ----------------------------------------------------LoggedIn:Yes |__________Type:fc   PathCount:4   State:ok
                                                                                  |          Initiator: 21:00:34:80:0d:72:e6:d8
        B1:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        B3:fc    ----------------------------------------------------LoggedIn:Yes |

        A2:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        A4:fc    ----------------------------------------------------LoggedIn:Yes |__________Type:fc   PathCount:4   State:ok
                                                                                  |          Initiator: 21:00:34:80:0d:72:e6:d9
        B2:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        B4:fc    ----------------------------------------------------LoggedIn:Yes |


        HOST:OAALNX13   OS:Linux   HOST_GROUP:N/A

        A1:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        A3:fc    ----------------------------------------------------LoggedIn:Yes |__________Type:fc   PathCount:4   State:ok
                                                                                  |          Initiator: 21:00:34:80:0d:72:e4:b0
        B1:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        B3:fc    ----------------------------------------------------LoggedIn:Yes |

        A2:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        A4:fc    ----------------------------------------------------LoggedIn:Yes |__________Type:fc   PathCount:4   State:ok
                                                                                  |          Initiator: 21:00:34:80:0d:72:e4:b1
        B2:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        B4:fc    ----------------------------------------------------LoggedIn:Yes |


        HOST:OAALNX14   OS:Linux   HOST_GROUP:N/A

        A2:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        A4:fc    ----------------------------------------------------LoggedIn:Yes |__________Type:fc   PathCount:4   State:ok
                                                                                  |          Initiator: 21:00:34:80:0d:72:e4:99
        B2:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        B4:fc    ----------------------------------------------------LoggedIn:Yes |

        A1:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        A3:fc    ----------------------------------------------------LoggedIn:Yes |__________Type:fc   PathCount:4   State:ok
                                                                                  |          Initiator: 21:00:34:80:0d:72:e4:98
        B1:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        B3:fc    ----------------------------------------------------LoggedIn:Yes |


        HOST:OAALNX19   OS:Linux   HOST_GROUP:N/A

        A1:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        A3:fc    ----------------------------------------------------LoggedIn:Yes |__________Type:fc   PathCount:4   State:ok
                                                                                  |          Initiator: 21:00:34:80:0d:72:e5:c4
        B1:fc    ----------------------------------------------------LoggedIn:Yes |          Aborts/Timeouts: [15]
                                                                                  |
        B3:fc    --- Aborts/Timeouts:[1]-----------------------------LoggedIn:Yes |

        A2:fc    --- Aborts/Timeouts:[1]-----------------------------LoggedIn:Yes |
                                                                                  |
        A4:fc    ----------------------------------------------------LoggedIn:Yes |__________Type:fc   PathCount:4   State:ok
                                                                                  |          Initiator: 21:00:34:80:0d:72:e5:c5
        B2:fc    ----------------------------------------------------LoggedIn:Yes |          Aborts/Timeouts: [10]
                                                                                  |
        B4:fc    --- Aborts/Timeouts:[1]-----------------------------LoggedIn:Yes |


        HOST:OAALNX21   OS:Linux   HOST_GROUP:N/A

        A1:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        A3:fc    ----------------------------------------------------LoggedIn:Yes |__________Type:fc   PathCount:4   State:ok
                                                                                  |          Initiator: 21:00:34:80:0d:72:e4:a0
        B1:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        B3:fc    ----------------------------------------------------LoggedIn:Yes |

        A2:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        A4:fc    ----------------------------------------------------LoggedIn:Yes |__________Type:fc   PathCount:4   State:ok
                                                                                  |          Initiator: 21:00:34:80:0d:72:e4:a1
        B2:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        B4:fc    ----------------------------------------------------LoggedIn:Yes |


        HOST:OAALNX22   OS:Linux   HOST_GROUP:N/A

        A1:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        A3:fc    ----------------------------------------------------LoggedIn:Yes |__________Type:fc   PathCount:4   State:ok
                                                                                  |          Initiator: 10:00:00:10:9b:a9:d8:09
        B1:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        B3:fc    ----------------------------------------------------LoggedIn:Yes |

        A2:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        A4:fc    ----------------------------------------------------LoggedIn:Yes |__________Type:fc   PathCount:4   State:ok
                                                                                  |          Initiator: 10:00:00:10:9b:a9:d8:0a
        B2:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        B4:fc    ----------------------------------------------------LoggedIn:Yes |


        HOST:OAALNX23   OS:Linux   HOST_GROUP:N/A

        A1:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        A3:fc    ----------------------------------------------------LoggedIn:Yes |__________Type:fc   PathCount:4   State:ok
                                                                                  |          Initiator: 10:00:00:10:9b:a9:d9:4e
        B1:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        B3:fc    ----------------------------------------------------LoggedIn:Yes |

        A2:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        A4:fc    ----------------------------------------------------LoggedIn:Yes |__________Type:fc   PathCount:4   State:ok
                                                                                  |          Initiator: 10:00:00:10:9b:a9:d9:4f
        B2:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        B4:fc    ----------------------------------------------------LoggedIn:Yes |


        HOST:OAALNX24   OS:Linux   HOST_GROUP:N/A

        A2:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        A4:fc    ----------------------------------------------------LoggedIn:Yes |__________Type:fc   PathCount:4   State:ok
                                                                                  |          Initiator: 10:00:00:10:9b:a9:d9:9d
        B2:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        B4:fc    ----------------------------------------------------LoggedIn:Yes |

        A1:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        A3:fc    ----------------------------------------------------LoggedIn:Yes |__________Type:fc   PathCount:4   State:ok
                                                                                  |          Initiator: 10:00:00:10:9b:a9:d9:9c
        B1:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        B3:fc    ----------------------------------------------------LoggedIn:Yes |


        HOST:OAALNX25   OS:Linux   HOST_GROUP:N/A

        A2:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        A4:fc    ----------------------------------------------------LoggedIn:Yes |__________Type:fc   PathCount:4   State:ok
                                                                                  |          Initiator: 10:00:00:10:9b:a9:d9:55
        B2:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        B4:fc    ----------------------------------------------------LoggedIn:Yes |

        A1:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        A3:fc    ----------------------------------------------------LoggedIn:Yes |__________Type:fc   PathCount:4   State:ok
                                                                                  |          Initiator: 10:00:00:10:9b:a9:d9:54
        B1:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        B3:fc    ----------------------------------------------------LoggedIn:Yes |


        HOST:OAALNX26   OS:Linux   HOST_GROUP:N/A

        A1:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        A3:fc    ----------------------------------------------------LoggedIn:Yes |__________Type:fc   PathCount:4   State:ok
                                                                                  |          Initiator: 10:00:00:10:9b:a9:d9:57
        B1:fc    ----------------------------------------------------LoggedIn:Yes |          Aborts/Timeouts: [1]
                                                                                  |
        B3:fc    ----------------------------------------------------LoggedIn:Yes |

        A2:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        A4:fc    ----------------------------------------------------LoggedIn:Yes |__________Type:fc   PathCount:4   State:ok
                                                                                  |          Initiator: 10:00:00:10:9b:a9:d9:58
        B2:fc    ----------------------------------------------------LoggedIn:Yes |          Aborts/Timeouts: [1]
                                                                                  |
        B4:fc    ----------------------------------------------------LoggedIn:Yes |


        HOST:OAALNX27   OS:Linux   HOST_GROUP:N/A

        A2:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        A4:fc    ----------------------------------------------------LoggedIn:Yes |__________Type:fc   PathCount:4   State:ok
                                                                                  |          Initiator: 10:00:00:10:9b:a9:d9:67
        B2:fc    ----------------------------------------------------LoggedIn:Yes |          Aborts/Timeouts: [2]
                                                                                  |
        B4:fc    ----------------------------------------------------LoggedIn:Yes |

        A1:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        A3:fc    ----------------------------------------------------LoggedIn:Yes |__________Type:fc   PathCount:4   State:ok
                                                                                  |          Initiator: 10:00:00:10:9b:a9:d9:66
        B1:fc    ----------------------------------------------------LoggedIn:Yes |          Aborts/Timeouts: [3]
                                                                                  |
        B3:fc    ----------------------------------------------------LoggedIn:Yes |


        HOST:OAALNX28   OS:Linux   HOST_GROUP:N/A

        A2:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        A4:fc    ----------------------------------------------------LoggedIn:Yes |__________Type:fc   PathCount:4   State:ok
                                                                                  |          Initiator: 10:00:00:10:9b:a9:d9:22
        B2:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        B4:fc    ----------------------------------------------------LoggedIn:Yes |

        A1:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        A3:fc    ----------------------------------------------------LoggedIn:Yes |__________Type:fc   PathCount:4   State:ok
                                                                                  |          Initiator: 10:00:00:10:9b:a9:d9:21
        B1:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        B3:fc    ----------------------------------------------------LoggedIn:Yes |


        HOST:OAALNX29   OS:Linux   HOST_GROUP:N/A

        A2:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        A4:fc    ----------------------------------------------------LoggedIn:Yes |__________Type:fc   PathCount:4   State:ok
                                                                                  |          Initiator: 10:00:00:10:9b:a9:d9:a0
        B2:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        B4:fc    ----------------------------------------------------LoggedIn:Yes |

        A1:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        A3:fc    ----------------------------------------------------LoggedIn:Yes |__________Type:fc   PathCount:4   State:ok
                                                                                  |          Initiator: 10:00:00:10:9b:a9:d9:9f
        B1:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        B3:fc    ----------------------------------------------------LoggedIn:Yes |


        HOST:OAALNX30   OS:Linux   HOST_GROUP:N/A

        A1:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        A3:fc    ----------------------------------------------------LoggedIn:Yes |__________Type:fc   PathCount:4   State:ok
                                                                                  |          Initiator: 10:00:00:10:9b:a9:d9:8d
        B1:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        B3:fc    ----------------------------------------------------LoggedIn:Yes |

        A2:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        A4:fc    ----------------------------------------------------LoggedIn:Yes |__________Type:fc   PathCount:4   State:ok
                                                                                  |          Initiator: 10:00:00:10:9b:a9:d9:8e
        B2:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        B4:fc    ----------------------------------------------------LoggedIn:Yes |


        HOST:OAALNX31   OS:Linux   HOST_GROUP:N/A

        A1:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        A3:fc    ----------------------------------------------------LoggedIn:Yes |__________Type:fc   PathCount:4   State:ok
                                                                                  |          Initiator: 10:00:00:10:9b:a9:d8:f0
        B1:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        B3:fc    ----------------------------------------------------LoggedIn:Yes |

        A2:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        A4:fc    ----------------------------------------------------LoggedIn:Yes |__________Type:fc   PathCount:4   State:ok
                                                                                  |          Initiator: 10:00:00:10:9b:a9:d8:f1
        B2:fc    --- Aborts/Timeouts:[1]-----------------------------LoggedIn:Yes |          Aborts/Timeouts: [1]
                                                                                  |
        B4:fc    ----------------------------------------------------LoggedIn:Yes |


        HOST:OAALNX32   OS:Linux   HOST_GROUP:N/A

        A1:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        A3:fc    ----------------------------------------------------LoggedIn:Yes |__________Type:fc   PathCount:4   State:ok
                                                                                  |          Initiator: 10:00:00:10:9b:a9:d9:93
        B1:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        B3:fc    ----------------------------------------------------LoggedIn:Yes |

        A2:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        A4:fc    ----------------------------------------------------LoggedIn:Yes |__________Type:fc   PathCount:4   State:ok
                                                                                  |          Initiator: 10:00:00:10:9b:a9:d9:94
        B2:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        B4:fc    ----------------------------------------------------LoggedIn:Yes |


        HOST:OAALNX33   OS:Linux   HOST_GROUP:N/A

        A2:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        A4:fc    ----------------------------------------------------LoggedIn:Yes |__________Type:fc   PathCount:4   State:ok
                                                                                  |          Initiator: 21:00:34:80:0d:72:e6:d5
        B2:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        B4:fc    ----------------------------------------------------LoggedIn:Yes |

        A1:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        A3:fc    ----------------------------------------------------LoggedIn:Yes |__________Type:fc   PathCount:4   State:ok
                                                                                  |          Initiator: 21:00:34:80:0d:72:e6:d4
        B1:fc    ----------------------------------------------------LoggedIn:Yes |
                                                                                  |
        B3:fc    ----------------------------------------------------LoggedIn:Yes |


######################################################################################################################################################################################

--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
                                                                             Powerstore Analysis Complete
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

                                                                                  Finalizing logs
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------


        Analysis report: powerstore_defect_diagnose_report_2021-05-15-23-58-58.txt

        Moving analysis report to archive.

        Extracting logs and moving to archive

        Analysis Report and extracted logs: pfd_export_2021-05-15-23-58-58.tar


######################################################################################################################################################################################

--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
                                                                      Powerstore Fault Detection Script Complete
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
