#!/usr/bin/env python
# -*- coding: utf-8 -*-
#! python2
#POWERSTORE FAULT DETECTION #BRANCHED VERSION 0.0.48

################################################################################################################################
# COMMAND HELP
# For command usage run "python pst_fd.py -h"
################################################################################################################################

################################################################################################################################
# ANALYSING DATACOLLECTS:
#
# 1. Put script and IssueDB in the unpacked DC folder which has the "cyc_triage.pl" script
#
################################################################################################################################

################################################################################################################################
# ANALYSING LIVE POWERSTORE
#
# 1. Put the scirpt and IssueDB under "/home/service/user" (svc container)
#
# 2. chmod 777 pst_fd.py IssueDB (Option)
#
################################################################################################################################

################################################################################################################################
# RUNNING POWERSTORE FAULT DETECTION TOOL
#
# 1. Run the command "python pst_fd.py".
#
# 2. Run "python pst_fd.py -h" to see usage and advanced options
#
################################################################################################################################

import subprocess
import sys
import re
import os
import io
import time
import csv
import json
import datetime
import base64
import select
import collections
import math
import shutil
import tarfile
import zipfile
import pickle
import operator
import stat
import codecs
from functools import reduce
from optparse import OptionParser
from optparse import OptionGroup
from distutils.version import LooseVersion, StrictVersion

version = "0.0.48"
vermagic = "d2dldCBmdHA6Ly9ZSUJ3dFV5Vnk6QjczeEwzN3N4N0BmdHAuZW1jLmNvbS92ZXJzaW9uLm51bQ=="
pfdmagic = "d2dldCBmdHA6Ly9ZSUJ3dFV5Vnk6QjczeEwzN3N4N0BmdHAuZW1jLmNvbS8="

################################################################################################################################
# PRINT_MODULE: print_pres dual_print
################################################################################################################################


class dual_print_formatter:
  def __init__(self):
    global settings
    self.write = False
    self.terminal_width=settings_term_check()
    self.layout = composition()
    self.col = bcolors()
    self.grid_conf={}
    self.groups={}
    self.seg ={}
    self.seq=[]
    self.alt_grid_conf={}
    self.alt_groups={}
    self.alt_seg ={}
    self.alt_seq=[]
    self.alt_string={'on':{'grid_conf':'alt_grid_conf', 'groups':'alt_groups','seg':'alt_seg','seq':'alt_seq'},
              'off':{'grid_conf':'grid_conf', 'groups':'groups','seg':'seg','seq':'seq'}
              }

  def   dp(self, *text):
           dp_text=[]
           for i in range(len(text)):
                      dp_text.append(text[i])
           if len(dp_text)==1:
              dp_text.append(self.col.DEFAULT+str(dp_text[0])+self.col.ENDC)
           dp_text=self.layout.compose(dp_text, self.terminal_width)
           self.dp_print(dp_text)

  def   dp_print(self, text):
           print(text[len(text)-1])
           if g.settings['save_analysis'] and self.write:
               line = text[0]+'\n'
               f.write(line)

  def   dp_n_break(self, text):
           self.dp(text)
           self.dp('  ')

  def   dp_break(self):
           self.dp('  ')

  def   dp_line(self, text):
           text=(text[0]*(self.terminal_width))
           dp_text = self.dp_format(text)
           self.dp_print(dp_text)

  def   dp_subtitle(self, text):
           self.col.DEFAULT='\33[94m'
           self.dp_line('-')
           dp_text=self.layout.center([text,self.col.BOLD+text+self.col.ENDC])
           self.dp_print(dp_text)
           self.dp_line('-')
           self.col.DEFAULT='\33[97m'

  def   dp_title(self, text):
           self.col.DEFAULT='\33[94m'
           self.dp_line('=')
           dp_text=self.layout.center([text,self.col.BOLD+text+self.col.ENDC]) #'\33[97m'+
           self.dp_print(dp_text)
           self.dp_line('=')
           self.col.DEFAULT='\33[97m'

  def   dp_get_outer_grid(self, grid_body, border='border_title', title=''):
          max_length=len(max(grid_body, key=len))
          outer_grid = {'none':[self.layout.border_top_left,self.layout.border_row,self.layout.border_top_right],
                        'border_title':[self.layout.border_top_left+self.layout.border_row+self.layout.border_row*max_length+self.layout.border_top_right,
                                  self.layout.border_column+' '+title+' '*(max_length-len(title))+self.layout.border_column,
                                  self.layout.border_left_divider+self.layout.border_row+self.layout.border_row*max_length+self.layout.border_right_divider],
                        'line_title':[self.layout.border_top_left+self.layout.border_row+title+(self.layout.border_row*(max_length-len(title)))+self.layout.border_top_right],
                        'footer':self.layout.border_bottom_left+self.layout.border_row+self.layout.border_row*max_length+self.layout.border_bottom_right}

          header_footer=outer_grid[border]
          for g_line in grid_body:
              g_line=self.layout.border_column+' '+g_line+(' '*(max_length-len(g_line)))+self.layout.border_column
              header_footer.append(g_line)
          header_footer.append(outer_grid['footer'])
          return header_footer


  def   dp_get_header(self, grid_body, title,border_style,type):

           max_length=len(max(grid_body, key=len))
           title='  '+title+' '
           header_footer =[]

           outer_grid = {'none':[self.layout.border_top_left,self.layout.border_row,self.layout.border_top_right],
                        'single':[self.layout.border_top_left+self.layout.border_row+self.layout.border_row*max_length+self.layout.border_top_right,
                                  self.layout.border_column+' '+title+' '*(max_length-len(title))+self.layout.border_column,
                                  self.layout.border_left_divider+self.layout.border_row+self.layout.border_row*max_length+self.layout.border_right_divider],
                        'footer':self.layout.border_bottom_left+self.layout.border_row+self.layout.border_row*max_length+self.layout.border_bottom_right}
           if border_style =='outer_grid':
                            header_footer=outer_grid[type]
                            for g_line in grid_body:
                                g_line=self.layout.border_column+' '+g_line+(' '*(max_length-len(g_line)))+self.layout.border_column
                                header_footer.append(g_line)
                            header_footer.append(outer_grid['footer'])

           return header_footer

  def   dp_format(self, text):
           return [text,self.col.BOLD+self.col.DEFAULT+text+self.col.ENDC]


  def   dp_grid_post(self, text):
           print('PRINTING   '+text)

  def   dp_grid_ad(self, string_list, group=1, option='null', alt='off'):
           (getattr(self, self.alt_string[alt]['groups'])).setdefault(str(group),{})['join']=True if option == 'join' and g.join_enabled==True else False
           rng=len(string_list)
           (getattr(self, self.alt_string[alt]['groups'])).setdefault(str(group),{})['range']=max(rng,self.groups.get(str(group),{}).get('range',0))
           (getattr(self, self.alt_string[alt]['groups'])).setdefault(str(group),{})['center']=False if option != 'center' else True
           (getattr(self, self.alt_string[alt]['seq'])).append(str(group))
           for i in range(rng):
               key=(str(group)+'-'+str(i))
               if key not in (getattr(self, self.alt_string[alt]['seg'])):
                        (getattr(self, self.alt_string[alt]['seg']))[key]=grid_segment(i)
               (getattr(self, self.alt_string[alt]['seg']))[key].list.append(string_list[i]+self.layout.fill)
               (getattr(self, self.alt_string[alt]['seg']))[key].layout.max_width=max(len(string_list[i]+self.layout.fill),self.seg[key].layout.max_width)


  def   dp_grid_build(self, name, title_type='none', title='',border_style='outer_grid',alt='off'):
           build={'name':name,'border_style':border_style, 'join_enabled':True}
           if title: build.setdefault('title', {}).update({'title':title, 'title_type':title_type})
           setattr(self, self.alt_string[alt]['grid_conf'],build)
           self.layout.max_width=self.terminal_width

  def   dp_grid(self,alt='off'):
            group=(getattr(self, self.alt_string[alt]['groups'])).keys()
            join=None
            max_length=0
            for grp,rng in (getattr(self, self.alt_string[alt]['groups'])).items():
                rng['position']=0
                for i in range(rng['range']):
                    rng['length'] = rng.get('length',0)+(getattr(self, self.alt_string[alt]['seg']))[grp+'-'+str(i)].layout.max_width
                max_length=max(max_length,rng['length'])
                if join:
                     if (join['f_group_length']+rng['length'])>=(self.terminal_width-self.layout.indent_size):(getattr(self, self.alt_string[alt]['groups']))[join['f_group']]['join']=False #- self.layout.indent_size):self.groups[join['f_group']]['join']=False
                     join=None
                if rng['join']==True:join={'f_group':grp, 'f_group_length':rng['length']}
            grid_body=[]
            pre_line=''
            apply_join=False
            for sequence in range(len((getattr(self, self.alt_string[alt]['seq'])))):
                line=''
                if apply_join:line,apply_join=pre_line,False
                for i in range((getattr(self, self.alt_string[alt]['groups']))[(getattr(self, self.alt_string[alt]['seq']))[sequence]]['range']):
                    seg=(getattr(self, self.alt_string[alt]['seg']))[(getattr(self, self.alt_string[alt]['seq']))[sequence]+'-'+str(i)].list[(getattr(self, self.alt_string[alt]['groups']))[(getattr(self, self.alt_string[alt]['seq']))[sequence]]['position']]
                    fill_out=self.layout.fill*(((getattr(self, self.alt_string[alt]['seg']))[(getattr(self, self.alt_string[alt]['seq']))[sequence]+'-'+str(i)].layout.max_width)-len(seg))
                    line=line+seg+fill_out
                if (getattr(self, self.alt_string[alt]['groups']))[(getattr(self, self.alt_string[alt]['seq']))[sequence]]['join']==True: pre_line, apply_join=line,True
                else:
                   if (getattr(self, self.alt_string[alt]['groups']))[(getattr(self, self.alt_string[alt]['seq']))[sequence]]['center']==True: line = ' '*math.trunc((max_length-(getattr(self, self.alt_string[alt]['groups']))[(getattr(self, self.alt_string[alt]['seq']))[sequence]]['length'])/2)+line
                   grid_body.append(line)
                (getattr(self, self.alt_string[alt]['groups']))[(getattr(self, self.alt_string[alt]['seq']))[sequence]]['position']+=1

            header = self.dp_get_header(grid_body,(getattr(self, self.alt_string[alt]['grid_conf'])).get('title',{}).get('title',''),(getattr(self, self.alt_string[alt]['grid_conf']))['border_style'],(getattr(self, self.alt_string[alt]['grid_conf'])).get('title',{}).get('title_type',''))
            for g_line in header:
                g_line=self.layout.center([g_line,'\33[97m'+g_line])
                self.dp_print(g_line)
            setattr(self, self.alt_string[alt]['grid_conf'],{}),setattr(self, self.alt_string[alt]['groups'],{}),setattr(self, self.alt_string[alt]['seg'],{}),setattr(self, self.alt_string[alt]['seq'],[])

class grid:
    def __init__(self, name='dp_grid',group=1, segs_per_line=8, title=True , title_string='DUAL PRINT GRID STYLEZ',title_seg_count=3,footer_line=True,border_style='outer_segments'):
        self.name=name
        self.segs_per_line=segs_per_line
        self.segs_loaded_from='left'
        self.layout=composition()
        self.title=title
        self.title_line_count=3
        self.footer=footer_line
        self.title_string=title_string
        self.border_style=border_style     # 'outer_segments|column_sides'
        self.seg={}
        self.seq={'dp_seq':[]}

class bcolors:
    HEADER = '\033[95m'
    OKBLUE = '\033[94m'
    OKCYAN = '\033[96m'
    OKGREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'
    CWHITE = '\33[37m'
    WHITE = '\33[97m'
    DEFAULT = '\33[97m'

try:
  advanced_corner=('╔')
  if not isinstance(advanced_corner, unicode):
            UTF8Writer = codecs.getwriter('utf8')
            sys.stdout = UTF8Writer(sys.stdout)
except Exception as e:
       corner='+'


class composition:
    def __init__(self):
        self.align='left'   #left|right|center
        self.width=0
        self.max_width=0
        self.fill_on= '|'
        self.fill_off= ' '
        self.fill=' '
        self.indent_size = math.trunc((settings_term_check()/100)*10)
        self.min_buffer_size = 2
        self.border_top_left = (u'╔')
        self.border_row = (u'═')
        self.border_top_right = (u'╗')
        self.border_left_divider = (u'╠')
        self.border_right_divider = (u'╣')
        self.border_column = (u'║')
        self.border_bottom_left = (u'╚')
        self.border_bottom_right = (u'╝')

    def compose(self, text, max_width):
        self.max_width=max_width
        map={'right':self.right,'left':self.left,'center':self.center}
        text=map[self.align](text)
        return text

    def right(self, text):
        indent=math.trunc(min(self.indent_size, (self.max_width-(len(text[0])))))
        indent=math.trunc(max(indent, self.min_buffer_size))
        for i in range(len(text)): text[i] =(self.fill*(math.trunc(self.max_width-indent-len(text[0])))+text[i]+(self.fill*indent))
        return text

    def left(self, text):
        indent=math.trunc(min(self.indent_size, (self.max_width-len(text[0]))))
        indent=math.trunc(max(indent, self.min_buffer_size))
        for i in range(len(text)):text[i] =((self.fill*indent)+text[i]+self.fill*(math.trunc(self.max_width-indent-len(text[0]))))
        return text

    def center(self, text):
        indent=math.trunc((self.max_width-len(text[0]))/2)
        indent=math.trunc(max(indent, self.min_buffer_size))
        for i in range(len(text)): text[i] =(self.fill*indent)+text[i]+(self.fill*(math.trunc(self.max_width-indent-len(text[0]))))
        return text


    def border(self, change='heavy'):
        borders={'heavy':{'border_top_left':'╔','border_row':'═','border_top_right':'╗','border_left_divider':'╠','border_right_divider':'╣','border_column':'║','border_bottom_left':'╚','border_bottom_right':'╝'},
                 'medium':{'border_top_left':'╔','border_row':'—','border_top_right':'╗','border_left_divider':'╟','border_right_divider':'╢','border_column':'║','border_bottom_left':'╚','border_bottom_right':'╝'},
                 'light':{'border_top_left':'┌','border_row':'─','border_top_right':'┐','border_left_divider':'┼','border_right_divider':'┼','border_column':'│','border_bottom_left':'└','border_bottom_right':'┘'},
                 'plain':{'border_top_left':'+','border_row':'-','border_top_right':'+','border_left_divider':'|','border_right_divider':'|','border_column':'|','border_bottom_left':'+','border_bottom_right':'+'}}
        border_style=borders[change]
        self.border_top_left,self.border_row,self.border_top_right,self.border_left_divider,self.border_right_divider,self.border_column,self.border_bottom_left,self.border_bottom_right=border_style['border_top_left'],border_style['border_row'],border_style['border_top_right'],border_style['border_left_divider'],border_style['border_right_divider'],border_style['border_column'],border_style['border_bottom_left'],border_style['border_bottom_right']

class grid_segment:
    def __init__(self, index):
        self.index=index
        self.type='data'    #data|border|title
        self.layout=composition()
        self.border=False
        self.border_sides='left'   #left|right|both
        self.break_after = False
        self.join_next_seg = False
        self.join_with=' '
        self.max_width_join_kill=False
        self.list=[]


################################################################################################################################
# SETTINGS_OPTIONS_MODULE settings_
################################################################################################################################

class settings_parser(OptionParser):
    def print_help(arg):
        global parimiko_active
        r.dp_line('=')
        r.layout.align='center'
        r.dp(u'           ╔══╤══╗          ',u'\033[0m'+u'\033[1m'+u'           '+u'\33[94m'+u'╔══╤══╗'+u'\033[0m'+u'          ')
        r.dp(u'POWERSTORE ╟FAULT╢ DETECTION',u'\033[1m'+u'POWERSTORE '+u'\33[94m'+u'╟'+u'\033[0m'+u'\033[1m'+u'FAULT'+u'\33[94m'+u'╢'+u'\33[97m'+u' DETECTION')
        r.dp(u'           ╚══╧══╝          ',u'\033[0m'+u'\033[1m'+u'           '+u'\33[94m'+u'╚══╧══╝'+u'\033[0m'+u'          ')
        r.dp_line('=')
        r.col.DEFAULT='\33[97m'
        r.dp_break()
        r.layout.align='left'
        r.dp('HELP:')
        r.dp_break()
        r.dp('-h, --help                             Displays help on Powerstore Fault Detection commands and usage.')
        r.dp('-s, --settings                         Displays saved configuaration settings stored in ./settings file.')
        r.dp('-b, --bypass                           Bypass general checks for Known Issues.')
        r.dp('-i, --ignore_oe                        Check all known issues, even if not applicable to OE')
        if parimiko_active: r.dp('-u, --upload <file_name>|dc            Upload file to registered ftp link')
        if parimiko_active: r.dp('                                       -u <file_name>  File name or path and filename, if not in working directory. eg. -u log.txt')
        if parimiko_active: r.dp('                                       -u dc           Selects newest Data Collect on current node, then uploads.')
        if parimiko_active: r.dp('-d, --download <file_name>|dc          Download file(s) from registered ftp link to current working directory')
        if parimiko_active: r.dp('                                       -d <file_name>  File name or path and filename, if not in working directory. eg. -d log.txt')
        if parimiko_active: r.dp('                                       -d dc           Selects newest Data Collect on ftp link, then downloads it.')
        if parimiko_active: r.dp_break()
        r.dp_break()
        r.dp('TARGETED TROUBLESHOOTING:')
        r.dp_break()
        r.dp('--connectivity_block                   Host connectivity troubleshooting-block level.')
        r.dp('--connectivity_file                    Host connectivity troubleshooting-file level.')
        r.dp('--ndu                                  Non Disruptive Upgrade (NDU) troubleshooting.')
        r.dp_break()
        r.dp('SETTINGS:')
        r.dp_n_break('')
        r.dp('--hours                                Sets the default range in hours to search journal logs.')
        r.dp('--save on|off                          Save PFD Analysis to text file in working directory.')
        r.dp('--logs on|off                          Extract associated logs with selected TARGETED TROUBLESHOOTING.')
        if parimiko_active: r.dp('--ftp "<ftp_link>"                     Register a Dell-EMC ftp link to upload files to. Remember to encase link in quotation marks.')
        if parimiko_active: r.dp('--ftp_auto on|off                      Automatically uploads logs from TARGETED TROUBLESHOOTING to registered FTP link.')
        r.dp_break()
        r.dp_break()
        r.dp_title('Powerstore Fault Detection Script Complete')

def settings_pre_startup_environment_checks():
    global g
    global offline_mode
    global online_mode
    global current_mode

    cwd = os.getcwd()
    r.dp_line('-')
    r.layout.align='center'
    r.dp("NOTE: For HELP with commands run script with -h switch ie. python pst_fd.py -h")
    r.dp_break()
    if os.path.exists('./cyc_triage.pl')and(os.path.exists('./node_b/command_output')or os.path.exists('./node_a/command_output')):
       current_mode = offline_mode
       g.offline = True
       r.dp("Detected Data Collect in local directory")
       r.dp("Initiating OFFLINE mode")
       r.layout.align='left'
       r.dp_line('-')
       return True
    elif cwd == r'/home/service/user':
         output = cmd_run('svc_inject status')
         if re.search('Access is ENABLED', output):
            ###REMOVING THIS CMD AS YOU CAN"T RUN PYTHON WITHOUT ENABLING ROOT### os.system('svc_service_shell > /dev/null &')
            current_mode = online_mode
            g.online = True
            r.dp_line('-')
            r.dp("Detected Powerstore with service shell enabled \n")
            r.dp("Initiating ONLINE mode")
            r.layout.align='left'
            r.dp_line('-')
            return True
         r.dp('SERVICE SHELL CHECKS FAILED!')
         r.dp_break()
         status = output.split('\n')
         for line in status:
             r.dp(line)
    r.dp_line('-')
    r.dp("ENVIRONMENT CHECKS FAILED!")
    r.dp("To run on Data Collect put script & issueDB in extracted DCs root directory (contains cyc_triage.pl)")
    r.dp("To run on live Powerstore put script & issueDB in /home/service/user, enable service shell and make script executable using chmod777")
    r.dp_line('-')
    r.layout.align='left'
    return False

def settings_term_check():
    try:
      y, x = os.popen('stty size', 'r').read().split()
    except:
      x, y = os.get_terminal_size()
    terminal_width = int(x)-2
    if terminal_width > 200: terminal_width = 200
    elif terminal_width < 120: terminal_width = 120
    else: terminal_width = terminal_width-2
    return math.trunc(terminal_width)


def settings_check():
    global settings_file
    global settings
    global parimiko_active
    update_settings = False
    update_valid = []
    state = {'on': True, 'off': False}
    if os.path.exists(settings_file): settings_load()
    if options.settings:
       r.dp_break()
       r.dp_line('=')
       r.layout.align='center'
       r.dp(u'           ╔══╤══╗          ',u'\033[0m'+u'\033[1m'+u'           '+u'\33[94m'+u'╔══╤══╗'+u'\033[0m'+u'          ')
       r.dp(u'POWERSTORE ╟FAULT╢ DETECTION',u'\033[1m'+u'POWERSTORE '+u'\33[94m'+u'╟'+u'\033[0m'+u'\033[1m'+u'FAULT'+u'\33[94m'+u'╢'+u'\33[97m'+u' DETECTION')
       r.dp(u'           ╚══╧══╝          ',u'\033[0m'+u'\033[1m'+u'           '+u'\33[94m'+u'╚══╧══╝'+u'\033[0m'+u'          ')
       r.dp_line('=')
       r.col.DEFAULT='\33[97m'
       r.layout.align='left'
       r.dp_break()
       r.dp('SETTINGS:')
       r.dp_break()
       settings_print()
    if options.hours != 0:
       settings['time_delta'] = options.hours
       update_settings = True
    if options.save_analysis:
       if valid_on_off(options.save_analysis): settings['save_analysis'] = state[options.save_analysis]
       else: update_valid.append('--save')
       update_settings = True
    if options.save_logs:
       if valid_on_off(options.save_logs): settings['save_logs'] = state[options.save_logs]
       else: update_valid.append('--logs')
       update_settings = True
    if options.ftp_link and parimiko_active:
       if valid_ftp(options.ftp_link): settings['ftp_link'] = options.ftp_link
       else: update_valid.append('--ftp')
       update_settings = True
    if options.autoftp and parimiko_active:
       if valid_on_off(options.autoftp):
          settings['autoftp'] = state[options.autoftp]
          settings['delete_logs_after_upload'] = state[options.autoftp]
       else: update_valid.append('--ftp_auto')
       update_settings = True
    settings_save()
    g.settings=settings
    if update_settings:
       r.dp_break()
       r.dp_title("Powerstore Fault Detection")
       r.dp_break()
       if not update_valid:
          r.dp('SETTINGS UPDATED:')
          r.dp_break()
       if update_valid:
          list =''
          for update in update_valid:
              list = list + ', '+update
          r.dp('SETTINGS NOT UPDATED, INPUT NOT VALID FOR: '+list[2:])
          r.dp('PLEASE REFER TO HELP MENU (-h, --help) FOR INPUT GUIDANCE')
       r.dp_break()
       settings_print()

def settings_print():
       global settings
       global parimiko_active
       ftp_link = settings['ftp_link']
       if not ftp_link: ftp_link = 'None'
       r.dp('--hours                                '+str(settings['time_delta'])+' - Default range in hours to search journal logs. '+str(settings['time_delta'])+' hours of journal logs')
       r.dp('--save                                 '+str(settings['save_analysis'])+' - Save PFD Analysis to text file in working directory')
       r.dp('--logs                                 '+str(settings['save_logs'])+' - Extract associated logs with selected TARGETED TROUBLESHOOTING')
       if parimiko_active: r.dp('--ftp                                  '+ftp_link)
       if parimiko_active: r.dp('--ftp_auto                             '+str(settings['autoftp'])+' - Automatically uploads logs from TARGETED TROUBLESHOOTING to registered FTP link')
       r.dp_break()
       r.dp_break()
       pfd_exit()

def settings_load():
    global g
    global settings
    global settings_file
    with open(settings_file, mode='rb') as f:
        settings = pickle.load(f)

def settings_save():
    global g
    global settings
    global settings_file
    with open(settings_file, mode='wb') as f:
        pickle.dump(settings, f, 2)


################################################################################################################################
# INPUT_VALIDATION_ERROR_CONTROL_MODULE: valid_ try_hard_
################################################################################################################################

def valid_ftp(link):
       ftp = re.search('(?<=domain=)(.*)(?=&username=)', link)
       f_username = re.search('(?<=username=)(.*)(?=&password=)', link)
       f_password = re.search('(?<=password=).*', link)
       if ftp and f_username and f_password: return True
       else: return False

def valid_on_off(input):
       if input == 'on' or input == 'off': return True
       else: return False

def valid_download(sftp, file):
           valid = False
           if file == 'dc':
              valid, file = ftp_filelist_recursive(sftp)
              return valid, file
           else:
              valid, file = ftp_file_exists(sftp, file)
              return valid, file

################################################################################################################################
# FTP_MODULE ftp_
################################################################################################################################

def cmd_dummy():
    pass

parimiko_active=False
class dummy:
      def __init__(self):
        self.transport = cmd_dummy
        self.connect = cmd_dummy
        self.SFTPClient = cmd_dummy
        self.put = cmd_dummy
        self.get = cmd_dummy
        self.close = cmd_dummy

try:
   import paramiko
   parimiko_active=True
except:
   paramiko = dummy()

def ftp_transfer(file, direction='up', dont_delete=False):
    if g.settings['ftp_link']:
       link = re.search('(?<=domain=)(.*)(?=&username=)', g.settings['ftp_link']).group(0)
       f_username = re.search('(?<=username=)(.*)(?=&password=)', g.settings['ftp_link']).group(0)
       f_password = re.search('(?<=password=).*', g.settings['ftp_link']).group(0)
       r.dp_n_break('Connecting to ftp site..... ')
       try:
          transport = paramiko.Transport((link, 22))
          transport.connect(None, f_username, f_password)
          sftp = paramiko.SFTPClient.from_transport(transport)
          r.dp_n_break('Connected!')
          if direction == 'up':
             if '/' not in file: file = '/'+file
             r.dp_n_break('Uploading logs: '+file.rsplit('/', 1)[1])
             sftp.put(file, file.rsplit('/', 1)[1])
             r.dp_n_break('Upload complete!')
          elif direction == 'down':
             valid, file = valid_download(sftp, file)
             if valid:
                if '/' not in file: file = '/'+file
                r.dp_n_break('Downloading logs: '+file.rsplit('/', 1)[1])
                sftp.get(file, file.rsplit('/', 1)[1])
                r.dp_n_break('Download complete!')
          sftp.close()
          transport.close()
       except Exception as e:
         r.dp_n_break(str(e))
       r.dp_n_break(g.settings['ftp_link'])
       if direction=='up' and g.settings['delete_logs_after_upload'] and not dont_delete: os.remove(file)
    elif not g.settings['ftp_link']:
       r.dp_break()
       r.dp('No FTP link stored in settings!')
       r.dp_n_break('Register an ftp link using PFD switch -f "<insert Dell-EMC ftp link>"')
       r.dp_n_break("Note: Won't register ftp link unless encased in quatation marks.")
       r.dp_break()

def ftp_file_exists(sftp, file):
    try:
       check = sftp.stat(file)
       return True, file
    except Exception as e:
      r.dp_n_break(str(e))
      return False, file

def ftp_helper(sftp, files):
    stats = sftp.listdir_attr('.')
    files[sftp.getcwd()] = [attr.filename for attr in stats if stat.S_ISREG(attr.st_mode)]

    for attr in stats:
        if stat.S_ISDIR(attr.st_mode):  # If the file is a directory, recurse it
            sftp.chdir(attr.filename)
            ftp_helper(sftp, files)
            sftp.chdir('..')

def ftp_filelist_recursive(sftp):
    files_all = {}
    files = []
    dc_time = []
    times = []
    try:
       ftp_helper(sftp, files_all)
       paths = files_all.keys()
       for path in paths:
           filez = files_all[path]
           for file in filez:
               if re.match('powerstore_.*_service-data.tgz', file):
                  root = path
                  if not root: root = ''
                  files.append(os.path.join(root, file))
                  dc_time = re.search('[0-9]{4}-[0-9]{2}-[0-9]{2}_[0-9]{2}-[0-9]{2}-[0-9]{2}', file).group(0)
                  times.append(datetime.datetime.strptime(dc_time, '%Y-%m-%d_%H-%M-%S'))
       current_time = max(times)
       index = 0
       for time in times:
           if time == current_time: break
           index+=1
       return True, files[index]
    except Exception as e:
      r.dp_n_break(str(e))
      return False, files

def ftp_log_cleanup():
    global g
    global f
    if g.settings['save_analysis']:
         f.close()
         os.remove(g.analysis_file)
    shutil.rmtree(g.log_folder)

def ftp_download_current_dc(sftp):
    global g
    file = try_hard_get(sftp, 'dc')

def ftp_upload_current_dc():
    global g
    global appliance_info
    ftp_log_cleanup()
    dcs = []
    times = []
    r.dp_n_break('FTP UPLOAD SERVICE')
    for root, dir, files in os.walk('/cyc_var/cyc_service/data_collection/'):
        for file in files:
            if re.match('powerstore_.*_service-data.tgz', file):
               dcs.append(os.path.join(root, file))
               dc_time = re.search('[0-9]{4}-[0-9]{2}-[0-9]{2}_[0-9]{2}-[0-9]{2}-[0-9]{2}', file).group(0)
               times.append(datetime.datetime.strptime(dc_time, '%Y-%m-%d_%H-%M-%S'))
    current_time = max(times)
    index = 0
    for time in times:
        if time == current_time: break
        index+=1
    ftp_transfer(dcs[index], 'up', True)
    pfd_exit()

def ftp_download(file):
    ftp_log_cleanup()
    ftp_transfer(file, 'down', True)
    pfd_exit()

def ftp_download_online_dc():
    ftp_log_cleanup()
    r.dp_n_break('DOWNLOADING EXTERNAL DATA COLLECTS TO POWERSTORE NOT SUPPORTED')
    pfd_exit()

def ftp_upload_file(file):
    global g
    global appliance_info
    ftp_log_cleanup()
    r.dp_title('FTP UPLOAD SERVICE')
    if os.path.exists('./'+file):
       path_file = os.getcwd()+os.path.sep+file
       if not os.path.exists(path_file):
          r.dp_break()
          r.dp(file+' does not exist')
          r.dp_break()
          pfd_exit()
       file = path_file
    ftp_transfer(file, 'up', True)
    pfd_exit()

################################################################################################################################
# COMMAND_MODULE cmd_
################################################################################################################################

def cmd_run(cmd) :
    p = subprocess.Popen(cmd,stdout=subprocess.PIPE, stderr=subprocess.PIPE,shell=True)
    output,err = p.communicate()
    p_status = p.wait()
    return output

def cmd_get_output(cmd) :
    node_a = './node_a/command_output/'
    node_b = './node_b/command_output/'
    node = node_a
    if not os.path.exists(node + cmd):
           node = node_b
    if os.path.exists(node + cmd):
        fileObj = open(node + cmd, "r")
        output = fileObj.read().splitlines()
        fileObj.close()
        return output

# COMMAND_MODULE cmd_stored

def cmd_stored(cmd):
    cmd_dict = {'zgrep': cmd_stored_zgrep, 'hung_process_log_check': cmd_stored_hung_process_log_check}
    output = cmd_dict[cmd['cmd']](cmd)
    return output

def cmd_stored_zgrep(cmd):
    global g
    if cmd['zgrep_path'].startswith('/'): cmd['zgrep_path'] =cmd['zgrep_path'][1:]
    a = cmd['peer_a']+'zgrep '+'"'+cmd['zgrep_keyword']+'" '+current_mode['a_dir_adjustment']+os.path.sep+cmd['zgrep_path']
    b = cmd['peer_b']+'zgrep '+'"'+cmd['zgrep_keyword']+'" '+current_mode['b_dir_adjustment']+os.path.sep+cmd['zgrep_path']
    sp_dict = {'A': a, 'B': b, 'primary': '', 'both': a+' & '+b}
    sp_dict['primary'] = sp_dict[appliance_info.Primary]
    output = cmd_run(sp_dict[cmd['run_on_node']])
    return output.decode("utf-8", "backslashreplace").strip()

def cmd_stored_hung_process_log_check(cmd):
    global g
    key_latest_entry = ' -r --lines=1 | tail -1| grep -o "[A-Z]\{1\}[a-z]\{2\}\s[0-9]\{2\}\s[0-9]\{2\}:[0-9]\{2\}:[0-9]\{2\}" | head -1'
    time_string = cmd_run(current_mode['journal_ctl_cmd']+' -t '+cmd['log_identifier']+key_latest_entry)
    if time_string: time_of_latest_entry = datetime.datetime.strptime(time_string.decode("utf-8", "backslashreplace").strip(), "%b %d %H:%M:%S")
    acceptable_hours = g.end_of_journal_time - datetime.timedelta(hours=int(cmd['hours_no_entries']))
    output = 'Log entries found within acceptable time range'
    if time_of_latest_entry < acceptable_hours or not time_string: output = 'No log entries in first '+cmd['hours_no_entries']+' hours of '+cmd['log_identifier']+' logs, associated process may have hung'
    return output

# COMMAND_MODULE cmd_custom

def cmd_custom(cmd):
    global g
    a = cmd['peer_a']+cmd['cmd']
    b = cmd['peer_b']+cmd['cmd']
    sp_dict = {'A': a, 'B': b, 'primary': '', 'both': a+' & '+b}
    sp_dict['primary'] = sp_dict[appliance_info.Primary]
    output = cmd_run(sp_dict[cmd['run_on_node']])
    return output

# COMMAND_MODULE cmd_output_folder

def cmd_output_folder(cmd):
    current_mode['cmd_output_folder'](cmd)
    output = cmd_output_folder_read(cmd['cmd'])
    return output

def cmd_output_folder_read(logfile):
            output = None
            with open(g.log_folder+os.path.sep+logfile, 'rb') as log:
                 output = log.read().decode("utf-8", "backslashreplace").strip()
            if logfile not in g.required_logs: os.remove(g.log_folder+os.path.sep+logfile)
            return output

def cmd_output_folder_live(cmd):
    global g
    output = cmd['cmd']
    xms = base64.b64decode("WDEwVGVjaCE=").decode("utf-8")
    cmdsstart={'xmc': 'docker exec cyc_xms_docker /usr/local/bin/xmcli -u tech -p'+xms+' -c ', 'svc': '', 'cli': 'docker exec cyc_bsc_docker /cyc_bsc/datapath/bin/cli.py ', 'clu': '', 'cyc': '', 'dme': '', 'dmi': '', 'fcc': '', 'har': '', 'isc': ''}
    shortname = output[:3]
    cmd1 = cmdsstart[shortname]
    if not os.path.exists(g.log_folder+os.path.sep+output):
        cmdsend = {'xmc': {
                   'xmcli_-x__-c_query-dare-status.txt': 'query-dare-status',
                   'xmcli_-x__-c_query-kms-ntfs.txt': 'query-kms-ntfs',
                   'xmcli_-x__-c_query-monitoring-data_entity=Initiator_limit=1.txt': '"query-monitoring-data entity=Initiator limit=1"',
                   'xmcli_-x__-c_query-monitoring-data_entity=ScsiTarget_limit=1.txt': '"query-monitoring-data entity=ScsiTarget limit=1"',
                   'xmcli_-x__-c_query-monitoring-data_entity=Volume_limit=1.txt': '"query-monitoring-data entity=Volume limit=1"',
                   'xmcli_-x__-c_show-bricks.txt': 'show-bricks',
                   'xmcli_-x__-c_show-daes-controllers-sas-ports.txt': 'show-daes-controllers-sas-ports',
                   'xmcli_-x__-c_show-daes-controllers.txt': 'show-daes-controllers',
                   'xmcli_-x__-c_show-daes-psus.txt': 'show-daes-psus',
                   'xmcli_-x__-c_show-daes.txt': 'show-daes',
                   'xmcli_-x__-c_show-dimms.txt': 'show-dimms',
                   'xmcli_-x__-c_show-discovered-initiators-connectivity_target-details.txt': 'show-discovered-initiators-connectivity target-details',
                   'xmcli_-x__-c_show-enclosures.txt': 'show-enclosures',
                   'xmcli_-x__-c_show-events_limit=5000.txt': '"show-events limit=5000"',
                   'xmcli_-x__-c_show-fanpacks.txt': 'show-fanpacks',
                   'xmcli_-x__-c_show-frontend-ports-topology.txt': 'show-frontend-ports-topology',
                   'xmcli_-x__-c_show-frontend-ports.txt': 'show-frontend-ports',
                   'xmcli_-x__-c_show-initiator-groups.txt': 'show-initiator-groups',
                   'xmcli_-x__-c_show-initiators-connectivity_target-details.txt': '"show-initiators-connectivity target-details"',
                   'xmcli_-x__-c_show-initiators.txt': 'show-initiators',
                   'xmcli_-x__-c_show-ioms.txt': 'show-ioms',
                   'xmcli_-x__-c_show-ip-addresses.txt': 'show-ip-addresses',
                   'xmcli_-x__-c_show-ip-interfaces.txt': 'show-ip-interfaces',
                   'xmcli_-x__-c_show-ip-routes.txt': 'show-ip-routes',
                   'xmcli_-x__-c_show-iscsi-portals.txt': 'show-iscsi-portals',
                   'xmcli_-x__-c_show-leds.txt': 'show-leds',
                   'xmcli_-x__-c_show-local-disks.txt': 'show-local-disks',
                   'xmcli_-x__-c_show-lun-mappings.txt': 'show-lun-mappings',
                   'xmcli_-x__-c_show-net-devices.txt': 'show-net-devices',
                   'xmcli_-x__-c_show-networks.txt': 'show-networks',
                   'xmcli_-x__-c_show-nodebbus.txt': 'show-nodebbus',
                   'xmcli_-x__-c_show-relative-target-port-portals.txt': 'show-relative-target-port-portals',
                   'xmcli_-x__-c_show-relative-target-ports.txt': 'show-relative-target-ports',
                   'xmcli_-x__-c_show-sfps.txt': 'show-sfps',
                   'xmcli_-x__-c_show-slots.txt': 'show-slots',
                   'xmcli_-x__-c_show-ssds-diagnostic.txt': 'show-ssds-diagnostic',
                   'xmcli_-x__-c_show-ssds.txt': 'show-ssds',
                   'xmcli_-x__-c_show-storage-controllers-psus.txt': 'show-storage-controllers-psus',
                   'xmcli_-x__-c_show-storage-controllers-sensors.txt': 'show-storage-controllers-sensors',
                   'xmcli_-x__-c_show-storage-controllers.txt': 'show-storage-controllers',
                   'xmcli_-x__-c_show-target-port-groups.txt': 'show-target-port-groups',
                   'xmcli_-x__-c_show-targets-performance.txt': 'show-targets-performance',
                   'xmcli_-x__-c_show-targets.txt': 'show-targets',
                   'xmcli_-x__-c_show-volumes-performance.txt': 'show-volumes-performance',
                   'xmcli_-x__-c_show-volumes.txt': 'show-volumes',
                   'xmcli_-x__-c_show-xms-info.txt': 'show-xms-info',
                   'xmcli_-x__-c_show-xms.txt': 'show-xms',
                   'xmcli_drive_mgmt-_dieh_get_buckets.txt': '\'drive-mgmt command="dieh_get_buckets"\'',
                   'xmcli_drive_mgmt-_dieh_show_profiles.txt': '\'drive-mgmt command="dieh_show_profiles"\'', },
                   'cli': {
                   'cli.py_dc_plugin_dump_backend.txt': 'dc_plugin dump_backend',
                   'cli.py_dc_plugin_dump_mapper.txt': 'dc_plugin dump_mapper',
                   'cli.py_dc_plugin_dump_ns_objects.txt': 'dc_plugin dump_ns_objects',
                   'cli.py_dc_plugin_dump_ns_spacestats.txt': 'dc_plugin dump_ns_spacestats',
                   'cli.py_dc_plugin_dump_ns_stats.txt': 'dc_plugin dump_ns_stats',
                   'cli.py_dc_plugin_dump_ns_volumes.txt': 'dc_plugin dump_ns_volumes',
                   'cli.py_dc_plugin_dump_raid_debug.txt': 'dc_plugin dump_raid_debug',
                   'cli.py_dc_plugin_dump_raid_rebuild.txt': 'dc_plugin dump_raid_rebuild',
                   'cli.py_dc_plugin_dump_raid_stats.txt': 'dc_plugin dump_raid_stats',
                   'cli.py_dc_plugin_dump_raid_summary.txt': 'dc_plugin dump_raid_summary',
                   'cli.py_mapper_get_fua_stats.txt': 'mapper get_fua_stats',
                   'cli.py_namespace_spacestats_enumobjects.txt': 'namespace spacestats enumobjects',
                   'cli.py_namespace_spacestats_enumsnapgroups.txt': 'namespace spacestats enumsnapgroups',
                   'cli.py_namespace_spacestats_enumtenants.txt': 'namespace spacestats enumtenants',
                   'cli.py_stats_system_space_usage_stats.txt': 'stats system_space_usage_stats'},
                   'clu': {
                   'cluster.py.txt': 'docker exec cyc_xms_docker /cyc_host/cyc_service/bin/plugins/diag/cluster.py'},
                   'cyc': {
                   'cyc_dc_filels_--core.txt': '/cyc_host/cyc_service/lib/cyc_dc_filels --core',
                   'cyc_fwtool.sh_-list.txt': '/cyc_host/cyc_bsc/scripts/cyc_fwtool.sh -list',
                   'cyc_fwtool.sh_-showrev.txt': '/cyc_host/cyc_bsc/scripts/cyc_fwtool.sh -showrev',
                   'cyc_fwtool.sh_-version.txt': '/cyc_host/cyc_bsc/scripts/cyc_fwtool.sh -version',
                   'cyc_get_free_space.sh.txt': '/cyc_host/cyc_service/bin/plugins/cyc_get_free_space.sh',
                   'cyc_ipmitool_fru_list.txt': '/cyc_host/cyc_bsc/scripts/cyc_ipmitool fru list',
                   'cyc_ipmitool_mrsoem_fsr_display.txt': '/cyc_host/cyc_bsc/scripts/cyc_ipmitool mrsoem fsr display',
                   'cyc_ipmitool_sdr_elist.txt': '/cyc_host/cyc_bsc/scripts/cyc_ipmitool sdr elist',
                   'cyc_ipmitool_sel_elist.txt': '/cyc_host/cyc_bsc/scripts/cyc_ipmitool sel elist',
                   'cyc_ipmitool_sensor_list.txt': '/cyc_host/cyc_bsc/scripts/cyc_ipmitool sensor list',
                   'cyc_net_client_-node_local_-realm_L2D_-command_get_l2_discovery_info_-verbose_1.txt': 'docker exec cyc_bsc_docker /cyc_bsc/bin/cyc_net_client -node local -realm L2D -command get_l2_discovery_info -verbose 1',
                   'cyc_peer_--fsr.txt': '/cyc_host/cyc_bsc/scripts/cyc_peer --fsr',
                   'cyc_proxy_debug_datacollect_connection_objects.txt': 'NO_IDEA',
                   'cyc_proxy_debug_datacollect_process_thread_stacks.txt': 'NO_IDEA'},
                   'dme': {
                   'dmesg_-T.txt': 'dmesg -T'},
                   'dmi': {
                   'dmidecode.txt': 'docker exec cyc_bsc_docker /usr/sbin/dmidecode'},
                   'fcc': {'fcc.sh_info.txt': 'docker exec cyc_bsc_docker /cyc_host/cyc_bsc/scripts/fcc.sh info', 'fcc.sh_list.txt': 'docker exec cyc_bsc_docker /cyc_host/cyc_bsc/scripts/fcc.sh list', 'fcc.sh_stats.txt': 'docker exec cyc_bsc_docker /cyc_host/cyc_bsc/scripts/fcc.sh stats'},
                   'har': {
                   'hardware.py_--local_drive.txt': '/cyc_host/cyc_service/bin/plugins/diag/hardware.py --local_drive'},
                   'isc': {
                   'iscsiadm_-m_iface.txt': 'docker exec cyc_bsc_docker /usr/sbin/iscsiadm -m iface',
                   'iscsiadm_-m_node.txt': 'docker exec cyc_bsc_docker /usr/sbin/iscsiadm -m node',
                   'iscsiadm_-m_node_-o_show.txt': 'docker exec cyc_bsc_docker /usr/sbin/iscsiadm -m node -o show',
                   'iscsiadm_-m_session.txt': 'docker exec cyc_bsc_docker /usr/sbin/iscsiadm -m session',
                   'iscsiadm_-m_session_-P_3.txt': 'docker exec cyc_bsc_docker /usr/sbin/iscsiadm -m session -P 3',
                   'iscsiadm_-m_session_-s.txt': 'docker exec cyc_bsc_docker /usr/sbin/iscsiadm -m session -s'},
                   'lsp': {
                   'lspci_-v.txt': 'docker exec cyc_bsc_docker lspci -vdocker exec cyc_bsc_docker lspci -v'},
                   'net': {
                   'netstat_-s.txt': 'netstat -s'},
                   'nvm': {
                   'nvme_drive.py.txt': '/cyc_host/cyc_service/bin/plugins/diag/nvme_drive.py'},
                   'sar': {
                   'sar_-n_DEV.txt': 'docker exec cyc_bsc_docker sar -n DEV'},
                   'svc': {
                   'svc_diag_list_--basic.txt': 'svc_diag list --basic',
                   'svc_diag_list_--expansion_resume.txt': 'svc_diag list --expansion_resume',
                   'svc_diag_list_--icw_hardware.txt': 'svc_diag list --icw_hardware',
                   'svc_diag_list_--info.txt': 'svc_diag list --info',
                   'svc_diag_list_--network.txt': 'svc_diag list --network',
                   'svc_diag_list_--show_drives.txt': 'svc_diag list --show_drives',
                   'svc_drive_stats_list_--smartData.txt': 'svc_drive_stats list --smartData',
                   'svc_mgmt_operations_granted_locks_with_pending_locks.txt': 'svc_mgmt_operations granted_locks_with_pending_locks',
                   'svc_mgmt_operations_pending_locks.txt': 'svc_mgmt_operations pending_locks',
                   'svc_password_mgmt_recovery_-s.txt': 'svc_password_mgmt recovery -s',
                   'svc_security_protocol_status.txt': 'svc_security_protocol status',
                   'svc_service_config_list.txt': 'svc_service_config list'}
                   }

        dic_cmds = cmdsend[shortname]
        cmd2 = dic_cmds[output]
        command = cmd1+cmd2
        result = cmd_run(command+' > '+g.log_folder+os.path.sep+output)



def cmd_get_config_capture_file_dc(file_name):
    result = cmd_find_load_json(os.getcwd()+os.path.sep+'node_'+appliance_info.Primary.lower(), file_name)
    return result

def cmd_get_config_capture_file_live(file_name):
    result = cmd_find_load_json(os.getcwd(), file_name)
    return result

def cmd_get_config_capture_files(file_name_list):
    files_found = True
    for file_name in file_name_list:
        result = current_mode['get_config_capture_file'](file_name)
        if result == False: files_found = False
    return files_found

def cmd_find_copy(directory, file):
       for root, dir, files in os.walk(directory):
         if file in files:
            log_output = os.path.join(root, file)
            shutil.copy(log_output, g.log_folder+os.path.sep+file)
            return True
       return False

def cmd_find_load_json(directory, file):
       global json_info
       key='id'
       if ';' in file:
           list = file.split(';')
           file, key = list[1],list[0]
       for root, dir, files in os.walk(directory):
         if file in files:
            log_output = os.path.join(root, file)
            try:
              var,item=json.load(open(log_output, 'r'))['data'], {}
              for entry in var:item.setdefault(entry[key], {}).update(entry)
              setattr(json_info, file.replace('.json', ''),item)
            except Exception as e:
              r.dp_n_break(str(e))
            return True
       return False

def cmd_merg_dict(l1, l2, key1, key2):
      d = collections.defaultdict(dict)
      l1 = {(d[key1], d[key2]):d for d in l1}
      results = [dict(d, **l1.get((d[key1],d[key2]), {})) for d in l2]
      return results


def cmd_dict_select_keys(l1, l2, match1, match2, grab1, grab2, grab3):
      for l in l2:
        if cmd_check_key_value_exist(l, match2, value=None):
           for li in l1:
              if cmd_check_key_value_exist(li, match1, value=None) and l[match2]==li[match1]:
                  try:
                    l[grab1],l[grab2],l[grab3]=li[grab1],li[grab2],li[grab3]
                  except Exception as e:
                    r.dp_n_break(str(e))
      return l2


def cmd_output_folder_dc(cmd):
    global g
    global appliance_info
    output = cmd['cmd']
    if not os.path.exists(g.log_folder+os.path.sep+output):
       node = appliance_info.Primary.lower()
       found = cmd_find_copy('node_'+node+os.path.sep+'command_output', output)
       if not found:
           a_b = {'a': 'b', 'b': 'a'}
           node = a_b[node]
           found = cmd_find_copy('node_'+node+os.path.sep+'command_output', output)

def cmd_check_key_value_exist(dic, key, value=None):
  if value==None:
    try:
        return key in dic
    except KeyError:
        return False
  else:
    try:
        return dic[key] == value
    except KeyError:
        return False

def cmd_copy_key_if_exists(dict, key, if_null='null'):
        try:
           return dict[key]
        except KeyError:
           return if_null

################################################################################################################################
# JOURNAL_MODULE journalctl_
################################################################################################################################

def journalctl_Reader(keywordlist, identifier, journal_range, path=''):
   global g
   logfile = g.log_folder+os.path.sep+identifier+'.txt'
   journalctlcmd = current_mode['journal_ctl_cmd']+' -t '+identifier+' --since="'+journal_range.strftime("%Y-%m-%d %H:%M:%S")+'" > '+logfile
   os.system(journalctlcmd)
   log_read = open(logfile, 'rb')
   for line in log_read:
        for keyword in keywordlist:
             if re.search(keyword['keyword'], line.decode("utf-8", "backslashreplace").strip()):
               keyword['count']+=1
   log_read.close()
   if identifier not in g.required_logs: os.remove(logfile)
   return keywordlist

def journalctl_Reader_dump_to_text(identifier, journal_range, path=''):
   global g
   logfile = g.log_folder+os.path.sep+identifier+'.txt'
   journalctlcmd = current_mode['journal_ctl_cmd']+' -t '+identifier+' --since="'+journal_range.strftime("%Y-%m-%d %H:%M:%S")+'" > '+logfile
   os.system(journalctlcmd)

def journalctl_offline_check():
    global g
    keycmd = './cyc_triage.pl -j -- -r --lines=1 | grep UTC | head -1| grep -o "[0-9]\{4\}-[0-9]\{2\}-[0-9]\{2\}\s[0-9]\{2\}.[0-9]\{2\}.[0-9]\{2\}" | tail -1'
    output = cmd_run(keycmd)
    output=(output.decode("utf-8", "backslashreplace"))[:19]
    g.end_of_journal_time= datetime.datetime.strptime(output, "%Y-%m-%d %H:%M:%S")


################################################################################################################################
# TROUBLESHOOTING_MODULE troubleshooting_
################################################################################################################################

def version_check():
    ver_file = 'cat version.num'
    cmd_run(base64.b64decode(vermagic).decode("utf-8"))
    new_ver = cmd_run(ver_file)
    if LooseVersion(version) >= LooseVersion(new_ver):
        r.layout.align='center'
        r.dp('The running script is the latest version.')
        r.dp_line('-')
        r.layout.align='left'
    elif LooseVersion(version) < LooseVersion(new_ver):
        r.layout.align='center'
        r.dp('The latest version is v' + new_ver + ', downlaoding......')
        dl_file = base64.b64decode(pfdmagic).decode("utf-8") + "pfd_fd_v" + new_ver + ".zip"
        cmd_run(dl_file)
        r.dp('Completed! ')
        r.dp('Could find the new script in current folder and run it for next try.')
        r.dp_line('-')
        r.layout.align='left'

def troubleshooting_required_logs():
        global g
        required_logs = g.settings['troubleshooting_logs']
        for logs in required_logs:
            if logs['opt_parse']:
               for log in logs['log_name_list']:
                   if log.startswith('extract_only:') and g.settings['save_logs']: log=log.replace('extract_only:', '')
                   if not log in g.required_logs and not log.startswith('extract_only:'):
                      g.required_logs.append(log)

def troubleshooting_regex_converter(keyword):
    if not keyword.startswith('regex:'): keyword = re.escape(keyword)
    else: keyword = keyword.replace('regex:', '')
    return keyword

class known_issue:
    def __init__(self, ID, Title, Reference, OE_start, OE_end, Journal, Commands):
        self.ID = ID
        self.Title = Title
        self.Reference = Reference
        self.OE_start = OE_start
        self.OE_end = OE_end
        self.Journal = Journal
        self.Commands = Commands
        self.Kb_JMatch = True
        self.Kb_CMatch = True

IssuesDB = [
  {
    "Title": "DC uploading failed due to cyc_cfs full",
    "Reference": "LKB#182353: TEE-869, TEE-908, TEE-937",
    "OE_range_start" : "1.0.4.0.5.003",
    "OE_range_end" : "1.0.4.0.5.003",
    "Jnlctl": [{"log_identifier": "bsc-coredump_sweep", "keyword": "Failed to move it due to not enough space on /cyc_cfs", "min_count": "1"}],
    "Commands": []
  },
  {
    "Title": "Datapath rolling restarts due to deduplication issue",
    "Reference": "LKB#181399: TEE-870",
    "OE_range_start" : "1.0.4.0.5.003",
    "OE_range_end" : "1.0.4.0.5.003",
    "Jnlctl": [{"log_identifier": "xtremapp", "keyword": "(dedupeFlushsetEntry.targetIndex == (0xFFFF)) && (dedupeFlushsetEntry.destLocation == (uint64_t)mergeResult[i].cacheBlock)", "min_count": "1"}],
    "Commands": [{"cmd_type": "custom", "mode": "online", "cmd": "docker exec cyc_bsc_docker /cyc_bsc/datapath/bin/cli.py  mapper config_get --name mapper_dedupe_state | grep mapper_dedupe_state", "keyword": "0", "run_on_node": "both"}]
  },
  {
    "Title": "Daily Data Collection no longer running on an appliance",
    "Reference": "LKB#181570: TEE-895, TEE-640",
    "OE_range_start" : "1.0.4.0.5.003",
    "OE_range_end" : "1.0.4.0.5.003",
    "Jnlctl": [{"log_identifier": "schedule_subsystem", "keyword": "No entries", "min_count": "1"}],
    "Commands": [{"cmd_type": "stored", "cmd": "hung_process_log_check", "log_identifier": "schedule_subsystem", "hours_no_entries": "30", "keyword": "No log entries in first"}]
  },
  {
    "Title": "Node Reboot Due to MD Driver Timeout",
    "Reference": "LKB#182294: TEE-893",
    "OE_range_start" : "1.0.4.0.5.006",
    "OE_range_end" : "1.0.4.0.6.140",
    "Jnlctl": [{"log_identifier": "kernel", "keyword": "regex:task md:[0-9]+ blocked for more than 600 seconds", "min_count": "1"}],
    "Commands": []
  },
  {
    "Title": "Modification of the management network IPs may fail",
    "Reference": "LKB#182373: TEE-918",
    "OE_range_start" : "",
    "OE_range_end" : "",
    "Jnlctl": [{"log_identifier": "control-path", "keyword": "encountered an error when processing an update Ip Address request from this appliance", "min_count": "1"}],
    "Commands": []
  },
  {
    "Title": "PM1643 or PM1643A drives locked",
    "Reference": "LKB#132949: MDT-151179",
    "OE_range_start" : "",
    "OE_range_end" : "",
    "Jnlctl": [{"log_identifier": "cyc_bsc", "keyword": "exception:ComPacket length is zero", "min_count": "1"}],
    "Commands": []
  },
  {
    "Title": "I/O Errors with status=0x7d1 gainst the cache drives",
    "Reference": "LKB#131576",
    "OE_range_start" : "",
    "OE_range_end" : "",
    "Jnlctl": [{"log_identifier": "kernel", "keyword": "status=0x7d1", "min_count": "1"}],
    "Commands": []
  },
  {
    "Title": "Loss of Cluster management after Data Path transitions",
    "Reference": "LKB#126293 | 180321: MDT-164535",
    "OE_range_start" : "",
    "OE_range_end" : "",
    "Jnlctl": [{"log_identifier": "cyc-cluster-master", "keyword": "REINDEX metrics schema", "min_count": "1"}],
    "Commands": []
  },
  {
    "Title": "Unexpected node reboot due to failhandler failure",
    "Reference": "LKB#180125: TEE-682 TEE-888 TEE-803 TEE-1063",
    "OE_range_start" : "1.0.4.0.5.006",
    "OE_range_end" : "",
    "Jnlctl": [{"log_identifier": "ha_monitor_bsc", "keyword": "BSCFailHandler@BSCFailHandler", "min_count": "1"}, {"log_identifier": "bsc-fail_handler", "keyword": "BSCFailHandler", "min_count": "1"}],
    "Commands": []
  },
  {
    "Title": "Node recovery of critical temp is not completed",
    "Reference": "LKB#181272: MDT-153773",
    "OE_range_start" : "1.0.3.0.5.007",
    "OE_range_end" : "1.0.3.0.5.007",
    "Jnlctl": [{"log_identifier": "xtremapp", "keyword": "single node 9 temp critical for more than a minute", "min_count": "1"}, {"log_identifier": "xtremapp-pm", "keyword": "node_reconnect for csid 9 completed with status msg_connection_error", "min_count": "1"}],
    "Commands": []
  },
  {
    "Title": "Namespace corruption detected after volume deletion",
    "Reference": "LKB#180457: MDT-216193",
    "OE_range_start" : "",
    "OE_range_end" : "",
    "Jnlctl": [{"log_identifier": "xtremapp", "keyword": "Detected corruption in tier", "min_count": "1"}],
    "Commands": []
  },
  {
    "Title": "Platform DARE CDR drives check failed",
    "Reference": "LKB#180962: TEE-834",
    "OE_range_start" : "1.0.4.0.5.003",
    "OE_range_end" : "1.0.4.0.5.003",
    "Jnlctl": [{"log_identifier": "cyc_puhc", "keyword": "Platform DARE CDR drives check failed", "min_count": "1"}],
    "Commands": []
  },
  {
    "Title": "NDU Retry Failed with Out of Space",
    "Reference": "LKB#181274: MDT-190467",
    "OE_range_start" : "",
    "OE_range_end" : "",
    "Jnlctl": [{"log_identifier": "cyc_upgrade", "keyword": "no space left on device", "min_count": "1"}],
    "Commands": []
  },
  {
    "Title": "NDU failure during P4U_M and BU_M",
    "Reference": "LKB#180521: MDT-225042",
    "OE_range_start" : "",
    "OE_range_end" : "",
    "Jnlctl": [{"log_identifier": "xtremapp", "keyword": "NDU failed during stage: SYM_NDU_WAIT_FOR_CP_TO_PREPARE_SDNAS", "min_count": "1"}],
    "Commands": []
  },
  {
    "Title": "0x00302006 slot 24 cannot be determined",
    "Reference": "LKB#128574 | 179969: TEE-590 MDT-141071 MDT-206600",
    "OE_range_start" : "1.0.3.0.5.007",
    "OE_range_end" : "1.0.3.0.5.007",
    "Jnlctl": [{"log_identifier": "xtremapp", "keyword": "signature mismatch", "min_count": "1"}],
    "Commands": []
  },
  {
    "Title": "Formatting Windows volumes 2 TB lead to node reboots",
    "Reference": "LKB#180636: TEE-703",
    "OE_range_start" : "1.0.3.0.5.007",
    "OE_range_end" : "1.0.3.0.5.007",
    "Jnlctl": [{"log_identifier": "xtremapp", "keyword": "LayeredServiceScsiGetLBAStatusRequest", "min_count": "1"}],
    "Commands": []
  },
  {
    "Title": "Upgrade failure with the error code 0xE04030010003",
    "Reference": "LKB#182394: TEE-976",
    "OE_range_start" : "Foothills",
    "OE_range_end" : "Foothills",
    "Jnlctl": [{"log_identifier": "control-path", "keyword": "SDNAS: Node Upgrade Failed. Error in call to ansible REST Call", "min_count": "1"}],
    "Commands": []
  },
  {
    "Title": "PANIC in DEBUC CLIENT",
    "Reference": "LKB#182596",
    "OE_range_start" : "1.0.4.0.5.003",
    "OE_range_end" : "1.0.4.0.5.006",
    "Jnlctl": [{"log_identifier": "debuc_client", "keyword": "PANIC in DEBUC CLIENT", "min_count": "1"}],
    "Commands": []
  },
  {
    "Title": "Guest OS install failure on VM using a PowerstoreT",
    "Reference": "LKB#182665: VMware KB 2137402 TEE-1078",
    "OE_range_start" : "",
    "OE_range_end" : "",
    "Jnlctl": [{"log_identifier": "xtremapp", "keyword": "size exceeding MAX TRANSFER SIZE", "min_count": "1"}],
    "Commands": []
  },
  {
    "Title": "NAS Installation failed due to Cluster IP unreachable",
    "Reference": "LKB#130218: TEE-558 TEE-380 MDT-138600",
    "OE_range_start" : "",
    "OE_range_end" : "",
    "Jnlctl": [{"log_identifier": "nas_preinstall", "keyword": "FATAL ERROR: Check connectivity of ICM network", "min_count": "1"}],
    "Commands": []
  },
  {
    "Title": "The system encountered unexpected backend errors",
    "Reference": "LKB#131938: TEE-450 MDT-188170",
    "OE_range_start" : "1.0.3.0.5.007",
    "OE_range_end" : "1.0.3.0.5.007",
    "Jnlctl": [{"log_identifier": "control-path", "keyword": "503 Service Unavailable", "min_count": "1"}],
    "Commands": []
  },
  {
    "Title": "detailed DC results in 0 GB with SUCCESS",
    "Reference": "LKB#126689: TEE-404 MDT-181078",
    "OE_range_start" : "",
    "OE_range_end" : "",
    "Jnlctl": [{"log_identifier": "dc_engine", "keyword": "Unable to run cmd", "min_count": "1"}],
    "Commands": []
  },
  {
    "Title": "PUHC failed with Storage Migration In Progress",
    "Reference": "LKB#133102: TEE-389, MDT-140202",
    "OE_range_start" : "",
    "OE_range_end" : "",
    "Jnlctl": [{"log_identifier": "cyc_puhc", "keyword": "Failed to determine ICM cluster IP from /cyc_var/security/clusterInfo.json", "min_count": "1"}],
    "Commands": []
  },
  {
    "Title": "Node panic with code 0x340402e",
    "Reference": "LKB#133517: TEE-743 TEE-341 MDT-135305",
    "OE_range_start" : "1.0.3.0.5.007",
    "OE_range_end" : "1.0.3.0.5.007",
    "Jnlctl": [{"log_identifier": "panic_log", "keyword": "panic_code=0x340402e", "min_count": "1"}],
    "Commands": []
  },
  {
    "Title": "Unexpected reboot due to systemd-tmpfiles-clean.service",
    "Reference": "LKB#129743: TEE-376 TEE-507 TEE-569 TEE-658 TEE-679 TEE-711 TEE-718 TEE-755",
    "OE_range_start" : "1.0.2.0.6.119",
    "OE_range_end" : "1.0.3.0.5.007",
    "Jnlctl": [{"log_identifier": "bsc-fail_handler", "keyword": "detected failure of systemd-tmpfiles-clean", "min_count": "1"}],
    "Commands": []
  },
  {
    "Title": "No longer receiving responses regarding the creation",
    "Reference": "LKB#131062: TEE-402 TEE-403 TEE-410",
    "OE_range_start" : "1.0.3.0.5.007",
    "OE_range_end" : "1.0.3.0.5.007",
    "Jnlctl": [{"log_identifier": "cyc_postgres_ha", "keyword": "ZMQ Server is not ready", "min_count": "1"}, {"log_identifier": "cyc_pacemaker_proxy", "keyword": "ZMQ Server is not ready", "min_count": "1"}],
    "Commands": []
  },
  {
    "Title": "Node offline or service mode on 3 or 4 appliance cluster",
    "Reference": "LKB#126027: MDT-162392",
    "OE_range_start" : "",
    "OE_range_end" : "",
    "Jnlctl": [{"log_identifier": "xtremapp", "keyword": "IoRequestWatchdog", "min_count": "1"}],
    "Commands": []
  },
  {
    "Title": "Blocked threads on NAS docker",
    "Reference": "LKB#130646: MDT-152927",
    "OE_range_start" : "",
    "OE_range_end" : "",
    "Jnlctl": [],
    "Commands": [{"cmd_type": "stored", "cmd": "zgrep", "zgrep_keyword": "blocked", "zgrep_path": "/var/log/sdnas/sdnas_logs/sdnas.log*", "keyword": "BLOCKED for", "run_on_node": "both"}]
  },
  {
    "Title": "After a node reboot DC is no longer being sent",
    "Reference": "LKB#130745: MDT-162773",
    "OE_range_start" : "1.0.3.0.5.007",
    "OE_range_end" : "1.0.3.0.5.007",
    "Jnlctl": [{"log_identifier": "cyc_eve", "keyword": "Cyclone Eve post stop", "min_count": "1"}],
    "Commands": []
  },
  {
    "Title": "SupportAssist fails with Error 401: Unauthorized",
    "Reference": "LKB#183602: TEE-1074 TEE-1086 TEE-1088",
    "OE_range_start" : "",
    "OE_range_end" : "",
    "Jnlctl": [{"log_identifier": "control-path", "keyword": "Universal-HMac_Validation-Authorization_Failure_Not_Authorized_401", "min_count": "1"}],
    "Commands": []
  },
  {
    "Title": "Error 0xE03010040010 when adding a StorageCenter",
    "Reference": "LKB#183460",
    "OE_range_start" : "",
    "OE_range_end" : "",
    "Jnlctl": [{"log_identifier": "control-path", "keyword": "Addition of StorageCenter remote system failed due to internal error", "min_count": "1"}],
    "Commands": []
  },
  {
    "Title": "Platform service cannot run after adding new drives",
    "Reference": "LKB#187118: MDT-261784, TEE-1141",
    "OE_range_start" : "",
    "OE_range_end" : "",
    "Jnlctl": [{"log_identifier": "xtremapp-trace_collector", "keyword": "Error: trace_collector did not find device /dev/ppds/PL_TA!", "min_count": "1"}],
    "Commands": []
  },
  {
    "Title": "Cutover fails after HA happens during sync operation",
    "Reference": "LKB#188023: MDT-281010",
    "OE_range_start" : "",
    "OE_range_end" : "",
    "Jnlctl": [{"log_identifier": "control-path", "keyword": "got error: Encountered an irrecoverable error during command execution, Reason obj_not_found", "min_count": "1"}, {"log_identifier": "control-path", "keyword": "error: STATUS_OBJECT_NOT_FOUND", "min_count": "1"}],
    "Commands": []
  },
  {
    "Title": "Node Reboot Unexpectedly from a Linux Driver Memory Leak",
    "Reference": "LKB#185532: MDT-261192",
    "OE_range_start" : "1.0.4.0.5.006",
    "OE_range_end" : "1.0.4.0.5.006",
    "Jnlctl": [{"log_identifier": "kernel", "keyword": "REPORT LUNS got", "min_count": "1"}],
    "Commands": []
  },
  {
    "Title": "SupportAssist Failure due to Error of SRS secret",
    "Reference": "LKB#184564",
    "OE_range_start" : "2.0.0.0",
    "OE_range_end" : "2.0.0.0",
    "Jnlctl": [{"log_identifier": "control-path", "keyword": "Error during retrieval of srs secret", "min_count": "1"}],
    "Commands": []
  },
  {
    "Title": "Expansion enclosure not supported after 2.0.X",
    "Reference": "LKB#192167: TEE-1673, TEE-2356",
    "OE_range_start" : "2.0.0.0",
    "OE_range_end" : "2.1.0.0",
    "Jnlctl": [{"log_identifier": "control-path", "keyword": "0x0030CA02", "min_count": "1"}],
    "Commands": []
  },
  {
    "Title": "SYM_NDU_WAIT_FOR_CP_TO_PREPARE_SDNAS network issue",
    "Reference": "LKB#192316: TEE-2222, TEE-2203",
    "OE_range_start" : "2.0.0.0",
    "OE_range_end" : "2.0.0.0",
    "Jnlctl": [{"log_identifier": "xtremapp", "keyword": "SYM_NDU_WAIT_FOR_CP_TO_PREPARE_SDNAS", "min_count": "1"}],
    "Commands": []
  },
  {
    "Title": "SupportAssist fails due to lockbox info missing",
    "Reference": "LKB#192152: TEE-2352",
    "OE_range_start" : "",
    "OE_range_end" : "",
    "Jnlctl": [{"log_identifier": "cyc_eve", "keyword": "Failed to retrieve the zip provisioning password", "min_count": "1"}],
    "Commands": []
  },
  {
    "Title": "Unable to upload an upgrade package",
    "Reference": "LKB#190884",
    "OE_range_start" : "",
    "OE_range_end" : "",
    "Jnlctl": [{"log_identifier": "control-path", "keyword": "This package is already uploaded on the system", "min_count": "1"}],
    "Commands": []
  },
  {
    "Title": "Vipr SRM unable to fetch latest data via RestAPI",
    "Reference": "LKB#192269: TEE-2390",
    "OE_range_start" : "",
    "OE_range_end" : "",
    "Jnlctl": [{"log_identifier": "postgres_cluster", "keyword": "for writing: Permission denied", "min_count": "1"}],
    "Commands": []
  },
  {
    "Title": "SYM module may restart every 75 days",
    "Reference": "LKB#191594: TEE-2107",
    "OE_range_start" : "2.0.1.1",
    "OE_range_end" : "2.0.1.1",
    "Jnlctl": [{"log_identifier": "xtremapp", "keyword": "couldn't get the object from the mom (type=", "min_count": "1"}],
    "Commands": []
  },
  {
    "Title": "NDU fails at NEW_SYM_NDU_WAIT_FOR_DP_READY",
    "Reference": "LKB#192288: TEE-2223, TEE-2306, TEE-2309",
    "OE_range_start" : "",
    "OE_range_end" : "",
    "Jnlctl": [{"log_identifier": "xtremapp", "keyword": "NEW_SYM_NDU_WAIT_FOR_DP_READY", "min_count": "1"}],
    "Commands": []
  },
  {
    "Title": "NDU to 2.0.1.0 stops at 20%",
    "Reference": "LKB#192238: TEE-2213, TEE-2283",
    "OE_range_start" : "",
    "OE_range_end" : "",
    "Jnlctl": [{"log_identifier": "xtremapp", "keyword": "handle_wait_interval:1028: CP Ping for Node A not received in 600 seconds", "min_count": "1"}],
    "Commands": []
  },
  {
    "Title": "NDU failed at stage SYM_NDU_VERIFY_NDU_CAN_RUN",
    "Reference": "LKB#192244: TEE-2249, TEE-2250",
    "OE_range_start" : "",
    "OE_range_end" : "",
    "Jnlctl": [{"log_identifier": "xtremapp", "keyword": "TRINDU_FLOW_ERR: NDU failed during stage: SYM_NDU_VERIFY_NDU_CAN_RUN", "min_count": "1"}],
    "Commands": []
  },
  {
    "Title": "D@RE Encryption key issue",
    "Reference": "LKB#191410, 191004, 191634: TEE-2250",
    "OE_range_start" : "2.0.1.0",
    "OE_range_end" : "2.0.1.0",
    "Jnlctl": [{"log_identifier": "cyc_puhc", "keyword": "dare drive no key failed", "min_count": "1"}],
    "Commands": []
  },
  {
    "Title": "Metadata conversion issue may cause performance issue",
    "Reference": "LKB#192141: TEE-1818 | LKB#189103",
    "OE_range_start" : "",
    "OE_range_end" : "",
    "Jnlctl": [{"log_identifier": "control-path", "keyword": "DATA_PATH_SCHEDULE_MAPPER_RECOVERY_LATER", "min_count": "1"}],
    "Commands": []
  },
  {
    "Title": "Adding new drives to SPE may cause panic",
    "Reference": "LKB#191693",
    "OE_range_start" : "",
    "OE_range_end" : "",
    "Jnlctl": [{"log_identifier": "xtremapp-pm", "keyword": "written SYM MD file magic <>", "min_count": "1"}],
    "Commands": []
  },
  {
    "Title": "SAS Controller Hardware Lockup",
    "Reference": "LKB#130333: TEE-1682, TEE-1201,TEE-2160, TEE_2268",
    "OE_range_start" : "2.0.0.0",
    "OE_range_end" : "2.0.0.0",
    "Jnlctl": [{"log_identifier": "kernel", "keyword": "sas_exm_handle_timeout", "min_count": "1"}],
    "Commands": []
  },
  {
    "Title": "PowerstoreX node reboots due to credential failure",
    "Reference": "LKB#185103: TEE-961 | LKB#187988",
    "OE_range_start" : "",
    "OE_range_end" : "",
    "Jnlctl": [{"log_identifier": "policy", "keyword": "cyc_ssh_credentials_control.service has failed", "min_count": "1"}],
    "Commands": []
  },
  {
    "Title": "Failed to collect DC in FHC No such file or directory",
    "Reference": "LKB#190373: TEE-1688, TEE-1962",
    "OE_range_start" : "",
    "OE_range_end" : "",
    "Jnlctl": [{"log_identifier": "service_fireman", "keyword": "[Errno 2] No such file or directory", "min_count": "1"}],
    "Commands": []
  },
  {
    "Title": "Stop reporting capacity metrics for an appliance",
    "Reference": "LKB#184448: TEE-1196",
    "OE_range_start" : "1.0.3.0.5.007",
    "OE_range_end" : "1.0.3.0.5.007",
    "Jnlctl": [{"log_identifier": "control-path", "keyword": "Received ping error: The source did not signal an event", "min_count": "1"}],
    "Commands": []
  },
  {
    "Title": "Replication setting failed due to cluster name too long",
    "Reference": "LKB#190527: TEE-2028",
    "OE_range_start" : "2.1.0.0",
    "OE_range_end" : "2.1.0.0",
    "Jnlctl": [{"log_identifier": "xtremapp", "keyword": "Proto string is too long", "min_count": "1"}],
    "Commands": []
  },
  {
    "Title": "Polling failed for internal M.2 boot module in slot 1",
    "Reference": "LKB#185738",
    "OE_range_start" : "",
    "OE_range_end" : "",
    "Jnlctl": [{"log_identifier": "xtremapp-pm", "keyword": "Fail to poll local disks status from ESX", "min_count": "1"}],
    "Commands": []
  },
]

def troubleshooting_format_luns(lun_dets,lun_title,lun_title_fill,r):
     lun_dets[0]=lun_title_fill+lun_dets[0]
     lun_dets[1]=lun_title+lun_dets[1]
     lun_dets[2]=lun_title_fill+lun_dets[2]
     rows,lun_end=0,''
     while len(lun_dets[1])>(g.terminal_width-4):
        pos=(g.terminal_width-4)
        word=lun_dets[1][:pos]
        split=word.rfind('[')
        if rows ==3:
           lun_end='...'
           lun_dets[0]=lun_dets[0][:split]
           lun_dets[1]=lun_dets[1][:split]
           lun_dets[2]=lun_dets[2][:split]
        else:
           lun_dets[0], folded0=lun_dets[0][split:],lun_dets[0][:pos]
           lun_dets[1], folded1=lun_dets[1][split:],lun_dets[1][:split]
           lun_dets[2], folded2=lun_dets[2][split:],lun_dets[2][:pos]
           if folded0: r.dp_grid_ad([folded0],2)
           r.dp_grid_ad([folded1],2)
           if folded2:r.dp_grid_ad([folded2],2)
           rows+=1

     if lun_dets[0]:r.dp_grid_ad([lun_dets[0]],2)
     r.dp_grid_ad([lun_dets[1]+lun_end],2)
     if lun_dets[2]:r.dp_grid_ad([lun_dets[2]],2)

def troubleshooting_extract_identifier(lst):
    return [item[0]['log_identifier'] for item in lst]

def troubleshooting_known_issues() :
            global g
            global r
            global current_mode
            global appliance_info
            global IssuesDB
            r.dp_break()
            r.write=False
            if g.known_issues_loaded == False:
                if not options.known_issues_oe: IssuesDB = [issue_db_f for issue_db_f in IssuesDB if (not issue_db_f['OE_range_start'] or LooseVersion(appliance_info.Code) < LooseVersion(issue_db_f['OE_range_start'])) and (not issue_db_f['OE_range_end'] or LooseVersion(appliance_info.Code) < LooseVersion(issue_db_f['OE_range_end']))]
                for issue in IssuesDB:
                    g.ki_id+=1
                    for jnl in issue["Jnlctl"]:
                        jnl['ID'] = g.ki_id
                        jnl['kb_match'] = 'False'
                        jnl['count'] = 0
                        jnl['keyword'] = troubleshooting_regex_converter(jnl['keyword'])
                    issue["Commands"] = [cmd for cmd in issue["Commands"] if not 'mode' in cmd or cmd['mode']==current_mode['mode_type']]
                    for cmd in issue["Commands"]:
                        cmd['ID'] = g.ki_id
                        cmd['kb_match'] = 'False'
                        cmd['keyword'] = troubleshooting_regex_converter(cmd['keyword'])
                    g.known_issues.append(known_issue(g.ki_id, issue["Title"], issue["Reference"], issue["OE_range_start"], issue["OE_range_end"], issue['Jnlctl'], issue["Commands"]))
                g.known_issues_loaded = True
            jrnlList = []
            for ki in g.known_issues:
                for item in ki.Journal:
                    item['count'] = 0
                jrnlList.extend(ki.Journal)
                ki.Journal = []
            result = collections.defaultdict(list)
            for d in jrnlList:
                result[d['log_identifier']].append(d)
            result_list = list(result.values())
            result_list_index = 0
            identifier_list = troubleshooting_extract_identifier(result_list)
            journal_range = g.end_of_journal_time - datetime.timedelta(hours=g.settings['time_delta'])
            for identifier in identifier_list:
                r.dp_n_break('Searching ' + identifier + ' logs......')
                keyword_counted = current_mode['journal_reader'](result_list[result_list_index], identifier, journal_range)
                for known_kb in result_list[result_list_index]:
                    if known_kb['count'] >= int(known_kb['min_count']):
                       known_kb['kb_match'] = True
                    for ki in g.known_issues:
                        if known_kb['ID']==ki.ID:
                           ki.Journal.append(known_kb)
                result_list_index+=1
            for ki in g.known_issues:
              for ki_cmd in ki.Commands:
                keycmd = ki_cmd['cmd']
                cmd_dict = {'stored': cmd_stored, 'output_folder': cmd_output_folder, 'custom': cmd_custom}
                output = None
                result_required = ['hung_process_log_check']
                if ki_cmd['cmd_type']:
                   if appliance_info.CurrentNode == 'A':
                      ki_cmd['peer_b'] = current_mode['cmd_on_peer']
                      ki_cmd['peer_a'] = ''
                   else:
                      ki_cmd['peer_a'] = current_mode['cmd_on_peer']
                      ki_cmd['peer_b'] = ''
                   output = cmd_dict[ki_cmd['cmd_type']](ki_cmd)
                   if ki_cmd['cmd_type'] == 'stored' and ki_cmd['cmd'] in result_required: ki_cmd['result']=output
                else:
                   output = cmd_run(keycmd)
                ki_cmd['count'] = len(re.findall(ki_cmd['keyword'], output))
                if ki_cmd['count'] > 0:
                   ki_cmd['kb_match'] = True
            for ki in g.known_issues:
                for jrn in ki.Journal:
                   if jrn['kb_match']=='False':
                      ki.Kb_JMatch = False
                for cmd in ki.Commands:
                   if cmd['kb_match']=='False':
                      ki.Kb_CMatch = False

            r.dp_break()
            r.dp_title('Known Issue Search Results')
            r.dp_break()
            r.dp_break()
            r.write=True
            found = False
            for ki in g.known_issues:
                if ki.Kb_CMatch == True and ki.Kb_JMatch == True:
                   r.dp('Match found for '+ki.Title+' Reference: '+ki.Reference)
                   found = True
                   for item in ki.Journal:
                       r.dp('     - Count for keyword "{:.66}{trail}" is {} in last {} hour(s) of {} logs'.format(str(item['keyword'].replace('\\', '')), str(item['count']), g.settings['time_delta'], str(item['log_identifier']), trail=''if len(item['keyword'])<66 else '~'))
                   for item in ki.Commands:
                       if 'result' in item: r.dp(('     - '+item['result']))
                       else: r.dp('     - Count for keyword "{:.66}{trail}" is {} in command output'.format(item['keyword'].replace('\\', ''), str(item['count']), trail=''if len(item['keyword'])<66 else '~'))
                   if ki.OE_end: r.dp('     - Fix available in '+ki.OE_end)
                   r.dp_break()
            if found == False:
                   r.dp_break()
                   r.dp('Powerstore '+appliance_info.Name+' has no known issues detected')
            r.dp_break()
            r.dp_break()

def troubleshooting_connectivity_block() :
            global g
            global f
            global current_mode
            global json_info
            global formatter
            r.write=False
            load_troubleshooting_connectivity_block_objects()
            journal_range = g.end_of_journal_time - datetime.timedelta(hours=g.settings['time_delta'])
            log_list = next((x for x in g.settings['troubleshooting_logs'] if x['area'] == 'host connectivity troubleshooting-block level'), None)
            r.dp_break()
            r.dp_n_break('Preparing connectivity logs and objects ......')
            for log in log_list['log_name_list']:
                if log.startswith('extract_only:') and g.settings['save_logs']: log=log.replace('extract_only:', '')
                if log.startswith('extract_only:'): continue
                if log.endswith('.txt')and not os.path.exists(g.log_folder+os.path.sep+log): current_mode['cmd_output_folder']({'cmd': log})
                if not log.endswith('.txt')and not os.path.exists(g.log_folder+os.path.sep+log): journalctl_Reader_dump_to_text(log, journal_range)
            r.dp_n_break('Searching kernel logs......')
            logfile = g.log_folder+os.path.sep+'kernel.txt'
            log_read = open(logfile, 'rb')
            for line in log_read:
                 line=line.decode("utf-8", "backslashreplace").strip()
                 logged_initiator=re.search('(?<=Initiator\s)(.*)(?=\sopcode)', line)
                 match_object = re.search('(Check\sCondition)|(TM\sfn\s(?:[A-Z]+)(_[A-Z]+)*\/\d+)', line)
                 try:
                    if match_object.group(1) and re.search('(?<=Initiator\s)(.*)(?=\sopcode)', line):
                       CheckCondition = re.search(r'[A-Za-z0-9]{2}\/[A-Za-z0-9]{2}\/[A-Za-z0-9]{2}', line).group(0)
                       json_info.initiators.get(logged_initiator.group(0), 'null')['check_condition'][CheckCondition]=json_info.initiators.get(logged_initiator.group(0), 'null')['check_condition'].get(CheckCondition, 0)+1
                 except AttributeError: e = 'no match'
                 try:
                   if match_object.group(2):
                      TM_fn = match_object.group(2)[-1]
                      init = re.search(r'(?<=initiator\s)(.*)(?=,\starget)', line).group(0)
                      target = re.search(r'(?<=target\s)(.*)(?=\))', line).group(0)
                      json_info.initiators.get(init, 'null')['error_initiator_target'].setdefault(target, {})[TM_fn]=json_info.initiators.get(logged_initiator.group(0), 'null')['error_initiator_target'].get(target, {}).get(TM_fn, 0)+1
                 except AttributeError:  e = 'no match'

            r.dp_n_break('Searching xtremapp logs......')
            logfile = g.log_folder+os.path.sep+'xtremapp.txt'
            log_read = open(logfile, 'rb')
            for line in log_read:
                 line=line.decode("utf-8", "backslashreplace").strip()
                 match_object = re.search('I\/O operation failure', line)
                 if match_object and re.search("(?<=initiator_name=')(.*)(?=')", line):
                    init = re.search(r"(?<=initiator_name=')(.*)(?=')", line).group(0)
                    json_info.initiators.get(init, 'null')['aborts_timeouts']=json_info.initiators.get(init, 'null').get('aborts_timeouts', 0)+1

            r.dp_break()
            r.dp_title('Host Block Connectivity Results')
            r.write=True
            r.dp_subtitle('Powerstore')
            r.dp_n_break('')
            r.dp_grid_build('spa_ports', 'single', appliance_info.Name+' Node A','outer_grid')
            r.dp_grid_build('spb_ports', 'single', appliance_info.Name+' Node B','outer_grid','on')
            r.dp_grid_ad(['         ','',''],3)
            r.dp_grid_ad(['         ','',''],3,'null','on')
            for Int in sorted(json_info.initiators.values(), key=operator.itemgetter('type', 'port_index','name')):
               if Int['name'].startswith('BaseEnclosure-Node') and not Int.get('wwn', 'null').endswith('bonded'):
                   alt='off' if Int['name'].startswith('BaseEnclosure-NodeA') else 'on'
                   bond_port1,bond_port2,bond_port3,bond_port4,bond_port5='','','','',''
                   if Int['bond_id']:
                      link_b, sfp_state_b, speed_b ='down', 'SFPstate: '+(json_info.initiators[(Int['wwn']+'-bonded')].get('sfp_lifecycle_state', 'null')or'null'),'CurrentSpeed: '+(json_info.initiators[(Int['wwn']+'-bonded')].get('current_speed', 'null')or'null')
                      if json_info.initiators[(Int['wwn']+'-bonded')]['type']=='iscsi': sfp_state_b='MTU: '+str(json_info.initiators[(Int['wwn']+'-bonded')].get('current_mtu', 0))
                      if json_info.initiators[(Int['wwn']+'-bonded')]['is_link_up']:link_b='up'
                      bond_port1,bond_port2,bond_port3,bond_port4,bond_port5=(json_info.initiators[(Int['wwn']+'-bonded')].get('name', 'null')or'null'),'{:^5}'.format(json_info.initiators[(Int['wwn']+'-bonded')].get('type', 'null')or'null'),'LinkState: '+'{:^4}'.format(link_b),speed_b,sfp_state_b
                   link, sfp_state, speed ='down', 'SFPstate: '+(Int.get('sfp_lifecycle_state', 'null')or'null'),'CurrentSpeed: '+(Int.get('current_speed', 'null')or'null')
                   if Int['type']=='iscsi': sfp_state='MTU: '+str(Int.get('current_mtu', 0))
                   if Int['is_link_up']:link='up'
                   r.dp_grid_ad(['Initiator Target: '+(Int.get('wwn', 'null')or'null')],1,'join',alt)
                   r.dp_grid_ad([(Int.get('name', 'null')or'null'),'{:^5}'.format(Int.get('type', 'null')or'null'),'LinkState: '+'{:^4}'.format(link),speed,sfp_state],2,'null',alt)
                   if Int['bond_id']:
                      r.dp_grid_ad([bond_port1,bond_port2,bond_port3,bond_port4,bond_port5],2,'null',alt)
                   check_string1='    CheckCondition:'
                   check_string2=''
                   for check, count in Int['check_condition'].items():
                       check_string2=check_string2+' '+check+'['+str(count)+']'
                   if check_string2 and Int['aborts_timeouts'] > 0: r.dp_grid_ad([(' '+check_string1+check_string2),'',' Aborts/Timeouts[' +str(Int['aborts_timeouts'])+']'],3,'null',alt)
                   elif check_string2: r.dp_grid_ad([(' '+check_string1+check_string2),'',' '],3,'null',alt)
                   elif Int['aborts_timeouts'] > 0:r.dp_grid_ad([' ','',' Aborts/Timeouts[' +str(Int['aborts_timeouts'])+']'],3,'null',alt)
                   r.dp_grid_ad(['         ','',''],3,'null',alt)
            r.dp_grid()
            r.dp_n_break('')
            r.dp_grid(alt)
            r.dp_n_break('')
            r.dp_subtitle('Hosts')


            form={}


            host_length = max(len(x['name']) for x in json_info.host.values())+3
            os_length = max(len(x['os_type']) for x in json_info.host.values())+3
            host_group_length = max(len(x['name']) for x in json_info.host_group.values())+3
            form['host_length'], form['os_length'], form['host_group_length'] =host_length, os_length, host_group_length
            type, seg0, seg1, seg2, seg3, seg4, spread =[], [], [], [], [], [], []
            left_border,left_border_blank,right_border,right_border_blank='| ','  ',' |',''

            lun_g=1
            host_g=0
            for group in json_info.host_group.values():
              if group['name']=='null':host_group='   Hosts(non grouped):  '
              else:host_group='   HostGroup: '+group['name']+' '
              r.dp_grid_build('hosts', 'single', host_group,'outer_grid')
              lun_count=0
              all_luns_length=0
              for lun in group.get('volumes', {}).values():
                  lun_count=lun_count+len(lun)
                  all_luns_length=all_luns_length+(sum(map(len, lun)))
              group['lun_count']=lun_count
              group['all_luns_length']=all_luns_length
              if 'null' in group['volumes']:
                 group['null_volumes']=group['volumes']['null']
                 group['volumes'].pop('null')
              lun_dets=['','','']
              for grp, vol in group['volumes'].items():
                  lun_str=''
                  for v in vol:
                        lun_str=lun_str+'['+v+'] '
                  lun_str_list = r.dp_get_outer_grid([lun_str], border='line_title', title=' '+grp+' ')
                  lun_dets[0] = lun_dets[0]+' '+lun_str_list[0]
                  lun_dets[1] = lun_dets[1]+' '+lun_str_list[1]
                  lun_dets[2] = lun_dets[2]+' '+lun_str_list[2]
              if 'null_volumes' in group:
                 lun_str=''
                 for v in group['null_volumes']:
                     lun_str=lun_str+'['+v+'] '
                 lun_dets[1] = lun_dets[1]+' '+lun_str
              lun_title='LUNs['+str(lun_count)+']:'
              lun_title_fill=(' '*len(lun_title))
              if lun_count>0: troubleshooting_format_luns(lun_dets,lun_title,lun_title_fill,r)

              for hst in group['hosts']:
                  hst_key=list(hst.keys())[0]
                  lun_count=0
                  all_luns_length=0
                  lun1=53
                  lun2=81
                  hst.get(hst_key, {}).setdefault('volumes', {})
                  for lu in hst.get(hst_key, {}).get('volumes', {}).values():
                    lun_count=lun_count+len(lu)
                    all_luns_length=all_luns_length+(sum(map(len, lu)))
                    hst.get(hst_key, 'null')['lun_count']=lun_count
                    if all_luns_length<(lun1+lun2):lun1=50

                  if 'null' in hst.get(hst_key, 'null').get('volumes', {}):
                         hst['null_volumes']=hst.get(hst_key, 'null')['volumes']['null']
                         hst.get(hst_key, 'null')['volumes'].pop('null')

                  lun_dets=['','','']
                  lun_title='LUNs['+str(lun_count)+']:'
                  lun_title_fill=''
                  for sub_vol in hst.get(hst_key, 'null')['volumes']:
                      lun_title_fill=(' '*len(lun_title))
                      lun_str=''
                      for v in vol:
                            lun_str=lun_str+'['+v+'] '

                      lun_str_list = r.dp_get_outer_grid([lun_str], border='line_title', title=' '+grp+' ')
                      lun_dets[0] = lun_dets[0]+' '+lun_str_list[0]
                      lun_dets[1] = lun_dets[1]+' '+lun_str_list[1]
                      lun_dets[2] = lun_dets[2]+' '+lun_str_list[2]
                  if 'null_volumes' in hst:
                      lun_str=''
                      for v in hst['null_volumes']:
                         lun_str=lun_str+'['+v+'] '
                      lun_dets[1] = lun_dets[1]+' '+lun_str
                  host_dets='HOST:'+hst[hst_key]['name']+'  '+'OS:'+hst[hst_key]['os_type']
                  r.dp_grid_ad([''],1)
                  r.dp_grid_ad([host_dets],1)
                  r.dp_grid_ad([''],1)
                  if lun_count>0: troubleshooting_format_luns(lun_dets,lun_title,lun_title_fill,r)
                  r.dp_grid_ad([''],1)
                  for inita in hst.get(hst_key, 'null')['initiators']:
                      requirements=False
                      string_formatt_list =['_'*10,' '*10]
                      #if inita not in json_info.initiators:
                      index=len(json_info.initiators[inita]['target_ports'])
                      host_init= math.floor(index/2)
                      string3=' '*10
                      formatted_init=''
                      gate_access=False
                      for targ in sorted(json_info.initiators[inita]['target_ports'].values()):
                              gap = ' '*13+'|'
                              int_mid=''
                              if not gate_access:
                                 string_formatt_list[0], string_formatt_list[1] = '_'*10+'Type:'+json_info.initiators[inita]['type'], ' '*10+'Initiator: '+json_info.initiators[inita]['wwn']
                                 if json_info.initiators[inita]['aborts_timeouts']: string3 = string3+'Aborts/Timeouts:'+' ['+ str(json_info.initiators[inita]['aborts_timeouts'])+']   '
                                 checkity=False
                                 checkc='CheckCondition: '
                                 for check, count in json_info.initiators[inita]['check_condition'].items():
                                     if checkity: checkc=''
                                     string3 = string3+checkc+check+' ['+str(count)+'] '
                                     checkity=True
                                 string_formatt_list=troubleshooting_formatter_string('PathCount:'+str(json_info.initiators[inita]['path_count']), string_formatt_list)
                                 string_formatt_list=troubleshooting_formatter_string('LinkState:'+'up', string_formatt_list)
                                 gate_access=True
                              if index == (host_init+1): formatted_init, int_mid = string_formatt_list[0], string_formatt_list[1]
                              if index == (host_init): formatted_init = string3
                              error_list=[]
                              initiator_list=[]
                              error_list.append(' Aborts/Timeouts:'+str([x['0'] for y, x in json_info.initiators[inita]['error_initiator_target'].items() if y==targ['address'] and cmd_check_key_value_exist(x, '0')]))
                              error_list.append(' Disconnects:'+str([x['6'] for y, x in json_info.initiators[inita]['error_initiator_target'].items() if y==targ['address'] and cmd_check_key_value_exist(x, '6')]))
                              r.dp_grid_ad([targ['short_name']+':'+"{:<6}".format(json_info.initiators[inita]['type'])+troubleshooting_formatter(error_list), 'LoggedIn:'+"{:<3}".format(targ['logged_in'])+' |', formatted_init],3,'center')
                              if index==1:
                                 gap=''
                              r.dp_grid_ad([' ',gap,int_mid],3,'center')
                              if len(json_info.initiators[inita]['target_ports'])==1 and string3: r.dp_grid_ad([' ', ' ', string3],3,'center')
                              index=index-1
                              formatted_init=''

              if len(group['hosts'])>0:r.dp_grid()


def troubleshooting_formatter_string(string, list):
     orig=min(list, key=len)
     string=orig+'   '+string
     new_list =[string if x==orig else x for x in list]
     return new_list

def troubleshooting_formatter(list) :
    formated_line=''
    end=''
    for string in list:
        if string.endswith(':[]'): end = end+(26*'-')
        else:
           fill = '-'*(math.trunc(26-len(string))/2)
           formated_line = formated_line+fill+string+fill
    return formated_line+end

def troubleshooting_connectivity_file() :
            r.dp_title('IN DEVELOPMENT')

def troubleshooting_ndu() :
            r.dp_title('IN DEVELOPMENT')

################################################################################################################################
# DIRECTORY_&_FILE_MANAGEMENT_MODULE dirofile_
################################################################################################################################

def dirofile_log_cleanup():
     global g
     global parimiko_active
     if not g.settings['save_logs'] and not g.settings['save_analysis']:
        shutil.rmtree(g.log_folder)
     elif g.settings['save_logs']:
        files_list = os.listdir(g.log_folder)
        if files_list:
           r.dp_subtitle('Finalizing logs')
           r.dp_break()
           if os.path.exists(g.analysis_file):
              shutil.move(g.analysis_file, g.log_folder)
              r.dp_n_break('Analysis report: '+g.analysis_file)
              r.dp_n_break('Moving analysis report to archive.')
           shutil.make_archive(g.log_folder, 'tar', g.log_folder)
           r.dp_n_break('Extracting logs and moving to archive')
           r.dp_n_break('Analysis Report and extracted logs: '+g.log_folder+'.tar')
        shutil.rmtree(g.log_folder)
        if g.settings['autoftp']and files_list and parimiko_active: ftp_transfer(os.getcwd()+os.path.sep+g.log_folder+'.tar')
     elif os.path.exists(g.log_folder):
            shutil.rmtree(g.log_folder)
            if os.path.exists(g.analysis_file):
               r.dp_n_break('Analaysis report: '+g.analysis_file)


def dirofile_make_tarfile(output_filename, source_dir):
    with tarfile.open(output_filename, "w:gz") as tar:
        tar.add(source_dir, arcname=os.path.basename(source_dir))
    shutil.rmtree(source_dir)


################################################################################################################################
# GENERAL_PURPOSE_FUNCTIONS
################################################################################################################################

class global_info:
    def __init__(self):
        global settings
        self.online = False
        self.offline = False
        self.ki_id = 1000
        self.terminal_width = settings_term_check()
        self.end_of_journal_time = datetime.datetime.now()
        self.log_folder = ''
        self.analysis_file =''
        self.settings = settings
        self.required_logs = []
        self.known_issues = []
        self.known_issues_loaded = False
        self.host_block_connectivity = []
        self.host_block_connectivity_loaded = False
        self.initiators = []
        self.hosts =[]
        self.volumes = []
        self.join_enabled=True





class json_data:
    def __init__(self):
        self.host={}
        self.host_group={}
        self.host_volume_mapping={}
        self.host_combined_cma_view={}
        self.config_item={}
        self.volume_group={}
        self.volume={}
        self.volume_group_volume_view={}
        self.fc_eth_port_view={}
        self.hardware={}
        self.ip_port={}
        self.audit_event={}
        self.initiators={}
        self.hosts={}
        self.volumes ={}
        self.active_session={}
        self.initiator_active_session_association={}

class appliance_information:
    def __init__(self, Name, Primary, CurrentNode, ServiceTag, Model, Code, MgmtIp, SshEnabled, DareEnabled):
        self.Name = Name
        self.Primary = Primary
        self.CurrentNode = CurrentNode
        self.ServiceTag = ServiceTag
        self.Model = Model
        self.Code = Code
        self.MgmtIp = MgmtIp
        self.SshEnabled = SshEnabled
        self.DareEnabled = DareEnabled

class initiator:
    def __init__(self, Name, PortType, PortAddress, State, Host_id):
        self.Name = Name
        self.PortType = PortType
        self.PortAddress = PortAddress
        self.PathCount = 0
        self.TargetPorts = []
        self.LinkState=''
        self.State=State
        self.SFPPart=''
        self.Speed=''
        self.Mtu=''
        self.Host_id = Host_id
        self.CheckCondition = []
        self.Aborts_Timeouts = 0
        self.Error_from_Target= []

class host:
    def __init__(self, Name, ID, Uuid, GroupId, GroupUuid, Volumes, OS):
        self.Name = Name
        self.ID = ID
        self.Uuid = Uuid
        self.GroupId = GroupId
        self.GroupUuid = GroupUuid
        self.Volumes = Volumes
        self.OS = OS

def format_code(text):
   try:
          if not isinstance(text, unicode):
                 text=text.decode("utf-8", "backslashreplace").strip()
                 return text
          else: return text
   except Exception as e:
          print('fail')
          return text

def pfd_exit() :
    r.dp_title('Powerstore Fault Detection Script Complete')
    sys.exit()

def load_appliance_info() :
    global appliance_info
    global current_mode
    output = current_mode['command_method'](current_mode['svc_diag_list_info'])
    troubleshooting_check = [x['opt_parse'] for x in g.settings['troubleshooting_logs']]
    if current_mode['mode_type'] == 'online':
       output = output.decode("utf-8", "backslashreplace").strip()
       output = output.split('\n')
    appliance_info = appliance_information(output[1].split(': ')[-1], output[8].split(': ')[-1], output[0].split(': ')[-1], output[2].split(': ')[-1], output[3].split(': ')[-1], output[4].split(': ')[-1], output[5].split(': ')[-1], output[9].split(': ')[-1], output[10].split(': ')[-1])

def load_troubleshooting_connectivity_block_objects():
            global g
            global current_mode
            global json_info
            if current_mode['mode_type'] == 'online':
               os.mkdir(g.log_folder+os.path.sep+'ac_e')
               os.mkdir(g.log_folder+os.path.sep+'ac_i')
               os.system('svc_arrayconfig run -f json -o '+g.log_folder+os.path.sep+'ac_e'+' -t full -c /cyc_host/cyc_service/conf/ConfigCaptureConfig_Extended.json </dev/null &>/dev/null')
               os.system('svc_arrayconfig run -f json -o '+g.log_folder+os.path.sep+'ac_i'+' -t full -c /cyc_host/cyc_service/conf/ConfigCaptureConfigInternalManagement.json </dev/null &>/dev/null')
            capture = ['host.json', 'host_group.json', 'volume_id;volume_group_volume_view.json', 'config_item.json','volume_group.json', 'volume.json' , 'host_volume_mapping.json', 'host_combined_cma_view.json', 'fc_eth_port_view.json', 'hardware.json', 'ip_port.json', 'audit_event.json', 'active_session.json', 'initiator_port_name;initiator_active_session_association.json']
            result = cmd_get_config_capture_files(capture)
            if current_mode['mode_type'] == 'online':shutil.rmtree(g.log_folder+os.path.sep+'ac_e'), shutil.rmtree(g.log_folder+os.path.sep+'ac_i')
            for port in json_info.ip_port.values():
                if port['eth_port_id']:json_info.fc_eth_port_view[port['eth_port_id']]['wwn']=port['target_iqn']
                if port['bond_id']:
                    bonded=''
                    for item in (sorted(json_info.fc_eth_port_view.values(), key=operator.itemgetter('port_index','name'))):
                             if item['bond_id'] == port['bond_id']:
                                    item['wwn']=port['target_iqn']+bonded
                                    bonded='-bonded'
                                    g.join_enabled=False
            for port in json_info.fc_eth_port_view.values():
                if port['type']=='eth':port['sfp_lifecycle_state'],port['sfp_part_number'],port['type']='null', 'null','iscsi'
                port['check_condition'],port['aborts_timeouts'],port['error_initiator_target'] ={},0,{}
                if port['type']=='fc':
                        sfp = next(item for item in json_info.hardware.values() if item["id"] == port["sfp_id"])
                        port['sfp_lifecycle_state'],port['sfp_part_number']=(sfp.get('lifecycle_state', 'null')or'null'),(sfp.get('part_number', 'null')or'null')
                if port['wwn']: json_info.initiators.setdefault(port['wwn'], {}).update(port)
            for association in json_info.initiator_active_session_association.values():
                 port_add, port_type, path_count, target_ports = association['initiator_port_name'], '', 0, {}
                 for session in json_info.active_session.values():
                     if association['active_session_id']==session['id']:
                        tar_address,short_name,tar_name=session['port_name'],'null','null'
                        if tar_address in json_info.initiators:
                           logged_in='Yes'
                           path_count+=1
                           port_type=json_info.initiators[tar_address]['type']
                           tar_name=json_info.initiators[tar_address]['name']
                           short_name = re.search('(?<=Node)(A|B).*?([0-9]{1,2}$)', tar_name).group(1)+re.search('(?<=Node)(A|B).*?([0-9]{1,2}$)', tar_name).group(2)
                           target_ports[tar_address]={'name':tar_name,'short_name':short_name,'address':tar_address, 'logged_in':logged_in}
                 paths={'wwn': port_add,'type': port_type, 'node_id': 'host', 'name': 'host','port_index': 0,'path_count': path_count, 'target_ports': target_ports, 'check_condition': {},'aborts_timeouts': 0, 'error_initiator_target':{}}
                 json_info.initiators.setdefault(port_add, {}).update(paths)
            for entry in json_info.volume.values():
                if entry['id'] in json_info.volume_group_volume_view:
                        entry['volume_group_id'], entry['volume_group_name']=json_info.volume_group_volume_view[entry['id']].get('volume_group_id', 'null')or'null', json_info.volume_group_volume_view[entry['id']].get('volume_group_name', 'null')or'null'
                else: entry['volume_group_id'], entry['volume_group_name']='null','null'
            json_info.volume_group.setdefault('null',{})['id'],json_info.volume_group.setdefault('null',{})['name']='null','null'
            for entry in json_info.config_item.values():
                if entry['type']=='INITIATOR':
                          if json_info.config_item[entry['data']['host_id']]['data']['host_type']=='EXTERNAL':
                             h_id=json_info.config_item[entry['data']['host_id']]['data']['host_uuid']
                             json_info.host[h_id].setdefault('initiators', [])
                             json_info.host[h_id]['initiators'].append(entry['data']['port_name'])
                             if entry['data'].get('port_name') not in json_info.initiators:
                                target_ports,port_add={},entry['data'].get('port_name')
                                target_ports['null']={'name':'null','short_name':'~~','address':'null', 'logged_in':'No'}
                                paths={'wwn': port_add,'type': (entry['data'].get('port_type')).lower(), 'node_id': 'host', 'name': 'host','port_index': 0,'path_count': 0, 'target_ports': target_ports, 'check_condition': {},'aborts_timeouts': 0, 'error_initiator_target':{}}
                                json_info.initiators.setdefault(port_add, {}).update(paths)
            json_info.host_group.setdefault('null', {})['id'],json_info.host_group.setdefault('null', {})['name']='null','null'
            for group in json_info.host_group.values():
                group.setdefault('volumes', {})
                group.setdefault('hosts', [])
            for map in json_info.host_volume_mapping.values():
                if (map.get('host_type', 'null')or'null')!='Restricted':
                   if (map.get('host_group_id', 'null')or'null')!='null':
                       json_info.host_group[map['host_group_id']].setdefault('volumes',{}).setdefault(json_info.volume[(map.get('volume_id', 'null')or'null')]['volume_group_name'],[]).append(json_info.volume[(map.get('volume_id', 'null')or'null')]['name'])
                       json_info.volume[(map.get('volume_id', 'null')or'null')]['volume_group_name']
                   if (map.get('host_id', 'null')or'null')!='null':
                       json_info.host[map['host_id']].setdefault('volumes',{}).setdefault(json_info.volume[(map.get('volume_id', 'null')or'null')]['volume_group_name'],[]).append(json_info.volume[(map.get('volume_id', 'null')or'null')]['name'])
                       json_info.volume[(map.get('volume_id', 'null')or'null')]['volume_group_name']
            poplist=[]
            for entry in json_info.host.values():
                    if entry['type']=='External':
                       json_info.host_group[(entry.get('host_group_id', 'null')or'null')]['hosts'].append({entry['name']: entry})
                    else:poplist.append(entry['id'])
            for pop_mag in poplist:
                json_info.host.pop(pop_mag)

def nothing(fill_1=None, fill_2=None, fill_3=None, fill_4=None, fill_5=None):
    pass

################################################################################################################################
# POWERSTORE FAULT DETECTION APP START
################################################################################################################################


# OFFLINE_&_ONLINE_MODE_DICTIONARY
offline_mode = {'mode_type': 'offline', 'journal_reader': journalctl_Reader, 'journal_ctl_cmd': './cyc_triage.pl -j --', 'command_method': cmd_get_output, 'journal_path': './triage_analysis/journal/nodes_all', 'compress': nothing, 'svc_diag_list_info': 'svc_diag_list_--info.txt', 'a_dir_adjustment': 'node_a', 'b_dir_adjustment': 'node_b', 'cmd_on_peer': '', 'cmd_output_folder': cmd_output_folder_dc, 'get_config_capture_file': cmd_get_config_capture_file_dc}
online_mode = {'mode_type': 'online', 'journal_reader': journalctl_Reader, 'journal_ctl_cmd': 'journalctl', 'command_method': cmd_run, 'journal_path': None, 'journal_dump_text': None, 'compress': dirofile_make_tarfile, 'svc_diag_list_info': 'svc_diag list --info', 'a_dir_adjustment': '', 'b_dir_adjustment': '', 'cmd_on_peer': 'ssh ssh -oStrictHostKeyChecking=no peer -p26 ', 'cmd_output_folder': cmd_output_folder_live, 'get_config_capture_file': cmd_get_config_capture_file_live}
current_mode = {}

settings_file='settings'
appliance_info = ''
g = ''
settings={}
settings={'save_analysis': False, 'save_logs': False, 'time_delta': 6, 'troubleshooting_logs': [],
'autoftp': False, 'ftp_link': '', 'delete_logs_after_upload': False
}
parser = settings_parser()
parser.add_option('-s', '--settings', action="store_true", dest="settings", help='show current settings', default=False)
parser.add_option('-u', '--upload', action="store", type="string", dest="upload", help='upload file to ftp', default=False)
parser.add_option('-d', '--download', action="store", type="string", dest="download", help='download file from ftp', default=False)
parser.add_option('-b', '--bypass', action="store_false", dest="known_issues", help='bypass checking for known issues', default=True)
parser.add_option('-i', '--ignore_oe', action="store_true", dest="known_issues_oe", help='check all known issues, even if not applicable to OE', default=False)
group = OptionGroup(parser, "Permanent Settings",
                    "These only need to be set once and can be toggled or reset later as needed")

group.add_option('--hours', type="int", dest="hours", help='sets the default range in hours to search journal logs', default=0)
group.add_option('--save', action="store", type="string", dest="save_analysis", help="save analysis to working directory", default=False)
group.add_option("--logs", action="store", type="string", dest="save_logs", help='save "troubleshooting" logs to working directory', default=False)
group.add_option('--ftp', action="store", type="string", dest="ftp_link", help='stores Dell-EMC ftp link, remember to use quotation marks -f "full_ftp_link"')
group.add_option('--ftp_auto', action="store", type="string", dest="autoftp", help='automatically uploads extracted troubleshooting logs to stored ftp link', default=False)
parser.add_option_group(group)

group = OptionGroup(parser, "Troubleshooting Options",
                    "Caution: These options should be used in response to symptoms.        "
                    "Not recommended for general health checks!")
group.add_option("--connectivity_block", action="store_true", dest="HOST_B", help="host connectivity troubleshooting-block level", default=False)
group.add_option("--connectivity_file", action="store_true", dest="HOST_F", help="host connectivity troubleshooting-file level", default=False)
group.add_option("--ndu", action="store_true", dest="NDU", help="non disruptive upgrade (ndu) troubleshooting", default=False)
g = global_info()
r = dual_print_formatter()
r.layout.align='left'

settings_term_check()
parser.add_option_group(group)
(options, args) = parser.parse_args()
settings_check()
timestamp = time.strftime("%Y-%m-%d-%H-%M-%S", time.localtime())
g.log_folder = 'pfd_export_'+timestamp
os.mkdir(g.log_folder)
if g.settings['save_analysis']:
   g.analysis_file = "powerstore_defect_diagnose_report_" + timestamp + ".txt"
   f = codecs.open(g.analysis_file,"w", "utf-8")
   r.write=True
r.dp_break()


r.dp_line('=')
r.layout.align='center'
r.dp(u'           ╔══╤══╗          ',u'\033[0m'+u'\033[1m'+u'           '+u'\33[94m'+u'╔══╤══╗'+u'\033[0m'+u'          ')
r.dp(u'POWERSTORE ╟FAULT╢ DETECTION',u'\033[1m'+u'POWERSTORE '+u'\33[94m'+u'╟'+u'\033[0m'+u'\033[1m'+u'FAULT'+u'\33[94m'+u'╢'+u'\033[0m'+u'\033[1m'+u' DETECTION')
r.dp(u'           ╚══╧══╝          ',u'\033[0m'+u'\033[1m'+u'           '+u'\33[94m'+u'╚══╧══╝'+u'\033[0m'+u'          ')
r.dp_line('=')
r.col.DEFAULT='\33[97m'
r.dp_break()
r.layout.align='left'


check_env = settings_pre_startup_environment_checks()

if not g.settings['troubleshooting_logs']: g.settings['troubleshooting_logs']= [{
        'area': 'host connectivity troubleshooting-block level', 'opt_parse': options.HOST_B,
        'log_name_list': ['kernel', 'xtremapp', 'extract_only:xmcli_-x__-c_show-sfps.txt', 'xmcli_-x__-c_show-initiators.txt', 'xmcli_-x__-c_show-targets.txt', 'extract_only:xmcli_-x__-c_show-lun-mappings.txt', 'extract_only:xmcli_-x__-c_show-ioms.txt', 'xmcli_-x__-c_show-initiators-connectivity_target-details.txt', 'extract_only:xmcli_-x__-c_show-initiator-groups.txt', 'extract_only:xmcli_-x__-c_show-frontend-ports-topology.txt', 'extract_only:xmcli_-x__-c_show-frontend-ports.txt', 'xmcli_-x__-c_show-discovered-initiators-connectivity_target-details.txt', 'extract_only:xmcli_-x__-c_query-monitoring-data_entity=ScsiTarget_limit=1.txt', 'extract_only:xmcli_-x__-c_query-monitoring-data_entity=Initiator_limit=1.txt', 'extract_only:svc_diag_list_--network.txt', 'extract_only:iscsiadm_-m_session_-s.txt', 'extract_only:iscsiadm_-m_session_-P_3.txt', 'extract_only:fcc.sh_stats.txt', 'extract_only:fcc.sh_list.txt', 'extract_only:fcc.sh_info.txt', 'extract_only:dmidecode.txt', 'extract_only:dmesg_-T.txt']},
        {'area': 'host connectivity troubleshooting-file level', 'opt_parse': options.HOST_F,
        'log_name_list': []},
        {'area': 'non disruptive upgrade (ndu) troubleshooting', 'opt_parse': options.NDU,
        'log_name_list': []}
        ]


if check_env:
   json_info=json_data()
   load_appliance_info()
   if options.upload == 'dc' and g.online and parimiko_active: ftp_upload_current_dc()
   elif options.upload and parimiko_active: ftp_upload_file(options.upload)
   if options.download == 'dc' and g.online and parimiko_active: ftp_download_online_dc()
   elif options.download and parimiko_active: ftp_download(options.download)
   troubleshooting_required_logs()
   if current_mode['mode_type'] == 'offline':
      version_check()
      journalctl_offline_check()
   r.layout.indent_size=(math.trunc((r.terminal_width-40)/2))
   r.dp_break()
   r.dp("Appliance Name:             "+appliance_info.Name)
   r.dp("Service Tag:                "+appliance_info.ServiceTag)
   r.dp("Model No:                   "+appliance_info.Model)
   r.dp("Software Rev:               "+appliance_info.Code)
   r.dp("MGMT IP:                    "+appliance_info.MgmtIp)
   r.dp("Ssh Enabled:                "+appliance_info.SshEnabled)
   r.dp("D@RE:                       "+appliance_info.DareEnabled)
   r.dp("Log range:                  "+str(g.settings['time_delta'])+" hour(s) prior")
   r.layout.indent_size=((r.terminal_width/100)*10)
   r.dp_break()
   if options.known_issues == True:
      r.dp_title('Known Issues Check')
      troubleshooting_known_issues()
      r.dp_subtitle('Known Issues Check End')
   if options.HOST_B == True:
      r.dp_title('Host Block Connectivity Check')
      r.dp_break()
      troubleshooting_connectivity_block()
      r.dp_subtitle('Host Block Connectivity Check End')
   if options.HOST_F == True:
      troubleshooting_connectivity_file()
   if options.NDU == True:
      troubleshooting_ndu()
   r.layout.align=('center')
   r.dp('Powerstore Analysis Complete')
   r.layout.align=('left')
r.write=False
if settings['save_analysis']:
        f.close()
dirofile_log_cleanup()
pfd_exit()
