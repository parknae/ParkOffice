#!/usr/bin/perl -w

#PST Array Log Scan Tool (Support T, X)
# author jason.hu@dell.com
# report bug to: jason.hu@dell.com

use Getopt::Long;
use threads;
use threads::shared;
use File::Find;

my $current_ver = "29";
my $remote_ver = "";


my $no_upgrade = 0;
my $node_a_journal_path = "./node_a/var/log/journal/";
my $node_b_journal_path = "./node_b/var/log/journal/";
my $node_a_journal_exist = 0;
my @node_a_journal = ();
my $node_b_journal_exist = 0;
my @node_b_journal = ();
my $node_a_svc_diag_list_info_txt = '';
my $node_a_svc_diag_list_info_txt_exist = 0;
my $node_b_svc_diag_list_info_txt = '';
my $node_b_svc_diag_list_info_txt_exist = 0;
my $node_a_svc_diag_list_basic_txt = '';
my $node_a_svc_diag_list_basic_txt_exist = 0;
my $node_b_svc_diag_list_basic_txt = '';
my $node_b_svc_diag_list_basic_txt_exist = 0;
my $node_a_svc_diag_list_icw_hardware_txt = '';
my $node_a_svc_diag_list_icw_hardware_txt_exist = 0;
my $node_b_svc_diag_list_icw_hardware_txt = '';
my $node_b_svc_diag_list_icw_hardware_txt_exist = 0;
my $node_a_cyc_ipmitool_sel_elist_txt = '';
my $node_a_cyc_ipmitool_sel_elist_txt_exist = 0;
my $node_b_cyc_ipmitool_sel_elist_txt = '';
my $node_b_cyc_ipmitool_sel_elist_txt_exist = 0;
my $node_a_cyc_ipmitool_sdr_elist_txt = '';
my $node_a_cyc_ipmitool_sdr_elist_txt_exist = 0;
my $node_b_cyc_ipmitool_sdr_elist_txt = '';
my $node_b_cyc_ipmitool_sdr_elist_txt_exist = 0;
my $node_a_datacollection_json_exist = 0;
my $node_a_datacollection_json = '';
my $node_b_datacollection_json_exist = 0;
my $node_b_datacollection_json = '';
my $node_a_alert_json_exist = 0;
my $node_a_alert_json = '';
my $node_b_alert_json_exist = 0;
my $node_b_alert_json = '';
my $node_a_system_dump_json_exist = 0;
my $node_a_system_dump_json = '';
my $node_b_system_dump_json_exist = 0;
my $node_b_system_dump_json = '';
my $node_a_volume_json = '';
my $node_a_volume_json_exist = 0;
my $node_b_volume_json = '';
my $node_b_volume_json_exist = 0;
my $node_a_host_json = '';
my $node_a_host_json_exist = 0;
my $node_b_host_json = '';
my $node_b_host_json_exist = 0;
my $node_a_host_group_json = '';
my $node_a_host_group_json_exist = 0;
my $node_b_host_group_json = '';
my $node_b_host_group_json_exist = 0;
my $node_a_host_volume_mapping_json = '';
my $node_a_host_volume_mapping_json_exist = 0;
my $node_b_host_volume_mapping_json = '';
my $node_b_host_volume_mapping_json_exist = 0;
my $node_a_remote_system_json = '';
my $node_a_remote_system_json_exist = 0;
my $node_b_remote_system_json = '';
my $node_b_remote_system_json_exist = 0;
my $node_a_config_item_json = '';
my $node_a_config_item_json_exist = 0;
my $node_b_config_item_json = '';
my $node_b_config_item_json_exist = 0;
my $node_a_memory_node_a_log_exist = 0;
my $node_a_memory_node_a_log = '';
my $node_b_memory_node_b_log_exist = 0;
my $node_b_memory_node_b_log = '';
my $node_a_sar_n_EDEV_txt = '';
my $node_a_sar_n_EDEV_txt_exist = 0;
my $node_b_sar_n_EDEV_txt = '';
my $node_b_sar_n_EDEV_txt_exist = 0;
my $node_a_dp_cache_txt = '';
my $node_a_dp_cache_txt_exist = 0;
my $node_b_dp_cache_txt = '';
my $node_b_dp_cache_txt_exist = 0;
my $node_a_dp_app_txt = '';
my $node_a_dp_app_txt_exist = 0;
my $node_b_dp_app_txt = '';
my $node_b_dp_app_txt_exist = 0;
my $node_a_dp_mapper_txt = '';
my $node_a_dp_mapper_txt_exist = 0;
my $node_b_dp_mapper_txt = '';
my $node_b_dp_mapper_txt_exist = 0;
my $node_a_dp_raid_txt = '';
my $node_a_dp_raid_txt_exist = 0;
my $node_b_dp_raid_txt = '';
my $node_b_dp_raid_txt_exist = 0;
my $node_a_housemd_show_xenv_txt = '';
my $node_a_housemd_show_xenv_txt_exist = 0;
my $node_b_housemd_show_xenv_txt = '';
my $node_b_housemd_show_xenv_txt_exist = 0;
my $node_a_enclmgmt_txt = '';
my $node_a_enclmgmt_txt_exist = 0;
my $node_b_enclmgmt_txt = '';
my $node_b_enclmgmt_txt_exist = 0;
my $node_a_sfpinfo_txt = '';
my $node_a_sfpinfo_txt_exist = 0;
my $node_b_sfpinfo_txt = '';
my $node_b_sfpinfo_txt_exist = 0;
my $node_a_sdnas_upgrade_playbook_status_txt = '';
my $node_a_sdnas_upgrade_playbook_status_txt_exist = 0;
my $node_b_sdnas_upgrade_playbook_status_txt = '';
my $node_b_sdnas_upgrade_playbook_status_txt_exist = 0;
my $node_a_housemd_show_base_enclosure_txt = '';
my $node_a_housemd_show_base_enclosure_txt_exist = 0;
my $node_b_housemd_show_base_enclosure_txt = '';
my $node_b_housemd_show_base_enclosure_txt_exist = 0;
my $node_a_housemd_show_dimms_txt = '';
my $node_a_housemd_show_dimms_txt_exist = 0;
my $node_b_housemd_show_dimms_txt = '';
my $node_b_housemd_show_dimms_txt_exist = 0;
my $node_a_housemd_show_nodes_txt = '';
my $node_a_housemd_show_nodes_txt_exist = 0;
my $node_b_housemd_show_nodes_txt = '';
my $node_b_housemd_show_nodes_txt_exist = 0;
my $node_a_housemd_show_sfps_txt = '';
my $node_a_housemd_show_sfps_txt_exist = 0;
my $node_b_housemd_show_sfps_txt = '';
my $node_b_housemd_show_sfps_txt_exist = 0;
my $node_a_housemd_show_ioms_txt = '';
my $node_a_housemd_show_ioms_txt_exist = 0;
my $node_b_housemd_show_ioms_txt = '';
my $node_b_housemd_show_ioms_txt_exist = 0;
my $node_a_housemd_show_fanpacks_txt = '';
my $node_a_housemd_show_fanpacks_txt_exist = 0;
my $node_b_housemd_show_fanpacks_txt = '';
my $node_b_housemd_show_fanpacks_txt_exist = 0;
my $node_a_housemd_show_drives_basic_txt = '';
my $node_a_housemd_show_drives_basic_txt_exist = 0;
my $node_b_housemd_show_drives_basic_txt = '';
my $node_b_housemd_show_drives_basic_txt_exist = 0;
my $node_a_housemd_show_localdisks_txt = '';
my $node_a_housemd_show_localdisks_txt_exist = 0;
my $node_b_housemd_show_localdisks_txt = '';
my $node_b_housemd_show_localdisks_txt_exist = 0;
my $node_a_housemd_show_exp_encls_txt = '';
my $node_a_housemd_show_exp_encls_txt_exist = 0;
my $node_b_housemd_show_exp_encls_txt = '';
my $node_b_housemd_show_exp_encls_txt_exist = 0;
my $node_a_housemd_show_lccs_basic_txt = '';
my $node_a_housemd_show_lccs_basic_txt_exist = 0;
my $node_b_housemd_show_lccs_basic_txt = '';
my $node_b_housemd_show_lccs_basic_txt_exist = 0;
my $node_a_housemd_show_scsi_reservations_txt = '';
my $node_a_housemd_show_scsi_reservations_txt_exist = 0;
my $node_b_housemd_show_scsi_reservations_txt = '';
my $node_b_housemd_show_scsi_reservations_txt_exist = 0;
my $node_a_housemd_show_feport_txt = '';
my $node_a_housemd_show_feport_txt_exist = 0;
my $node_b_housemd_show_feport_txt = '';
my $node_b_housemd_show_feport_txt_exist = 0;
my $node_a_housemd_show_initiators_connectivity_txt = '';
my $node_a_housemd_show_initiators_connectivity_txt_exist = 0;
my $node_b_housemd_show_initiators_connectivity_txt = '';
my $node_b_housemd_show_initiators_connectivity_txt_exist = 0;
my $node_a_xmcli_x_c_show_storage_controllers_txt_exist = 0;
my $node_a_xmcli_x_c_show_storage_controllers_txt = '';
my $node_b_xmcli_x_c_show_storage_controllers_txt_exist = 0;
my $node_b_xmcli_x_c_show_storage_controllers_txt = '';
my $node_a_xmcli_x_c_show_dimms_txt_exist = 0;
my $node_a_xmcli_x_c_show_dimms_txt = '';
my $node_b_xmcli_x_c_show_dimms_txt_exist = 0;
my $node_b_xmcli_x_c_show_dimms_txt = '';
my $node_a_xmcli_x_c_show_ioms_txt_exist = 0;
my $node_a_xmcli_x_c_show_ioms_txt = '';
my $node_b_xmcli_x_c_show_ioms_txt_exist = 0;
my $node_b_xmcli_x_c_show_ioms_txt = '';
my $node_a_xmcli_x_c_show_sfps_txt_exist = 0;
my $node_a_xmcli_x_c_show_sfps_txt = '';
my $node_b_xmcli_x_c_show_sfps_txt_exist = 0;
my $node_b_xmcli_x_c_show_sfps_txt = '';
my $node_a_xmcli_x_c_show_slots_txt_exist = 0;
my $node_a_xmcli_x_c_show_slots_txt = '';
my $node_b_xmcli_x_c_show_slots_txt_exist = 0;
my $node_b_xmcli_x_c_show_slots_txt = '';
my $node_a_xmcli_x_c_show_ssds_txt_exist = 0;
my $node_a_xmcli_x_c_show_ssds_txt = '';
my $node_b_xmcli_x_c_show_ssds_txt_exist = 0;
my $node_b_xmcli_x_c_show_ssds_txt = '';
my $node_a_xmcli_x_c_show_ssds_diagnostic_txt_exist = 0;
my $node_a_xmcli_x_c_show_ssds_diagnostic_txt = '';
my $node_b_xmcli_x_c_show_ssds_diagnostic_txt_exist = 0;
my $node_b_xmcli_x_c_show_ssds_diagnostic_txt = '';
my $node_a_xmcli_x_c_show_fanpacks_txt_exist = 0;
my $node_a_xmcli_x_c_show_fanpacks_txt = '';
my $node_b_xmcli_x_c_show_fanpacks_txt_exist = 0;
my $node_b_xmcli_x_c_show_fanpacks_txt = '';
my $node_a_xmcli_x_c_show_local_disks_txt_exist = 0;
my $node_a_xmcli_x_c_show_local_disks_txt = '';
my $node_b_xmcli_x_c_show_local_disks_txt_exist = 0;
my $node_b_xmcli_x_c_show_local_disks_txt = '';
my $node_a_xmcli_x_c_show_enclosures_txt_exist = 0;
my $node_a_xmcli_x_c_show_enclosures_txt = '';
my $node_b_xmcli_x_c_show_enclosures_txt_exist = 0;
my $node_b_xmcli_x_c_show_enclosures_txt = '';
my $node_a_xmcli_x_c_show_daes_txt_exist = 0;
my $node_a_xmcli_x_c_show_daes_txt = '';
my $node_b_xmcli_x_c_show_daes_txt_exist = 0;
my $node_b_xmcli_x_c_show_daes_txt = '';

my $node_a_cli_py_namespace_spacestats_enumtenants_txt_exist = 0;
my $node_a_cli_py_namespace_spacestats_enumtenants_txt = '';
my $node_b_cli_py_namespace_spacestats_enumtenants_txt_exist = 0;
my $node_b_cli_py_namespace_spacestats_enumtenants_txt = '';

my @node_a_mdt_304895 : shared;
my @node_b_mdt_304895 : shared;
my @node_a_mdt_304623 : shared;
my @node_b_mdt_304623 : shared;
my @node_a_mdt_305100 : shared;
my @node_b_mdt_305100 : shared;
my @node_a_tee_2091 : shared;
my @node_b_tee_2091 : shared;
my @node_a_mdt_307082 : shared;
my @node_b_mdt_307082 : shared;
my @node_a_tee_2325 : shared;
my @node_b_tee_2325 : shared;
my @node_a_tee_979 : shared;
my @node_b_tee_979 : shared;
my @node_a_tee_1627 : shared;
my @node_b_tee_1627 : shared;
my @node_a_mdt_335078 : shared;
my @node_b_mdt_335078 : shared;
my @node_a_mdt_329167 : shared;
my @node_b_mdt_329167 : shared;
my @node_a_mdt_185460 : shared;
my @node_b_mdt_185460 : shared;
my @node_a_tee_703 : shared;
my @node_b_tee_703 : shared;
my @node_a_tee_2064 : shared;
my @node_b_tee_2064 : shared;
my @node_a_mdt_239421 : shared;
my @node_b_mdt_239421 : shared;
my @node_a_mdt_344382 : shared;
my @node_b_mdt_344382 : shared;
my @node_a_tee_1987 : shared;
my @node_b_tee_1987 : shared;
my @node_a_tee_1393 : shared;
my @node_b_tee_1393 : shared;
my @node_a_mdt_294054 : shared;
my @node_b_mdt_294054 : shared;
my @node_a_mdt_303484 : shared;
my @node_b_mdt_303484 : shared;
my @node_a_mdt_201561 : shared;
my @node_b_mdt_201561 : shared;
my @node_a_mdt_312975 : shared;
my @node_b_mdt_312975 : shared;
my @node_a_mdt_247214 : shared;
my @node_b_mdt_247214 : shared;
my @node_a_mdt_342762 : shared;
my @node_b_mdt_342762 : shared;
my @node_a_mdt_305828 : shared;
my @node_b_mdt_305828 : shared;
my @node_a_kb_182665 : shared;
my @node_b_kb_182665 : shared;
my @node_a_mdt_173900 : shared;
my @node_b_mdt_173900 : shared;
my @node_a_tee_x_corruptions : shared;
my @node_b_tee_x_corruptions : shared;
my @node_a_kb_131062 : shared;
my @node_b_kb_131062 : shared;
my @node_a_kb_130232 : shared;
my @node_b_kb_130232 : shared;
my @node_a_mdt_168926 : shared;
my @node_b_mdt_168926 : shared;
my @node_a_tee_2388 : shared;
my @node_b_tee_2388 : shared;
my @node_a_mdt_304388 : shared;
my @node_b_mdt_304388 : shared;
my @node_a_mdt_237350 : shared;
my @node_b_mdt_237350 : shared;
my @node_a_mdt_227944 : shared;
my @node_b_mdt_227944 : shared;
my @node_a_kb_126293 : shared;
my @node_b_kb_126293 : shared;
my @node_a_mdt_291470 : shared;
my @node_b_mdt_291470 : shared;
my @node_a_tee_1414 : shared;
my @node_b_tee_1414 : shared;
my @node_a_mdt_180273 : shared;
my @node_b_mdt_180273 : shared;
my @node_a_mdt_334812 : shared;
my @node_b_mdt_334812 : shared;
my @node_a_tee_1898 : shared;
my @node_b_tee_1898 : shared;
my @node_a_tee_2161 : shared;
my @node_b_tee_2161 : shared;
my @node_a_tee_2249 : shared;
my @node_b_tee_2249 : shared;
my @node_a_tee_1021 : shared;
my @node_b_tee_1021 : shared;
my @node_a_kb_189524 : shared;
my @node_b_kb_189524 : shared;
my @node_a_tee_2213 : shared;
my @node_b_tee_2213 : shared;
my @node_a_mdt_205619 : shared;
my @node_b_mdt_205619 : shared;
my @node_a_kb_180125 : shared;
my @node_b_kb_180125 : shared;
my @node_a_mdt_194042 : shared;
my @node_b_mdt_194042 : shared;
my @node_a_tee_711 : shared;
my @node_b_tee_711 : shared;
my @node_a_mdt_195039 : shared;
my @node_b_mdt_195039 : shared;
my @node_a_mdt_149702 : shared;
my @node_b_mdt_149702 : shared;
my @node_a_mdt_283614 : shared;
my @node_b_mdt_283614 : shared;
my @node_a_mdt_285220 : shared;
my @node_b_mdt_285220 : shared;
my @node_a_kb_pstx_icw_ca : shared;
my @node_b_kb_pstx_icw_ca : shared;
my @node_a_tee_1128 : shared;
my @node_b_tee_1128 : shared;
my @node_a_mdt_259371 : shared;
my @node_b_mdt_259371 : shared;
my @node_a_mdt_163197 : shared;
my @node_b_mdt_163197 : shared;
my @node_a_tee_834 : shared;
my @node_b_tee_834 : shared;
my @node_a_tee_2432 : shared;
my @node_b_tee_2432 : shared;
my @node_a_tee_2345 : shared;
my @node_b_tee_2345 : shared;
my @node_a_tee_1673 : shared;
my @node_b_tee_1673 : shared;
my @node_a_scsi_status_0x28 : shared;
my @node_b_scsi_status_0x28 : shared;
my @node_a_ats_lock_block : shared;
my @node_b_ats_lock_block : shared;
my @node_a_scsi_lock_block : shared;
my @node_b_scsi_lock_block : shared;
my @node_a_reservation_block : shared;
my @node_b_reservation_block : shared;
my @node_a_io_operation_failure : shared;
my @node_b_io_operation_failure : shared;
my @node_a_initiator_cc : shared;
my @node_b_initiator_cc : shared;
my @node_a_kb_ndu_proc : shared;
my @node_b_kb_ndu_proc : shared;
my @node_a_tee_2434 : shared;
my @node_b_tee_2434 : shared;
my @node_a_tee_2433 : shared;
my @node_b_tee_2433 : shared;
my @node_a_kb_192316 : shared;
my @node_b_kb_192316 : shared;
my @node_a_tee_2107 : shared;
my @node_b_tee_2107 : shared;
my @node_a_kb_191693 : shared;
my @node_b_kb_191693 : shared;
my @node_a_kb_192483 : shared;
my @node_b_kb_192483 : shared;
my @node_a_kb_130333 : shared;
my @node_b_kb_130333 : shared;
my @node_a_factory_complete : shared;
my @node_b_factory_complete : shared;
my @node_a_tee_2462 : shared;
my @node_b_tee_2462 : shared;
my @node_a_tee_2543 : shared;
my @node_b_tee_2543 : shared;
my @node_a_kb_user_reboot_actions : shared;
my @node_b_kb_user_reboot_actions : shared;
my @node_a_kb_184530 : shared;
my @node_b_kb_184530 : shared;
my @node_a_mdt_342774 : shared;
my @node_b_mdt_342774 : shared;
my @node_a_mdt_347737 : shared;
my @node_b_mdt_347737 : shared;
my @node_a_tee_2255 : shared;
my @node_b_tee_2255 : shared;
my @node_a_tee_2450 : shared;
my @node_b_tee_2450 : shared;
my @node_a_tee_1854 : shared;
my @node_b_tee_1854 : shared;
my @node_a_kb_interface_flapping : shared;
my @node_b_kb_interface_flapping : shared;
my @node_a_tee_2184 : shared;
my @node_b_tee_2184 : shared;
my @node_a_kb_fc_login : shared;
my @node_b_kb_fc_login : shared;
my @node_a_kb_fc_logout : shared;
my @node_b_kb_fc_logout : shared;
my @node_a_kb_fc_abts_unknown_address : shared;
my @node_b_kb_fc_abts_unknown_address : shared;
my @node_a_tee_2524 : shared;
my @node_b_tee_2524 : shared;
my @node_a_tee_2239 : shared;
my @node_b_tee_2239 : shared;
my @node_a_reservation_conflict : shared;
my @node_b_reservation_conflict : shared;
my @node_a_kb_session_logout : shared;
my @node_b_kb_session_logout : shared;
my @node_a_kb_st_io_counters : shared;
my @node_b_kb_st_io_counters : shared;
my @node_a_kb_193397 : shared;
my @node_b_kb_193397 : shared;
my @node_a_kb_193396 : shared;
my @node_b_kb_193396 : shared;
my @node_a_kb_193399 : shared;
my @node_b_kb_193399 : shared;
my @node_a_kb_187268 : shared;
my @node_b_kb_187268 : shared;
my @node_a_kb_185738 : shared;
my @node_b_kb_185738 : shared;


#######################################################################
sub wget_get_remote_ver {
    my $command = 'wget ftp://anonymous:jasonhu@10.84.100.154/pstscan/pstscan_version.txt -O pstscan_version.txt';
    print "\nPing remote server and check pst_scan script the latest version ... ...\n\n\n";
    system($command);
}
#######################################################################


#######################################################################
sub compare_remote_ver {
    my $file = 'pstscan_version.txt';   
    open( CONFREF, "< $file" );

    my $line = <CONFREF>;
    if ( defined $line ) {
        $line =~ s/^\s+|\s+$//g;
        $remote_ver = $line;
    }

    close(CONFREF);

    unless ( defined $line ) {
        print "Cannot reach to remote server.\n";
        return 0;
    }

    if ( $line > $current_ver ) {
        print "The latest pstscan script version is $line.\n";
        return 1;
    } else {
        print "The script is the latest version $current_ver.\n";
        return 0;
    }
}
#######################################################################


#######################################################################
sub wget_get_script {
    my $command = 'wget ftp://anonymous:jasonhu@10.84.100.154/pstscan/pstscan_script.tar -O pstscan_script.tar';
    print "Download the latest version ... ...\n";
    system($command);
    print "Complete download latest script pstscan_script.tar!\n";
    print "Please run \"tar -xvf pstscan_script.tar\" to extrace the script\n"; 
    print "Please run script again\n";
}
#######################################################################


#######################################################################
sub usage {
    my $help_msg = "[pstscan version $current_ver howto: perl pstscan.pl]\n" .
    "-h   : help\n" .
    "   copy pstscan.pl to the unpack log folder then run 'perl pstcan.pl' \n" .
    "   e.g. cd /powerstore/data/_Tag/6V/6V70/6V70643/2021-08-17/powerstore_6V70643_PS563e2f32a70e_APM01204309260_2021-08-17_18-27-16_service-data\n" .
    "        perl pstscan_script.pl\n".
    "   Please download latest tool from below anonymous FTP or http site or confluence page.\n" .
    "   http://10.84.100.154:8000\n" .
    "   anonymous\@ftp://10.84.100.154\n" .
    "   [contact: jason.hu\@dell.com]\n\n" .
    "-a   : skip check and download new version automatically\n\n";    

    print "$help_msg";
    exit;
}
#######################################################################


#######################################################################
sub upgrade {
    $no_upgrade = 1;
}
#######################################################################


unless (GetOptions ("noupgrade|a" => sub { &upgrade},
                    "help|h|?" => sub { &usage})){
       &usage;
    }


if ( $no_upgrade == 0 ) {
    &wget_get_remote_ver;
    my $result = &compare_remote_ver;
    if ( $result == 1 ) {
        &wget_get_script;
        exit;
    }
}

#######################################################################
sub print_header {
    print "\n######################################################################################################################\n";
    print "# PST Array Log Scan Tool (Support T, X and SDNAS)                                                                   #\n";
    print "# PSTScan tool will ping remote server and download the latest script automatically.                                 #\n";
    print "#                                                                                                                    #\n";      
    print "#    You can also check the latest tool version from below ftp or http or confluence site.                           #\n";   
    print "#    anonymous\@ftp://10.84.100.154                                                                                   #\n";
    print "#    http://10.84.100.154:8000/scan_site/pstscan/                                                                    #\n";
    print "#                                                                                                                    #\n";
    print "# How to read report:                                                                                                #\n";
    print "#  https://confluence.cec.lab.emc.com/pages/viewpage.action?pageId=603104469                                         #\n";
    print "#                                                                                                                    #\n";    
    print "# Contact: Jason.Hu\@dell.com                                                                                         #\n";
    print "# Report bug to: Jason.Hu\@dell.com                                                                                   #\n";
    print "######################################################################################################################\n\n\n";
}
#######################################################################


#######################################################################
sub threaded_dump_journal_to_txt {

    my $thr_id = threads->self->tid;
    #print "Starting dump_journal_to_txt thread $thr_id\n";

    my $journal_txt_file = $_[0].'.txt';
    #print("journalctl --file=\"$_[0]\" > $journal_txt_file\n");
    system("journalctl --file=\"$_[0]\" > $journal_txt_file");

    #print "Ending dump_journal_to_txt thread $thr_id\n";
}
#######################################################################


#######################################################################
sub initialize_dump_journal_to_txt {
    my $node_a_time_range = `journalctl -D node_a/var/log/journal/ -n 0`;
    my $node_b_time_range = `journalctl -D node_b/var/log/journal/ -n 0`;
    my $current_time = `date`;

    $node_a_time_range =~ s/^\s+|\s+$//g;
    $node_b_time_range =~ s/^\s+|\s+$//g;
    $current_time =~ s/^\s+|\s+$//g;
    
    print "\n\n######################################################################################################################\n";
    print "# sub dump_journal_to_txt: dump node journal log to txt                                                              #\n";
    print "# journal location: node_x/var/log/journal/                                                                          #\n";
    print "# node_a journal time range:                                                                                         #\n"; 
    print "#  $node_a_time_range                              #\n";
    print "# node_b journal time range:                                                                                         #\n";
    print "#  $node_b_time_range                              #\n";
    print "#                                                                                                                    #\n";
    print "# current time: $current_time                                                                         #\n"; 
    print "# Starting dump_journal_to_txt threads (Please wait for a short period of time 1-3 minutes.                          #\n";
    print "#  Even specific journal log file is corupt and dump journal fails with errors, script is still running fine.)       #\n";

    find({ wanted => sub { if (-f $_) {push(@node_a_journal, $_) if (m/\.journal$/)} },
         no_chdir => 1}, $node_a_journal_path);

    find({ wanted => sub { if (-f $_) {push(@node_b_journal, $_) if (m/\.journal$/)} },
         no_chdir => 1}, $node_b_journal_path);

    my @thread_node_a_journal_to_txt;
    my $i = 0;
    foreach (@node_a_journal) {
        $thread_node_a_journal_to_txt[$i] = threads->create( \&threaded_dump_journal_to_txt, $_ );  
        $i++; 
    }

    my @thread_node_b_journal_to_txt;
    $i = 0;
    foreach (@node_b_journal) {
        $thread_node_b_journal_to_txt[$i] = threads->create( \&threaded_dump_journal_to_txt, $_ );  
        $i++; 
    }

    foreach (@thread_node_a_journal_to_txt) {
        $_->join();
    }

    foreach (@thread_node_b_journal_to_txt) {
        $_->join();
    }   

    print "# Ending dump_journal_to_txt threads                                                                                 #\n";
    print "# if node_x journal has no entries, please refer to tee or kb articles:                                              #\n";
    print "# 1, restart cyc_service_control.service (svc_dc doesn't collect journal)                                            #\n";
    print "# 2, https://www.dell.com/support/kbdoc/000129683/  (MDT-155968: svc_dc doesn't collect journal with ~)              #\n";
    print "######################################################################################################################\n\n";
}
#######################################################################


#######################################################################
sub array_pst_terms {
    print "\n\n######################################################################################################################\n";
    print "# Powerstore Terms                                                                                                   #\n";
    print "#                                                                                                                    #\n";
    print "# Data Path:                                                                                                         #\n";
    print "# Namespace - The top level of the DP code, it exports the file systems and volumes that can be host visible.        #\n";
    print "# Mapper - The middle level of DP code.  Converts read and write requests into stripes which are then passed on      #\n";
    print "#  to RAID or the (write) cache.                                                                                     #\n"; 
    print "# RAID - Reads and writes stripes of data.  Parity protection and mirroring are handled at this level.               #\n";                         
    print "# NBtruck – A (Linux) OS thread that is used to run lightweight X threads.                                           #\n";
    print "#  Except for a few synchronization cases, the X threads are not allowed to block the NBtruck, hence the \“NB\”.       #\n";
    print "# FSCK - DP component used to validate mapper/namespace metadata and fix corruptions to make the metadata            #\n";
    print "#  consistent. It will also attempt to recover user data where possible.                                             #\n";                                                                       #\n";    
    print "######################################################################################################################\n\n";
}
#######################################################################


#######################################################################
sub array_useful_commands {
    print "\n\n######################################################################################################################\n";
    print "# Useful online command sets                                                                                         #\n";
    print "#                                                                                                                    #\n";    
    print "# Hardware                                                                                                           #\n";
    print "#  1.clear hardware fault fsr bit. without -p means local node.                                                      #\n";
    print "#  [svc]/cyc_host/cyc_bsc/scripts/cyc_ipmitool -p mrsoem fsr display                                                 #\n";                              #\n";
    print "#  [svc]/cyc_host/cyc_bsc/scripts/cyc_ipmitool -p mrsoem fsr clear all                                               #\n";                             #\n";
    print "#  [svc]ipmitool -I openpeer -m 0x02 -t 0x1e mrsoem fsr display                                                      #\n";
    print "#  2.check power status (node stuck issue)                                                                           #\n";
    print "#  [svc]ipmitool -I openpeer -m 0x02 -t 0x1e chassis power status                                                    #\n";
    print "#  [svc]ipmitool -I open -m 0x02 -t 0x1e chassis power status                                                        #\n";
    print "######################################################################################################################\n\n";
}
#######################################################################


#######################################################################
sub array_logs_location_list {
    print "\n\n######################################################################################################################\n";
    print "# Support Material log files location                                                                                #\n";
    print "#                                                                                                                    #\n";    
    print "# svc_diag_* (svc_diag_list, svc_diag_list_icw_hardware etc)                                  node_x/command_output/ #\n";
    print "# cyc_ipmitool_sdr_elist (hardware sdr info)                                                  node_x/command_output/ #\n";
    print "# raid.txt (data path raid status)                               node_*/command_output/dc-datapath-[timestamp]-logs/ #\n"; 
    print "# sdnas_upgrade_playbook_status.txt                                                 node_*/var/log/sdnas/sdnas_logs/ #\n";
    print "######################################################################################################################\n\n";
}


#######################################################################
sub initialize_array_logs_exist {
    my $path = "./node_a/command_output/*";
    @dir = glob($path);
    foreach (@dir) {
        if ( m/svc_diag_list_--info/ ) {
            $node_a_svc_diag_list_info_txt = $_;
            $node_a_svc_diag_list_info_txt_exist = 1;
        }

        if ( m/svc_diag_list_--basic/ ) {
            $node_a_svc_diag_list_basic_txt = $_;
            $node_a_svc_diag_list_basic_txt_exist = 1;
        }
                
        if ( m/svc_diag_list_--icw_hardware/ ) {
            $node_a_svc_diag_list_icw_hardware_txt = $_;
            $node_a_svc_diag_list_icw_hardware_txt_exist = 1;
        }

        if ( m/cyc_ipmitool_sel_elist/ ) {
            $node_a_cyc_ipmitool_sel_elist_txt = $_;
            $node_a_cyc_ipmitool_sel_elist_txt_exist = 1;
        }

        if ( m/cyc_ipmitool_sdr_elist/ ) {
            $node_a_cyc_ipmitool_sdr_elist_txt = $_;
            $node_a_cyc_ipmitool_sdr_elist_txt_exist = 1;
        }

        if ( m/sar_-n_EDEV\.txt$/ ) {
            $node_a_sar_n_EDEV_txt = $_;
            $node_a_sar_n_EDEV_txt_exist = 1;
        }  

        if ( m/cli\.py_namespace_spacestats_enumtenants\.txt$/ ) {
            $node_a_cli_py_namespace_spacestats_enumtenants_txt_exist = 1;
            $node_a_cli_py_namespace_spacestats_enumtenants_txt = $_;
        }

        if ( m/xmcli_-x__-c_show-storage-controllers\.txt$/ ) {
            $node_a_xmcli_x_c_show_storage_controllers_txt_exist = 1;
            $node_a_xmcli_x_c_show_storage_controllers_txt = $_;
        }

        if ( m/xmcli_-x__-c_show-dimms\.txt$/ ) {
            $node_a_xmcli_x_c_show_dimms_txt_exist = 1;
            $node_a_xmcli_x_c_show_dimms_txt = $_;
        }

        if ( m/xmcli_-x__-c_show-ioms\.txt$/ ) {
            $node_a_xmcli_x_c_show_ioms_txt_exist = 1;
            $node_a_xmcli_x_c_show_ioms_txt = $_;
        }

        if ( m/xmcli_-x__-c_show-sfps\.txt$/ ) {
            $node_a_xmcli_x_c_show_sfps_txt_exist = 1;
            $node_a_xmcli_x_c_show_sfps_txt = $_;
        }

        if ( m/xmcli_-x__-c_show-slots\.txt$/ ) {
            $node_a_xmcli_x_c_show_slots_txt_exist = 1;
            $node_a_xmcli_x_c_show_slots_txt = $_;
        }

        if ( m/xmcli_-x__-c_show-ssds\.txt$/ ) {
            $node_a_xmcli_x_c_show_ssds_txt_exist = 1;
            $node_a_xmcli_x_c_show_ssds_txt = $_;
        }

        if ( m/xmcli_-x__-c_show-ssds-diagnostic\.txt$/ ) {
            $node_a_xmcli_x_c_show_ssds_diagnostic_txt_exist = 1;
            $node_a_xmcli_x_c_show_ssds_diagnostic_txt = $_;
        }

        if ( m/xmcli_-x__-c_show-fanpacks\.txt$/ ) {
            $node_a_xmcli_x_c_show_fanpacks_txt_exist = 1;
            $node_a_xmcli_x_c_show_fanpacks_txt = $_;
        }

        if ( m/xmcli_-x__-c_show-local-disks\.txt$/ ) {
            $node_a_xmcli_x_c_show_local_disks_txt_exist = 1;
            $node_a_xmcli_x_c_show_local_disks_txt = $_;
        } 

        if ( m/xmcli_-x__-c_show-enclosures\.txt$/ ) {
            $node_a_xmcli_x_c_show_enclosures_txt_exist = 1;
            $node_a_xmcli_x_c_show_enclosures_txt = $_;
        } 

        if ( m/xmcli_-x__-c_show-daes\.txt$/ ) {
            $node_a_xmcli_x_c_show_daes_txt_exist = 1;
            $node_a_xmcli_x_c_show_daes_txt = $_;
        }
            
    }   

    $path = "./node_b/command_output/*";
    @dir = glob($path);
    foreach (@dir) {
        if ( m/svc_diag_list_--info/ ) {
            $node_b_svc_diag_list_info_txt = $_;
            $node_b_svc_diag_list_info_txt_exist = 1;
        }

        if ( m/svc_diag_list_--basic/ ) {
            $node_b_svc_diag_list_basic_txt = $_;
            $node_b_svc_diag_list_basic_txt_exist = 1;
        }
                
        if ( m/svc_diag_list_--icw_hardware/ ) {
            $node_b_svc_diag_list_icw_hardware_txt = $_;
            $node_b_svc_diag_list_icw_hardware_txt_exist = 1;
        }

        if ( m/cyc_ipmitool_sel_elist/ ) {
            $node_b_cyc_ipmitool_sel_elist_txt = $_;
            $node_b_cyc_ipmitool_sel_elist_txt_exist = 1;
        }

        if ( m/cyc_ipmitool_sdr_elist/ ) {
            $node_b_cyc_ipmitool_sdr_elist_txt = $_;
            $node_b_cyc_ipmitool_sdr_elist_txt_exist = 1;
        }

        if ( m/sar_-n_EDEV\.txt$/ ) {
            $node_b_sar_n_EDEV_txt = $_;
            $node_b_sar_n_EDEV_txt_exist = 1;
        } 

        if ( m/cli\.py_namespace_spacestats_enumtenants\.txt$/ ) {
            $node_b_cli_py_namespace_spacestats_enumtenants_txt_exist = 1;
            $node_b_cli_py_namespace_spacestats_enumtenants_txt = $_;
        }                

        if ( m/xmcli_-x__-c_show-storage-controllers\.txt$/ ) {
            $node_b_xmcli_x_c_show_storage_controllers_txt_exist = 1;
            $node_b_xmcli_x_c_show_storage_controllers_txt = $_;
        }

        if ( m/xmcli_-x__-c_show-dimms\.txt$/ ) {
            $node_b_xmcli_x_c_show_dimms_txt_exist = 1;
            $node_b_xmcli_x_c_show_dimms_txt = $_;
        }

        if ( m/xmcli_-x__-c_show-ioms\.txt$/ ) {
            $node_b_xmcli_x_c_show_ioms_txt_exist = 1;
            $node_b_xmcli_x_c_show_ioms_txt = $_;
        }

        if ( m/xmcli_-x__-c_show-sfps\.txt$/ ) {
            $node_b_xmcli_x_c_show_sfps_txt_exist = 1;
            $node_b_xmcli_x_c_show_sfps_txt = $_;
        }

        if ( m/xmcli_-x__-c_show-slots\.txt$/ ) {
            $node_b_xmcli_x_c_show_slots_txt_exist = 1;
            $node_b_xmcli_x_c_show_slots_txt = $_;
        }

        if ( m/xmcli_-x__-c_show-ssds\.txt$/ ) {
            $node_b_xmcli_x_c_show_ssds_txt_exist = 1;
            $node_b_xmcli_x_c_show_ssds_txt = $_;
        }

        if ( m/xmcli_-x__-c_show-ssds-diagnostic\.txt$/ ) {
            $node_b_xmcli_x_c_show_ssds_diagnostic_txt_exist = 1;
            $node_b_xmcli_x_c_show_ssds_diagnostic_txt = $_;
        }

        if ( m/xmcli_-x__-c_show-fanpacks\.txt$/ ) {
            $node_b_xmcli_x_c_show_fanpacks_txt_exist = 1;
            $node_b_xmcli_x_c_show_fanpacks_txt = $_;
        }

        if ( m/xmcli_-x__-c_show-local-disks\.txt$/ ) {
            $node_b_xmcli_x_c_show_local_disks_txt_exist = 1;
            $node_b_xmcli_x_c_show_local_disks_txt = $_;
        } 

        if ( m/xmcli_-x__-c_show-enclosures\.txt$/ ) {
            $node_b_xmcli_x_c_show_enclosures_txt_exist = 1;
            $node_b_xmcli_x_c_show_enclosures_txt = $_;
        } 

        if ( m/xmcli_-x__-c_show-daes\.txt$/ ) {
            $node_b_xmcli_x_c_show_daes_txt_exist = 1;
            $node_b_xmcli_x_c_show_daes_txt = $_;
        }                
    }

    $path = "./node_a/command_output/pmcli/*";
    @dir = glob($path);
    foreach (@dir) {
        if ( m/enclmgmt\.txt$/ ) {
            $node_a_enclmgmt_txt = $_;
            $node_a_enclmgmt_txt_exist = 1;
        }

         if ( m/sfpinfo\.txt$/ ) {
            $node_a_sfpinfo_txt = $_;
            $node_a_sfpinfo_txt_exist = 1;
        }       
    }    

    $path = "./node_b/command_output/pmcli/*";
    @dir = glob($path);
    foreach (@dir) {
        if ( m/enclmgmt\.txt$/ ) {
            $node_b_enclmgmt_txt = $_;
            $node_b_enclmgmt_txt_exist = 1;
        }

         if ( m/sfpinfo\.txt$/ ) {
            $node_b_sfpinfo_txt = $_;
            $node_b_sfpinfo_txt_exist = 1;
        }        
    }

    $path = "./node_a/config_capture_management_internal_data/*";
    @dir = glob($path);
    foreach (@dir) {
        if ( m/datacollection\.json$/ ) {
            $node_a_datacollection_json = $_;
            $node_a_datacollection_json_exist = 1;
        }

        if ( m/system_dump\.json$/ ) {
            $node_a_system_dump_json = $_;
            $node_a_system_dump_json_exist = 1;
        }              
    }

    $path = "./node_b/config_capture_management_internal_data/*";
    @dir = glob($path);
    foreach (@dir) {
        if ( m/datacollection\.json$/ ) {
            $node_b_datacollection_json = $_;
            $node_b_datacollection_json_exist = 1;
        }

        if ( m/system_dump\.json$/ ) {
            $node_b_system_dump_json = $_;
            $node_b_system_dump_json_exist = 1;
        }                       
    }

    $path = "./node_a/config_capture_management_data/*";
    @dir = glob($path);
    foreach (@dir) {
        if ( m/alert\.json$/ ) {
            $node_a_alert_json = $_;
            $node_a_alert_json_exist = 1;
        }        

        if ( m/volume\.json$/ ) {
            $node_a_volume_json = $_;
            $node_a_volume_json_exist = 1;
        }         

        if ( m/host\.json$/ ) {
            $node_a_host_json = $_;
            $node_a_host_json_exist = 1;
        } 

        if ( m/host_group\.json$/ ) {
            $node_a_host_group_json = $_;
            $node_a_host_group_json_exist = 1;
        }

        if ( m/host_volume_mapping\.json$/ ) {
            $node_a_host_volume_mapping_json = $_;
            $node_a_host_volume_mapping_json_exist = 1;
        }   

        if ( m/remote_system\.json$/ ) {
            $node_a_remote_system_json = $_;
            $node_a_remote_system_json_exist = 1;
        }

        if ( m/config_item\.json$/ ) {
            $node_a_config_item_json = $_;
            $node_a_config_item_json_exist = 1;
        }                              
    }

    $path = "./node_b/config_capture_management_data/*";
    @dir = glob($path);
    foreach (@dir) {
        if ( m/alert\.json$/ ) {
            $node_b_alert_json = $_;
            $node_b_alert_json_exist = 1;
        }    

        if ( m/volume\.json$/ ) {
            $node_b_volume_json = $_;
            $node_b_volume_json_exist = 1;
        }

        if ( m/host\.json$/ ) {
            $node_b_host_json = $_;
            $node_b_host_json_exist = 1;
        } 

        if ( m/host_group\.json$/ ) {
            $node_b_host_group_json = $_;
            $node_b_host_group_json_exist = 1;
        }

        if ( m/host_volume_mapping\.json$/ ) {
            $node_b_host_volume_mapping_json = $_;
            $node_b_host_volume_mapping_json_exist = 1;
        }  

        if ( m/remote_system\.json$/ ) {
            $node_b_remote_system_json = $_;
            $node_b_remote_system_json_exist = 1;
        }                                                   

        if ( m/config_item\.json$/ ) {
            $node_b_config_item_json = $_;
            $node_b_config_item_json_exist = 1;
        }        
    }


    $path = "./node_a/cyc_var/resources/*";
    @dir = glob($path);
    foreach (@dir) {
        if ( m/memory-node-a\.log$/ ) {
            $node_a_memory_node_a_log = $_;
            $node_a_memory_node_a_log_exist = 1;
        }       
    }   

    $path = "./node_b/cyc_var/resources/*";
    @dir = glob($path);
    foreach (@dir) {
        if ( m/memory-node-b\.log$/ ) {
            $node_b_memory_node_b_log = $_;
            $node_b_memory_node_b_log_exist = 1;
        }       
    }

    $path = "./node_a/var/log/sdnas/sdnas_logs/*";
    @dir = glob($path);
    foreach (@dir) {
        if ( m/sdnas_upgrade_playbook_status\.txt$/ ) {
            $node_a_sdnas_upgrade_playbook_status_txt = $_;
            $node_a_sdnas_upgrade_playbook_status_txt_exist = 1;
        }       
    }

    $path = "./node_b/var/log/sdnas/sdnas_logs/*";
    @dir = glob($path);
    foreach (@dir) {
        if ( m/sdnas_upgrade_playbook_status\.txt$/ ) {
            $node_b_sdnas_upgrade_playbook_status_txt = $_;
            $node_b_sdnas_upgrade_playbook_status_txt_exist = 1;
        }       
    }

    $path = "./node_a/command_output/";

    find({ wanted => sub { if (-f $_) {$node_a_dp_cache_txt = $_ if (m/cache\.txt$/)} },
         no_chdir => 1}, $path);        

    $node_a_dp_cache_txt_exist = 1 if ($node_a_dp_cache_txt ne '');

    find({ wanted => sub { if (-f $_) {$node_a_dp_app_txt = $_ if (m/app\.txt$/)} },
         no_chdir => 1}, $path);        

    $node_a_dp_app_txt_exist = 1 if ($node_a_dp_app_txt ne '');

    find({ wanted => sub { if (-f $_) {$node_a_dp_raid_txt = $_ if (m/raid\.txt$/)} },
         no_chdir => 1}, $path);        

    $node_a_dp_raid_txt_exist = 1 if ($node_a_dp_raid_txt ne '');

    find({ wanted => sub { if (-f $_) {$node_a_dp_mapper_txt = $_ if (m/mapper\.txt$/)} },
         no_chdir => 1}, $path);        

    $node_a_dp_mapper_txt_exist = 1 if ($node_a_dp_mapper_txt ne '');

    $path = "./node_b/command_output/";
    
    find({ wanted => sub { if (-f $_) {$node_b_dp_cache_txt = $_ if (m/cache\.txt$/)} },
         no_chdir => 1}, $path);

    $node_b_dp_cache_txt_exist = 1 if ($node_b_dp_cache_txt ne '');

    find({ wanted => sub { if (-f $_) {$node_b_dp_app_txt = $_ if (m/app\.txt$/)} },
         no_chdir => 1}, $path);        

    $node_b_dp_app_txt_exist = 1 if ($node_b_dp_app_txt ne '');

    find({ wanted => sub { if (-f $_) {$node_b_dp_raid_txt = $_ if (m/raid\.txt$/)} },
         no_chdir => 1}, $path);        

    $node_b_dp_raid_txt_exist = 1 if ($node_b_dp_raid_txt ne '');

    find({ wanted => sub { if (-f $_) {$node_b_dp_mapper_txt = $_ if (m/mapper\.txt$/)} },
         no_chdir => 1}, $path);        

    $node_b_dp_mapper_txt_exist = 1 if ($node_b_dp_mapper_txt ne '');

    $path = "./node_a/command_output/housemd/*";

    @dir = glob($path);
    foreach (@dir) {
        if ( m/show_xenv\.txt$/ ) {
            $node_a_housemd_show_xenv_txt = $_;
            $node_a_housemd_show_xenv_txt_exist = 1;
        } 

        if ( m/show_base_enclosure\.txt$/ ) {
            $node_a_housemd_show_base_enclosure_txt = $_;
            $node_a_housemd_show_base_enclosure_txt_exist = 1;
        }

        if ( m/show_dimms\.txt$/ ) {
            $node_a_housemd_show_dimms_txt = $_;
            $node_a_housemd_show_dimms_txt_exist = 1;
        }        

        if ( m/show_nodes\.txt$/ ) {
            $node_a_housemd_show_nodes_txt = $_;
            $node_a_housemd_show_nodes_txt_exist = 1;
        }

        if ( m/show_sfps\.txt$/ ) {
            $node_a_housemd_show_sfps_txt = $_;
            $node_a_housemd_show_sfps_txt_exist = 1;
        }

        if ( m/show_ioms\.txt$/ ) {
            $node_a_housemd_show_ioms_txt = $_;
            $node_a_housemd_show_ioms_txt_exist = 1;
        }

        if ( m/show_fanpacks\.txt$/ ) {
            $node_a_housemd_show_fanpacks_txt = $_;
            $node_a_housemd_show_fanpacks_txt_exist = 1;
        }
        
        if ( m/show_drives_basic\.txt$/ ) {
            $node_a_housemd_show_drives_basic_txt = $_;
            $node_a_housemd_show_drives_basic_txt_exist = 1;
        } 

        if ( m/show_localdisks\.txt$/ ) {
            $node_a_housemd_show_localdisks_txt = $_;
            $node_a_housemd_show_localdisks_txt_exist = 1;
        }  

        if ( m/show_exp_encls\.txt$/ ) {
            $node_a_housemd_show_exp_encls_txt = $_;
            $node_a_housemd_show_exp_encls_txt_exist = 1;
        } 

        if ( m/show_lccs_basic\.txt$/ ) {
            $node_a_housemd_show_lccs_basic_txt = $_;
            $node_a_housemd_show_lccs_basic_txt_exist = 1;
        }

        if ( m/show_scsi_reservations\.txt$/ ) {
            $node_a_housemd_show_scsi_reservations_txt = $_;
            $node_a_housemd_show_scsi_reservations_txt_exist = 1;
        }      

        if ( m/show_feport\.txt$/ ) {
            $node_a_housemd_show_feport_txt = $_;
            $node_a_housemd_show_feport_txt_exist = 1;
        }

        if ( m/show_initiators_connectivity\.txt$/ ) {
            $node_a_housemd_show_initiators_connectivity_txt = $_;
            $node_a_housemd_show_initiators_connectivity_txt_exist = 1;
        }                        
    }   

    $path = "./node_b/command_output/housemd/*";

    @dir = glob($path);
    foreach (@dir) {
        if ( m/show_xenv\.txt$/ ) {
            $node_b_housemd_show_xenv_txt = $_;
            $node_b_housemd_show_xenv_txt_exist = 1;
        }

        if ( m/show_base_enclosure\.txt$/ ) {
            $node_b_housemd_show_base_enclosure_txt = $_;
            $node_b_housemd_show_base_enclosure_txt_exist = 1;
        }

        if ( m/show_dimms\.txt$/ ) {
            $node_b_housemd_show_dimms_txt = $_;
            $node_b_housemd_show_dimms_txt_exist = 1;
        }        

        if ( m/show_nodes\.txt$/ ) {
            $node_b_housemd_show_nodes_txt = $_;
            $node_b_housemd_show_nodes_txt_exist = 1;
        }

        if ( m/show_sfps\.txt$/ ) {
            $node_b_housemd_show_sfps_txt = $_;
            $node_b_housemd_show_sfps_txt_exist = 1;
        }

        if ( m/show_ioms\.txt$/ ) {
            $node_b_housemd_show_ioms_txt = $_;
            $node_b_housemd_show_ioms_txt_exist = 1;
        }

        if ( m/show_fanpacks\.txt$/ ) {
            $node_b_housemd_show_fanpacks_txt = $_;
            $node_b_housemd_show_fanpacks_txt_exist = 1;
        }
        
        if ( m/show_drives_basic\.txt$/ ) {
            $node_b_housemd_show_drives_basic_txt = $_;
            $node_b_housemd_show_drives_basic_txt_exist = 1;
        }

        if ( m/show_localdisks\.txt$/ ) {
            $node_b_housemd_show_localdisks_txt = $_;
            $node_b_housemd_show_localdisks_txt_exist = 1;
        }

        if ( m/show_exp_encls\.txt$/ ) {
            $node_b_housemd_show_exp_encls_txt = $_;
            $node_b_housemd_show_exp_encls_txt_exist = 1;
        }

        if ( m/show_lccs_basic\.txt$/ ) {
            $node_b_housemd_show_lccs_basic_txt = $_;
            $node_b_housemd_show_lccs_basic_txt_exist = 1;
        }

        if ( m/show_scsi_reservations\.txt$/ ) {
            $node_b_housemd_show_scsi_reservations_txt = $_;
            $node_b_housemd_show_scsi_reservations_txt_exist = 1;
        }  

        if ( m/show_feport\.txt$/ ) {
            $node_b_housemd_show_feport_txt = $_;
            $node_b_housemd_show_feport_txt_exist = 1;
        }

        if ( m/show_initiators_connectivity\.txt$/ ) {
            $node_b_housemd_show_initiators_connectivity_txt = $_;
            $node_b_housemd_show_initiators_connectivity_txt_exist = 1;
        }                                                                 
    }

    $node_a_journal_exist = 1 if ( $#node_a_journal >= 0 );
    $node_b_journal_exist = 1 if ( $#node_b_journal >= 0 );    
}
#######################################################################


sub array_important_notice {
    print "\n\n######################################################################################################################\n";
    print "# Important Notice                                                                                                   #\n";
    print "#                                                                                                                    #\n";
    print "# 1. PST 500T node replacement needs to be escalated to GSE with logs BEFORE any node replacements take place.       #\n";
    print "#  https://www.dell.com/support/kbdoc/en-us/193398                                                                   #\n";
    print "######################################################################################################################\n\n";  
}


#######################################################################
sub array_procedure_list {
    print "\n\n######################################################################################################################\n";
    print "# Procedures list and useful websites                                                                                #\n";
    print "#                                                                                                                    #\n";
    print "# 1. SolveOnline PST procedure                                                                                       #\n";
    print "#  https://solveonline.emc.com/solve/home                                                                            #\n";
    print "# 2. SPMD Hardware Part Number                                                                                       #\n";
    print "#  https://spmd.dell.com/SPMD/TechSupport/                                                                           #\n";
    print "# 3. Port security for PST (management, supportassist etc)                                                           #\n";
    print "#  https://dl.dell.com/topicspdf/pwrstr-scg_en-us.pdf                                                                #\n";
    print "# 4. How to submit security vulnerability request?                                                                   #\n";
    print "#  https://dellservices.lightning.force.com/lightning/articles/Lightning_Knowledge/Customer-                         #\n";
    print "#   Reported-Product-Security-Issues-Guidance?language=en_US                                                         #\n";
    print "# 5. PowerStore: Collaboration Matrix - How to engage and work with other product teams                              #\n";
    print "#  https://www.dell.com/support/kbdoc/en-us/000130931/                                                               #\n";
    print "# 6. PowerStore X Upgrade Guide                                                                                      #\n";
    print "#  https://dl.dell.com/topicspdf/pwrstr-upgrade_en-us.pdf                                                            #\n";
    print "# 7. Order and account detailed info                                                                                 #\n";
    print "#  https://quality.dell.com/Home/welcome                                                                             #\n";
    print "# 8. PowerStore: Data Reduction efficiency and Storage efficiency guarantee programs                                 #\n";
    print "#  https://www.dell.com/support/kbdoc/en-us/190303                                                                   #\n";
    print "######################################################################################################################\n\n";    
}
#######################################################################


#######################################################################
sub array_code_known_issues {
    print "\n\n######################################################################################################################\n";
    print "# Code Release                                                                                                       #\n";
    print "#                                                                                                                    #\n";    
    print "# PowerStore                                                                                                         #\n";
    print "# Malka ETA Jan 2022                                                                                                 #\n";
    print "# 2.0.1.1-1471924   int/foothills-core-sp1  Oct 04, 2021   Foothills Core SP1 Patch 1                                #\n";                                                     
    print "# 2.0.1.0-1452126   int/foothills-core-sp1  Sep 09, 2021   Foothills Core SP1                                        #\n";                                                             
    print "# 2.0.0.0-1397847*  integration/foothills   Jun 30, 2021   Foothills Core (Re-spin)                                  #\n";                                                       
    print "# 2.0.0.0-1376722*  integration/foothills   Jun 10, 2021   Foothills Core Released                                   #\n";                                                     
    print "# 2.0.0.0-1371720*  integration/foothills   Jun 10, 2021   Foothills Core (factory installs only)                    #\n";                                          
    print "# 1.0.4.0.6.149*    hotfix/smuttynose-sp4   Aug 13, 2021   Smuttynose SP4.1 Hotfix 3                                 #\n";                                                     
    print "# 1.0.4.0.6.146*    hotfix/smuttynose-sp4   May 06, 2021   Smuttynose SP4.1 Hotfix 2                                 #\n";                                                     
    print "# 1.0.4.0.6.142*    hotfix/smuttynose-sp4   Apr 16, 2021   Smuttynose SP4.1 Hotfix 1                                 #\n";                                                     
    print "# 1.0.4.0.5.006     smuttynose-sp4          Mar 30, 2021   Smuttynose SP4.1 (Target Code: 04/14/2021 - Present)      #\n";
    print "# 1.0.4.0.6.140*    hotfix/smuttynose-sp4   Feb 22, 2021   Smuttynose SP4 Hotfix 1                                   #\n";                                                        
    print "# 1.0.4.0.5.003     smuttynose-sp4          Feb 03, 2021   Smuttynose SP4                                            #\n";                                                                
    print "# 1.0.3.0.6.135*    hotfix/smuttynose-sp3   Dec 22, 2020   Smuttynose SP3 Hotfix 1                                   #\n";                                                       
    print "# 1.0.3.0.5.007     smuttynose-sp3          Dec 17, 2020   Smuttynose SP3 (Target Code: 01/28/2021 - 04/14/2021)     #\n"; 
    print "# 1.0.2.0.6.119*    hotfix/smuttynose-sp2   Nov 13, 2020   Smuttynose SP2 Hotfix 2 Released                          #\n";                                            
    print "# 1.0.2.0.6.114*    hotfix/smuttynose-sp2   Sep 21, 2020   Smuttynose SP2 Hotfix 1 Released                          #\n";                                            
    print "# 1.0.2.0.5.003     smuttynose-sp2          Sep 16, 2020   Smuttynose SP2                                            #\n";                                                                 
    print "# 1.0.1.0.5.003     smuttynose-sp1          Aug 24, 2020   Smuttynose SP1.1                                          #\n";                                                              
    print "# 1.0.1.0.5.002     smuttynose-sp1          Jun 16, 2020   Smuttynose SP1                                            #\n";                                                                 
    print "# 1.0.0.0.5.109     smuttynose              May 05, 2020   Smuttynose GA                                             #\n";
    print "#                                                                                                                    #\n";                                         
    print "# SDNAS:                                                                                                             #\n";
    print "# 1.0.3.0.3.327     hawaii-sp3         Jun 10, 2021   Hawaii SP3 Included with                                       #\n"; 
    print "#                                                                PowerStore Foothills Core & SP1 (2.0.0.0 & 2.0.1.0) #\n";    
    print "# 1.0.2.9.3.205*    hawaii/sp2         Feb 03, 2021   Hawaii SP2 Included with PowerStore SP4 (1.0.4.0.5.003)        #\n"; 
    print "# 1.0.1.9.3.143     hawaii/sp1         Dec 17, 2020   Hawaii SP1 Included with PowerStore SP3 (1.0.3.0.5.007)        #\n"; 
    print "# 1.0.0.0.6.241508* hotfix/hawaii/p07  Sep 23, 2020   Hawaii Included with PowerStore SP2 (1.0.2.0.5.003)            #\n"; 
    print "# 1.0.0.6.6.241502* hotfix/hawaii/hf1  Jun 16, 2020   Hawaii Included with PowerStore SP1 (1.0.1.0.5.002)            #\n"; 
    print "# 1.0.0.0.5.2415    sdnas/hawaii       May 05, 2020   Hawaii  GA with PowerStore                                     #\n";                                                
    print "######################################################################################################################\n\n";


    print "\n\n######################################################################################################################\n";
    print "# POWERSTORE SMUTTYNOSE SP2: RTS 16 Sept 2020                                                                        #\n";
    print "# Version 1.0.2.0.5.003                                                                                              #\n";
    print "# REVISE ICM NETWORK BEHAVIOR (SN SP2):                                                                              #\n";
    print "# --Support for FC-Only Appliance                                                                                    #\n";
    print "# --For single Unified NAS systems only, this feature redirects ICM communications from the requirement to pass      #\n"; 
    print "#  through the System bond Ports 0 & 1 and the Top-of-Rack switches, between the Nodes, to pass through the          #\n";
    print "#  backplane interconnect                                                                                            #\n";
    print "#  interfaces (twin10GbE) between Node A and Node B, instead.                                                        #\n";
    print "# Note: The net effect of this would be that the use of ToR switches would not be required for Cluster Creation      #\n";
    print "#  purposes, particularly if the system is only going to be used for Fibre Channel Hosts.                            #\n";
    print "# --This feature allows for simpler installation of a single PowerStore T Unified/NAS appliance,without TOR switches #\n";
    print "# Note: Basic goal to bypass network complexities by allowing single Unified system to be setup in its Cluster       #\n";
    print "# --This feature does not remove the requirement to use ToR switches with the proper Native VLAN ports,              #\n";
    print "#  if using SDNAS, iSCSI, or Replication                                                                             #\n";
    print "# --If SDNAS is required, then cabling of mezzanine ports 0 & 1 (i.e., System Bond) is also required,                #\n";
    print "#  along with the use of ToR switches                                                                                #\n";
    print "# --If iSCSI is required, then cabling of mezzanine ports will also be required in order to support IP connectivity, #\n";
    print "#  along with ToR switches                                                                                           #\n";
    print "# --This feature is not intended for Block Optimized systems, PowerStore X systems, or any multi-appliance           #\n";
    print "#  Clusters, as all these scenarios would require the use of ToR switches and cabling of the mezzanine 4-port        #\n";
    print "#  card on each Node                                                                                                 #\n";
    print "# --The ICM redirect supports SDNAS inter-container and SDNAS-to-PowerStore communications with this feature         #\n";
    print "# --One specific Use Case for this feature, without requiring ToR switches, would be for FC-only configurations,     #\n";
    print "#  where IP networking is not required for Host support                                                              #\n";
    print "# --The ICM network is IPv6-only, encrypted via IPSEC, requires native VLAN-configured switch ports if using ToR,    #\n";
    print "#  cannot be manually configured or reconfigured                                                                     #\n"; 
    print "######################################################################################################################\n\n";
    

    print "\n\n######################################################################################################################\n";
    print "# Array Known Issues                                                                                                 #\n";
    print "#                                                                                                                    #\n";
    print "# Hardware:                                                                                                          #\n";
    print "# 1. PowerStore: D\@RE Encryption key issue that may cause a data integrity issue                                     #\n";
    print "#  https://www.dell.com/support/kbdoc/en-us/000191410/                                                               #\n";
    print "# 2. PowerStore 500T Node Replacement Failure: PXE Server Not Reachable During Booting Phase                         #\n";
    print "#  https://confluence.cec.lab.emc.com/display/ETS/Riptide+-+PowerStore+500T+Node+Replacement+Failure%3A+PXE+Server+Not+Reachable+During+Booting+Phase #\n";
    print "#                                                                                                                    #\n";   
    print "# Reboot:                                                                                                            #\n";
    print "# 1. Node reboot alert not cleared after NDU (re-visioned MDT-144301)                                                #\n";
    print "#  https://www.dell.com/support/kbdoc/en-us/000125660/                                                               #\n";
    print "# 2. Node in service mode has / (root) partition full due to many dumps from db_space_check_ev                       #\n";
    print "#  https://www.dell.com/support/kbdoc/en-us/000124773/                                                               #\n";
    print "#                                                                                                                    #\n";
    print "# Networking:                                                                                                        #\n";
    print "# 1. Excessive Switch SSH Login may trigger bug in DELL TOR switch that causes OOM & ToR reboot.                     #\n";
    print "#  Fixed in Power-Switch OS 10.5.2.0                                                                                 #\n";
    print "#  https://www.dell.com/support/kbdoc/en-us/000130082/                                                               #\n";
    print "#  https://confluence.cec.lab.emc.com/pages/viewpage.action?pageId=393817278#ExcessiveSwitch                         #\n";
    print "#   SSHLoginmaytriggerbuginDELLTORswitchthatcausesOOM&ToRreboot-Impact                                               #\n";
    print "# 2. Hosts may disconnect during fabric changes (zone changes) in a Cisco FC switch configured                       #\n";
    print "#     with RSCN-3 format (default from NX-OS 6.2)                                                                    #\n";
    print "#  Fixed in SN SP3                                                                                                   #\n";
    print "#  https://www.dell.com/support/kbdoc/en-us/000181461/                                                               #\n";
    print "#  https://confluence.cec.lab.emc.com/display/ETS/Fabric+change+on+Cisco+FC+switches+may+lead+to+DU                  #\n";
    print "# 3. PowerStore: Direct attached fibre channel volumes are not detected by ESXi hosts in PowerStoreOS 2.0            #\n";
    print "#  https://www.dell.com/support/kbdoc/en-us/000193380/                                                               #\n";
    print "#                                                                                                                    #\n";
    print "# Factory Reset:                                                                                                     #\n";
    print "# 1. MDT-232828 Svc_factory_reset script was intermitted by some Customer's action (Ctrl+C,                          #\n"; 
    print "#     power outage or something)                                                                                     #\n";
    print "#  https://confluence.cec.lab.emc.com/display/ETS/Factory+Reset+failed                                               #\n";
    print "# 2. TEE-724, MDT-229833 svc_factory_reset or *.bin file reimage nodes will wipe out the                             #\n";
    print "#     'vsphere enterprise plus license' on PowerStoreX nodes.                                                        #\n";
    print "#  https://confluence.cec.lab.emc.com/pages/viewpage.action?pageId=371560162                                         #\n";
    print "#  https://www.dell.com/support/kbdoc/en-us/180691                                                                   #\n";
    print "#                                                                                                                    #\n";
    print "# NDU:                                                                                                               #\n";
    print "# 1. TEE-2311 PUHC failure: Too much storage capacity to allow cached DeDup. The upgrade cannot                      #\n";
    print "#     start because Cached DeDup will have insufficient memory.                                                      #\n"; 
    print "#  https://www.dell.com/support/kbdoc/en-us/000191981/                                                               #\n";
    print "#                                                                                                                    #\n";
    print "# Services:                                                                                                          #\n";
    print "# 1. MDT-142484 Fail to DELETE HostGroup, Host by REST or GUI                                                        #\n";
    print "#  Error code 0xE0A03001000B - Invalid host group ID is provided                                                     #\n";
    print "#  Error code 0xE0A010010002 - No Host config item found for ID provided                                             #\n";
    print "#  Resolution:  Delete it from the management database.                                                              #\n";
    print "#  https://confluence.cec.lab.emc.com/pages/viewpage.action?pageId=293025169                                         #\n";
    print "# 2. MDT-302981 Failed to upload a version This package is already uploaded on                                       #\n"; 
    print "#     the system (0xE04030010035)                                                                                    #\n";
    print "#  Package entry exists in SYM, but CP is not aware.                                                                 #\n";
    print "#  https://confluence.cec.lab.emc.com/display/ETS/Failed+to+upload+an+upgrade+package                                #\n";
    print "#  https://www.dell.com/support/kbdoc/en-us/000190884/                                                               #\n";
    print "# 3. After a node reboot Support Materials are no longer being sent to Dell                                          #\n";
    print "#  https://www.dell.com/support/kbdoc/en-us/000130745/                                                               #\n";
    print "#                                                                                                                    #\n";
    print "# Replication:                                                                                                       #\n";
    print "# 1. Replication can be impacted if node(s) rebooted in FHC                                                          #\n";
    print "#  https://confluence.cec.lab.emc.com/display/ETS/Replication+can+be+impacted+if+node%28s%29+rebooted+in+FHC         #\n";
    print "#                                                                                                                    #\n";    
    print "# Performance:                                                                                                       #\n";
    print "# 1. MDT-33835, TEE-452 High CPU usage and memory usage alarm against PowerStoreX Controller VM in vCenter           #\n";
    print "#  Virtual machine memory usage and Virtual machine CPU usage alarm against PowerStoreX Controller VM in vCenter.    #\n"; 
    print "#  After Reset to Green in vCenter, the alarms returned after a day or so.                                           #\n";
    print "#  Function as designed. The issue may be addressed in FootHills (MDT-237745)                                        #\n";
    print "#  https://confluence.cec.lab.emc.com/display/ETS/High+CPU+usage+and+memory+usage+alarm+                             #\n";
    print "#   against+PowerStoreX+Controller+VM+in+vCenter#HighCPUusageandmemoryusagealarmagainst                              #\n";
    print "#   PowerStoreXControllerVMinvCenter-Workaround:                                                                     #\n";
    print "#  https://www.dell.com/support/kbdoc/en-us/149604                                                                   #\n";
    print "# 2. MDT-218936 Large Sequential Block IO May Cause High Latency                                                     #\n";
    print "#  Affected in All SmuttyNose Version, improve in FHC                                                                #\n";
    print "#  https://confluence.cec.lab.emc.com/display/ETS/Large+Sequential+Block+IO+May+Cause+High+Latency                   #\n";
    print "#  TRIES-35671 - https://jira.cec.lab.emc.com/browse/TRIES-35671                                                     #\n";
    print "#  Enhancements to increase flush performance under burst workloads and Enhancements to                              #\n"; 
    print "#   sequential IO workloads, allowing more parallel flushing of ingested data*                                       #\n";  
    print "# 3. Enhancement to large UNMAP performance                                                                          #\n";
    print "#  https://jira.cec.lab.emc.com/browse/TRIF-822                                                                      #\n";
    print "# 4. Enhancements to optimize flushing over dedupping data inline when the system is getting                         #\n";
    print "#     close to throttling (non-deduped data will later be process).                                                  #\n";
    print "#  https://jira.cec.lab.emc.com/browse/TRIF-1                                                                        #\n";
    print "# 5. PowerStore: Non-primary Node unable to display performance metrics with \"no data to display\" (mdt-311324)       #\n";
    print "#  https://www.dell.com/support/kbdoc/en-us/000189844/                                                               #\n";
    print "######################################################################################################################\n\n";
}


#######################################################################
sub array_configuration_header {
    print "\n\n######################################################################################################################\n";
    print "# Array Configuraiton Part                                                                                           #\n";
    print "#                                                                                                                    #\n";    
    print "# 1. Basic info                                                                                                      #\n";
    print "# 2. Hardware info                                                                                                   #\n";
    print "# 3. Volume info                                                                                                     #\n";
    print "# 4. VVol info                                                                                                       #\n";
    print "# 5. Data Path status                                                                                                #\n";
    print "# 6. Alert list                                                                                                      #\n";
    print "# 7. DC log list                                                                                                     #\n";
    print "# 8. Dump list                                                                                                       #\n";
    print "# 9. Host list                                                                                                       #\n";
    print "######################################################################################################################\n\n";
}
#######################################################################


#######################################################################
sub array_basic_info {
    print "\n\ncccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc\n";
    print "  Array Configuraiton Part: sub array_basic_info                                               c\n";
    print "  log location: node_x/command_output/: svc_diag_list_info svc_diag_list_basic                 c\n";
    print "                                                                                               c\n";
    print "  tip 1:                                                                                       c\n";
    print "   both node-a and node-b expected mode should be normal.                                      c\n";        
    print "  tip 2:                                                                                       c\n";
    print "   in case where NDU succeeded, but system version was not updated correctly, its easy to      c\n";
    print "    detect by running the svc_diag list --basic                                                c\n";
    print "   example                                                                                     c\n";
    print "   as you can see, all container versions were already upgraded to version 1.0.2.0.5.003       c\n"; 
    print "    (can also be verified by running docker ps) but the nodes, appliance and cluster versions  c\n";
    print "    is still 1.0.0.0.5.109.                                                                    c\n";
    print "   node a:                                                                                     c\n";
    print "   release_version: 1.0.0.0.5.109                                                              c\n";
    print "   service: cyc_service_20200905175031_cbbec0-1.0.2.0.5.003                                    c\n";
    print "   xms: cyc_xms_20200905175031_cbbec0-1.0.2.0.5.003                                            c\n";
    print "   bsc: cyc_bsc_20200905175031_cbbec0-1.0.2.0.5.003                                            c\n";
    print "   https://confluence.cec.lab.emc.com/display/ETS/How+to+Update+System+Version+After+NDU       c\n";
    print "                                                                                               c\n";    
    print "  svc_diag list --info may print error as below on non-sym node. it is probably expected for   c\n";
    print "   single appliance storage becuase tor switch is not needed for icm. backplane is used instead. c\n";
    print "  Failure to connect to database: could not connect to server: Connection timed out            c\n";
    print "  Is the server running on host \"fd57:fc8b:4fbd::201:44f7:f5e9:5d3a\" (fd57:fc8b:4fbd:0:201:44f7:f5e9:5d3a) and accepting c\n";       
    print "  TCP/IP connections on port 5433?                                                             c\n";
    print "cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc\n\n";

    print "[node_a/command_output/: svc_diag_list_info]\n\n";
    if ($node_a_svc_diag_list_info_txt_exist) {
        open(my $file,  "<",  $node_a_svc_diag_list_info_txt)  or die "Can't open $node_a_svc_diag_list_info_txt: $!";
        while (<$file>) {
            print "$_";
        }
        close $file;
    }

    print "[node_b/command_output/: svc_diag_list_info]\n\n";
    if ($node_b_svc_diag_list_info_txt_exist) {
        open(my $file,  "<",  $node_b_svc_diag_list_info_txt)  or die "Can't open $node_b_svc_diag_list_info_txt: $!";
        while (<$file>) {
            print "$_";
        }
        close $file;
    }

    print "\n[node_x/command_output/: svc_diag_list_basic]\n\n";
    if ($node_a_svc_diag_list_basic_txt_exist) {
        open(my $file,  "<",  $node_a_svc_diag_list_basic_txt)  or die "Can't open $node_a_svc_diag_list_basic_txt: $!";
        while (<$file>) {
            print "$_";
        }
        close $file;
    } elsif ($node_b_svc_diag_list_basic_txt_exist) {
        open(my $file,  "<",  $node_b_svc_diag_list_basic_txt)  or die "Can't open $node_b_svc_diag_list_basic_txt: $!";
        while (<$file>) {
            print "$_";
        }
        close $file;
    }     
}
#######################################################################


#######################################################################
sub array_hardware {
    print "\ncccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc\n";
    print "  Array Configuraiton Part: sub array_hardware: hardware info                                  c\n";
    print "  log location: node_x/command_output/: svc_diag_list_icw_hardware                             c\n";
    print "  error examples:                                                                              c\n";
    print "  1. DIMM                                                                                      c\n";
    print "   FLT | DIMM21                                                                                c\n";
    print "  2. Disk Recoganiz and Expansion enclosure                                                    c\n";
    print "   Drive Check               : Failed                                                          c\n";
    print "   Node Drives Compare Check : Failed                                                          c\n";
    print "   Enclosure Check           : Failed                                                          c\n";
    print "   compareNodeDrives - Nodes see different number of                                           c\n";
    print "                       drives(SAS Drives have dual paths/seen twice) -> miscable (tee-2361)    c\n";
    print "   compareNodeDrives SAS Drive Diff (NodeA Missing SN's): set([])                              c\n";
    print "   checkExpansionEnclosures - Dual/HA connections to enclosures not seen                       c\n";
    print "  3. M2STAT                                                                                    c\n";
    print "   EmbeddedDrve Drive00: FLT | Drive01: OK |                                                   c\n";
    print "                                                                                               c\n";
    print "  CPU module probably reports FLT if any internal component like DIMM is faulted.              c\n";
    print "   System Bit 0 CPU Module: FLT                                                                c\n";
    print "   Replace internal faulted component may help clear the CPU fault possibly.                   c\n"; 
    print "cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc\n\n";

    print "\n[node_x/command_output/: svc_diag_list_icw_hardware]\n\n";
    if ($node_a_svc_diag_list_icw_hardware_txt_exist) {
        open(my $file,  "<",  $node_a_svc_diag_list_icw_hardware_txt)  or die "Can't open $node_a_svc_diag_list_icw_hardware_txt: $!";
        while (<$file>) {
            print "$_";
        }
        close $file;
    } elsif ($node_b_svc_diag_list_icw_hardware_txt_exist) {
        open(my $file,  "<",  $node_b_svc_diag_list_icw_hardware_txt)  or die "Can't open $node_b_svc_diag_list_icw_hardware_txt: $!";
        while (<$file>) {
            print "$_";
        }
        close $file;
    }
}
#######################################################################


#######################################################################
sub array_sdr_hardware {
    print "\ncccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc\n";
    print "  Array Configuraiton Part: sub array_sdr_hardware: hardware info                              c\n";
    print "  log location: node_x/command_output/: cyc_ipmitool_sdr_elist                                 c\n";
    print "  error examples:                                                                              c\n";
    print "   PS1_Status       | 98h | ns  | 10.1 | No Reading                                            c\n";
    print "   PS1_Input_Power  | 99h | ns  | 10.1 | No Reading                                            c\n";
    print "   PS1_In_Voltage   | 9Ah | ns  | 10.1 | No Reading                                            c\n";
    print "   PS1_Temp0        | 9Bh | ns  | 10.1 | No Reading                                            c\n";
    print "   PS1_Temp1        | 9Ch | ns  | 10.1 | No Reading                                            c\n";
    print "   PS_Redundancy    | CAh | ok  | 19.0 | Redundancy Lost                                       c\n";
    print "  No Reading is expected if no hardware installed                                              c\n";
    print "  Please check what hardware part installed from previous svc_diag_list_icw_hardware in report c\n";
    print "cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc\n\n";

    print "[node-a cyc_ipmitool_sdr_elist_txt]\n";
    if ($node_a_cyc_ipmitool_sdr_elist_txt_exist) {
        open(my $file,  "<",  $node_a_cyc_ipmitool_sdr_elist_txt)  or die "Can't open $node_a_cyc_ipmitool_sdr_elist_txt: $!";
        while (<$file>) {
            print "$_";
        }
        close $file;
    }

    print "\n[node-b cyc_ipmitool_sdr_elist_txt]\n";
    if ($node_b_cyc_ipmitool_sdr_elist_txt_exist) {
        open(my $file,  "<",  $node_b_cyc_ipmitool_sdr_elist_txt)  or die "Can't open $node_b_cyc_ipmitool_sdr_elist_txt: $!";
        while (<$file>) {
            print "$_";
        }
        close $file;
    }
}
#######################################################################


#######################################################################
sub array_dp_status {
    print "\ncccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc\n";
    print "  Array Configuraiton Part: sub array_dp_status: array node-a and node-b data path status      c\n";
    print "  log location: {DC_Filename}/node_*/command_output/dc-datapath-[timestamp]-logs/app.txt       c\n";
    print "  root needed: svc_storage_integrity_check --dpcli                                             c\n";
    print "  Enter the DP CLI command to run or q to quit: app get_app_state                              c\n";
    print "   get app state successful.                                                                   c\n";
    print "   app state : 1 (running)                                                                     c\n";
    print "   raid state : 1 (running)                                                                    c\n";
    print "   mapper state : 0 (initting)                                                                 c\n";
    print "   cache state : 0 (initting)                                                                  c\n";
    print "   data path state: 0 (initting)                                                               c\n";
    print "   system type: HW_BM                                                                          c\n";
    print "   app PID: 742                                                                                c\n"; 
    print "  All 1 indicates datapath running normally!                                                   c\n"; 
    print "  Otherwise, 0 indicats data path problem and possible DU.                                     c\n";
    print "cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc\n\n";

    print "[node-a DP status]\n";
    if ($node_a_dp_app_txt_exist) {
        open(my $file,  "<",  $node_a_dp_app_txt)  or die "Can't open $node_a_dp_app_txt: $!";
        my $hit = 0;
        while (<$file>) {
            next unless ( m/get app state successful/ or $hit == 1);
            last if (m/Monitor Thread Ran /);
            $hit = 1;
            print "$_";
        }
        close $file;
    }

    print "[node-b DP status]\n";
    if ($node_b_dp_app_txt_exist) {
        open(my $file,  "<",  $node_b_dp_app_txt)  or die "Can't open $node_b_dp_app_txt: $!";
        my $hit = 0;
        while (<$file>) {
            next unless ( m/get app state successful/ or $hit == 1);
            last if (m/Monitor Thread Ran /);
            $hit = 1;
            print "$_";
        }
        close $file;
    }
}
#######################################################################


#######################################################################
sub array_drr_status {
    print "\ncccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc\n";
    print "  Array Configuraiton Part: sub array_drr_status: compression and drr status                   c\n";
    print "  log location: {DC_Filename}/node_*/command_output/cli.py_namespace_spacestats_enumtenants.txt c\n";
    print "  Tenant ID 1 contains compression statistics.                                                 c\n";
    print "  Tenant ID 5 contains dedup statistics.                                                       c\n";
    print "  Deduped Space (Only for tenant 5)                                                            c\n";
    print "   if data_physical_used is reported as wrong at cluster or appliance level, check             c\n";
    print "   the \"Deduped Space\" for tenant 5 in all appliances. data_physical_used is also              c\n";
    print "   adjusted base don shared_logical_used and DRR. Look in the link provided in 2nd column      c\n";
    print "   and verify other attributes that is depended on.                                            c\n";
    print "                                                                                               c\n";
    print "  Known issues:                                                                                c\n";
    print "  1. PowerStore: Deduplication ratio causes back-end latency                                   c\n";
    print "   https://www.dell.com/support/kbdoc/en-us/000186778/                                         c\n";
    print "  2. PowerStore: Data Reduction efficiency and Storage efficiency guarantee programs           c\n";
    print "   https://www.dell.com/support/kbdoc/en-us/190303                                             c\n";
    print "   Outside of break/fix scenarios, any questions or complaints from Customers (regarding 4:1   c\n";
    print "   DRR offer) should be referred to a Sales account manager, who should then engage            c\n";
    print "   STORAGE.DATA.REDUCTION team ( storage.data.rduction\@dell.com) D-list for further assistance. c\n";     
    print "cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc\n\n";

    print "[System DRR Status]\n";
    if ($node_a_cli_py_namespace_spacestats_enumtenants_txt_exist) {
        open(my $file,  "<",  $node_a_cli_py_namespace_spacestats_enumtenants_txt)  or die "Can't open $node_a_cli_py_namespace_spacestats_enumtenants_txt: $!";
        while (<$file>) {
            print "$_";
        }
        close $file;
    } elsif ($node_b_cli_py_namespace_spacestats_enumtenants_txt_exist) {
        open(my $file,  "<",  $node_b_cli_py_namespace_spacestats_enumtenants_txt)  or die "Can't open $node_b_cli_py_namespace_spacestats_enumtenants_txt: $!";
        while (<$file>) {
            print "$_";
        }
        close $file;
    }
}
#######################################################################


#######################################################################
sub array_replication_status {
    print "\nbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb\n";
    print "  Array Configuraiton Part: sub array_replication_status: array replication status             b\n";
    print "  log location: {DC_Filename}/node_*/config_capture_management_data/remote_system.json         b\n";
    print "                                                                                               b\n";
    print "  Replication:                                                                                 b\n";
    print "  1. Replication can be impacted if node(s) rebooted in FHC (MDT-342857)                       b\n";
    print "   https://confluence.cec.lab.emc.com/display/ETS/Replication+can+be+impacted+if+node%28s%29+rebooted+in+FHC b\n"; 
    print "  cluster with more than one storage network, and replication tag is on one of the network,    b\n"; 
    print "   if system A has SYM node reboot or SYM restart, remote system is Partial/complete data      b\n";
    print "   connection loss.                                                                            b\n";
    print "  https://www.dell.com/support/kbdoc/en-us/000192782/                                          b\n";
    print "                                                                                               b\n";    
    print "  internal data connection for replication exists by default even without real remote system   b\n";
    print "  data_connection state and management_state should be ok for both internal and real remote system connection b\n";
    print "  for partial connection, please verify connectivity like mtu settings need be consistent.     b\n";
    print "bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb\n\n";

    my $data_connection_state = '';
    my $data_network_latency = '';
    my $iscsi_addresses = '';
    my $is_internal = '';
    my $management_address = '';
    my $name = '';
    my $state = '';
    my $version = '';
    my $description = '';

    print "[Replication Remote System]\n";

    if ($node_a_remote_system_json_exist) {        
        print "\n------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------\n";        
        print "| data_connection_state      | data_network_latency | iscsi_addresses                                  | is_internal | management_address         | name                | state    | version    | description                |\n";
        print "------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------\n";        
    
        open (FILE, $node_a_remote_system_json) or die "Cannot open $node_a_remote_system_json: $!\n";      
        my $hit = 0;
        while ( <FILE> ) {
            $_ =~ s/^\s+|\s+$//g;
            $data_connection_state = $_ if ( m/\"data_connection_state\":/ );
            $data_network_latency = $_ if ( m/\"data_network_latency\":/ ); 
            $description = $_ if ( m/\"description\":/ ); 
            $is_internal = $_ if ( m/\"is_internal\":/ );
            if ( m/\"management_address\":/ ) {
                $management_address = $_;
                $hit = 0;
            }
            $name = $_ if ( m/\"name\":/ );
            $state = $_ if ( m/\"state\":/ );
            $hit = 1 if ( m/\"iscsi_addresses\":/ );
            if ($hit == 1) {
                next if ( m/],/ );
                next if ( m/\"iscsi_addresses\":/ );
                if ( $iscsi_addresses ne '' ) {
                    $_ =~ s/^\s+//;
                    $iscsi_addresses = $iscsi_addresses."\n".$_;
                } else {
                    $_ =~ s/^\s+//;
                    $iscsi_addresses = $_;
                }
            }
                                                                                                                                            
            if ( m/\"version\":/ ) {
                $version = $_;
                my @tmp = split( /:\s+/, $data_connection_state );
                $data_connection_state = $tmp[1];
                chop $data_connection_state;
                
                @tmp = split( /:\s+/, $data_network_latency );
                $data_network_latency = $tmp[1];
                chop $data_network_latency;

                @tmp = split( /:\s+/, $description );
                $description = $tmp[1];
                chop $description;

                @tmp = split( /:\s+/, $is_internal );
                $is_internal = $tmp[1];
                chop $is_internal;

                @tmp = split( /:\s+/, $management_address );
                $management_address = $tmp[1];
                chop $management_address;

                @tmp = split( /:\s+/, $name );
                $name = $tmp[1];
                chop $name;
                
                @tmp = split( /:\s+/, $state );
                $state = $tmp[1];
                chop $state;

                $~ = REPSYSTEMA;
                                
                format REPSYSTEMA =     
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------         
| ^<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<< | ^<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<<<<<<<< | ^<<<<<<< | ^<<<<<<<<< | ^<<<<<<<<<<<<<<<<<<<<<<<<< |
$data_connection_state, $data_network_latency, $iscsi_addresses, $is_internal, $management_address, $name, $state, $version, $description
| ^<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<< | ^<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<<<<<<<< | ^<<<<<<< | ^<<<<<<<<< | ^<<<<<<<<<<<<<<<<<<<<<<<<< |
$data_connection_state, $data_network_latency, $iscsi_addresses, $is_internal, $management_address, $name, $state, $version, $description
| ^<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<< | ^<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<<<<<<<< | ^<<<<<<< | ^<<<<<<<<< | ^<<<<<<<<<<<<<<<<<<<<<<<<< |
$data_connection_state, $data_network_latency, $iscsi_addresses, $is_internal, $management_address, $name, $state, $version, $description
| ^<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<< | ^<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<<<<<<<< | ^<<<<<<< | ^<<<<<<<<< | ^<<<<<<<<<<<<<<<<<<<<<<<<< |
$data_connection_state, $data_network_latency, $iscsi_addresses, $is_internal, $management_address, $name, $state, $version, $description
.
                write; 
                                        
                $data_connection_state = '';
                $data_network_latency = '';
                $iscsi_addresses = '';
                $is_internal = '';
                $management_address = '';
                $name = '';
                $state = '';
                $version = '';
                $description = '';
            }
        }
        close FILE;
        print "------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------\n";
    }

    if ($node_b_remote_system_json_exist) {        
        print "\n------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------\n";        
        print "| data_connection_state      | data_network_latency | iscsi_addresses                                  | is_internal | management_address         | name                | state    | version    | description                |\n";
        print "------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------\n";        
    
        open (FILE, $node_b_remote_system_json) or die "Cannot open $node_b_remote_system_json: $!\n";      
        my $hit = 0;
        while ( <FILE> ) {
            $_ =~ s/^\s+|\s+$//g;
            $data_connection_state = $_ if ( m/\"data_connection_state\":/ );
            $data_network_latency = $_ if ( m/\"data_network_latency\":/ ); 
            $description = $_ if ( m/\"description\":/ ); 
            $is_internal = $_ if ( m/\"is_internal\":/ );
            if ( m/\"management_address\":/ ) {
                $management_address = $_;
                $hit = 0;
            }
            $name = $_ if ( m/\"name\":/ );
            $state = $_ if ( m/\"state\":/ );
            $hit = 1 if ( m/\"iscsi_addresses\":/ );
            if ($hit == 1) {
                next if ( m/],/ );
                next if ( m/\"iscsi_addresses\":/ );
                if ( $iscsi_addresses ne '' ) {
                    $_ =~ s/^\s+//;
                    $iscsi_addresses = $iscsi_addresses."\n".$_;
                } else {
                    $_ =~ s/^\s+//;
                    $iscsi_addresses = $_;
                }
            }
                                                                                                                                            
            if ( m/\"version\":/ ) {
                $version = $_;
                my @tmp = split( /:\s+/, $data_connection_state );
                $data_connection_state = $tmp[1];
                chop $data_connection_state;
                
                @tmp = split( /:\s+/, $data_network_latency );
                $data_network_latency = $tmp[1];
                chop $data_network_latency;

                @tmp = split( /:\s+/, $description );
                $description = $tmp[1];
                chop $description;

                @tmp = split( /:\s+/, $is_internal );
                $is_internal = $tmp[1];
                chop $is_internal;

                @tmp = split( /:\s+/, $management_address );
                $management_address = $tmp[1];
                chop $management_address;

                @tmp = split( /:\s+/, $name );
                $name = $tmp[1];
                chop $name;
                
                @tmp = split( /:\s+/, $state );
                $state = $tmp[1];
                chop $state;

                $~ = REPSYSTEMB;
                                
                format REPSYSTEMB =     
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------         
| ^<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<< | ^<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<<<<<<<< | ^<<<<<<< | ^<<<<<<<<< | ^<<<<<<<<<<<<<<<<<<<<<<<<< |
$data_connection_state, $data_network_latency, $iscsi_addresses, $is_internal, $management_address, $name, $state, $version, $description
| ^<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<< | ^<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<<<<<<<< | ^<<<<<<< | ^<<<<<<<<< | ^<<<<<<<<<<<<<<<<<<<<<<<<< |
$data_connection_state, $data_network_latency, $iscsi_addresses, $is_internal, $management_address, $name, $state, $version, $description
| ^<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<< | ^<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<<<<<<<< | ^<<<<<<< | ^<<<<<<<<< | ^<<<<<<<<<<<<<<<<<<<<<<<<< |
$data_connection_state, $data_network_latency, $iscsi_addresses, $is_internal, $management_address, $name, $state, $version, $description
| ^<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<< | ^<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<<<<<<<< | ^<<<<<<< | ^<<<<<<<<< | ^<<<<<<<<<<<<<<<<<<<<<<<<< |
$data_connection_state, $data_network_latency, $iscsi_addresses, $is_internal, $management_address, $name, $state, $version, $description
.
                write; 
                                        
                $data_connection_state = '';
                $data_network_latency = '';
                $iscsi_addresses = '';
                $is_internal = '';
                $management_address = '';
                $name = '';
                $state = '';
                $version = '';
                $description = '';
            }
        }
        close FILE;
        print "------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------\n";
    }
}
#######################################################################


#######################################################################
sub array_reboot_info {
    print "\n\ncccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc\n";
    print "  sub array_reboot_info: array node reboot info                                                c\n";
    print "  log location: node_x/command_output/: cyc_ipmitool_sel_elist                                 c\n";
    print "  bmc supports node reboot or shutdown sensor for logging an SEL event due to emergency        c\n";
    print "   shutdown of node or due to loss of power supply redundancy                                  c\n";
    print "                                                                                               c\n";
    print "  how to read bmc sel log:                                                                     c\n";
    print "  asserted: sending singal (usually negative or detect in progress)                            c\n";
    print "  deasserted: stopping singnal (usually positive or stop detect)                               c\n";
    print "  1.node reboot                                                                                c\n";
    print "   sel events usually start with Power Reset and end with Starting OS boot process             c\n";
    print "   SSP Power/Reset Action | Power/Reset Action | ICH/PCH Reset Detected | Asserted             c\n";
    print "    ELOG(13) RESET EVENT                                                                       c\n";
    print "   BIOS Progress |  BIOS Progress/Event | Starting OS boot process | Asserted                  c\n";
    print "                                                                                               c\n";
    print "  error examples:                                                                              c\n";
    print "  1.m2sata 0                                                                                   c\n";
    print "   EPOST Error Message | Onboard Removable Disk 0 | EPOST Failure | Asserted |                 c\n";
    print "    Error code=0x0420                                                                          c\n";
    print "   ELOG(139) ErrorCode: 0x00000420 Device: M.2 SATA 0 Description: Storage device              c\n";
    print "    not found Error!                                                                           c\n";
    print "  2.m2sata 0 and m2sata 1                                                                      c\n";
    print "   | EPOST Warning Message |  #0x40 | Miscellaneous | Asserted                                 c\n";
    print "    ELOG(56) WARNING: M.2 SATA 0 does not have a valid MBR signature                           c\n";
    print "   | EPOST Warning Message |  #0x41 | Miscellaneous | Asserted                                 c\n";
    print "   ELOG(56) WARNING: M.2 SATA 1 FW FileSystem Inaccessible (0x00FF)                            c\n";
    print "  3.possible code panic                                                                        c\n";
    print "   | OS Critical Stop | HostOS | Run-time critical stop | Asserted                             c\n";
    print "  4. mezz0 card                                                                                c\n";
    print "   SMI AER Correctable PCI-e Errors | Mezzanine 0 | Receiver Error | Asserted |                c\n";
    print "    Bus=0x0b Dev=0x00 Func=0x00                                                                c\n";
    print "   ELOG(53) RECEIVER ERROR STATUS. Bus:0BH Dev:00H Fn:00H PS:C0H                               c\n";
    print "   SMI AER Correctable PCI-e Errors | Mezzanine 0 | Bad TLP | Asserted |                       c\n";
    print "    Bus=0x0b Dev=0x00 Func=0x00                                                                c\n";
    print "   ELOG(46) BAD TLP STATUS. Bus:0BH Dev:00H Fn:00H PS:C0H                                      c\n";
    print "  5.dimm error                                                                                 c\n";
    print "   | BIOS Memory Errors |  #0x04 | MRC Error (DIMM) | Asserted | DIMM=255                      c\n";
    print "   ELOG(60) MRC WARN_NO_MEMORY_MINOR_NO_MEMORY, Failing DIMM = DIMM 255                        c\n";
    print "  6.dimm error                                                                                 c\n";
    print "   | SMI Memory Events |  Memory | Uncorrectable ECC | Asserted | DIMM=17 Syndrome=255         c\n";
    print "   ELOG(79) -R- Uncorrectable ECC Error: Socket 0 Channel 0 DIMM 1, Failing DIMM = DIMM 17     c\n";
    print "  7.embedded module                                                                            c\n";
    print "   | EPOST Error Message |  Entire Blade | EPOST Failure | Asserted | Error code=0x0078        c\n";
    print "   ELOG(184) ErrorCode: 0x00000078 Device: LAN Management Port Description: Null Pointer Error!c\n";
    print "  8.external power related                                                                     c\n";
    print "   | CMD Status  | Exp_Bay0_CMD | External Fault | Asserted                                    c\n";
    print "   | Power Supply Status |  PS0_Status | External Fault | Asserted                             c\n";
    print "   | Power Supply Status |  PS1_Status | External Fault | Asserted                             c\n";
    print "  9.pmp, mem cache flush                                                                       c\n";
    print "   | SSP Power-fail Memory Persistence | Power/Reset Action | PMP Start | Asserted             c\n";
    print "  10.high temperature                                                                          c\n";
    print "   | Temperature  | Ambient_Temp | Upper Non-critical going high | Asserted | Reading 43 > Threshold 43 degrees C c\n";
    print "   | Temperature  | Ambient_Temp | Upper Critical going high | Asserted | Reading 45 > Threshold 45 degrees C c\n";
    print "   | Shutdown In Progress  | Shutdown_In_Prog | Delayed Shutdown In Progress | Asserted | Reason Code=13 c\n"; 
    print "  11.node cpu fault                                                                            c\n";
    print "   | SMI Processor Events |  CPU Module (Motherboard) | Uncorrectable Machine Check | Asserted | Bank=1 ErrorType=255 c\n"; 
    print "  12.500T node replacement falure. PXE Server not reachable                                    c\n";
    print "   | BIOS Phase Errors | BIOS Progress/Event | BDS Phase Error | Asserted                      c\n";
    print "    EFI_SOFTWARE Subclass:50000; EFI_SOFTWARE_DXE_BS_DRIVER Operation:1002; DXE_BOOT_OPTION_LOAD_ERROR (EFI_SOFTWARE_DXE_BS_DRIVER | EFI_SW_DXE_BS_EC_BOOT_OPTION_LOAD_ERROR) c\n";    
    print "cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc\n\n";

    print "[node-a reboot info]\n";

    if ($node_a_cyc_ipmitool_sel_elist_txt_exist) {
        open(my $file,  "<",  $node_a_cyc_ipmitool_sel_elist_txt)  or die "Can't open $node_a_cyc_ipmitool_sel_elist_txt: $!";
        while (<$file>) {
            print "$_";
        }
        close $file;
    } 

    print "\n[node-b reboot info]\n";

    if ($node_b_cyc_ipmitool_sel_elist_txt_exist) {
        open(my $file,  "<",  $node_b_cyc_ipmitool_sel_elist_txt)  or die "Can't open $node_b_cyc_ipmitool_sel_elist_txt: $!";
        while (<$file>) {
            print "$_";
        }
        close $file;
    }
}
#######################################################################


#######################################################################
sub threaded_scan_journal_known_issues {
    my $thr_id = threads->self->tid;
    my $journal_txt_file = $_[0].'.txt';
    open (FILE, $journal_txt_file) or die "Cannot open $journal_txt_file: $!\n";

    while ( <FILE> ) {
        if ( $_[1] eq 'node_a' && m/could not create unique index/ && m/member_ref_id_uniq/ ) {
            lock @node_a_mdt_304895;
            push( @node_a_mdt_304895, $_ );
        }

        if ( $_[1] eq 'node_b' && m/could not create unique index/ && m/member_ref_id_uniq/ ) {
            lock @node_b_mdt_304895;
            push( @node_b_mdt_304895, $_ );
        }

        if ( $_[1] eq 'node_a' && m/AddVGMembershipRefUniqueConstraint.sql failed/ ) {
            lock @node_a_mdt_304895;
            push( @node_a_mdt_304895, $_ );
        }

        if ( $_[1] eq 'node_b' && m/AddVGMembershipRefUniqueConstraint.sql failed/ ) {
            lock @node_b_mdt_304895;
            push( @node_b_mdt_304895, $_ );
        }

        if ( $_[1] eq 'node_a' && m/could not create unique index/ && m/constraintname/ ) {
            lock @node_a_mdt_304623;
            push( @node_a_mdt_304623, $_ );
        }

        if ( $_[1] eq 'node_b' && m/could not create unique index/ && m/constraintname/ ) {
            lock @node_b_mdt_304623;
            push( @node_b_mdt_304623, $_ );
        }

        if ( $_[1] eq 'node_a' && m/ERROR: insert or update on table/ && m/ip_pool_address/ ) {
            lock @node_a_mdt_305100;
            push( @node_a_mdt_305100, $_ );
        }

        if ( $_[1] eq 'node_b' && m/ERROR: insert or update on table/ && m/ip_pool_address/ ) {
            lock @node_b_mdt_305100;
            push( @node_b_mdt_305100, $_ );
        }

        if ( $_[1] eq 'node_a' && m/is not present in table/ && m/ip_port/ ) {
            lock @node_a_mdt_305100;
            push( @node_a_mdt_305100, $_ );
        }

        if ( $_[1] eq 'node_b' && m/is not present in table/ && m/ip_port/ ) {
            lock @node_b_mdt_305100;
            push( @node_b_mdt_305100, $_ );
        }

        if ( $_[1] eq 'node_a' && m/watchdog_timer_expired/ && m/X_TIMERQ_20_SEC started before/ ) {
            lock @node_a_tee_2091;
            push( @node_a_tee_2091, $_ );
        }

        if ( $_[1] eq 'node_b' && m/watchdog_timer_expired/ && m/X_TIMERQ_20_SEC started before/ ) {
            lock @node_b_tee_2091;
            push( @node_b_tee_2091, $_ );
        }   

        if ( $_[1] eq 'node_a' && m/dare setting on peer node does not match local node/ ) {
            lock @node_a_mdt_307082;
            push( @node_a_mdt_307082, $_ );
        }

        if ( $_[1] eq 'node_b' && m/dare setting on peer node does not match local node/ ) {
            lock @node_b_mdt_307082;
            push( @node_b_mdt_307082, $_ );
        }               

        if ( $_[1] eq 'node_a' && m/Error/ && m/Dare Flag Check Work/ ) {
            lock @node_a_mdt_307082;
            push( @node_a_mdt_307082, $_ );
        }

        if ( $_[1] eq 'node_b' && m/Error/ && m/Dare Flag Check Work/ ) {
            lock @node_b_mdt_307082;
            push( @node_b_mdt_307082, $_ );
        }

        if ( $_[1] eq 'node_a' && m/No such file or directory/ && m/PL_LB/ ) {
            lock @node_a_tee_2325;
            push( @node_a_tee_2325, $_ );
        }

        if ( $_[1] eq 'node_b' && m/No such file or directory/ && m/PL_LB/ ) {
            lock @node_b_tee_2325;
            push( @node_b_tee_2325, $_ );
        }       

        if ( $_[1] eq 'node_a' && m/dare drive no key failed/ ) {
            lock @node_a_tee_2325;
            push( @node_a_tee_2325, $_ );
        }

        if ( $_[1] eq 'node_b' && m/dare drive no key failed/ ) {
            lock @node_b_tee_2325;
            push( @node_b_tee_2325, $_ );
        }

        if ( $_[1] eq 'node_a' && m/kms_process_ssd_unconfiged/ && m/KMS in read only mode/ ) {
            lock @node_a_tee_2325;
            push( @node_a_tee_2325, $_ );
        }

        if ( $_[1] eq 'node_b' && m/kms_process_ssd_unconfiged/ && m/KMS in read only mode/ ) {
            lock @node_b_tee_2325;
            push( @node_b_tee_2325, $_ );
        }   

        if ( $_[1] eq 'node_a' && m/GetPlbTargetDone error status/ ) {
            lock @node_a_tee_979;
            push( @node_a_tee_979, $_ );
        }

        if ( $_[1] eq 'node_b' && m/GetPlbTargetDone error status/ ) {
            lock @node_b_tee_979;
            push( @node_b_tee_979, $_ );
        }           

        if ( $_[1] eq 'node_a' && m/blockshim_xmit_timeout IO TIMEOUT PANIC DP/ ) {
            lock @node_a_tee_979;
            push( @node_a_tee_979, $_ );
        }

        if ( $_[1] eq 'node_b' && m/blockshim_xmit_timeout IO TIMEOUT PANIC DP/ ) {
            lock @node_b_tee_979;
            push( @node_b_tee_979, $_ );
        }       

        if ( $_[1] eq 'node_a' && m/due to VLB discrepency/ && m/Dropping PLB/ ) {
            lock @node_a_tee_1627;
            push( @node_a_tee_1627, $_ );
        }

        if ( $_[1] eq 'node_b' && m/due to VLB discrepency/ && m/Dropping PLB/ ) {
            lock @node_b_tee_1627;
            push( @node_b_tee_1627, $_ );
        }

        if ( $_[1] eq 'node_a' && m/page list not found/ && m/DefRefCntBin/ ) {
            lock @node_a_mdt_335078;
            push( @node_a_mdt_335078, $_ );
        }

        if ( $_[1] eq 'node_b' && m/page list not found/ && m/DefRefCntBin/ ) {
            lock @node_b_mdt_335078;
            push( @node_b_mdt_335078, $_ );
        }

        if ( $_[1] eq 'node_a' && m/SA ids are corrupted in the virtual page/ ) {
            lock @node_a_mdt_335078;
            push( @node_a_mdt_335078, $_ );
        }

        if ( $_[1] eq 'node_b' && m/SA ids are corrupted in the virtual page/ ) {
            lock @node_b_mdt_335078;
            push( @node_b_mdt_335078, $_ );
        }       

        if ( $_[1] eq 'node_a' && m/ASSERT failed on condition/ && m/VirtualRedirectType/ && m/VirtualRedirectLogic/ ) {
            lock @node_a_mdt_335078;
            push( @node_a_mdt_335078, $_ );
        }

        if ( $_[1] eq 'node_b' && m/ASSERT failed on condition/ && m/VirtualRedirectType/ && m/VirtualRedirectLogic/ ) {
            lock @node_b_mdt_335078;
            push( @node_b_mdt_335078, $_ );
        }

        if ( $_[1] eq 'node_a' && m/Send to KMS to remove ssd/ ) {
            lock @node_a_mdt_329167;
            push( @node_a_mdt_329167, $_ );
        }

        if ( $_[1] eq 'node_b' && m/Send to KMS to remove ssd/ ) {
            lock @node_b_mdt_329167;
            push( @node_b_mdt_329167, $_ );
        }       

        if ( $_[1] eq 'node_a' && m/Namespace Not Ready on path/ ) {
            lock @node_a_mdt_329167;
            push( @node_a_mdt_329167, $_ );
        }

        if ( $_[1] eq 'node_b' && m/Namespace Not Ready on path/ ) {
            lock @node_b_mdt_329167;
            push( @node_b_mdt_329167, $_ );
        }

        if ( $_[1] eq 'node_a' && m/Metadata Corruption Detected/ ) {
            lock @node_a_mdt_329167;
            push( @node_a_mdt_329167, $_ );
        }

        if ( $_[1] eq 'node_b' && m/Metadata Corruption Detected/ ) {
            lock @node_b_mdt_329167;
            push( @node_b_mdt_329167, $_ );
        }       

        if ( $_[1] eq 'node_a' && m/Metadata corruption detected in header/ ) {
            lock @node_a_mdt_329167;
            push( @node_a_mdt_329167, $_ );
        }

        if ( $_[1] eq 'node_b' && m/Metadata corruption detected in header/ ) {
            lock @node_b_mdt_329167;
            push( @node_b_mdt_329167, $_ );
        }       

        if ( $_[1] eq 'node_a' && m/Page metadata corruption detected/ ) {
            lock @node_a_mdt_329167;
            push( @node_a_mdt_329167, $_ );
        }

        if ( $_[1] eq 'node_b' && m/Page metadata corruption detected/ ) {
            lock @node_b_mdt_329167;
            push( @node_b_mdt_329167, $_ );
        }

        if ( $_[1] eq 'node_a' && m/debuc conn_perform_command failed/ ) {
            lock @node_a_mdt_185460;
            push( @node_a_mdt_185460, $_ );
        }

        if ( $_[1] eq 'node_b' && m/debuc conn_perform_command failed/ ) {
            lock @node_b_mdt_185460;
            push( @node_b_mdt_185460, $_ );
        }

        if ( $_[1] eq 'node_a' && m/debuc socket_receive failed/ ) {
            lock @node_a_mdt_185460;
            push( @node_a_mdt_185460, $_ );
        }

        if ( $_[1] eq 'node_b' && m/debuc socket_receive failed/ ) {
            lock @node_b_mdt_185460;
            push( @node_b_mdt_185460, $_ );
        }

        if ( $_[1] eq 'node_a' && m/ASSERT failed/ && m/numberOfLogicalBlocks/ ) {
            lock @node_a_tee_703;
            push( @node_a_tee_703, $_ );
        }

        if ( $_[1] eq 'node_b' && m/ASSERT failed/ && m/numberOfLogicalBlocks/ ) {
            lock @node_b_tee_703;
            push( @node_b_tee_703, $_ );
        }       

        if ( $_[1] eq 'node_a' && m/GetDeltaPageByIdxDone/ && m/ASSERT failed on condition/ ) {
            lock @node_a_tee_2064;
            push( @node_a_tee_2064, $_ );
        }

        if ( $_[1] eq 'node_b' && m/GetDeltaPageByIdxDone/ && m/ASSERT failed on condition/ ) {
            lock @node_b_tee_2064;
            push( @node_b_tee_2064, $_ );
        }   

        if ( $_[1] eq 'node_a' && m/DedupeProcessFlushsetActor/ && m/ASSERT failed on condition/ ) {
            lock @node_a_mdt_239421;
            push( @node_a_mdt_239421, $_ );
        }

        if ( $_[1] eq 'node_b' && m/DedupeProcessFlushsetActor/ && m/ASSERT failed on condition/ ) {
            lock @node_b_mdt_239421;
            push( @node_b_mdt_239421, $_ );
        }           

        if ( $_[1] eq 'node_a' && m/ccutils_bloomfilter/ && m/ASSERT failed on condition/ ) {
            lock @node_a_mdt_344382;
            push( @node_a_mdt_344382, $_ );
        }

        if ( $_[1] eq 'node_b' && m/ccutils_bloomfilter/ && m/ASSERT failed on condition/ ) {
            lock @node_b_mdt_344382;
            push( @node_b_mdt_344382, $_ );
        }

        if ( $_[1] eq 'node_a' && m/FlushProcessMergeResultsActor/ && m/Transaction out of resources/ ) {
            lock @node_a_tee_1987;
            push( @node_a_tee_1987, $_ );
        }

        if ( $_[1] eq 'node_b' && m/FlushProcessMergeResultsActor/ && m/Transaction out of resources/ ) {
            lock @node_b_tee_1987;
            push( @node_b_tee_1987, $_ );
        }   

        if ( $_[1] eq 'node_a' && m/IoRequestWatchdog/ && m/ASSERT failed on condition/ ) {
            lock @node_a_tee_1987;
            push( @node_a_tee_1987, $_ );
        }

        if ( $_[1] eq 'node_b' && m/IoRequestWatchdog/ && m/ASSERT failed on condition/ ) {
            lock @node_b_tee_1987;
            push( @node_b_tee_1987, $_ );
        }       

        if ( $_[1] eq 'node_a' && m/cyc_raid_repair_init_new_rrs_list/ && m/ASSERT failed on condition: disk_info/ ) {
            lock @node_a_tee_1393;
            push( @node_a_tee_1393, $_ );
        }

        if ( $_[1] eq 'node_b' && m/cyc_raid_repair_init_new_rrs_list/ && m/ASSERT failed on condition: disk_info/ ) {
            lock @node_b_tee_1393;
            push( @node_b_tee_1393, $_ );
        }           

        if ( $_[1] eq 'node_a' && m/Attach Sessions/ && m/duplicated session/ ) {
            lock @node_a_mdt_294054;
            push( @node_a_mdt_294054, $_ );
        }

        if ( $_[1] eq 'node_b' && m/Attach Sessions/ && m/duplicated session/ ) {
            lock @node_b_mdt_294054;
            push( @node_b_mdt_294054, $_ );
        }

        if ( $_[1] eq 'node_a' && m/Enabling SupportAssist failed/ && m/500/ ) {
            lock @node_a_mdt_303484;
            push( @node_a_mdt_303484, $_ );
        }

        if ( $_[1] eq 'node_b' && m/Enabling SupportAssist failed/ && m/500/ ) {
            lock @node_b_mdt_303484;
            push( @node_b_mdt_303484, $_ );
        }

        if ( $_[1] eq 'node_a' && m/Caught an error during sendFiremanCommand/ && m/The source did not signal an event for 240 seconds and has been terminated/ ) {
            lock @node_a_mdt_303484;
            push( @node_a_mdt_303484, $_ );
        }

        if ( $_[1] eq 'node_b' && m/Caught an error during sendFiremanCommand/ && m/The source did not signal an event for 240 seconds and has been terminated/ ) {
            lock @node_b_mdt_303484;
            push( @node_b_mdt_303484, $_ );
        }

        if ( $_[1] eq 'node_a' && m/RSCN: Fabric was affected/ && m/Addr format 3/ ) {
            lock @node_a_mdt_201561;
            push( @node_a_mdt_201561, $_ );
        }

        if ( $_[1] eq 'node_b' && m/RSCN: Fabric was affected/ && m/Addr format 3/ ) {
            lock @node_b_mdt_201561;
            push( @node_b_mdt_201561, $_ );
        }   

        if ( $_[1] eq 'node_a' && m/OSError/ && m/No such file or directory/ ) {
            lock @node_a_mdt_312975;
            push( @node_a_mdt_312975, $_ );
        }

        if ( $_[1] eq 'node_b' && m/OSError/ && m/No such file or directory/ ) {
            lock @node_b_mdt_312975;
            push( @node_b_mdt_312975, $_ );
        }

        if ( $_[1] eq 'node_a' && m/Failed to write the exec command/ && m/db_dump_minimal_critical_data/ ) {
            lock @node_a_mdt_247214;
            push( @node_a_mdt_247214, $_ );
        }

        if ( $_[1] eq 'node_b' && m/Failed to write the exec command/ && m/db_dump_minimal_critical_data/ ) {
            lock @node_b_mdt_247214;
            push( @node_b_mdt_247214, $_ );
        }


        if ( $_[1] eq 'node_a' && m/RuntimeError: Unable to tar/ ) {
            lock @node_a_mdt_247214;
            push( @node_a_mdt_247214, $_ );
        }

        if ( $_[1] eq 'node_b' && m/RuntimeError: Unable to tar/ ) {
            lock @node_b_mdt_247214;
            push( @node_b_mdt_247214, $_ );
        }       

        if ( $_[1] eq 'node_a' && m/Unable to bookmark trace buffer/ && m/buffer header not available/ ) {
            lock @node_a_mdt_342762;
            push( @node_a_mdt_342762, $_ );
        }

        if ( $_[1] eq 'node_b' && m/Unable to bookmark trace buffer/ && m/buffer header not available/ ) {
            lock @node_b_mdt_342762;
            push( @node_b_mdt_342762, $_ );
        }

        if ( $_[1] eq 'node_a' && m/panic_log/ && m/cyc_ppds_cli\.pl Kdump/ ) {
            lock @node_a_mdt_305828;
            push( @node_a_mdt_305828, $_ );
        }

        if ( $_[1] eq 'node_b' && m/panic_log/ && m/cyc_ppds_cli\.pl Kdump/ ) {
            lock @node_b_mdt_305828;
            push( @node_b_mdt_305828, $_ );
        }

        if ( $_[1] eq 'node_a' && m/with size exceeding MAX TRANSFER SIZE/ ) {
            lock @node_a_kb_182665;
            push( @node_a_kb_182665, $_ );
        }

        if ( $_[1] eq 'node_b' && m/with size exceeding MAX TRANSFER SIZE/ ) {
            lock @node_b_kb_182665;
            push( @node_b_kb_182665, $_ );
        }   

        if ( $_[1] eq 'node_a' && m/proceeding with close gates without waiting for successful vault/ ) {
            lock @node_a_mdt_173900;
            push( @node_a_mdt_173900, $_ );
        }

        if ( $_[1] eq 'node_b' && m/proceeding with close gates without waiting for successful vault/ ) {
            lock @node_b_mdt_173900;
            push( @node_b_mdt_173900, $_ );
        }   

        if ( $_[1] eq 'node_a' && m/uncorrectable error/ && m/Checksum mismatch/ ) {
            lock @node_a_tee_x_corruptions;
            push( @node_a_tee_x_corruptions, $_ );
        }

        if ( $_[1] eq 'node_b' && m/uncorrectable error/ && m/Checksum mismatch/ ) {
            lock @node_b_tee_x_corruptions;
            push( @node_b_tee_x_corruptions, $_ );
        }  

        if ( $_[1] eq 'node_a' && m/ZMQ Server is not ready/ ) {
            lock @node_a_kb_131062;
            push( @node_a_kb_131062, $_ );
        }

        if ( $_[1] eq 'node_b' && m/ZMQ Server is not ready/ ) {
            lock @node_b_kb_131062;
            push( @node_b_kb_131062, $_ );
        }        

        if ( $_[1] eq 'node_a' && m/FATAL ERROR/ && m/Cluster IP/ && m/unreachable from Node/ ) {
            lock @node_a_kb_130232;
            push( @node_a_kb_130232, $_ );
        }

        if ( $_[1] eq 'node_b' && m/FATAL ERROR/ && m/Cluster IP/ && m/unreachable from Node/ ) {
            lock @node_b_kb_130232;
            push( @node_b_kb_130232, $_ );
        }

        if ( $_[1] eq 'node_a' && m/FATAL ERROR: Check connectivity of ICM network/ ) {
            lock @node_a_kb_130232;
            push( @node_a_kb_130232, $_ );
        }

        if ( $_[1] eq 'node_b' && m/FATAL ERROR: Check connectivity of ICM network/ ) {
            lock @node_b_kb_130232;
            push( @node_b_kb_130232, $_ );
        }

        if ( $_[1] eq 'node_a' && m/Failed to set DNS server/ && m/does not support more than/ ) {
            lock @node_a_mdt_168926;
            push( @node_a_mdt_168926, $_ );
        }

        if ( $_[1] eq 'node_b' && m/Failed to set DNS server/ && m/does not support more than/ ) {
            lock @node_b_mdt_168926;
            push( @node_b_mdt_168926, $_ );
        }        

        if ( $_[1] eq 'node_a' && m/Failed to set IP/ ) {
            lock @node_a_tee_2388;
            push( @node_a_tee_2388, $_ );
        }

        if ( $_[1] eq 'node_b' && m/Failed to set IP/ ) {
            lock @node_b_tee_2388;
            push( @node_b_tee_2388, $_ );
        } 

        if ( $_[1] eq 'node_a' && m/ERROR: Network already has GSIP/ ) {
            lock @node_a_mdt_304388;
            push( @node_a_mdt_304388, $_ );
        }

        if ( $_[1] eq 'node_b' && m/ERROR: Network already has GSIP/ ) {
            lock @node_b_mdt_304388;
            push( @node_b_mdt_304388, $_ );
        }   

        if ( $_[1] eq 'node_a' && m/Modify Network/ && m/ip_addr_invalid/ ) {
            lock @node_a_mdt_304388;
            push( @node_a_mdt_304388, $_ );
        }

        if ( $_[1] eq 'node_b' && m/Modify Network/ && m/ip_addr_invalid/ ) {
            lock @node_b_mdt_304388;
            push( @node_b_mdt_304388, $_ );
        }

        if ( $_[1] eq 'node_a' && m/managementdb/ && m/No space left on device/ ) {
            lock @node_a_mdt_237350;
            push( @node_a_mdt_237350, $_ );
        }

        if ( $_[1] eq 'node_b' && m/managementdb/ && m/No space left on device/ ) {
            lock @node_b_mdt_237350;
            push( @node_b_mdt_237350, $_ );
        }   

        if ( $_[1] eq 'node_a' && m/Core database space is at or above/ ) {
            lock @node_a_mdt_237350;
            push( @node_a_mdt_237350, $_ );
        }

        if ( $_[1] eq 'node_b' && m/Core database space is at or above/ ) {
            lock @node_b_mdt_237350;
            push( @node_b_mdt_237350, $_ );
        }    


        if ( $_[1] eq 'node_a' && m/bsc-pacemaker_cluster/ && m/Cluster not being started as issue with platform volume detected/ ) {
            lock @node_a_mdt_227944;
            push( @node_a_mdt_227944, $_ );
        }

        if ( $_[1] eq 'node_b' && m/bsc-pacemaker_cluster/ && m/Cluster not being started as issue with platform volume detected/ ) {
            lock @node_b_mdt_227944;
            push( @node_b_mdt_227944, $_ );
        }    

        if ( $_[1] eq 'node_a' && m/managementdb/ && m/VACUUM/ ) {
            lock @node_a_kb_126293;
            push( @node_a_kb_126293, $_ );
        }

        if ( $_[1] eq 'node_b' && m/managementdb/ && m/VACUUM/ ) {
            lock @node_b_kb_126293;
            push( @node_b_kb_126293, $_ );
        }

        if ( $_[1] eq 'node_a' && m/There are iSCSI devices in illegal state/ ) {
            lock @node_a_mdt_291470;
            push( @node_a_mdt_291470, $_ );
        }

        if ( $_[1] eq 'node_b' && m/There are iSCSI devices in illegal state/ ) {
            lock @node_b_mdt_291470;
            push( @node_b_mdt_291470, $_ );
        }    

        if ( $_[1] eq 'node_a' && m/NAS NDU Startup operation failed with ERROR/ && m/0:0:0:0:0:0:0:1:18080/ ) {
            lock @node_a_tee_1414;
            push( @node_a_tee_1414, $_ );
        }

        if ( $_[1] eq 'node_b' && m/NAS NDU Startup operation failed with ERROR/ && m/0:0:0:0:0:0:0:1:18080/ ) {
            lock @node_b_tee_1414;
            push( @node_b_tee_1414, $_ );
        }

        if ( $_[1] eq 'node_a' && m/NASNDU_FLOW/ && m/start_new_sdnas_container on A1:b failed/ ) {
            lock @node_a_mdt_180273;
            push( @node_a_mdt_180273, $_ );
        }

        if ( $_[1] eq 'node_b' && m/NASNDU_FLOW/ && m/start_new_sdnas_container on A1:b failed/ ) {
            lock @node_b_mdt_180273;
            push( @node_b_mdt_180273, $_ );
        }   

        if ( $_[1] eq 'node_a' && m/Failed waiting for all system LUNs availability/ ) {
            lock @node_a_mdt_334812;
            push( @node_a_mdt_334812, $_ );
        }

        if ( $_[1] eq 'node_b' && m/Failed waiting for all system LUNs availability/ ) {
            lock @node_b_mdt_334812;
            push( @node_b_mdt_334812, $_ );
        }    

        if ( $_[1] eq 'node_a' && m/XmsLogger/ && m/out of range for type integer/ ) {
            lock @node_a_tee_1898;
            push( @node_a_tee_1898, $_ );
        }

        if ( $_[1] eq 'node_b' && m/XmsLogger/ && m/out of range for type integer/ ) {
            lock @node_b_tee_1898;
            push( @node_b_tee_1898, $_ );
        }

        if ( $_[1] eq 'node_a' && m/Folder does not exist and there will likely be a gap in performance metrics/ ) {
            lock @node_a_tee_2161;
            push( @node_a_tee_2161, $_ );
        }

        if ( $_[1] eq 'node_b' && m/Folder does not exist and there will likely be a gap in performance metrics/ ) {
            lock @node_b_tee_2161;
            push( @node_b_tee_2161, $_ );
        }

        if ( $_[1] eq 'node_a' && m/NDU is not allowed since RAID event is expected for/ ) {
            lock @node_a_tee_2249;
            push( @node_a_tee_2249, $_ );
        }

        if ( $_[1] eq 'node_b' && m/NDU is not allowed since RAID event is expected for/ ) {
            lock @node_b_tee_2249;
            push( @node_b_tee_2249, $_ );
        }   

        if ( $_[1] eq 'node_a' && m/Aborting TriNDU flow due to unexpected disk event/ ) {
            lock @node_a_tee_2249;
            push( @node_a_tee_2249, $_ );
        }

        if ( $_[1] eq 'node_b' && m/Aborting TriNDU flow due to unexpected disk event/ ) {
            lock @node_b_tee_2249;
            push( @node_b_tee_2249, $_ );
        }

        if ( $_[1] eq 'node_a' && m/Error/ && m/Validate Firmware/ ) {
            lock @node_a_tee_1021;
            push( @node_a_tee_1021, $_ );
        }

        if ( $_[1] eq 'node_b' && m/Error/ && m/Validate Firmware/ ) {
            lock @node_b_tee_1021;
            push( @node_b_tee_1021, $_ );
        }   

        if ( $_[1] eq 'node_a' && m/kernel/ && m/blocked for more than 120 seconds/ ) {
            lock @node_a_kb_189524;
            push( @node_a_kb_189524, $_ );
        }

        if ( $_[1] eq 'node_b' && m/kernel/ && m/blocked for more than 120 seconds/ ) {
            lock @node_b_kb_189524;
            push( @node_b_kb_189524, $_ );
        }

        if ( $_[1] eq 'node_a' && m/CP Ping for/ && m/not received/ ) {
            lock @node_a_tee_2213;
            push( @node_a_tee_2213, $_ );
        }

        if ( $_[1] eq 'node_b' && m/CP Ping for/ && m/not received/ ) {
            lock @node_b_tee_2213;
            push( @node_b_tee_2213, $_ );
        }

        if ( $_[1] eq 'node_a' && m/BMC mode switch failed/ ) {
            lock @node_a_mdt_205619;
            push( @node_a_mdt_205619, $_ );
        }

        if ( $_[1] eq 'node_a' && m/BMC mode switch failed/ ) {
            lock @node_b_mdt_205619;
            push( @node_b_mdt_205619, $_ );
        }

        if ( $_[1] eq 'node_b' && m/Switching BMC from mgmt to service port failed/ ) {
            lock @node_a_mdt_205619;
            push( @node_a_mdt_205619, $_ );
        }

        if ( $_[1] eq 'node_b' && m/Switching BMC from mgmt to service port failed/ ) {
            lock @node_b_mdt_205619;
            push( @node_b_mdt_205619, $_ );
        }

        if ( $_[1] eq 'node_a' && m/BSCFailHandler/ && m/failed/ ) {
            lock @node_a_kb_180125;
            push( @node_a_kb_180125, $_ );
        }

        if ( $_[1] eq 'node_b' && m/BSCFailHandler/ && m/failed/ ) {
            lock @node_b_kb_180125;
            push( @node_b_kb_180125, $_ );
        }

        if ( $_[1] eq 'node_a' && m/task md/ && m/blocked for more than/ ) {
            lock @node_a_mdt_194042;
            push( @node_a_mdt_194042, $_ );
        }

        if ( $_[1] eq 'node_b' && m/task md/ && m/blocked for more than/ ) {
            lock @node_b_mdt_194042;
            push( @node_b_mdt_194042, $_ );
        }    

        if ( $_[1] eq 'node_a' && m/debuc_client/ && m/blocked for more than/ ) {
            lock @node_a_tee_711;
            push( @node_a_tee_711, $_ );
        }

        if ( $_[1] eq 'node_b' && m/debuc_client/ && m/blocked for more than/ ) {
            lock @node_b_tee_711;
            push( @node_b_tee_711, $_ );
        }    

        if ( $_[1] eq 'node_a' && m/pg_basebackup/ && m/metrics_tbs/ && m/exists but is not empty/ ) {
            lock @node_a_mdt_195039;
            push( @node_a_mdt_195039, $_ );
        }

        if ( $_[1] eq 'node_b' && m/pg_basebackup/ && m/metrics_tbs/ && m/exists but is not empty/ ) {
            lock @node_b_mdt_195039;
            push( @node_b_mdt_195039, $_ );
        }  

        if ( $_[1] eq 'node_a' && m/DP mode is normal/ && m/cyc_hafs not mounted in BSC/ ) {
            lock @node_a_mdt_149702;
            push( @node_a_mdt_149702, $_ );
        }

        if ( $_[1] eq 'node_b' && m/DP mode is normal/ && m/cyc_hafs not mounted in BSC/ ) {
            lock @node_b_mdt_149702;
            push( @node_b_mdt_149702, $_ );
        }          

        if ( $_[1] eq 'node_a' && m/out of memory/ && m/java/ ) {
            lock @node_a_mdt_283614;
            push( @node_a_mdt_283614, $_ );
        }

        if ( $_[1] eq 'node_b' && m/out of memory/ && m/java/ ) {
            lock @node_b_mdt_283614;
            push( @node_b_mdt_283614, $_ );
        }                                

        if ( $_[1] eq 'node_a' && m/frumon: failed: add-ssd/ && m/xms_internal_error/ ) {
            lock @node_a_mdt_285220;
            push( @node_a_mdt_285220, $_ );
        }

        if ( $_[1] eq 'node_b' && m/frumon: failed: add-ssd/ && m/xms_internal_error/ ) {
            lock @node_b_mdt_285220;
            push( @node_b_mdt_285220, $_ );
        } 

        if ( $_[1] eq 'node_a' && m/Failed to finalize Cluster/ && m/Failed to create ISOs directory/ ) {
            lock @node_a_kb_pstx_icw_ca;
            push( @node_a_kb_pstx_icw_ca, $_ );
        }

        if ( $_[1] eq 'node_b' && m/Failed to finalize Cluster/ && m/Failed to create ISOs directory/ ) {
            lock @node_b_kb_pstx_icw_ca;
            push( @node_b_kb_pstx_icw_ca, $_ );
        }        

        if ( $_[1] eq 'node_a' && m/The remote host certificate has these problems/ ) {
            lock @node_a_kb_pstx_icw_ca;
            push( @node_a_kb_pstx_icw_ca, $_ );
        }

        if ( $_[1] eq 'node_b' && m/The remote host certificate has these problems/ ) {
            lock @node_b_kb_pstx_icw_ca;
            push( @node_b_kb_pstx_icw_ca, $_ );
        }  

        if ( $_[1] eq 'node_a' && m/Unexpected cyc_net error occurred/ ) {
            lock @node_a_tee_1128;
            push( @node_a_tee_1128, $_ );
        }

        if ( $_[1] eq 'node_b' && m/Unexpected cyc_net error occurred/ ) {
            lock @node_b_tee_1128;
            push( @node_b_tee_1128, $_ );
        } 

        if ( $_[1] eq 'node_a' && m/ESXi PowerStore VIB versions/ && m/Error/ ) {
            lock @node_a_mdt_259371;
            push( @node_a_mdt_259371, $_ );
        }

        if ( $_[1] eq 'node_b' && m/ESXi PowerStore VIB versions/ && m/Error/ ) {
            lock @node_b_mdt_259371;
            push( @node_b_mdt_259371, $_ );
        }                

        if ( $_[1] eq 'node_a' && m/cyc_puhc/ && m/Component version is in incorrect format/ ) {
            lock @node_a_mdt_259371;
            push( @node_a_mdt_259371, $_ );
        }

        if ( $_[1] eq 'node_b' && m/cyc_puhc/ && m/Component version is in incorrect format/ ) {
            lock @node_b_mdt_259371;
            push( @node_b_mdt_259371, $_ );
        } 

        if ( $_[1] eq 'node_a' && m/cyc_puhc/ && m/One or more tiers are offline or degraded/ ) {
            lock @node_a_mdt_163197;
            push( @node_a_mdt_163197, $_ );
        }

        if ( $_[1] eq 'node_b' && m/cyc_puhc/ && m/One or more tiers are offline or degraded/ ) {
            lock @node_b_mdt_163197;
            push( @node_b_mdt_163197, $_ );
        }         

        if ( $_[1] eq 'node_a' && m/cyc_puhc/ && m/Checking for RAID/ && m/Error/ ) {
            lock @node_a_mdt_163197;
            push( @node_a_mdt_163197, $_ );
        }

        if ( $_[1] eq 'node_b' && m/cyc_puhc/ && m/Checking for RAID/ && m/Error/ ) {
            lock @node_b_mdt_163197;
            push( @node_b_mdt_163197, $_ );
        }    

        if ( $_[1] eq 'node_a' && m/cyc_puhc/ && m/dare_cdr_check_failed/ ) {
            lock @node_a_tee_834;
            push( @node_a_tee_834, $_ );
        }

        if ( $_[1] eq 'node_b' && m/cyc_puhc/ && m/dare_cdr_check_failed/ ) {
            lock @node_b_tee_834;
            push( @node_b_tee_834, $_ );
        }  

        if ( $_[1] eq 'node_a' && m/cyc_puhc/ && m/DARE CDR drives check failed/ ) {
            lock @node_a_tee_834;
            push( @node_a_tee_834, $_ );
        }

        if ( $_[1] eq 'node_b' && m/cyc_puhc/ && m/DARE CDR drives check failed/ ) {
            lock @node_b_tee_834;
            push( @node_b_tee_834, $_ );
        }

        if ( $_[1] eq 'node_a' && m/ONV_ICC_MGMT_PING_STATUS_UNREACHABLE/ && m/management network addresses are not reachable via ICMP/ ) {
            lock @node_a_tee_2432;
            push( @node_a_tee_2432, $_ );
        }

        if ( $_[1] eq 'node_b' && m/ONV_ICC_MGMT_PING_STATUS_UNREACHABLE/ && m/management network addresses are not reachable via ICMP/ ) {
            lock @node_b_tee_2432;
            push( @node_b_tee_2432, $_ );
        }

        if ( $_[1] eq 'node_a' && m/pm_ssd_check_enclosure_cabling/ && m/likely MISCABLED/ ) {
            lock @node_a_tee_2345;
            push( @node_a_tee_2345, $_ );
        }

        if ( $_[1] eq 'node_b' && m/pm_ssd_check_enclosure_cabling/ && m/likely MISCABLED/ ) {
            lock @node_b_tee_2345;
            push( @node_b_tee_2345, $_ );
        }

        if ( $_[1] eq 'node_a' && m/Encl compatibility status changed from ok to unsupported/ ) {
            lock @node_a_tee_1673;
            push( @node_a_tee_1673, $_ );
        }

        if ( $_[1] eq 'node_b' && m/Encl compatibility status changed from ok to unsupported/ ) {
            lock @node_b_tee_1673;
            push( @node_b_tee_1673, $_ );
        }  

        if ( $_[1] eq 'node_a' && m/Initiator/ && m/completed with status 0x28/ ) {
            lock @node_a_scsi_status_0x28;
            push( @node_a_scsi_status_0x28, $_ );
        }

        if ( $_[1] eq 'node_b' && m/Initiator/ && m/completed with status 0x28/ ) {
            lock @node_b_scsi_status_0x28;
            push( @node_b_scsi_status_0x28, $_ );
        }

        if ( $_[1] eq 'node_a' && m/EXEC_CHECK_BLOCKING/ && m/op COMPARE AND WRITE/ ) {
            lock @node_a_ats_lock_block;
            push( @node_a_ats_lock_block, $_ );
        }

        if ( $_[1] eq 'node_b' && m/EXEC_CHECK_BLOCKING/ && m/op COMPARE AND WRITE/ ) {
            lock @node_b_ats_lock_block;
            push( @node_b_ats_lock_block, $_ );
        }

        if ( $_[1] eq 'node_a' && m/EXEC_CHECK_BLOCKING/ && m/op RESERVE/ ) {
            lock @node_a_scsi_lock_block;
            push( @node_a_scsi_lock_block, $_ );
        }

        if ( $_[1] eq 'node_b' && m/EXEC_CHECK_BLOCKING/ && m/op RESERVE/ ) {
            lock @node_b_scsi_lock_block;
            push( @node_b_scsi_lock_block, $_ );
        }    

        if ( $_[1] eq 'node_a' && m/EXEC_CHECK_BLOCKING/ ) {
            lock @node_a_reservation_block;
            push( @node_a_reservation_block, $_ );
        }

        if ( $_[1] eq 'node_b' && m/EXEC_CHECK_BLOCKING/ ) {
            lock @node_b_reservation_block;
            push( @node_b_reservation_block, $_ );
        }

        if ( $_[1] eq 'node_a' && m/I\/O operation failure/ && m/initiator_name/ ) {
            lock @node_a_io_operation_failure;
            push( @node_a_io_operation_failure, $_ );
        }

        if ( $_[1] eq 'node_b' && m/I\/O operation failure/ && m/initiator_name/ ) {
            lock @node_b_io_operation_failure;
            push( @node_b_io_operation_failure, $_ );
        }

        if ( $_[1] eq 'node_a' && m/Initiator/ && m/completed with Check Condition/ ) {
            lock @node_a_initiator_cc;
            push( @node_a_initiator_cc, $_ );
        }

        if ( $_[1] eq 'node_b' && m/Initiator/ && m/completed with Check Condition/ ) {
            lock @node_b_initiator_cc;
            push( @node_b_initiator_cc, $_ );
        }

        if ( $_[1] eq 'node_a' && m/cyc_upgrade/ && m/\/14]:/ ) {
            lock @node_a_kb_ndu_proc;
            push( @node_a_kb_ndu_proc, $_ );
        }

        if ( $_[1] eq 'node_b' && m/cyc_upgrade/ && m/\/14]:/ ) {
            lock @node_b_kb_ndu_proc;
            push( @node_b_kb_ndu_proc, $_ );
        }

        if ( $_[1] eq 'node_a' && m/cyc_upgrade/ && m/\/3]:/ ) {
            lock @node_a_kb_ndu_proc;
            push( @node_a_kb_ndu_proc, $_ );
        }

        if ( $_[1] eq 'node_b' && m/cyc_upgrade/ && m/\/3]:/ ) {
            lock @node_b_kb_ndu_proc;
            push( @node_b_kb_ndu_proc, $_ );
        }

        if ( $_[1] eq 'node_a' && m/cyc_upgrade/ && m/Upgrading From:/ ) {
            lock @node_a_kb_ndu_proc;
            push( @node_a_kb_ndu_proc, $_ );
        }

        if ( $_[1] eq 'node_b' && m/cyc_upgrade/ && m/Upgrading From:/ ) {
            lock @node_b_kb_ndu_proc;
            push( @node_b_kb_ndu_proc, $_ );
        }  

        if ( $_[1] eq 'node_a' && m/cyc_upgrade/ && m/Upgrading To:/ ) {
            lock @node_a_kb_ndu_proc;
            push( @node_a_kb_ndu_proc, $_ );
        }

        if ( $_[1] eq 'node_b' && m/cyc_upgrade/ && m/Upgrading To:/ ) {
            lock @node_b_kb_ndu_proc;
            push( @node_b_kb_ndu_proc, $_ );
        }         

        if ( $_[1] eq 'node_a' && m/cyc_upgrade/ && m/Upgraded To:/ ) {
            lock @node_a_kb_ndu_proc;
            push( @node_a_kb_ndu_proc, $_ );
        }

        if ( $_[1] eq 'node_b' && m/cyc_upgrade/ && m/Upgraded To:/ ) {
            lock @node_b_kb_ndu_proc;
            push( @node_b_kb_ndu_proc, $_ );
        } 

        if ( $_[1] eq 'node_a' && m/cyc_upgrade/ && ( m/Package version:/ or m/CoreOS version:/ or m/BSC version:/ or m/XMS version:/ or m/Service version:/ or m/CP version:/ or m/eVE version:/ or m/Ansible version:/ or m/SDNAS version:/ or m/Recovery version:/ or m/Firmware version:/ ) ) {
            lock @node_a_kb_ndu_proc;
            push( @node_a_kb_ndu_proc, $_ );
        }

        if ( $_[1] eq 'node_b' && m/cyc_upgrade/ && ( m/Package version:/ or m/CoreOS version:/ or m/BSC version:/ or m/XMS version:/ or m/Service version:/ or m/CP version:/ or m/eVE version:/ or m/Ansible version:/ or m/SDNAS version:/ or m/Recovery version:/ or m/Firmware version:/ ) ) {
            lock @node_b_kb_ndu_proc;
            push( @node_b_kb_ndu_proc, $_ );
        }        

        if ( $_[1] eq 'node_a' && m/cyc_upgrade/ && m/Rolling Back From:/ ) {
            lock @node_a_kb_ndu_proc;
            push( @node_a_kb_ndu_proc, $_ );
        }

        if ( $_[1] eq 'node_b' && m/cyc_upgrade/ && m/Rolling Back From:/ ) {
            lock @node_b_kb_ndu_proc;
            push( @node_b_kb_ndu_proc, $_ );
        }

        if ( $_[1] eq 'node_a' && m/cyc_upgrade/ && m/Rolling Back To:/ ) {
            lock @node_a_kb_ndu_proc;
            push( @node_a_kb_ndu_proc, $_ );
        }

        if ( $_[1] eq 'node_b' && m/cyc_upgrade/ && m/Rolling Back To:/ ) {
            lock @node_b_kb_ndu_proc;
            push( @node_b_kb_ndu_proc, $_ );
        }       

        if ( $_[1] eq 'node_a' && m/cyc_upgrade/ && m/Copying hotfix/ ) {
            lock @node_a_kb_ndu_proc;
            push( @node_a_kb_ndu_proc, $_ );
        }

        if ( $_[1] eq 'node_b' && m/cyc_upgrade/ && m/Copying hotfix/ ) {
            lock @node_b_kb_ndu_proc;
            push( @node_b_kb_ndu_proc, $_ );
        }

        if ( $_[1] eq 'node_a' && m/cyc_upgrade/ && m/Hotfix Commit/ ) {
            lock @node_a_kb_ndu_proc;
            push( @node_a_kb_ndu_proc, $_ );
        }

        if ( $_[1] eq 'node_b' && m/cyc_upgrade/ && m/Hotfix Commit/ ) {
            lock @node_b_kb_ndu_proc;
            push( @node_b_kb_ndu_proc, $_ );
        }

        if ( $_[1] eq 'node_a' && m/check_cluster_network/ && ( m/dns_server_error/ or m/ntp_server_error/ or m/check_mgmt_connectivity_failed/ ) ) {
            lock @node_a_tee_2434;
            push( @node_a_tee_2434, $_ );
        }

        if ( $_[1] eq 'node_b' && m/check_cluster_network/ && ( m/dns_server_error/ or m/ntp_server_error/ or m/check_mgmt_connectivity_failed/ ) ) {
            lock @node_b_tee_2434;
            push( @node_b_tee_2434, $_ );
        }                                

        if ( $_[1] eq 'node_a' && m/cyc_puhc/ && ( m/The management network has connectivity issues/ or m/Platform Front End Connectivity check failed/ ) ) {
            lock @node_a_tee_2434;
            push( @node_a_tee_2434, $_ );
        }

        if ( $_[1] eq 'node_b' && m/cyc_puhc/ && ( m/The management network has connectivity issues/ or m/Platform Front End Connectivity check failed/ ) ) {
            lock @node_b_tee_2434;
            push( @node_b_tee_2434, $_ );
        }

        if ( $_[1] eq 'node_a' && m/NEW_SYM_NDU_HANDOVER_FINISHED/ && ( m/Failure reason: SYM started during NDU and that is a no rollback point/ ) ) {
            lock @node_a_tee_2433;
            push( @node_a_tee_2433, $_ );
        }

        if ( $_[1] eq 'node_b' && m/NEW_SYM_NDU_HANDOVER_FINISHED/ && ( m/Failure reason: SYM started during NDU and that is a no rollback point/ ) ) {
            lock @node_b_tee_2433;
            push( @node_b_tee_2433, $_ );
        }              

        if ( $_[1] eq 'node_a' && m/iscsid/ && ( m/Connection timed out/ ) ) {
            lock @node_a_kb_192316;
            push( @node_a_kb_192316, $_ );
        }

        if ( $_[1] eq 'node_b' && m/iscsid/ && ( m/Connection timed out/ ) ) {
            lock @node_b_kb_192316;
            push( @node_b_kb_192316, $_ );
        }

        if ( $_[1] eq 'node_a' && m/nas-control/ && ( m/Failed waiting for all system LUNs availability/ ) ) {
            lock @node_a_kb_192316;
            push( @node_a_kb_192316, $_ );
        }

        if ( $_[1] eq 'node_b' && m/nas-control/ && ( m/Failed waiting for all system LUNs availability/ ) ) {
            lock @node_b_kb_192316;
            push( @node_b_kb_192316, $_ );
        }    

        if ( $_[1] eq 'node_a' && m/NASNDU_FLOW: start_new_sdnas_container on A1:a failed/ ) {
            lock @node_a_kb_192316;
            push( @node_a_kb_192316, $_ );
        }

        if ( $_[1] eq 'node_b' && m/NASNDU_FLOW: start_new_sdnas_container on A1:a failed/ ) {
            lock @node_b_kb_192316;
            push( @node_b_kb_192316, $_ );
        } 

        if ( $_[1] eq 'node_a' && m/sym/ && m/pool exhausted/ ) {
            lock @node_a_tee_2107;
            push( @node_a_tee_2107, $_ );
        }

        if ( $_[1] eq 'node_b' && m/sym/ && m/pool exhausted/ ) {
            lock @node_b_tee_2107;
            push( @node_b_tee_2107, $_ );
        }     

        if ( $_[1] eq 'node_a' && m/PANIC/ && m/M9565/ ) {
            lock @node_a_kb_191693;
            push( @node_a_kb_191693, $_ );
        }

        if ( $_[1] eq 'node_b' && m/PANIC/ && m/M9565/ ) {
            lock @node_b_kb_191693;
            push( @node_b_kb_191693, $_ );
        }  

        if ( $_[1] eq 'node_a' && m/xtremapp-pm/ && m/SYM is not alive/ ) {
            lock @node_a_kb_191693;
            push( @node_a_kb_191693, $_ );
        }

        if ( $_[1] eq 'node_b' && m/xtremapp-pm/ && m/SYM is not alive/ ) {
            lock @node_b_kb_191693;
            push( @node_b_kb_191693, $_ );
        }

        if ( $_[1] eq 'node_a' && m/The following commands cannot be running during upgrade/ && m/Resume replication session/ ) {
            lock @node_a_kb_192483;
            push( @node_a_kb_192483, $_ );
        }

        if ( $_[1] eq 'node_b' && m/The following commands cannot be running during upgrade/ && m/Resume replication session/ ) {
            lock @node_b_kb_192483;
            push( @node_b_kb_192483, $_ );
        }  

        if ( $_[1] eq 'node_a' && m/timeout/ && m/Resume replication session/ ) {
            lock @node_a_kb_192483;
            push( @node_a_kb_192483, $_ );
        }

        if ( $_[1] eq 'node_b' && m/timeout/ && m/Resume replication session/ ) {
            lock @node_b_kb_192483;
            push( @node_b_kb_192483, $_ );
        }  

        if ( $_[1] eq 'node_a' && m/sas_exm_handle_timeout/ ) {
            lock @node_a_kb_130333;
            push( @node_a_kb_130333, $_ );
        }

        if ( $_[1] eq 'node_b' && m/sas_exm_handle_timeout/ ) {
            lock @node_b_kb_130333;
            push( @node_b_kb_130333, $_ );
        } 

        if ( $_[1] eq 'node_a' && m/half-reinited/ ) {
            lock @node_a_factory_complete;
            push( @node_a_factory_complete, $_ );
        }

        if ( $_[1] eq 'node_b' && m/half-reinited/ ) {
            lock @node_b_factory_complete;
            push( @node_b_factory_complete, $_ );
        }   

        if ( $_[1] eq 'node_a' && m/Initiator / && m/opcode 0x8e/ && m/Check Condition/ ) {
            lock @node_a_tee_2462;
            push( @node_a_tee_2462, $_ );
        }

        if ( $_[1] eq 'node_b' && m/Initiator / && m/opcode 0x8e/ && m/Check Condition/ ) {
            lock @node_b_tee_2462;
            push( @node_b_tee_2462, $_ );
        }    

        if ( $_[1] eq 'node_a' && m/CLEAR_ACA received/ ) {
            lock @node_a_tee_2462;
            push( @node_a_tee_2462, $_ );
        }

        if ( $_[1] eq 'node_b' && m/CLEAR_ACA received/ ) {
            lock @node_b_tee_2462;
            push( @node_b_tee_2462, $_ );
        }      

        if ( $_[1] eq 'node_a' && m/Prestage/ && m/Clean up the space under/ ) {
            lock @node_a_tee_2543;
            push( @node_a_tee_2543, $_ );
        }

        if ( $_[1] eq 'node_b' && m/Prestage/ && m/Clean up the space under/ ) {
            lock @node_b_tee_2543;
            push( @node_b_tee_2543, $_ );
        }                                                                    

        if ( $_[1] eq 'node_a' && m/USER=/ && m/COMMAND=/ && m/svc_node reboot/ ) {
            lock @node_a_kb_user_reboot_actions;
            push( @node_a_kb_user_reboot_actions, $_ );
        }

        if ( $_[1] eq 'node_b' && m/USER=/ && m/COMMAND=/ && m/svc_node reboot/ ) {
            lock @node_b_kb_user_reboot_actions;
            push( @node_b_kb_user_reboot_actions, $_ );
        }     

        if ( $_[1] eq 'node_a' && m/Method: POST/ && m/Reboot/ && m/execute/ ) {
            lock @node_a_kb_user_reboot_actions;
            push( @node_a_kb_user_reboot_actions, $_ );
        }

        if ( $_[1] eq 'node_b' && m/Method: POST/ && m/Reboot/ && m/execute/ ) {
            lock @node_b_kb_user_reboot_actions;
            push( @node_b_kb_user_reboot_actions, $_ );
        }

        if ( $_[1] eq 'node_a' && m/cyc_avahi_autoipd_address does not exist/ ) {
            lock @node_a_kb_184530;
            push( @node_a_kb_184530, $_ );
        }

        if ( $_[1] eq 'node_b' && m/cyc_avahi_autoipd_address does not exist/ ) {
            lock @node_b_kb_184530;
            push( @node_b_kb_184530, $_ );
        }           

        if ( $_[1] eq 'node_a' && m/dc_service/ && m/Timeout receiving action response from container/ ) {
            lock @node_a_mdt_342774;
            push( @node_a_mdt_342774, $_ );
        }

        if ( $_[1] eq 'node_b' && m/dc_service/ && m/Timeout receiving action response from container/ ) {
            lock @node_b_mdt_342774;
            push( @node_b_mdt_342774, $_ );
        }

        if ( $_[1] eq 'node_a' && m/PSQLException/ && m/could not open file/ && m/pg_tblspc/ ) {
            lock @node_a_mdt_347737;
            push( @node_a_mdt_347737, $_ );
        }

        if ( $_[1] eq 'node_b' && m/PSQLException/ && m/could not open file/ && m/pg_tblspc/ ) {
            lock @node_b_mdt_347737;
            push( @node_b_mdt_347737, $_ );
        }    

        if ( $_[1] eq 'node_a' && m/The following commands cannot be running during upgrade/ && m/Resume replication/ ) {
            lock @node_a_tee_2255;
            push( @node_a_tee_2255, $_ );
        }

        if ( $_[1] eq 'node_b' && m/The following commands cannot be running during upgrade/ && m/Resume replication/ ) {
            lock @node_b_tee_2255;
            push( @node_b_tee_2255, $_ );
        }   

        if ( $_[1] eq 'node_a' && m/Failed to process the package/ ) {
            lock @node_a_tee_2450;
            push( @node_a_tee_2450, $_ );
        }

        if ( $_[1] eq 'node_b' && m/Failed to process the package/ ) {
            lock @node_b_tee_2450;
            push( @node_b_tee_2450, $_ );
        } 

        if ( $_[1] eq 'node_a' && m/This package is already uploaded on the system/ ) {
            lock @node_a_tee_2450;
            push( @node_a_tee_2450, $_ );
        }

        if ( $_[1] eq 'node_b' && m/This package is already uploaded on the system/ ) {
            lock @node_b_tee_2450;
            push( @node_b_tee_2450, $_ );
        } 

        if ( $_[1] eq 'node_a' && m/NDU failed/ && m/SYM started during NDU and that is a no rollback point/ ) {
            lock @node_a_tee_1854;
            push( @node_a_tee_1854, $_ );
        }

        if ( $_[1] eq 'node_b' && m/NDU failed/ && m/SYM started during NDU and that is a no rollback point/ ) {
            lock @node_b_tee_1854;
            push( @node_b_tee_1854, $_ );
        }     

        if ( $_[1] eq 'node_a' && m/ICM interface is down/ ) {
            lock @node_a_kb_interface_flapping;
            push( @node_a_kb_interface_flapping, $_ );
        }

        if ( $_[1] eq 'node_b' && m/ICM interface is down/ ) {
            lock @node_b_kb_interface_flapping;
            push( @node_b_kb_interface_flapping, $_ );
        }

        if ( $_[1] eq 'node_a' && m/FEPort/ && m/Port link is down/ ) {
            lock @node_a_kb_interface_flapping;
            push( @node_a_kb_interface_flapping, $_ );
        }

        if ( $_[1] eq 'node_b' && m/FEPort/ && m/Port link is down/ ) {
            lock @node_b_kb_interface_flapping;
            push( @node_b_kb_interface_flapping, $_ );
        }

        if ( $_[1] eq 'node_a' && m/FEPort/ && m/Port state has changed from down_in_use to up/ ) {
            lock @node_a_kb_interface_flapping;
            push( @node_a_kb_interface_flapping, $_ );
        }

        if ( $_[1] eq 'node_b' && m/FEPort/ && m/Port state has changed from down_in_use to up/ ) {
            lock @node_b_kb_interface_flapping;
            push( @node_b_kb_interface_flapping, $_ );
        }

        if ( $_[1] eq 'node_a' && m/Chip Reset in progress/ ) {
            lock @node_a_kb_interface_flapping;
            push( @node_a_kb_interface_flapping, $_ );
        }

        if ( $_[1] eq 'node_b' && m/Chip Reset in progress/ ) {
            lock @node_b_kb_interface_flapping;
            push( @node_b_kb_interface_flapping, $_ );
        }

        if ( $_[1] eq 'node_a' && m/qla2xxx/ && m/LINK REINIT/ ) {
            lock @node_a_kb_interface_flapping;
            push( @node_a_kb_interface_flapping, $_ );
        }

        if ( $_[1] eq 'node_b' && m/qla2xxx/ && m/LINK REINIT/ ) {
            lock @node_b_kb_interface_flapping;
            push( @node_b_kb_interface_flapping, $_ );
        }

        if ( $_[1] eq 'node_a' && m/qla2xxx/ && m/Resetting RISC/ ) {
            lock @node_a_kb_interface_flapping;
            push( @node_a_kb_interface_flapping, $_ );
        }

        if ( $_[1] eq 'node_b' && m/qla2xxx/ && m/Resetting RISC/ ) {
            lock @node_b_kb_interface_flapping;
            push( @node_b_kb_interface_flapping, $_ );
        }

        if ( $_[1] eq 'node_a' && m/alarm/ && m/partial_fault/ ) {
            lock @node_a_tee_2184;
            push( @node_a_tee_2184, $_ );
        }

        if ( $_[1] eq 'node_b' && m/alarm/ && m/partial_fault/ ) {
            lock @node_b_tee_2184;
            push( @node_b_tee_2184, $_ );
        } 

        if ( $_[1] eq 'node_a' && m/pm_process_stuck_sensor/ && m/considered as stuck/ ) {
            lock @node_a_tee_2184;
            push( @node_a_tee_2184, $_ );
        }

        if ( $_[1] eq 'node_b' && m/pm_process_stuck_sensor/ && m/considered as stuck/ ) {
            lock @node_b_tee_2184;
            push( @node_b_tee_2184, $_ );
        }   

        if ( $_[1] eq 'node_a' && m/session for wwn/ && m/s_id/ && m/added/ ) {
            lock @node_a_kb_fc_login;
            push( @node_a_kb_fc_login, $_ );
        }

        if ( $_[1] eq 'node_b' && m/session for wwn/ && m/s_id/ && m/added/ ) {
            lock @node_b_kb_fc_login;
            push( @node_b_kb_fc_login, $_ );
        }                                                       

        if ( $_[1] eq 'node_a' && m/from port/ && m/s_id/ && m/logout/ ) {
            lock @node_a_kb_fc_logout;
            push( @node_a_kb_fc_logout, $_ );
        }

        if ( $_[1] eq 'node_b' && m/from port/ && m/s_id/ && m/logout/ ) {
            lock @node_b_kb_fc_logout;
            push( @node_b_kb_fc_logout, $_ );
        }

        if ( $_[1] eq 'node_a' && m/ABTS: Unknown Exchange Address/ ) {
            lock @node_a_kb_fc_abts_unknown_address;
            push( @node_a_kb_fc_abts_unknown_address, $_ );
        }

        if ( $_[1] eq 'node_b' && m/ABTS: Unknown Exchange Address/ ) {
            lock @node_b_kb_fc_abts_unknown_address;
            push( @node_b_kb_fc_abts_unknown_address, $_ );
        }        

        if ( $_[1] eq 'node_a' && m/dc_service/ && m/Timeout sending action to container/ ) {
            lock @node_a_tee_2524;
            push( @node_a_tee_2524, $_ );
        }

        if ( $_[1] eq 'node_b' && m/dc_service/ && m/Timeout sending action to container/ ) {
            lock @node_b_tee_2524;
            push( @node_b_tee_2524, $_ );
        }  

        if ( $_[1] eq 'node_a' && m/fireman_adapter/ && m/Timed out waiting for a handshake response/ ) {
            lock @node_a_tee_2524;
            push( @node_a_tee_2524, $_ );
        }

        if ( $_[1] eq 'node_b' && m/fireman_adapter/ && m/Timed out waiting for a handshake response/ ) {
            lock @node_b_tee_2524;
            push( @node_b_tee_2524, $_ );
        }

        if ( $_[1] eq 'node_a' && m/update_feport_in_mom/ && m/MGMT_FEPORT_LINK_DOWN_NOT_IN_USE->MGMT_FEPORT_LINK_DOWN_IN_USE/ ) {
            lock @node_a_tee_2239;
            push( @node_a_tee_2239, $_ );
        }

        if ( $_[1] eq 'node_b' && m/update_feport_in_mom/ && m/MGMT_FEPORT_LINK_DOWN_NOT_IN_USE->MGMT_FEPORT_LINK_DOWN_IN_USE/ ) {
            lock @node_b_tee_2239;
            push( @node_b_tee_2239, $_ );
        }  

        if ( $_[1] eq 'node_a' && m/reservation conflict/ ) {
            lock @node_a_reservation_conflict;
            push( @node_a_reservation_conflict, $_ );
        }

        if ( $_[1] eq 'node_b' && m/reservation conflict/ ) {
            lock @node_b_reservation_conflict;
            push( @node_b_reservation_conflict, $_ );
        }  

        if ( $_[1] eq 'node_a' && m/NEXUS_LOSS_SESS/ && m/initiator/ && m/target/ ) {
            lock @node_a_kb_session_logout;
            push( @node_a_kb_session_logout, $_ );
        }

        if ( $_[1] eq 'node_b' && m/NEXUS_LOSS_SESS/ && m/initiator/ && m/target/ ) {
            lock @node_b_kb_session_logout;
            push( @node_b_kb_session_logout, $_ );
        }

        if ( $_[1] eq 'node_a' && m/st_io_monitor/ && m/received/ && m/completed/ ) {
            lock @node_a_kb_st_io_counters;
            push( @node_a_kb_st_io_counters, $_ );
        }

        if ( $_[1] eq 'node_b' && m/st_io_monitor/ && m/received/ && m/completed/ ) {
            lock @node_b_kb_st_io_counters;
            push( @node_b_kb_st_io_counters, $_ );
        } 

        if ( $_[1] eq 'node_a' && m/ndu_failure_reason/ && m/Failed to send DP/ ) {
            lock @node_a_kb_193397;
            push( @node_a_kb_193397, $_ );
        }

        if ( $_[1] eq 'node_b' && m/ndu_failure_reason/ && m/Failed to send DP/ ) {
            lock @node_b_kb_193397;
            push( @node_b_kb_193397, $_ );
        }  

        if ( $_[1] eq 'node_a' && m/serial8250/ && m/too much work for irq4/ ) {
            lock @node_a_kb_193396;
            push( @node_a_kb_193396, $_ );
        }

        if ( $_[1] eq 'node_b' && m/serial8250/ && m/too much work for irq4/ ) {
            lock @node_b_kb_193396;
            push( @node_b_kb_193396, $_ );
        }

        if ( $_[1] eq 'node_a' && m/E08010160001/ && m/prepare_SDNAS_for_upgrade/ ) {
            lock @node_a_kb_193399;
            push( @node_a_kb_193399, $_ );
        }

        if ( $_[1] eq 'node_b' && m/E08010160001/ && m/prepare_SDNAS_for_upgrade/ ) {
            lock @node_b_kb_193399;
            push( @node_b_kb_193399, $_ );
        }

        if ( $_[1] eq 'node_a' && m/Bulk master command has failed subrequests/ ) {
            lock @node_a_kb_187268;
            push( @node_a_kb_187268, $_ );
        }

        if ( $_[1] eq 'node_b' && m/Bulk master command has failed subrequests/ ) {
            lock @node_b_kb_187268;
            push( @node_b_kb_187268, $_ );
        } 

        if ( $_[1] eq 'node_a' && m/Fail to poll local disks status from ESX/ ) {
            lock @node_a_kb_185738;
            push( @node_a_kb_185738, $_ );
        }

        if ( $_[1] eq 'node_b' && m/Fail to poll local disks status from ESX/ ) {
            lock @node_b_kb_185738;
            push( @node_b_kb_185738, $_ );
        }               

        if ( $_[1] eq 'node_a' && m/Polling localdisk/ && m/failed/ ) {
            lock @node_a_kb_185738;
            push( @node_a_kb_185738, $_ );
        }

        if ( $_[1] eq 'node_b' && m/Polling localdisk/ && m/failed/ ) {
            lock @node_b_kb_185738;
            push( @node_b_kb_185738, $_ );
        }  

        if ( $_[1] eq 'node_a' && m/Local disk polling failed/ ) {
            lock @node_a_kb_185738;
            push( @node_a_kb_185738, $_ );
        }

        if ( $_[1] eq 'node_b' && m/Local disk polling failed/ ) {
            lock @node_b_kb_185738;
            push( @node_b_kb_185738, $_ );
        }              
    }

    close FILE;
    #threads->detach(); #End thread.
}
#######################################################################


#######################################################################
sub initialize_scan_journal_known_issues {
    print "\n\n######################################################################################################################\n";
    print "# Scan journal txt files.                                                                                            #\n";
    print "#                                                                                                                    #\n";
    print "# Starting scan journal txt files (please wait for a short period of time, few minutes.)                             #\n";
    print "# -------------------------------------------------------------------------------------------------------------------#\n";

    my @thread_node_a_scan_journal;
    my $i = 0;
    foreach ( @node_a_journal ) {
        $thread_node_a_scan_journal[$i] = threads->create( \&threaded_scan_journal_known_issues, $_, 'node_a' );  
        $i++; 
    }

    my @thread_node_b_scan_journal;
    $i = 0;
    foreach (@node_b_journal) {
        $thread_node_b_scan_journal[$i] = threads->create( \&threaded_scan_journal_known_issues, $_, 'node_b' );  
        $i++; 
    }

    foreach (@thread_node_a_scan_journal) {
        $_->join();
    }

    foreach (@thread_node_b_scan_journal) {
        $_->join();
    }   

    print "# Ending scan journal txt files                                                                                      #\n";
    print "######################################################################################################################\n\n";    
}
#######################################################################


sub kb_factory_header {
    print "\n######################################################################################################################\n";
    print "# factory related errors in journal                                                                                  #\n";
    print "#                                                                                                                    #\n";
    print "# icw completes and node up log:                                                                                     #\n";
    print "#  journalctl -t cyc_config | grep half-reinited                                                                     #\n";
    print "#  cyc_config[2755]: A: reinit_install: left system in factory half-reinited state                                   #\n";
    print "#                                                                                                                    #\n";
    print "# This is a destructive procedure. All data and all configuration on the system will be permanently deleted          #\n";
    print "#  and cannot be recovered. The system will be returned to a factory state (same state it was when                   #\n";
    print "#  initially acquired).                                                                                              #\n";
    print "# This procedure will reinitialize the system to the same PowerStoreOS version installed on the PowerStore,          #\n";
    print "#  unless a downgrade is being carried out.                                                                          #\n";
    print "# For PowerStore X, the process is the same but the vCenter side will have to be manually cleaned up from            #\n";
    print "#  all previous PowerStore X configuration before the system can be initialized again (Unregister VASA,              #\n";
    print "#  remove the vDS, remove the PowerStore Cluster). See PowerStore: How to perform vCenter cleanup                    #\n";
    print "#  if cluster creation failed                                                                                        #\n";
    print "# ATTENTION: If the VMware license was acquired from Dell and not VMware, contact technical                          #\n";
    print "#  support before starting the procedure                                                                             #\n";
    print "# https://www.dell.com/support/kbdoc/en-us/000180964/                                                                #\n";
    print "# https://www.dell.com/support/kbdoc/en-us/000180691/                                                                #\n";
    print "#                                                                                                                    #\n";
    print "# Note: svc_factory_reset can only be run on the Primary node in a single system cluster.                            #\n";
    print "# For multiple appliances within a cluster, any non-master appliance must be removed using                           #\n";
    print "#  the svc_remove_appliance script.                                                                                  #\n";
    print "#                                                                                                                    #\n";
    print "# Note: no dare option is needed for specific account                                                                #\n";
    print "######################################################################################################################\n\n";
}


#######################################################################
sub kb_factory_complete {
    print "\nffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff\n";
    print "f factory completes and node up log:                                                           f\n";
    print "f  journalctl -t cyc_config | grep half-reinited                                               f\n";
    print "f  cyc_config[2755]: A: reinit_install: left system in factory half-reinited state             f\n";    
    print "ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff\n\n";

    print "[node_a journal]\n";
    foreach ( @node_a_factory_complete ) {
        print $_."\n";
    }

    print "\n[node_b journal]\n";
    foreach ( @node_b_factory_complete ) {
        print $_."\n";
    }   
}
#######################################################################


my $mdt307082_desc = '';
my $mdt307082_cate = '';
my $mdt307082_match = 'No';
#######################################################################
sub mdt_307082_init_failure {
    print "\nffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff\n";
    print "f Factory Issue mdt_307082_init_failure: Smuttynose GA.                                        f\n";
    print "f Factory Reset may fail due to D\@RE setting not match after 2nd M.2 Drive of either Node.     f\n";
    print "f https://confluence.cec.lab.emc.com/display/ETS/D\@RE+Disable+Configuration+Not+               f\n";
    print "f  Properly+Set+After+2nd+M.2+Drive+Replacement                                                f\n";
    print "f Impact                                                                                       f\n";
    print "f  If one Node has has 2nd M.2 Drive replaced while the other Node has not, a factory          f\n";
    print "f   reset afterwards will fail.                                                                f\n";
    print "f  In the worst case, where both Nodes have 2nd M.2 Drive replaced, a factory reset afterwards f\n";
    print "f   will leave the appliance successfully reimaged with D\@RE enabled, which might not          f\n"; 
    print "f   be easily detected by the customer or L2.                                                  f\n";
    print "f Recovery                                                                                     f\n";
    print "f  Please refer to this confluence page: Recovery Steps of D\@RE Disable Configuration          f\n";
    print "f   Not Properly Set After 2nd M.2 Drive Replacement for details.                              f\n";
    print "f  https://confluence.cec.lab.emc.com/pages/viewpage.action?pageId=499770210                   f\n";
    print "ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff\n\n";

    print "[node_a journal]\n";
    foreach ( @node_a_mdt_307082 ) {
        print $_."\n";
    }

    print "\n[node_b journal]\n";
    foreach ( @node_b_mdt_307082 ) {
        print $_."\n";
    } 

    $mdt307082_desc = 'Factory Issue mdt_307082_init_failure: Smuttynose GA';
    $mdt307082_cate = 'Journal';
    $mdt307082_match = 'Yes' if ( $#node_a_mdt_307082 >= 0 or $#node_b_mdt_307082 >= 0 );        
}
#######################################################################
    

my $mdt304895_desc = '';
my $mdt304895_cate = '';
my $mdt304895_match = 'No';
#######################################################################
sub mdt_304895_ndu_failure {
    print "\nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn\n";
    print "n NDU Issue mdt_304895_ndu_failure: NDU from SN to FHC                                         n\n";
    print "n  CP got stuck in DB schema migration during NDU from SN to FHC due to duplicated             n\n"; 
    print "n   member_ref_id in the volume_group_memership table exist before the NDU                     n\n";
    print "n  https://confluence.cec.lab.emc.com/pages/viewpage.action?pageId=485156125                   n\n";
    print "n Impact                                                                                       n\n";
    print "n  CP gets stuck in DB schema migration, GUI access lost, NDU doesn't complete                 n\n";
    print "n Workaround to L2/EE                                                                          n\n";
    print "n  Delete on of the duplicated entry from sdnas_event_configuration table before NDU.          n\n";
    print "n Recovery                                                                                     n\n";
    print "n  Current solution is to delete one of the duplicated entry.  After CP is up automatically    n\n";
    print "n   followed by NDU manual rollforward recovery.                                               n\n";
    print "n  The recovery step is similar to CP got stuck in DB schema migration during NDU from SN      n\n";
    print "n   to FHC due to duplicated member_ref_id in the volume_group_memership table  except         n\n";
    print "n   there is no need to add the deleted entry back to the table.                               n\n";    
    print "nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn\n\n";

    print "[node_a journal]\n";
    foreach ( @node_a_mdt_304895 ) {
        print $_."\n";
    }

    print "\n[node_b journal]\n";
    foreach ( @node_b_mdt_304895 ) {
        print $_."\n";
    }

    $mdt304895_desc = 'DU Issue mdt_304895_ndu_failure: NDU from SN to FHC';
    $mdt304895_cate = 'Journal';
    $mdt304895_match = 'Yes' if ( $#node_a_mdt_304895 >= 0 or $#node_b_mdt_304895 >= 0 );       
}
#######################################################################


my $mdt304623_desc = '';
my $mdt304623_cate = '';
my $mdt304623_match = 'No';
#######################################################################
sub mdt_304623_ndu_failure {
    print "\nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn\n";
    print "  NDU Issue mdt_304623_ndu_failure: NDU from SN to FHC                                         n\n";
    print "   CP got stuck in DB schema migration during NDU from SN to FHC due to duplicated             n\n";
    print "    parameter_key in the sdnas_event_configuration table                                       n\n";
    print "   https://confluence.cec.lab.emc.com/pages/viewpage.action?pageId=485160173                   n\n";
    print "  Impact                                                                                       n\n";
    print "   CP gets stuck in DB schema migration, GUI access lost, NDU doesn't complete                 n\n";
    print "  Workaround                                                                                   n\n";
    print "   Delete on of the duplicated entry from sdnas_event_configuration table before NDU.          n\n";
    print "  Recovery                                                                                     n\n";
    print "   Current solution is to delete one of the duplicated entry.  After CP is up automatically    n\n";
    print "    followed by NDU manual rollforward recovery.                                               n\n";
    print "   The recovery step is similar to CP got stuck in DB schema migration during NDU from         n\n";
    print "    SN to FHC due to duplicated member_ref_id in the volume_group_memership table              n\n";
    print "    except there is no need to add the deleted entry back to the table.                        n\n";    
    print "nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn\n\n";

    print "[node_a journal]\n";
    foreach ( @node_a_mdt_304623 ) {
        print $_."\n";
    }

    print "\n[node_b journal]\n";
    foreach ( @node_b_mdt_304623 ) {
        print $_."\n";
    }

    $mdt304623_desc = 'NDU Issue mdt_304623_ndu_failure: NDU from SN to FHC';
    $mdt304623_cate = 'Journal';
    $mdt304623_match = 'Yes' if ( $#node_a_mdt_304623 >= 0 or $#node_b_mdt_304623 >= 0 );       
}
#######################################################################


my $mdt305100_desc = '';
my $mdt305100_cate = '';
my $mdt305100_match = 'No';
#######################################################################
sub mdt_305100_ndu_failure {
    print "\nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn\n";
    print "  NDU Issue mdt_305100_ndu_failure: NDU from SN to FHC                                         n\n";
    print "   CP got stuck in DB schema migration during NDU from SN to FHC due to ip_port_id             n\n";
    print "    not present in table ip_port                                                               n\n";
    print "   https://confluence.cec.lab.emc.com/pages/viewpage.action?pageId=488637998                   n\n";
    print "  Impact                                                                                       n\n";
    print "   CP gets stuck in DB schema migration, GUI access lost, NDU doesn't complete                 n\n";
    print "  Workaround                                                                                   n\n";
    print "   Manually recovered by restoring the missing entries from the lower-level                    n\n";
    print "    database (details are in MDT-305100).                                                      n\n";
    print "nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn\n\n";

    print "[node_a journal]\n";
    foreach ( @node_a_mdt_305100 ) {
        print $_."\n";
    }

    print "\n[node_b journal]\n";
    foreach ( @node_b_mdt_305100 ) {
        print $_."\n";
    }

    $mdt305100_desc = 'NDU Issue mdt_305100_ndu_failure: NDU from SN to FHC';
    $mdt305100_cate = 'Journal';
    $mdt305100_match = 'Yes' if ( $#node_a_mdt_305100 >= 0 or $#node_b_mdt_305100 >= 0 );       
}
#######################################################################


sub kb_icw_header {
    print "\n######################################################################################################################\n";
    print "# icw related errors in journal                                                                                      #\n";
    print "#                                                                                                                    #\n";
    print "######################################################################################################################\n\n";
}
#######################################################################


my $tee2091_desc = '';
my $tee2091_cate = '';
my $tee2091_match = 'No';
#######################################################################
sub tee_2091_icw_failure {
    print "\niiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii\n";
    print "  ICW Issue tee_2091_icw_failure: All the FHC version, SmuttyNose is not affected.             i\n";
    print "   Create Cluster Failed due to Xtremapp PANIC <X1709> watchdog_timer_expired X_TIMERQ_20_SEC  i\n";
    print "  https://confluence.cec.lab.emc.com/display/ETS/Create+Cluster+Failed+due+to+Xtremapp+        i\n";
    print "   PANIC+%3CX1709%3E+watchdog_timer_expired+X_TIMERQ_20_SEC                                    i\n";
    print "  Impact                                                                                       i\n";
    print "   Create Cluster failed (ICW failed)                                                          i\n";
    print "  Workaround                                                                                   i\n";
    print "   The workaround  is to disconnect the FC cables before running cluster creation because      i\n"; 
    print "    it takes less time to enable the FC target port when the cable is disconnected.            i\n";
    print "iiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii\n\n";

    print "[node_a journal]\n";
    foreach ( @node_a_tee_2091 ) {
        print $_."\n";
    }

    print "\n[node_b journal]\n";
    foreach ( @node_b_tee_2091 ) {
        print $_."\n";
    } 

    $tee2091_desc = 'ICW Issue tee_2091_icw_failure: All the FHC version';
    $tee2091_cate = 'Journal';
    $tee2091_match = 'Yes' if ( $#node_a_tee_2091 >= 0 or $#node_b_tee_2091 >= 0 );       
}
#######################################################################



#######################################################################
sub kb_service_header {
    print "\n######################################################################################################################\n";
    print "# Service releated errors in journal                                                                                 #\n";
    print "#                                                                                                                    #\n";
    print "# 1.log collection related                                                                                           #\n";
    print "# 2.cp related                                                                                                       #\n";
    print "# 3.mgmt related                                                                                                     #\n";
    print "# 4.eve related                                                                                                      #\n";
    print "######################################################################################################################\n\n";   
}
#######################################################################


#######################################################################
sub mdt_242417_service_failure {
    print "\nssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssss\n";
    print "  Service Issue mdt_242417_service_failure: Affected in SN-SP3 and fixed in SN-SP4.            s\n";
    print "  After NDU to SP3, the scheduler subsystem may stop working after some time.                  s\n";
    print "  Due to a race condition, the scheduler subsystem may stop working after NDU to SP3 and       s\n";
    print "   all the tasks (including core dump trimming, daily DC) it manages won’t work.               s\n";
    print "  https://confluence.cec.lab.emc.com/display/ETS/Daily+DC+May+Stop+For+Appliance+Running+at+SP3 s\n";
    print "  The most direct evidence is there is not daily DC generated recently (which could be         s\n"; 
    print "   days before the issue was discovered) listed in svc_dc list output                          s\n";
    print "  Workaround                                                                                   s\n";
    print "   sudo systemctl restart service_serviceability.service                                       s\n";
    print "   svc_node reboot local                                                                       s\n";
    print "   sudo systemctl restart cyc_service_control                                                  s\n";  
    print "ssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssss\n\n";

    my $creator_type = '';
    my $dc_status = '';
    my $description = '';
    my $id = '';
    my $start_timestamp = '';

    print "[node_a svc_dc list: node_a/config_capture_management_internal_data/datacollection.json]\n";
    if ($node_a_datacollection_json_exist) {
        print "\n------------------------------------------------------------------------------------------------------------------------------------------------------------------------\n";        
        print "| creator_type     | dc_status      | description                              | id                                          | start_timestamp                         |\n";
        print "------------------------------------------------------------------------------------------------------------------------------------------------------------------------\n";        
        
        open (FILE, $node_a_datacollection_json) or die "Cannot open $node_a_datacollection_json: $!\n";        
        while ( <FILE> ) {
            $_ =~ s/^\s+|\s+$//g;
            $creator_type = $_ if ( m/creator_type/ );
            $dc_status = $_ if ( m/dc_status/ ); 
            $description = $_ if ( m/description/ );
            $id = $_ if ( m/id/ );
            if ( m/start_timestamp/ ) {
                $start_timestamp = $_;

                my @tmp = split( /:\s+/, $creator_type );
                $creator_type = $tmp[1];
                chop $creator_type;
                
                @tmp = split( /:\s+/, $dc_status );
                $dc_status = $tmp[1];
                chop $dc_status;

                @tmp = split( /:\s+/, $description );
                $description = $tmp[1];
                chop $description;

                @tmp = split( /:\s+/, $id );
                $id = $tmp[1];
                chop $id;

                @tmp = split( /:\s+/, $start_timestamp );
                $start_timestamp = $tmp[1];
                chop $start_timestamp;

                $~ = DCA;

                format DCA =
------------------------------------------------------------------------------------------------------------------------------------------------------------------------         
| ^<<<<<<<<<<<<<<< | ^<<<<<<<<<<<<< | ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< |
$creator_type, $dc_status, $description, $id, $start_timestamp
| ^<<<<<<<<<<<<<<< | ^<<<<<<<<<<<<< | ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< |
$creator_type, $dc_status, $description, $id, $start_timestamp       
.
                write;  

                $creator_type = '';
                $dc_status = '';
                $description = '';
                $id = '';
                $start_timestamp = '';                
            }
        }
        close FILE;
        print "------------------------------------------------------------------------------------------------------------------------------------------------------------------------\n";        
    }

    print "\n[node_b svc_dc list: node_b/config_capture_management_internal_data/datacollection.json]\n";
    if ($node_b_datacollection_json_exist) {
        print "\n------------------------------------------------------------------------------------------------------------------------------------------------------------------------\n";        
        print "| creator_type     | dc_status      | description                              | id                                          | start_timestamp                         |\n";
        print "------------------------------------------------------------------------------------------------------------------------------------------------------------------------\n";        

        open (FILE, $node_b_datacollection_json) or die "Cannot open $node_b_datacollection_json: $!\n";        
        while ( <FILE> ) {
            $_ =~ s/^\s+|\s+$//g;
            $creator_type = $_ if ( m/creator_type/ );
            $dc_status = $_ if ( m/dc_status/ ); 
            $description = $_ if ( m/description/ );
            $id = $_ if ( m/id/ );
            if ( m/start_timestamp/ ) {
                $start_timestamp = $_;

                my @tmp = split( /:\s+/, $creator_type );
                $creator_type = $tmp[1];
                chop $creator_type;
                
                @tmp = split( /:\s+/, $dc_status );
                $dc_status = $tmp[1];
                chop $dc_status;

                @tmp = split( /:\s+/, $description );
                $description = $tmp[1];
                chop $description;

                @tmp = split( /:\s+/, $id );
                $id = $tmp[1];
                chop $id;

                @tmp = split( /:\s+/, $start_timestamp );
                $start_timestamp = $tmp[1];
                chop $start_timestamp;

                $~ = DCB;

                format DCB =
------------------------------------------------------------------------------------------------------------------------------------------------------------------------         
| ^<<<<<<<<<<<<<<< | ^<<<<<<<<<<<<< | ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< |
$creator_type, $dc_status, $description, $id, $start_timestamp
| ^<<<<<<<<<<<<<<< | ^<<<<<<<<<<<<< | ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< |
$creator_type, $dc_status, $description, $id, $start_timestamp       
.
                write;  

                $creator_type = '';
                $dc_status = '';
                $description = '';
                $id = '';
                $start_timestamp = '';                
            }
        }
        close FILE;
        print "------------------------------------------------------------------------------------------------------------------------------------------------------------------------\n";                
    }
}
#######################################################################


#######################################################################
sub mdt_243089_242417_service_failure {
    print "\nssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssss\n";
    print "  Service Issue mdt_243089_242417_service_failure: No daily DC or telemetry will be            s\n";
    print "   uploaded to CloudIQ, even if they are generated successfully.                               s\n";
    print "   /cyc_cfs/ is filled up.                                                                     s\n";
    print "   Run a df -h in service container to check if /cyc_cfs is 100% can help to determine         s\n"; 
    print "    if this node is also affected by the /cyc_cfs full issue as mentioned in MDT-243089.       s\n";
    print "  Issue mdt_242417 may cause root partition full.                                              s\n";
    print "  Workaround                                                                                   s\n";
    print "   It the /cys_cfs is almost full with little DC usage, just try to restart the CP service     s\n";
    print "    (cp_java.service) within CP container.                                                     s\n";
    print "   If the schduler stops working, you may just try to restart the service_servicibility.service. s\n";
    print "   This report shows all the latest internal partion space usage check result.                 s\n"; 
    print "   If use% is very high, it may cause the problem.                                             s\n";
    print "ssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssss\n\n";

    print "[node_a: node_a/cyc_var/resources/memory-node-a.log]\n";
    my @tmp = ();
    my $hit = 0;
    my $last = -1;
    if ($node_a_memory_node_a_log_exist) {
        open (FILE, $node_a_memory_node_a_log) or die "Cannot open $node_a_memory_node_a_log: $!\n";        
        while ( <FILE> ) {
            if ( m/- df root -/ ) {
                #print $_;
                push (@tmp, $_);
                $hit = 0;
                $last++;
            }
            push (@tmp, $_) if ( m/Filesystem      Size  Used Avail/ );
            push (@tmp, $_) if ( m/overlay   / );
            push (@tmp, $_) if ( m/\/cyc_node/ );
            push (@tmp, $_) if ( m/\/cyc_hacs/ );
            push (@tmp, $_) if ( m/\/cyc_hafs/ );
            if ( m/ha-int:\/cyc_cfs/ ) {
                push (@tmp, $_);
                $hit = 1;
            }
            push (@tmp, $_) if ( m/\# END / && $hit == 1 );
        }
        close FILE;
    }

    my $count = -1;
    foreach ( @tmp ) {
        $count++ if ( m/- df root -/ );
        next if ( $count < $last );
        print $_;
    }

    print "\n[node_b: node_b/cyc_var/resources/memory-node-b.log]\n";
    @tmp = ();
    $last = -1;
    if ($node_b_memory_node_b_log_exist) {
        open (FILE, $node_b_memory_node_b_log) or die "Cannot open $node_b_memory_node_b_log: $!\n";        
        while ( <FILE> ) {
            if ( m/- df root -/ ) {
                #print $_;
                push (@tmp, $_);
                $hit = 0;
                $last++;
            }
            push (@tmp, $_) if ( m/Filesystem      Size  Used Avail/ );
            push (@tmp, $_) if ( m/overlay   / );
            push (@tmp, $_) if ( m/\/cyc_node/ );
            push (@tmp, $_) if ( m/\/cyc_hacs/ );
            push (@tmp, $_) if ( m/\/cyc_hafs/ );
            if ( m/ha-int:\/cyc_cfs/ ) {
                push (@tmp, $_);
                $hit = 1;
            }
            push (@tmp, $_) if ( m/\# END / && $hit == 1 );
        }
        close FILE;
    }

    $count = -1;
    foreach ( @tmp ) {
        $count++ if ( m/- df root -/ );
        next if ( $count < $last ); 
        print $_;
    }    
}
#######################################################################


#######################################################################
sub array_dump_list {
    print "\ncccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc\n";   
    print "c Dump log list:                                                                               c\n";
    print "c How to collect log: https://www.dell.com/support/kbdoc/en-us/191981                          c\n";
    print "cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc\n\n";

    print "[node_a svc_dc list_dumps: node_a/config_capture_management_internal_data/system_dump.json]\n";
    if ($node_a_system_dump_json_exist) {
        open (FILE, $node_a_system_dump_json) or die "Cannot open $node_a_system_dump_json: $!\n";      
        while ( <FILE> ) {
            $_ =~ s/^\s+//;
            $_ =~ s/^\s+|\s+$//g;
            if ( m/\"creation_timestamp\":/ or m/\"node\":/  ) {
                chop $_;
                print $_;
            }

            if ( m/\"path\":/ ) {
                chop $_;
                print $_;
                print "\n";
            }
        }
        close FILE;
    }

    print "\n\n[node_b svc_dc list_dumps: node_b/config_capture_management_internal_data/system_dump.json]\n";
    if ($node_b_system_dump_json_exist) {
        open (FILE, $node_b_system_dump_json) or die "Cannot open $node_b_system_dump_json: $!\n";      
        while ( <FILE> ) {
            $_ =~ s/^\s+//;
            $_ =~ s/^\s+|\s+$//g;
            if ( m/\"creation_timestamp\":/ or m/\"node\":/  ) {
                chop $_;
                print $_;
            }

            if ( m/\"path\":/ ) {
                chop $_;
                print $_;
                print "\n";
            }
        }
        close FILE;
    }
}
#######################################################################


#######################################################################
sub array_alert_list {
    print "\ncccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc\n";
    print "c Alert list:                                                                                  c\n";
    print "c                                                                                              c\n";
    print "c For customer facing document covering all alerts:                                            c\n";
    print "c https://downloads.dell.com/manuals/common/pwrstr-evntsalrtsg_en-us.pdf ( may 2021 )          c\n";
    print "c https://confluence.cec.lab.emc.com:8443/download/attachments/150295896/PowerStore_Events_Alerts_Reference_Guide.pdf?api=v2 ( May 2020 - older ) c\n";
    print "c you can also use :                                                                           c\n";
    print "c https://meet.cec.lab.emc.com/ which shows you, per each release version , :                  c\n";
    print "c EVENT codes ( what's called here events are external events and include  also events which raise alerts  )  - decimal codes c\n";
    print "c +                                                                                            c\n";
    print "c ERROR codes ( what's called here \"errors\" are internal errors ) - hexa codes                 c\n"; 
    print "c  (note that these internal errors don't appear in the guides mentioned above)                c\n";
    print "c For Destination Trident alerts:                                                              c\n";
    print "c Events & Alerts                                                                              c\n";
    print "c DTO Alerts - OKBs                                                                            c\n";
    print "c For Procedure for handling DL condition (from management perspective):                       c\n";
    print "c                                                                                              c\n";
    print "c How to clear alert:                                                                          c\n";
    print "c 1, root injection                                                                            c\n";
    print "c 2, svc_alert list                                                                            c\n";
    print "c 3, svc_alert clear <id>                                                                      c\n"; 
    print "cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc\n\n";

    my $acknowledged_timestamp = '';
    my $appliance_originator = '';
    my $description_l10n = ''; 
    my $event_code = '';
    my $generated_timestamp = '';
    my $id = '';
    my $is_acknowledged = '';
    my $name = '';
    my $node_originator = '';
    my $resource_name = '';
    my $resource_type = '';
    my $state = '';
    my $title_l10n = '';
    
    print "[node_a svc_alert: node_a/config_capture_management_internal_data/alert.json]\n";
    if ($node_a_alert_json_exist) {
        print "\n---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------\n";        
        print "| state            | generated_timestamp                     | event_code      | resource_name                      | resource_type         | title_l10n                                          | acknowledged_timestamp                  |\n";
        print "---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------\n";        
    
        open (FILE, $node_a_alert_json) or die "Cannot open $node_a_alert_json: $!\n";      
        while ( <FILE> ) {
            $_ =~ s/^\s+|\s+$//g;
            $acknowledged_timestamp = $_ if ( m/\"acknowledged_timestamp\":/ );
            #$appliance_originator = $_ if ( m/appliance_originator/ );         
            #$description_l10n = $_ if ( m/description_l10n/ );
            $event_code = $_ if ( m/\"event_code\":/ );
            $generated_timestamp = $_ if ( m/\"generated_timestamp\":/ );
            #$id = $_ if ( m/\"id\":/ );
            #$is_acknowledged = $_ if ( m/is_acknowledged/ );
            #$name = $_ if ( m/\"name\":/ );    
            #$node_originator = $_ if ( m/node_originator/ );  
            $resource_name = $_ if ( m/\"resource_name\":/ );
            $resource_type = $_ if ( m/\"resource_type\":/ );
            $state = $_ if ( m/\"state\":/ );
                                                                                            
            if ( m/\"title_l10n\":/ ) {
                $title_l10n = $_;
            
                my @tmp = split( /:\s+/, $acknowledged_timestamp );
                $acknowledged_timestamp = $tmp[1];
                chop $acknowledged_timestamp;
                
                @tmp = split( /:\s+/, $event_code );
                $event_code = $tmp[1];
                chop $event_code;

                @tmp = split( /:\s+/, $generated_timestamp );
                $generated_timestamp = $tmp[1];
                chop $generated_timestamp;

                @tmp = split( /:\s+/, $resource_name );
                $resource_name = $tmp[1];
                chop $resource_name;

                @tmp = split( /:\s+/, $resource_type );
                $resource_type = $tmp[1];
                chop $resource_type;
                
                @tmp = split( /:\s+/, $state );
                $state = $tmp[1];
                chop $state;

                @tmp = split( /:\s+/, $title_l10n );
                $title_l10n = $tmp[1];

                $~ = ALERTA;

                format ALERTA =
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------         
| ^<<<<<<<<<<<<<<< | ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<<<< | ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< |
$state, $generated_timestamp, $event_code, $resource_name, $resource_type, $title_l10n, $acknowledged_timestamp
| ^<<<<<<<<<<<<<<< | ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<<<< | ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< |
$state, $generated_timestamp, $event_code, $resource_name, $resource_type, $title_l10n, $acknowledged_timestamp        
.
                write; 

                $acknowledged_timestamp = '';
                $appliance_originator = '';
                $description_l10n = ''; 
                $event_code = '';
                $generated_timestamp = '';
                $id = '';
                $is_acknowledged = '';
                $name = '';
                $node_originator = '';
                $resource_name = '';
                $resource_type = '';
                $state = '';
                $title_l10n = '';               
            }
        }
        close FILE;
        print "---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------\n";                
    }

    print "\n[node_b svc_alert: node_b/config_capture_management_internal_data/alert.json]\n";
    if ($node_b_alert_json_exist) {
        print "\n---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------\n";        
        print "| state            | generated_timestamp                     | event_code      | resource_name                      | resource_type         | title_l10n                                          | acknowledged_timestamp                  |\n";
        print "---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------\n";        
     
        open (FILE, $node_b_alert_json) or die "Cannot open $node_b_alert_json: $!\n";      
        while ( <FILE> ) {
            $_ =~ s/^\s+|\s+$//g;
            $acknowledged_timestamp = $_ if ( m/\"acknowledged_timestamp\":/ );
            #$appliance_originator = $_ if ( m/appliance_originator/ ); 
            #$description_l10n = $_ if ( m/description_l10n/ );
            $event_code = $_ if ( m/\"event_code\":/ );
            $generated_timestamp = $_ if ( m/\"generated_timestamp\":/ );
            #$id = $_ if ( m/\"id\":/ );
            #$is_acknowledged = $_ if ( m/is_acknowledged/ );
            #$name = $_ if ( m/\"name\":/ );    
            #$node_originator = $_ if ( m/node_originator/ );  
            $resource_name = $_ if ( m/\"resource_name\":/ );
            $resource_type = $_ if ( m/\"resource_type\":/ );
            $state = $_ if ( m/\"state\":/ );
                                                                                            
            if ( m/\"title_l10n\":/ ) {
                $title_l10n = $_;
            
                my @tmp = split( /:\s+/, $acknowledged_timestamp );
                $acknowledged_timestamp = $tmp[1];
                chop $acknowledged_timestamp;
                
                @tmp = split( /:\s+/, $event_code );
                $event_code = $tmp[1];
                chop $event_code;

                @tmp = split( /:\s+/, $generated_timestamp );
                $generated_timestamp = $tmp[1];
                chop $generated_timestamp;

                @tmp = split( /:\s+/, $resource_name );
                $resource_name = $tmp[1];
                chop $resource_name;

                @tmp = split( /:\s+/, $resource_type );
                $resource_type = $tmp[1];
                chop $resource_type;
                
                @tmp = split( /:\s+/, $state );
                $state = $tmp[1];
                chop $state;

                @tmp = split( /:\s+/, $title_l10n );
                $title_l10n = $tmp[1];

                $~ = ALERTB;

                format ALERTB =
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------         
| ^<<<<<<<<<<<<<<< | ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<<<< | ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< |
$state, $generated_timestamp, $event_code, $resource_name, $resource_type, $title_l10n, $acknowledged_timestamp
| ^<<<<<<<<<<<<<<< | ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<<<< | ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< |
$state, $generated_timestamp, $event_code, $resource_name, $resource_type, $title_l10n, $acknowledged_timestamp        
.
                write; 

                $acknowledged_timestamp = '';
                $appliance_originator = '';
                $description_l10n = ''; 
                $event_code = '';
                $generated_timestamp = '';
                $id = '';
                $is_acknowledged = '';
                $name = '';
                $node_originator = '';
                $resource_name = '';
                $resource_type = '';
                $state = '';
                $title_l10n = '';               
            }
        }
        close FILE;
        print "---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------\n";       
    }    
}
#######################################################################


my $tee2325_desc = '';
my $tee2325_cate = '';
my $tee2325_match = 'No';
#######################################################################
sub tee_2325_puhc_datapath_failure {
    print "\nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn\n";
    print "n PUHC and Drive Issue tee_2325_puhc_datapath_failure (tee-2325,tee-2355,tee-2357,mdt-347182)  n\n";
    print "n Affected SmuttyNose, FHC.                                                                    n\n";
    print "n  PHUC fails, drive replacement may fail                                                      n\n";
    print "n  https://confluence.cec.lab.emc.com/display/ETS/dare_drive_no_key+PHUC+check+failed+         n\n";
    print "n   due+to+LB%28lockbox%29+region+not+assembled                                                n\n";
    print "n  https://confluence.cec.lab.emc.com/display/ETS/PowerStore+%7C+Health+Check+%                n\n";
    print "n   7C+How+to+Resolve+Platform+DARE+Drive+No+Encryption+Key+Check+Failed                       n\n";
    print "n Impact                                                                                       n\n";
    print "n  PUHC in FHC SP1 fails on dare_drive_no_key check due to LB(lock box) region not assembled   n\n";
    print "n Impact                                                                                       n\n";
    print "n TEE-2357, After a drive replacement GUI shows Encryption Status: Not Encrypted               n\n";
    print "nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn\n\n";

    print "[node_a journal]\n";
    my $count = 0;
    foreach ( @node_a_tee_2325 ) {
        print $_."\n";
        $count++;
        last if ( $count >= 10 );
    }

    print "\n[node_b journal]\n";
    $count = 0;
    foreach ( @node_b_tee_2325 ) {
        print $_."\n";
        $count++;
        last if ( $count >= 10 );        
    }

    $tee2325_desc = 'PUHC and Drive Issue tee_2325_puhc_datapath_failure';
    $tee2325_cate = 'Journal';
    $tee2325_match = 'Yes' if ( $#node_a_tee_2325 >= 0 or $#node_b_tee_2325 >= 0 );      
}
#######################################################################


sub kb_node_reboot_header {
    print "\n######################################################################################################################\n";
    print "# node reboot or internal software module restart error in journal                                                   #\n";
    print "#                                                                                                                    #\n";
    print "# how to check reboot:                                                                                               #\n";
    print "# 1. bmc sel log: pls refer to array_reboot_info                                                                     #\n";
    print "# 2. jouranl                                                                                                         #\n";
    print "# 3. docker ps log: pls refer to array_docker_status                                                                 #\n";
    print "# issue list:                                                                                                        #\n";
    print "######################################################################################################################\n\n";
}


my $tee979_desc = '';
my $tee979_cate = '';
my $tee979_match = 'No';
#######################################################################
sub tee_979_node_reboot_failure {
    print "\nrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr\n";
    print "r Node Reboot Issue tee_979_node_reboot_failure (tee-979, tee-1291, tee-1373, tee-1420,        r\n";
    print "r  tee-1426 ... mdt-226885)                                                                    r\n";
    print "r Resolution: Affected SmuttyNose, Fixed in FHC.                                               r\n";
    print "r Impact: No data integrity issue. Node might reboot.                                          r\n";
    print "r  DATA_PATH_SCHEDULE_MAPPER_RECOVERY_LATER [0x00200F02] alert caused by a race condition      r\n";
    print "r  in a metadata locking sequence                                                              r\n";
    print "r  https://confluence.cec.lab.emc.com/display/ETS/DATA_PATH_SCHEDULE_MAPPER_RECOVERY_LATER+    r\n";  
    print "r %5B0x00200F02%5D+alert+caused+by+a+race+condition+in+a+metadata+locking+sequence             r\n";
    print "rrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr\n\n";

    my $count = 0;
    print "[node_a journal]\n";
    foreach ( @node_a_tee_979 ) {
        print $_."\n" if ($count >= 10);
        $count++;
    }
    print "total: $count\n" if ($#node_a_tee_979 >= 0);

    $count = 0;
    print "\n[node_b journal]\n";
    foreach ( @node_b_tee_979 ) {
        print $_."\n" if ($count >= 10);
        $count++;
    }   
    print "total: $count\n" if ($#node_b_tee_979 >= 0); 

    $tee979_desc = 'Node Reboot Issue tee_979_node_reboot_failure';
    $tee979_cate = 'Journal';
    $tee979_match = 'Yes' if ( $#node_a_tee_979 >= 0 or $#node_b_tee_979 >= 0 );            
}
#######################################################################


my $tee1627_desc = '';
my $tee1627_cate = '';
my $tee1627_match = 'No';
#######################################################################
sub tee_1627_perf_failure {
    print "\npppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppp\n";
    print "p Performance Issue tee_1627_perf_failure (tee-1627,tee-1638,tee-1643,tee-1597 .. mdt-304359)  p\n";
    print "p Resolution: Affected FHC, Fixed in FHC SP1.                                                  p\n";
    print "p Impact: No data integrity issue. VLB conversion keeps trying against the affected PLBs.      p\n";
    print "p  Performance drop.                                                                           p\n";
    print "p  https://confluence.cec.lab.emc.com/display/ETS/DATA_PATH_SCHEDULE_MAPPER_RECOVERY_LATER+%5B0x00200F02%5D+alert+following+upgrade+to+FHC p\n";
    print "p  https://www.dell.com/support/kbdoc/en-us/189103                                             p\n";
    print "pppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppp\n\n";

    my $count = 0;
    print "[node_a journal]\n";
    foreach ( @node_a_tee_1627 ) {
        print $_."\n";
        $count++;
        last if ($count >= 10);
    }
    print "total: $#node_a_tee_1627\n" if ($#node_a_tee_1627 >= 0);

    $count = 0;
    print "\n[node_b journal]\n";
    foreach ( @node_b_tee_1627 ) {
        print $_."\n";
        $count++;
        last if ($count >= 10);     
    }   
    print "total: $#node_b_tee_1627\n" if ($#node_b_tee_1627 >= 0); 

    $tee1627_desc = 'Performance Issue tee_1627_perf_failure';
    $tee1627_cate = 'Journal';
    $tee1627_match = 'Yes' if ( $#node_a_tee_1627 >= 0 or $#node_b_tee_1627 >= 0 );    
}
#######################################################################


my $mdt335078_desc = '';
my $mdt335078_cate = '';
my $mdt335078_match = 'No';
#######################################################################
sub mdt_335078_node_reboot_mapper_corruption_failure {
    print "\nrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr\n";
    print "r Node Reboot and Mapper Corruption Issue mdt_335078_node_reboot_corruption_failure            r\n";
    print "r Fix: Affected FHC, Fixed in FHC SP1.                                                         r\n";
    print "r Impact: Data Corruption, DP Panic, Node in Service Mode.                                     r\n";
    print "r  A bug in Leaf Fix Flow sends the incorrect entry to Decref Bin and triggered Data Corruptionr\n";
    print "r   DP rolling Panic and Nodes reboot                                                          r\n"; 
    print "r  https://confluence.cec.lab.emc.com/display/ETS/Data+Lose+Would+Occur+During+Leaf+Fix+In+FHC r\n";
    print "r Workaround:                                                                                  r\n";
    print "r  Running FSCK without cleaning the Decref Bin will lead us back to the DP Panic.             r\n"; 
    print "r  The only way RnD suggested is to:                                                           r\n";
    print "r  Empty the Decref Bin on Node                                                                r\n";
    print "r  Run FSCK                                                                                    r\n";
    print "rrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr\n\n";

    my $count = 0;
    print "[node_a journal]\n";
    foreach ( @node_a_mdt_335078 ) {
        print $_."\n";
        $count++;
        last if ($count >= 10);
    }
    print "total: $#node_a_mdt_335078\n" if ($#node_a_mdt_335078 >= 0);

    $count = 0;
    print "\n[node_b journal]\n";
    foreach ( @node_b_mdt_335078 ) {
        print $_."\n";
        $count++;
        last if ($count >= 10);     
    }   
    print "total: $#node_b_mdt_335078\n" if ($#node_b_mdt_335078 >= 0); 

    $mdt335078_desc = 'Node Reboot and Mapper Corruption Issue mdt_335078';
    $mdt335078_cate = 'Journal';
    $mdt335078_match = 'Yes' if ( $#node_a_mdt_335078 >= 0 or $#node_b_mdt_335078 >= 0 );     
}
#######################################################################


my $mdt329167_desc = '';
my $mdt329167_cate = '';
my $mdt329167_match = 'No';
#######################################################################
sub mdt_329167_node_reboot_corruption_failure {
    print "\nrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr\n";
    print "r Node Reboot and Mapper Corruption Issue mdt_329167_node_reboot_corruption_failure            r\n";
    print "r Fix: Fixed in FHC SP1.                                                                       r\n";
    print "r Impact:                                                                                      r\n";
    print "r  In rare case, DL could occur in FHC systems when certain Samsung NVME drives were (self)    r\n";
    print "r   replaced and SYM restarted later.                                                          r\n";
    print "r  Node went into Service mode. Declared data loss due to corruption spreads                   r\n";
    print "r  https://confluence.cec.lab.emc.com/pages/viewpage.action?pageId=538264263                   r\n";
    print "r Workaround:                                                                                  r\n";
    print "r  Data loss situation                                                                         r\n";
    print "r  1. MDT-330535 PUHC fix to detect drives which are consumed by DP in an RG, but whose keys   r\n";
    print "r   have been removed from KMS's dare lockbox (SP1)                                            r\n";
    print "r  2. MDT-330538 Fix FRU Manager to avoid deleting SSD with fake WWN from KMS (SP1)            r\n";
    print "r  3. MDT-329638 Prevent spreading zero pages to other drives during restripe (Malka)          r\n";
    print "r  4. MDT-329572 Fix the code to avoid accessing null pointer when redirected VLB corruption   r\n";
    print "r   is detected during dedupe processing, so single node rolling panic can be avoided          r\n";
    print "r   (Malka) now SP2 (MDT-329167)                                                               r\n";
    print "r  https://www.dell.com/support/kbdoc/en-us/191004                                             r\n";
    print "r  https://www.dell.com/support/kbdoc/en-us/191410                                             r\n";
    print "rrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr\n\n";

    my $count = 0;
    print "[node_a journal]\n";
    foreach ( @node_a_mdt_329167 ) {
        print $_."\n";
        $count++;
        last if ($count >= 10);
    }
    print "total: $#node_a_mdt_329167\n" if ($#node_a_mdt_329167 >= 0);

    $count = 0;
    print "\n[node_b journal]\n";
    foreach ( @node_b_mdt_329167 ) {
        print $_."\n";
        $count++;
        last if ($count >= 10);     
    }   
    print "total: $#node_b_mdt_329167\n" if ($#node_b_mdt_329167 >= 0);

    $mdt329167_desc = 'Node Reboot and Mapper Corruption Issue mdt_329167';
    $mdt329167_cate = 'Journal';
    $mdt329167_match = 'Yes' if ( $#node_a_mdt_329167 >= 0 or $#node_b_mdt_329167 >= 0 );      
}
#######################################################################


my $mdt185460_desc = '';
my $mdt185460_cate = '';
my $mdt185460_match = 'No';
#######################################################################
sub mdt_185460_unknown_failure {
    print "\nuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuu\n";
    print "u Unknown Issue mdt_185460_unknown_failure : All versions.                                     u\n";
    print "u Impact is unknown.                                                                           u\n";
    print "u https://confluence.cec.lab.emc.com/pages/viewpage.action?pageId=308440910                    u\n";
    print "uuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuu\n\n";

    my $count = 0;
    print "[node_a journal]\n";
    foreach ( @node_a_mdt_185460 ) {
        print $_."\n";
        $count++;
        last if ($count >= 10);
    }
    print "total: $#node_a_mdt_185460\n" if ($#node_a_mdt_185460 >= 0);

    $count = 0;
    print "\n[node_b journal]\n";
    foreach ( @node_b_mdt_185460 ) {
        print $_."\n";
        $count++;
        last if ($count >= 10);     
    }   
    print "total: $#node_b_mdt_185460\n" if ($#node_b_mdt_185460 >= 0);

    $mdt185460_desc = 'Node Reboot and Mapper Corruption Issue mdt_329167';
    $mdt185460_cate = 'Journal';
    $mdt185460_match = 'Yes' if ( $#node_a_mdt_185460 >= 0 or $#node_b_mdt_185460 >= 0 );      
}
#######################################################################


my $tee703_desc = '';
my $tee703_cate = '';
my $tee703_match = 'No';
#######################################################################
sub tee_703_node_reboot_failure {
    print "\nrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr\n";
    print "r Node Reboot Issue tee_703_node_reboot_failure : All the versions prior to SN SP3.            r\n"; 
    print "r Fix: Fixed in SN SP3 (MDT-221299), hotfix-Smuttynose-SP2-HF2                                 r\n";
    print "r Impact is node panic reboot.                                                                 r\n";
    print "r https://confluence.cec.lab.emc.com/pages/viewpage.action?pageId=356787023                    r\n";
    print "rrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr\n\n";

    print "[node_a journal]\n";
    foreach ( @node_a_tee_703 ) {
        print $_."\n";
    }

    print "\n[node_b journal]\n";
    foreach ( @node_b_tee_703 ) {
        print $_."\n";
    }

    $tee703_desc = 'Node Reboot Issue tee_703_node_reboot_failure';
    $tee703_cate = 'Journal';
    $tee703_match = 'Yes' if ( $#node_a_tee_703 >= 0 or $#node_b_tee_703 >= 0 );       
}
#######################################################################


my $tee2064_desc;
my $tee2064_cate;
my $tee2064_match = 'No';
#######################################################################
sub tee_2064_node_reboot_failure {
    print "\nrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr\n";
    print "r Node Reboot or NDU Issue tee_2064_node_reboot_failure                                        r\n"; 
    print "r Fix: All the FHC version prior to FHC_SP1_Patch1                                             r\n";
    print "r Impact is node panic reboot or panic during NDU.                                             r\n"; 
    print "r https://confluence.cec.lab.emc.com/display/ETS/DP+rolling+PANIC+%3CS0%3E                     r\n";
    print "r  +GetDeltaPageByIdxDone+ASSERT+failed+on+condition%3A+false                                  r\n";
    print "rrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr\n\n";

    print "[node_a journal]\n";
    foreach ( @node_a_tee_2064 ) {
        print $_."\n";
    }

    print "\n[node_b journal]\n";
    foreach ( @node_b_tee_2064 ) {
        print $_."\n";
    }   

    $tee2064_desc = 'Node Reboot or NDU Issue tee_2064_node_reboot_failure';
    $tee2064_cate = 'Journal';
    $tee2064_match = 'Yes' if ( $#node_a_tee_2064 >= 0 or $#node_b_tee_2064 >= 0 ); 
}
#######################################################################


my $mdt239421_desc = '';
my $mdt239421_cate = '';
my $mdt239421_match = 'No';
#######################################################################
sub mdt_239421_node_reboot_failure {
    print "\nrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr\n";
    print "r Node Reboot or DU Issue mdt_239421_node_reboot_failure                                       r\n"; 
    print "r Fix: SN-GA - SN-SP3, fixed in SN-SP4                                                         r\n";
    print "r Impact is DU due to DP rolling panic due to DDP issue.                                       r\n";
    print "r Datapath module on both nodes got restart during flushing data to backend drive due          r\n";
    print "r  to an issue with dedup.                                                                     r\n";
    print "r R&D built a binary file to temporarily disable dedup so that the data can be flushed out.    r\n";
    print "r https://confluence.cec.lab.emc.com/display/ETS/DP+rolling+panic+due+to+DDP+issue             r\n";
    print "r https://www.dell.com/support/kbdoc/en-us/181399                                              r\n"; 
    print "rrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr\n\n";

    print "[node_a journal]\n";
    foreach ( @node_a_mdt_239421 ) {
        print $_."\n";
    }

    print "\n[node_b journal]\n";
    foreach ( @node_b_mdt_239421 ) {
        print $_."\n";
    } 

    $mdt239421_desc = 'Node Reboot or DU Issue mdt_239421';
    $mdt239421_cate = 'Journal';
    $mdt239421_match = 'Yes' if ( $#node_a_mdt_239421 >= 0 or $#node_b_mdt_239421 >= 0 );      
}
#######################################################################


my $kb193399_desc = '';
my $kb193399_cate = '';
my $kb193399_match = 'No';
#######################################################################
sub kb_193399_ndu_failure {
    print "\nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn\n";
    print "  NDU Issue kb_193399_ndu_failure :                                                            n\n";
    print "   NDU Fails with NAS related Alert : NASNDU_FLOW: pre_commit_healthcheck on A1: failed        n\n";
    print "  Workaround:                                                                                  n\n";
    print "   https://www.dell.com/support/kbdoc/en-us/193399                                             n\n";
    print "nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn\n\n";

    print "[node_a journal]\n";
    foreach ( @node_a_kb_193399 ) {
        print $_."\n";
    }

    print "\n[node_b journal]\n";
    foreach ( @node_b_kb_193399 ) {
        print $_."\n";
    }

    $kb193399_desc = 'NDU Issue kb_193399_ndu_failure';
    $kb193399_cate = 'Journal';
    $kb193399_match = 'Yes' if ( $#node_a_kb_193399 >= 0 or $#node_b_kb_193399 >= 0 );        
}
#######################################################################


my $kb193397_desc = '';
my $kb193397_cate = '';
my $kb193397_match = 'No';
#######################################################################
sub kb_193397_ndu_failure {
    print "\nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn\n";
    print "  NDU Issue kb_193397_ndu_failure : FHC SP2                                                    n\n";
    print "  NDU failed during stage: NEW_SYM_NDU_ONE_NODE_CODE_COMMIT due to watchdog panic              n\n";
    print "  Workaround:                                                                                  n\n";
    print "   https://www.dell.com/support/kbdoc/en-us/193397                                             n\n";
    print "nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn\n\n";

    print "[node_a journal]\n";
    foreach ( @node_a_kb_193397 ) {
        print $_."\n";
    }

    print "\n[node_b journal]\n";
    foreach ( @node_b_kb_193397 ) {
        print $_."\n";
    }

    $kb193397_desc = 'NDU Issue kb_193397_ndu_failure : FHC SP2';
    $kb193397_cate = 'Journal';
    $kb193397_match = 'Yes' if ( $#node_a_kb_193397 >= 0 or $#node_b_kb_193397 >= 0 );       
}
#######################################################################


my $tee2255_desc = '';
my $tee2255_cate = '';
my $tee2255_match = 'No';
#######################################################################
sub tee_2255_ndu_failure {
    print "\nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn\n";
    print "  NDU Issue tee_2255_ndu_failure : FHC                                                         n\n";
    print "  NDU failed due to stuck replication session resume commands                                  n\n";
    print "   https://confluence.cec.lab.emc.com/display/ETS/NDU+failed+due+to+stuck+replication+session+resume+commands n\n";
    print "  Workaround: engage EE                                                                        n\n";
    print "   High level steps to recover:                                                                n\n";
    print "   Cleanup such the stuck replication session resume command(s)                                n\n";
    print "   Cleanup the NDU work unit that are in PENDING state.                                        n\n";
    print "   Restart CP                                                                                  n\n";
    print "   Retry NDU from GUI.                                                                         n\n";
    print "nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn\n\n";

    print "[node_a journal]\n";
    foreach ( @node_a_tee_2255 ) {
        print $_."\n";
    }

    print "\n[node_b journal]\n";
    foreach ( @node_b_tee_2255 ) {
        print $_."\n";
    }

    $tee2255_desc = 'NDU Issue tee_2255_ndu_failure : FHC';
    $tee2255_cate = 'Journal';
    $tee2255_match = 'Yes' if ( $#node_a_tee_2255 >= 0 or $#node_b_tee_2255 >= 0 );       
}
#######################################################################


my $mdt344382_desc = '';
my $mdt344382_cate = '';
my $mdt344382_match = 'No';
#######################################################################
sub mdt_344382_ndu_failure {
    print "\nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn\n";
    print "  NDU Issue mdt_344382_ndu_failure : FHC                                                       n\n";
    print "  Impact is both nodes enter service mode, DU.                                                 n\n";
    print "   DP rolling panic due to dedupe bloom filter memory initialization failure during            n\n";
    print "    NDU compat_commit stage.                                                                   n\n";   
    print "   NDU V1 to V2 is unsuccessful and results in both nodes of                                   n\n";
    print "    the appliance entering Service Mode                                                        n\n";
    print "   https://confluence.cec.lab.emc.com/display/ETS/DP+rolling+panic+due+to+dedupe+bloom         n\n";
    print "    +filter+memory+initialization+failure+during+NDU+compat_commit+stage                       n\n";
    print "   https://www.dell.com/support/kbdoc/en-us/191981                                             n\n"; 
    print "nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn\n\n";

    print "[node_a journal]\n";
    foreach ( @node_a_mdt_344382 ) {
        print $_."\n";
    }

    print "\n[node_b journal]\n";
    foreach ( @node_b_mdt_344382 ) {
        print $_."\n";
    }


    $mdt344382_desc = 'NDU Issue mdt_344382_ndu_failure : FHC';
    $mdt344382_cate = 'Journal';
    $mdt344382_match = 'Yes' if ( $#node_a_mdt_344382 >= 0 or $#node_b_mdt_344382 >= 0 );         
}
#######################################################################


my $tee1987_desc;
my $tee1987_cate;
my $tee1987_match = 'No';
#######################################################################
sub tee_1987_node_reboot_failure {
    print "\nrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr\n";
    print "r Node Reboot or DU Issue tee_1987_node_reboot_failure                                         r\n";
    print "r Fixed in FHC-SP1                                                                             r\n";
    print "r Impact is DP Panic, Node in Service Mode, DU.                                                r\n";
    print "r DP Rolling Panic – flush stuck with Transaction out of resource.                             r\n";
    print "r https://confluence.cec.lab.emc.com/display/ETS/DU+due+to+flush+                              r\n";
    print "r  stuck+with+transaction+out+of+resource                                                      r\n";
    print "rrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr\n\n";

    my $count = 0;
    print "[node_a journal]\n";
    foreach ( @node_a_tee_1987 ) {
        print $_."\n";
        $count++;
        last if ($count >= 10);
    }
    print "total: $#node_a_tee_1987\n" if ($#node_a_tee_1987 >= 0);

    $count = 0;
    print "\n[node_b journal]\n";
    foreach ( @node_b_tee_1987 ) {
        print $_."\n";
        $count++;
        last if ($count >= 10);     
    }   
    print "total: $#node_b_tee_1987\n" if ($#node_b_tee_1987 >= 0); 

    $tee1987_desc = 'Node Reboot or DU Issue tee_1987_node_reboot_failure';
    $tee1987_cate = 'Journal';
    $tee1987_match = 'Yes' if ( $#node_a_tee_1987 >= 0 or $#node_b_tee_1987 >= 0 );     
}
#######################################################################


sub kb_hardware_header {
    print "\n######################################################################################################################\n";
    print "# hardware related errors in journal                                                                                 #\n";
    print "#                                                                                                                    #\n";
    print "######################################################################################################################\n\n";
}


my $tee2239_desc = '';
my $tee2239_cate = '';
my $tee2239_match = 'No';
#######################################################################
sub tee_2239_hardware_failure {
    print "\nhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh\n";
    print "h 500T onboard Mezz1 10G ports do not come up tee_2239_hardware_failure                        h\n";
    print "h 500T onboard Mezz1 10G ports do not come up following certain HA events including NDU        h\n";
    print "h Impact: port down                                                                            h\n";
    print "h Fix: FHC-SP1-Patch2                                                                          h\n";
    print "h https://confluence.cec.lab.emc.com/pages/viewpage.action?pageId=599722257                    h\n";
    print "h tee-2239, tee-2553                                                                           h\n";
    print "h qlogic driver issue when HA event using PMP power option.                                    h\n";
    print "h Workaround:                                                                                  h\n";
    print "h  need to Pull out the node and let it slow drain for 10 minutes, then push it back.          h\n";
    print "h  1) Shutdown Node A using svc_node script                                                    h\n";
    print "h  2) Once the Node is turned off - pull the node                                              h\n";
    print "h  3) Wait 10 minutes                                                                          h\n";
    print "h  4) Return the node and turn it on                                                           h\n";
    print "h Please read confluence page and check link status and ipmi reboot info                       h\n";
    print "hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh\n\n";

    print "[node_a journal]\n";
    my $count = 0;
    foreach ( @node_a_tee_2239 ) {
        print $_."\n" if ( $count <= 10 );
        $count++;
    }

    print "\n[node_b journal]\n";
    $count = 0;
    foreach ( @node_b_tee_2239 ) {
        print $_."\n" if ( $count <= 10 );
        $count++;  
    }  

    $tee2239_desc = '500T onboard Mezz1 10G ports do not come up tee_2239_hardware_failure';
    $tee2239_cate = 'Journal';
    $tee2239_match = 'Yes' if ( $#node_a_tee_2239 >= 0 or $#node_b_tee_2239 >= 0 );       
}
#######################################################################


my $tee2184_desc = '';
my $tee2184_cate = '';
my $tee2184_match = 'No';
#######################################################################
sub tee_2184_hardware_failure {
    print "\nhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh\n";
    print "h PSU sensor stuck tee_2184_hardware_failure                                                   h\n";
    print "h This fault event log may report couple of times and recovered automatically.                 h\n";
    print "h It could be sensor stuck and not real hardware issue.                                        h\n";
    print "h tee-2184, tee-2603                                                                           h\n";
    print "hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh\n\n";

    print "[node_a journal]\n";
    foreach ( @node_a_tee_2184 ) {
        print $_."\n";
    }

    print "\n[node_b journal]\n";
    foreach ( @node_b_tee_2184 ) {
        print $_."\n";  
    }

    $tee2184_desc = 'PSU sensor stuck tee_2184_hardware_failure';
    $tee2184_cate = 'Journal';
    $tee2184_match = 'Yes' if ( $#node_a_tee_2184 >= 0 or $#node_b_tee_2184 >= 0 );        
}
#######################################################################


my $tee1393_desc = '';
my $tee1393_cate = '';
my $tee1393_match = 'No';
#######################################################################
sub tee_1393_hardware_failure {
    print "\nhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh\n";
    print "h Node Reboot or DU or Hardware Issue tee_1393_hardware_failure                                h\n";
    print "h Fixed in FHC-SP1                                                                             h\n";
    print "h Impact is node Panic, DU due to RRS index change during drive replacement.                   h\n";
    print "h Since SP3, RRS indexing is changed to reserve 0 and 1 for NVRAM RRS.                         h\n";
    print "h For appliance created with release earlier than SP3 and later is upgraded, existing RRS      h\n";
    print "h  index will not be change right after NDU.                                                   h\n";
    print "h Later, if RRS index change is triggered during Drive replacement, the drive may be added     h\n";
    print "h  back to a different RRS and may trigger DU.                                                 h\n";
    print "h https://confluence.cec.lab.emc.com/display/ETS/DU+Due+to+RRS+Index+Change                    h\n";
    print "h  +During+Drive+Replacement                                                                   h\n";
    print "hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh\n\n";

    print "[node_a journal]\n";
    foreach ( @node_a_tee_1393 ) {
        print $_."\n";
    }

    print "\n[node_b journal]\n";
    foreach ( @node_b_tee_1393 ) {
        print $_."\n";  
    } 

    $tee1393_desc = 'Node Reboot or DU or Hardware Issue tee_1393_hardware_failure';
    $tee1393_cate = 'Journal';
    $tee1393_match = 'Yes' if ( $#node_a_tee_1393 >= 0 or $#node_b_tee_1393 >= 0 );      
}
#######################################################################


#######################################################################
sub kb_client_access_header {
    print "\n######################################################################################################################\n";
    print "# Host I/O or connectivity releated errors in journal                                                                #\n";
    print "#                                                                                                                    #\n";
    print "######################################################################################################################\n\n";   
}
#######################################################################

my $kb_int_flap_desc = '';
my $kb_int_flap_cate = '';
my $kb_int_flap_match = 'No';
#######################################################################
sub kb_interface_flapping {
    print "\ncccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc\n";
    print "c kb_interface_flapping                                                                        c\n";
    print "c statistic for flapping interface                                                             c\n";
    print "c example: 0000:bd:00.0   0000:bd:00 -> slic   .0 -> port0, .1 -> port1, .2 -> port 2          c\n";
    print "c node_x/command_output/lspci_-v.txt has fcid info                                             c\n";    
    print "cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc\n\n";

    print "[node_a journal]\n";
    my $count = 0;
    foreach ( @node_a_kb_interface_flapping ) {
        print $_;
        $count++;
        last if ( $count >= 30 );
    }

    print "\n[node_b journal]\n";
    $count = 0;
    foreach ( @node_b_kb_interface_flapping ) {
        print $_; 
        $count++;
        last if ( $count >= 30 );         
    }

    $kb_int_flap_desc = 'statistic for flapping interface kb_interface_flapping';
    $kb_int_flap_cate = 'Journal';
    $kb_int_flap_match = 'Yes' if ( $#node_a_kb_interface_flapping >= 0 or $#node_b_kb_interface_flapping >= 0 );        
}
#######################################################################


my $mdt294054_desc = '';
my $mdt294054_cate = '';
my $mdt294054_match = 'No';
#######################################################################
sub mdt_294054_ndu_vol_du_failure {
    print "\ncccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc\n";
    print "c Volume Access DU or NDU Issue mdt_294054_ndu_vol_du_failure (tee-1712)                       c\n";
    print "c Fix: Fixed in FHC-SP1                                                                        c\n";
    print "c Impact is node Panic, DU due to RRS index change during drive replacement.                   c\n";
    print "c  DU will happen to the volume that is mapped as Logical Unit Number 0 during NDU             c\n";
    print "c   from SN to FHC or when xenv gets restart on FHC.                                           c\n";
    print "c  After XENV is killed by NDU on the 2nd node, the session for LUN=0 is not re-attached,      c\n";
    print "c   due to conflict with an existing LUNZ session that is not detached properly.               c\n";
    print "c  https://confluence.cec.lab.emc.com/display/ETS/DU+will+happen+to+the+volume+that+is+mapped+as+Logical+Unit+Number+0+during+NDU+from+SN+to+FHC+or+when+xenv+gets+restart+on+FHC c\n";
    print "cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc\n\n";

    print "[node_a journal]\n";
    foreach ( @node_a_mdt_294054 ) {
        print $_."\n";
    }

    print "\n[node_b journal]\n";
    foreach ( @node_b_mdt_294054 ) {
        print $_."\n";  
    }

    $mdt294054_desc = 'Volume Access DU or NDU Issue mdt_294054';
    $mdt294054_cate = 'Journal';
    $mdt294054_match = 'Yes' if ( $#node_a_mdt_294054 >= 0 or $#node_b_mdt_294054 >= 0 );       
}
#######################################################################


my $mdt303484_desc = '';
my $mdt303484_cate = '';
my $mdt303484_match = 'No';
#######################################################################
sub mdt_303484_eve_failure {
    print "\nssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssss\n";
    print "s Service eVE docker Issue mdt_303484_eve_failure: Fixed in FHC-SP1                            s\n";
    print "s Impact is eVE Docker Cannot Start Due to Insufficient Space under /cyc_node.                 s\n";
    print "s  cyc_config.tgz backup file may occupy a lot of space under /cyc_node and eVE docker         s\n";
    print "s  may fail to start as a result.                                                              s\n";
    print "s  https://confluence.cec.lab.emc.com/pages/viewpage.action?pageId=506958342                   s\n";
    print "s  Please check /cyc_node space usage from mdt_243089_242417_service_failure !                 s\n";
    print "s Workaround:                                                                                  s\n";
    print "s  Since /cyc_node/cyc_config.tgz is still necessary for future Primary M.2 replace,           s\n"; 
    print "s  we need to delete the existing problematic cyc_config.tgz and regernate the correct one,    s\n";
    print "s  according to the following steps:                                                           s\n";
    print "s  Delete the RA trace                                                                         s\n";
    print "s  Delete the existing /cyc_node/cyc_config.tgz files                                          s\n";
    print "s  Re-generate the cyc_config.tgz by running the following command in CoreOS:                  s\n";
    print "ssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssss\n\n";

    print "[node_a journal]\n";
    foreach ( @node_a_mdt_303484 ) {
        print $_."\n";
    }

    print "\n[node_b journal]\n";
    foreach ( @node_b_mdt_303484 ) {
        print $_."\n";  
    }

    $mdt303484_desc = 'Service eVE docker Issue mdt_303484_eve_failure';
    $mdt303484_cate = 'Journal';
    $mdt303484_match = 'Yes' if ( $#node_a_mdt_303484 >= 0 or $#node_b_mdt_303484 >= 0 );        
}
#######################################################################


my $mdt201561_desc = '';
my $mdt201561_cate = '';
my $mdt201561_match = 'No';
#######################################################################
sub mdt_201561_fabric_rscn_failure {
    print "\ncccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc\n";
    print "c Access DU Issue mdt_201561_fabric_rscn_failure                                               c\n";
    print "c Fix: Fixed in FHC-SP1                                                                        c\n";
    print "c Impact is Hosts may disconnect during fabric changes (zone changes) in a Cisco FC switch     c\n"; 
    print "c  configured with RSCN-3 format (default from NX-OS 6.2).                                     c\n";
    print "c  Hosts will disconnect from the array and will not be able to re-login resulting in a DU.    c\n";
    print "c  https://confluence.cec.lab.emc.com/display/ETS/Fabric+change+on+Cisco+FC+switches+may+lead+to+DU#FabricchangeonCiscoFCswitchesmayleadtoDU-Impact c\n";
    print "c  https://www.dell.com/support/kbdoc/en-us/000181461/                                         c\n";
    print "cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc\n\n";

    print "[node_a journal]\n";
    foreach ( @node_a_mdt_201561 ) {
        print $_."\n";
    }

    print "\n[node_b journal]\n";
    foreach ( @node_b_mdt_201561 ) {
        print $_."\n";  
    } 

    $mdt201561_desc = 'Access DU Issue mdt_201561_fabric_rscn_failure';
    $mdt201561_cate = 'Journal';
    $mdt201561_match = 'Yes' if ( $#node_a_mdt_201561 >= 0 or $#node_b_mdt_201561 >= 0 );      
}
#######################################################################


my $mdt342774_desc = '';
my $mdt342774_cate = '';
my $mdt342774_match = 'No';
#######################################################################
sub mdt_342774_service_failure {
    print "\nssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssss\n";
    print "s Service Journal corrupt in DC Collect Issue mdt_342774_service_failure:                      s\n";
    print "s  No valid journal file for one Node in the DC                                                s\n";
    print "s  Please check svc_dc list in mdt_242417_service_failure. DC collection status is failure.    s\n";
    print "s  https://confluence.cec.lab.emc.com/pages/viewpage.action?spaceKey=ETS&title=No+Valid+Journal+File+in+DC+Due+to+Service+Container+Response+Timeout s\n";
    print "s Workaround:                                                                                  s\n";
    print "s  Usually restart Service Container in CoreOS on the affected Node can resolve the issue.     s\n";
    print "s  sudo systemctl restart cyc_service_control                                                  s\n";
    print "s  It is better to collect a detailed DC as soon as the issue is addressed on the affected     s\n";
    print "s  Node, hoping it can contain enough information to achieve RCA of this issue.                s\n";
    print "ssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssss\n\n";

    print "[node_a journal]\n";
    my $count = 0;
    foreach ( @node_a_mdt_342774 ) {
        print $_;
        $count++;
        last if ( $count >= 10 );
    }

    print "\n[node_b journal]\n";
    $count = 0;
    foreach ( @node_b_mdt_342774 ) {
        print $_;
        $count++;
        last if ( $count >= 10 );          
    } 

    $mdt342774_desc = 'Service Journal corrupt in DC Collect Issue mdt_342774';
    $mdt342774_cate = 'Journal';
    $mdt342774_match = 'Yes' if ( $#node_a_mdt_342774 >= 0 or $#node_b_mdt_342774 >= 0 );       
}
#######################################################################


my $kb185738_desc = '';
my $kb185738_cate = '';
my $kb185738_match = 'No';
#######################################################################
sub kb_185738_alert {
    print "\nssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssss\n";
    print "  Polling failed for internal M.2 boot module in slot. (0x0030BA02)                            s\n";
    print "  The Powerstore Manager will trigger an alert \"Polling failed for internal M.2 boot module in slot X\" s\n"; 
    print "  The alert has been seen for M.2 module in slot 1 and slot 0 at the same time and on both nodes. s\n";
    print "  No reboots of the nodes occurred and it does not fault the M.2 module.                       s\n";
    print "  Workaround:                                                                                  s\n";
    print "  https://www.dell.com/support/kbdoc/en-us/185738                                              s\n";
    print "ssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssss\n\n";

    print "[node_a journal]\n";
    my $count = 0;
    foreach ( @node_a_kb_185738 ) {
        print $_."\n" if ( $count <= 5 );
        $count++;
    }

    print "\n[node_b journal]\n";
    $count = 0;
    foreach ( @node_b_kb_185738 ) {
        print $_."\n" if ( $count <= 5 );
        $count++;  
    }

    $kb185738_desc = 'Polling failed for internal M.2 boot module in slot. (0x0030BA02)';
    $kb185738_cate = 'Journal';
    $kb185738_match = 'Yes' if ( $#node_a_kb_185738 >= 0 or $#node_b_kb_185738 >= 0 );       
}
#######################################################################


my $tee2524_desc = '';
my $tee2524_cate = '';
my $tee2524_match = 'No';
#######################################################################
sub tee_2524_service_failure {
    print "\nssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssss\n";
    print "s Service DataCollections failed tee_2524_service_failure:                                     s\n";
    print "s  DataCollections failed due to fireman service in service container stopped                  s\n";
    print "s DC failed with error \"Timed out receiving service data bundle command response from container\" s\n";
    print "s Some DCs could stuck in running status in GUI, but they don't show up in \"svc_dc list\"     s\n";
    print "s  https://confluence.cec.lab.emc.com/display/ETS/DataCollections+failed+due+to+fireman+service+in+service+container+stopped s\n";
    print "s Workaround:                                                                                  s\n";
    print "s  Restart the fireman service in service container if the process is not running.             s\n";
    print "s   [SVC:root] systemctl restart service_fireman.service                                       s\n";
    print "s  Restart CP container                                                                        s\n";
    print "s   svc_container_mgmt restart CP                                                              s\n";
    print "ssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssss\n\n";

    print "[node_a journal]\n";
    my $count = 0;
    foreach ( @node_a_tee_2524 ) {
        print $_."\n" if ( $count <= 10 );
        $count++;
    }

    print "\n[node_b journal]\n";
    $count = 0;
    foreach ( @node_b_tee_2524 ) {
        print $_."\n" if ( $count <= 10 );
        $count++;  
    }

    $tee2524_desc = 'Service DataCollections failed tee_2524_service_failure';
    $tee2524_cate = 'Journal';
    $tee2524_match = 'Yes' if ( $#node_a_tee_2524 >= 0 or $#node_b_tee_2524 >= 0 );        
}
#######################################################################


my $mdt347737_desc = '';
my $mdt347737_cate = '';
my $mdt347737_match = 'No';
#######################################################################
sub mdt_347737_service_failure {
    print "\nssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssss\n";
    print "s Service CP Metrics Collection Failed due to DB corruptions during NDU mdt_347737_service_failure: s\n";
    print "s  CP mal-function, TMA Performance or Capacity Not working in GUI                             s\n";
    print "s  https://confluence.cec.lab.emc.com/pages/viewpage.action?spaceKey=ETS&title=CP+-+Metrics+Collection+Failed+due+to+DB+corruptions+during+NDU s\n";
    print "s Workaround:                                                                                  s\n";
    print "s  we need CP side experts to do DB recovery,                                                  s\n";
    print "s  we need to contact L2 to reserve a maintenance window (3hours - 8hours)                     s\n";
    print "ssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssss\n\n";

    print "[node_a journal]\n";
    foreach ( @node_a_mdt_347737 ) {
        print $_."\n";
    }

    print "\n[node_b journal]\n";
    foreach ( @node_b_mdt_347737 ) {
        print $_."\n";  
    }

    $mdt347737_desc = 'Service CP Metrics Collection Failed due to DB corruptions mdt_347737';
    $mdt347737_cate = 'Journal';
    $mdt347737_match = 'Yes' if ( $#node_a_mdt_347737 >= 0 or $#node_b_mdt_347737 >= 0 );       
}
#######################################################################


my $mdt312975_desc = '';
my $mdt312975_cate = '';
my $mdt312975_match = 'No';
#######################################################################
sub mdt_312975_dc_failure {
    print "\nssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssss\n";
    print "s Service DC Collect Issue mdt_312975_dc_failure: Fixed in FHC-SP1                             s\n";
    print "s  Failed to collect DC in FHC - OSError: [Errno 2] No such file or directory.                 s\n";
    print "s  Please check svc_dc list in mdt_242417_service_failure. DC collection status is failure.    s\n";
    print "s  https://confluence.cec.lab.emc.com/display/ETS/Failed+to+collect+DC+in+FHC+-+OSError%3A+%5BErrno+2%5D+No+such+file+or+directory s\n";
    print "s Workaround:                                                                                  s\n";
    print "s  Obtain permission from the customer before applying the fix.                                s\n";
    print "s  Inject root                                                                                 s\n";
    print "s  Upload the injectable to the service container.  For example upload to /home/service/user   s\n";
    print "s  Run the injectable:  svc_inject run <path>                                                  s\n";
    print "ssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssss\n\n";

    print "[node_a journal]\n";
    foreach ( @node_a_mdt_312975 ) {
        print $_."\n";
    }

    print "\n[node_b journal]\n";
    foreach ( @node_b_mdt_312975 ) {
        print $_."\n";  
    }

    $mdt312975_desc = 'Service DC Collect Issue mdt_312975_dc_failure';
    $mdt312975_cate = 'Journal';
    $mdt312975_match = 'Yes' if ( $#node_a_mdt_312975 >= 0 or $#node_b_mdt_312975 >= 0 );       
}
#######################################################################


my $mdt247214_desc = '';
my $mdt247214_cate = '';
my $mdt247214_match = 'No';
#######################################################################
sub mdt_247214_dc_failure {
    print "\nssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssss\n";
    print "s Service DC Collect Issue mdt_247214_dc_failure: Fixed in FHC                                 s\n";
    print "s  At SumuttyNose versions, the daily DC and/or generating an essential DC might be failed     s\n"; 
    print "s   with status_message Unable to successfully perform Support materials gathering at this     s\n";
    print "s   time or FAILURE, Running too long.                                                         s\n";
    print "s  https://confluence.cec.lab.emc.com/display/ETS/Failed+to+collect+essential+DC+in+SN         s\n";
    print "s   +due+to+a+db_dump_minimal_critical_data+profile                                            s\n";
    print "s Workaround:                                                                                  s\n";
    print "s  As a temporary workaround to make the essential DC creation work, disable                   s\n";
    print "s   db_dump_minimal_critical_data.sh profile in the DataCollectionActionConfig.json file.      s\n";
    print "s  Inject root                                                                                 s\n";
    print "s  Open the following file /cyc_host/cyc_service/conf/DataCollectionActionConfig.json using vi s\n";
    print "s  Search the line of /cyc_bsc/scripts/dba/db_dump_minimal_critical_data.sh then change        s\n";
    print "s   the enabled in the below section from true to false                                        s\n";
    print "s  restart service_serviceability.service within the service container                         s\n"; 
    print "s   sudo systemctl restart service_serviceability.service                                      s\n";
    print "ssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssss\n\n";

    print "[node_a journal]\n";
    foreach ( @node_a_mdt_247214 ) {
        print $_."\n";
    }

    print "\n[node_b journal]\n";
    foreach ( @node_b_mdt_247214 ) {
        print $_."\n";  
    }

    $mdt247214_desc = 'Service DC Collect Issue mdt_247214_dc_failure';
    $mdt247214_cate = 'Journal';
    $mdt247214_match = 'Yes' if ( $#node_a_mdt_247214 >= 0 or $#node_b_mdt_247214 >= 0 );       
}
#######################################################################



#######################################################################
sub mdt_183942_switch_alert {
    print "\nssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssss\n";
    print "s Service Switch related Alert Issue mdt_183942_switch_alert:                                  s\n";
    print "s When adding ToR switches credentials, false positive alerts may be raised for vlan access,   s\n";
    print "s  connectivity and port speed                                                                 s\n"; 
    print "s  https://confluence.cec.lab.emc.com/display/ETS/False+positive+networking+alerts+are+raised+for+vlan+access%2C+connectivity%2C+STP+and+port+speed\ s\n";
    print "s Workaround:                                                                                  s\n";
    print "s  remove the ToR switches from the settings→Infrastructure Services→Physical switches lower pane. s\n";
    print "s  The alert that already generated will not disappear after the removal of the TOR            s\n";
    print "s   switches, we may need to escalate to root in service container then use svc_alert          s\n";
    print "s   to clear the alerts.                                                                       s\n";
    print "s Example alerts:                                                                              s\n";
    print "s  1.physical switch Dell 5248 has speed less than 1 Gbps, but the system requires at          s\n";
    print "s    least 1 Gbps ports                                                                        s\n";
    print "s  2.The second port of 4-Port card of node N1 has no access to VLANs 60 because it is         s\n"; 
    print "s    connected to port Ethernet 1/1/8:1 of Ethernet switch Dell 5248 with allowed VLANs        s\n";
    print "s  3.first port of 4-Port card is connected to switch IRV-S4048-01, second port of 4-Port      s\n";
    print "s    card is connected to switch IRV-S4048-02) and node N2 (first port of 4-Port card is       s\n";
    print "s    connected to switch IRV-S4048-02, second port of 4-Port card is connected to switch       s\n";
    print "s    IRV-S4048-01) are not connected to Ethernet switches configured with high availability    s\n";
    print "s https://www.dell.com/support/kbdoc/en-us/000177616/                                          s\n";
    print "s Please check array_alert_list manually                                                       s\n";
    print "ssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssss\n\n";

    print "[node_a svc_alert: node_a/config_capture_management_internal_data/alert.json]\n";
    if ($node_a_alert_json_exist) {
        open (FILE, $node_a_alert_json) or die "Cannot open $node_a_alert_json: $!\n";      
        while ( <FILE> ) {
            $_ =~ s/^\s+//;
            print $_ if ( m/less than 1 Gbps/ );
            print $_ if ( m/has no access to VLANs/ );          
        }
        close FILE;
    }

    print "\n[node_b svc_alert: node_b/config_capture_management_internal_data/alert.json]\n";
    if ($node_b_alert_json_exist) {
        open (FILE, $node_b_alert_json) or die "Cannot open $node_b_alert_json: $!\n";      
        while ( <FILE> ) {
            $_ =~ s/^\s+//;
            print $_ if ( m/less than 1 Gbps/ );
            print $_ if ( m/has no access to VLANs/ );        
        }
        close FILE;
    }     
}
#######################################################################


my $mdt342762_desc = '';
my $mdt342762_cate = '';
my $mdt342762_match = 'No';
#######################################################################
sub mdt_342762_node_reboot_failure {
    print "\nrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr\n";
    print "r Node Reboot when running DP_Stats script Issue mdt_342762_node_reboot_failure                r\n";  
    print "r Fix: TBD                                                                                     r\n";
    print "r Impact is DP Panic, DU for dual Panic.                                                       r\n";
    print "r While running the DP_Stats script to collect performance data the quantity of data about     r\n";
    print "r  XCOPY requests may exceed the available buffer space causing the collection to fail         r\n";
    print "r  and trigger a DP panic.                                                                     r\n";
    print "r As this script collects from both nodes if both have a high amount of XCOPY requests such    r\n";
    print "r  that they both exceed this buffer space in quick succession it can cause a DU.              r\n";
    print "r https://confluence.cec.lab.emc.com/pages/viewpage.action?pageId=                             r\n";
    print "r  571223160#FHC/SNDPPanicduringDP_stats-RootCause                                             r\n";
    print "rrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr\n\n";

    print "[node_a journal]\n";
    foreach ( @node_a_mdt_342762 ) {
        print $_."\n";
    }

    print "\n[node_b journal]\n";
    foreach ( @node_b_mdt_342762 ) {
        print $_."\n";  
    } 

    $mdt342762_desc = 'Node Reboot when running DP_Stats script Issue mdt_342762';
    $mdt342762_cate = 'Journal';
    $mdt342762_match = 'Yes' if ( $#node_a_mdt_342762 >= 0 or $#node_b_mdt_342762 >= 0 );       
}
#######################################################################


my $mdt305828_desc = '';
my $mdt305828_cate = '';
my $mdt305828_match = 'No';
#######################################################################
sub mdt_305828_node_reboot_failure {
    print "\nrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr\n";
    print "r Node Reboot Issue mdt_305828_node_reboot_failure                                             r\n";
    print "r Fix: Affected FHC, Fixed in FHC SP1                                                          r\n";
    print "r Impact is DP Panic.                                                                          r\n";
    print "r Primary node may panic due to a memory leak within the logic to generate a DataCollect if    r\n"; 
    print "r  ran array has over 312 unique initiators registered to hosts/host groups and logged in      r\n";
    print "r https://confluence.cec.lab.emc.com/display/ETS/FHC+-+Node+Panic+due+to+Memory+Leak           r\n";
    print "rrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr\n\n";

    print "[node_a journal]\n";
    foreach ( @node_a_mdt_305828 ) {
        print $_."\n";
    }

    print "\n[node_b journal]\n";
    foreach ( @node_b_mdt_305828 ) {
        print $_."\n";  
    }

    $mdt305828_desc = 'Node Reboot Issue mdt_305828_node_reboot_failure';
    $mdt305828_cate = 'Journal';
    $mdt305828_match = 'Yes' if ( $#node_a_mdt_305828 >= 0 or $#node_b_mdt_305828 >= 0 );        
}
#######################################################################


my $kb182665_desc = '';
my $kb182665_cate = '';
my $kb182665_match = 'No';
#######################################################################
sub kb_182665_max_transfer_size {
    print "\ncccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc\n";
    print "c MAX TRANSFER SIZE Issue kb_182665_max_transfer_size :                                        c\n";
    print "c Impact is performance, vmotion failure, vm cant boot up, IO failure.                         c\n";
    print "c In PowerStore array, the maximum I/O size is 1 MB. PowerStore does not set an optimal        c\n";
    print "c  transfer size.                                                                              c\n";
    print "c ESX: https://www.dell.com/support/kbdoc/en-us/182665                                         c\n";
    print "c AIX:                                                                                         c\n";
    print "c  lsattr -l fcs0 -E   (each AIX host will probably have additional fcs cards)                 c\n";
    print "c  sample outut should be similiar to                                                          c\n";
    print "c  max_xfer_size 0x400000 Maximum Transfer Size True                                           c\n";
    print "c Linux:                                                                                       c\n";
    print "c  Multipathing software configuration                                                         c\n";
    print "c  MPIO configuration                                                                          c\n";
    print "c  Red Hat Enterprise Linux                                                                    c\n";
    print "c  This section provides information for configuring the PowerStore storage                    c\n";
    print "c   array for RHEL 7.x and later.                                                              c\n";
    print "c  The following is an example of multipath.conf to support the PowerStore array:              c\n";
    print "c   defaults {                                                                                 c\n";
    print "c   user_friendly_names yes                                                                    c\n";
    print "c   }                                                                                          c\n";
    print "c   devices {                                                                                  c\n";
    print "c   device {                                                                                   c\n";
    print "c    max_sectors_kb 1024 #only for RHEL 6.9 and above                                          c\n";
    print "c    }                                                                                         c\n";
    print "c   }                                                                                          c\n";
    print "cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc\n\n";

    my $count = 0;
    print "[node_a journal]\n";
    foreach ( @node_a_kb_182665 ) {
        print $_."\n";
        $count++;
        last if ($count >= 10);
    }
    print "total: $#node_a_kb_182665\n" if ($#node_a_kb_182665 >= 0);

    $count = 0;
    print "\n[node_b journal]\n";
    foreach ( @node_b_kb_182665 ) {
        print $_."\n";
        $count++;
        last if ($count >= 10);     
    }   
    print "total: $#node_b_kb_182665\n" if ($#node_b_kb_182665 >= 0);

    $kb182665_desc = 'MAX TRANSFER SIZE Issue kb_182665_max_transfer_size';
    $kb182665_cate = 'Journal';
    $kb182665_match = 'Yes' if ( $#node_a_kb_182665 >= 0 or $#node_b_kb_182665 >= 0 );           
}
#######################################################################


my $mdt173900_desc = '';
my $mdt173900_cate = '';
my $mdt173900_match = 'No';
#######################################################################
sub mdt_173900_halt_vault_corruption {
    print "\nhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh\n";
    print "h Halt and Vault during Node reboot Issue mdt_173900_halt_vault_corruption                     h\n";
    print "h Fix: Fixed in SN SP3                                                                         h\n";
    print "h Impact is data in the TxCache of the rebooted/powered off Node will be lost, DL.             h\n";
    print "h Halt & Vault during one Node reboot or power off will cause DL during UnVault afterwards     h\n";
    print "h https://confluence.cec.lab.emc.com/pages/viewpage.action?pageId=308440134                    h\n";
    print "hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh\n\n";

    print "[node_a journal]\n";
    foreach ( @node_a_mdt_173900 ) {
        print $_."\n";
    }

    print "\n[node_b journal]\n";
    foreach ( @node_b_mdt_173900 ) {
        print $_."\n";  
    }

    $mdt173900_desc = 'Halt and Vault during Node reboot Issue mdt_173900';
    $mdt173900_cate = 'Journal';
    $mdt173900_match = 'Yes' if ( $#node_a_mdt_173900 >= 0 or $#node_b_mdt_173900 >= 0 );       
}
#######################################################################


my $tee_x_corrupt_desc = '';
my $tee_x_corrupt_cate = '';
my $tee_x_corrupt_match = 'No';
#######################################################################
sub tee_x_corruptions_detect {
    print "\nhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh\n";
    print "h Corruptions Issue tee_x_corruptions_detect                                                   h\n";
    print "h Impact is data loss or data unavailable.                                                     h\n";
    print "h It is general corruptions scan and not related to any known issues.                          h\n";
    print "h Please double check if any matched issues in report are the possible cause                   h\n";
    print "hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh\n\n";

    my $count = 0;
    print "[node_a journal]\n";
    foreach ( @node_a_tee_x_corruptions ) {
        print $_."\n";
        $count++;
        last if ($count >= 10);
    }
    print "total: $#node_a_tee_x_corruptions\n" if ($#node_a_tee_x_corruptions >= 0);

    $count = 0;
    print "\n[node_b journal]\n";
    foreach ( @node_b_tee_x_corruptions ) {
        print $_."\n";
        $count++;
        last if ($count >= 10);     
    }   
    print "total: $#node_b_tee_x_corruptions\n" if ($#node_b_tee_x_corruptions >= 0); 

    $tee_x_corrupt_desc = 'Halt and Vault during Node reboot Issue mdt_173900';
    $tee_x_corrupt_cate = 'Journal';
    $tee_x_corrupt_match = 'Yes' if ( $#node_a_tee_x_corruptions >= 0 or $#node_b_tee_x_corruptions >= 0 );      
}
#######################################################################


#######################################################################
sub kb_performance_header {
    print "\n######################################################################################################################\n";
    print "# Performance related kb_performance_header :                                                                        #\n";
    print "# 1. MDT-33835, TEE-452 High CPU usage and memory usage alarm against PowerStoreX Controller VM in vCenter           #\n";
    print "#  Virtual machine memory usage and Virtual machine CPU usage alarm against PowerStoreX Controller VM in vCenter.    #\n";
    print "#  After Reset to Green in vCenter, the alarms returned after a day or so.                                           #\n";
    print "#  Function as designed. The issue may be addressed in FootHills (MDT-237745)                                        #\n";
    print "#  https://confluence.cec.lab.emc.com/display/ETS/High+CPU+usage+and+memory+usage+alarm+against+PowerStoreX+Controller+VM+in+vCenter#HighCPUusageandmemoryusagealarmagainstPowerStoreXControllerVMinvCenter-Workaround: #\n";
    print "#  https://www.dell.com/support/kbdoc/en-us/149604                                                                   #\n";
    print "# 2. MDT-218936 Large Sequential Block IO May Cause High Latency                                                     #\n";
    print "#  Affected in All SmuttyNose Version, improve in FHC                                                                #\n";
    print "#  https://confluence.cec.lab.emc.com/display/ETS/Large+Sequential+Block+IO+May+Cause+High+Latency                   #\n";
    print "#  TRIES-35671 - https://jira.cec.lab.emc.com/browse/TRIES-35671                                                     #\n";
    print "#  Enhancements to increase flush performance under burst workloads and Enhancements to sequential IO workloads,     #\n";
    print "#   allowing more parallel flushing of ingested data*                                                                #\n";  
    print "# 3. Enhancement to large UNMAP performance                                                                          #\n";
    print "#  https://jira.cec.lab.emc.com/browse/TRIF-822                                                                      #\n";
    print "# 4. Enhancements to optimize flushing over dedupping data inline when the system is getting close to                #\n";
    print "#   throttling (non-deduped data will later be process).                                                             #\n";
    print "#  https://jira.cec.lab.emc.com/browse/TRIF-1                                                                        #\n";
    print "######################################################################################################################\n\n";   
}
#######################################################################


#######################################################################
sub mdt_218936_perf_failure {
    print "\npppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppp\n";
    print "p Performance Cache, ATS related mdt_218936_perf_failure :                                     p\n";
    print "p Log Full Waits and Cache Full Waits:                                                         p\n";
    print "p  One direct evidence is the Log Full Waits and Cache Full Waits in dpstat:                   p\n";
    print "p  Note: The Log Full Waits and Cache Full Waits information can be found in the dpstats info. p\n";
    print "p  In the DC, it can be found                                                                  p\n";
    print "p   {DC_Filename}/node_*/command_output/dc-datapath-[timestamp]-logs/cache.txt                 p\n";
    print "p  On the live appliance, such information can also be obtained using dpcli in                 p\n"; 
    print "p   BSC container: /usr/lib/python2.7/site-packages/PyCycloneDp/cli.py cache stats basic       p\n";
    print "p  1. The Log Full Waits and Cache Full Waits will increase over time which may                p\n";
    print "p   affect the performance!                                                                    p\n";
    print "p  2. If Log Full Waits and Cache Full Waits are higher on one node than the other node,       p\n";
    print "p   it may indicates workload not distribute evenly even node affinity is balanced.            p\n";
    print "p   If the workload is balanced, it may indicates node issue internally.                       p\n";
    print "p                                                                                              p\n";
    print "p ATS is one function of ESXi VAAI Suite:                                                      p\n";
    print "p ATS heartbeat is applied from ESXi 5.5 Update 2 and later version. For VMFS5,                p\n"; 
    print "p  ATS heartbeat setting is ON by default.                                                     p\n";
    print "p http://kb.vmware.com/kb/2136081                                                              p\n";
    print "p http://kb.vmware.com/kb/2113956                                                              p\n";
    print "p ATS heartbeat is one function in VAAI Block Primitives                                       p\n"; 
    print "p Atomic Test & Set (ATS) In VMware vSphere VMFS, many operations must establish a lock        p\n";
    print "p  on the volume when updating a resource. Because VMFS is a clustered file system,            p\n";
    print "p  many ESXi hosts can share the volume. When one host must make an update to the              p\n";
    print "p  VMFS metadata, a locking mechanism is required to maintain file system integrity            p\n";
    print "p  and prevent another host from coming in and updating the same metadata.                     p\n";
    print "p  The following operations require this lock:                                                 p\n";
    print "p 1. Acquire on-disk locks                                                                     p\n";
    print "p 2. Upgrade an optimistic lock to an exclusive/physical lock                                  p\n";
    print "p 3. Unlock a read-only/multiwriter lock                                                       p\n";
    print "p 4. Acquire a heartbeat                                                                       p\n";
    print "p 5. Clear a heartbeat                                                                         p\n"; 
    print "p 6. Replay a heartbeat                                                                        p\n"; 
    print "p 7. Reclaim a heartbeat                                                                       p\n";
    print "p 8. Acquire on-disk lock with dead owner                                                      p\n";
    print "p ATS is an enhanced locking mechanism designed to replace the use of SCSI reservations on     p\n";
    print "p  VMFS volumes when doing metadata updates.                                                   p\n";
    print "p A SCSI reservation locks a whole LUN and prevents other hosts from doing metadata updates    p\n";
    print "p  of a VMFS volume when one host sharing the volume has a lock.                               p\n";
    print "p  This can lead to various contention issues when many virtual machines                       p\n";
    print "p  are using the same datastore.                                                               p\n";
    print "p ATS is a lock mechanism that must modify only a disk sector on the VMFS volume.              p\n";
    print "p  When successful, it enables an ESXi host to perform a metadata update on the volume.        p\n";
    print "p The introduction of ATS addresses the contention issues with SCSI reservations and           p\n";
    print "p  enables VMFS volumes to scale to much larger sizes                                          p\n";
    print "p Operations 4-7 could be used to maintain ATS HB.                                             p\n";
    print "p                                                                                              p\n";
    print "p The VMFS datastores are monitored through the heartbeats that are issued in the form of      p\n";
    print "p  write operations approximately once in every 3 seconds to the VMFS volumes from the         p\n";
    print "p  hosts. Each ESXi host accessing the VMFS datastores expects these heartbeat write I/O       p\n";
    print "p  operations to complete within a 8 second window. If the heartbeat I/O does not complete     p\n";
    print "p  within an 8 second window, the I/O is timed out and a subsequent heartbeat I/O              p\n";
    print "p  is issued. If the total time of the heartbeat I/O does not complete within a 16             p\n";
    print "p  second window, the datastore is marked offline and a Lost access to volume log message      p\n";
    print "p  is generated by hostd to reflect this behavior.                                             p\n";
    print "p After a VMFS datastore is marked in an offline state, ESXi issues heartbeat I/O to           p\n";
    print "p  the datastore approximately every 1 second until connectivity is restored.                  p\n";
    print "p  If a heartbeat I/O completes, the datastore is marked back online and host                  p\n";
    print "p  I/O is allowed to continue.                                                                 p\n";
    print "p Large Sequential IO high latency:                                                            p\n";
    print "p Make host volume distribute to multiple PowerStore volumes which may help improve            p\n";
    print "p  the flushing effeciency.                                                                    p\n";
    print "pppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppp\n\n";

    print "[node_a : node_a/command_output/dc-datapth-timestamp-logs/cache.txt]\n";
    if ($node_a_dp_cache_txt_exist) {
        open (FILE, $node_a_dp_cache_txt) or die "Cannot open $node_a_dp_cache_txt: $!\n";      
        my $hit = 0;
        while ( <FILE> ) {
            next unless ( m/Cache Throttling Stats/ or $hit == 1);
            last if (m/Cache Partition Stats/);
            $hit = 1;
            print $_;                                                                                                                                                                                                                            
        }
        close FILE;
    }    

    print "\n[node_b : node_b/command_output/dc-datapth-timestamp-logs/cache.txt]\n";
    if ($node_b_dp_cache_txt_exist) {
        open (FILE, $node_b_dp_cache_txt) or die "Cannot open $node_b_dp_cache_txt: $!\n";      
        my $hit = 0;
        while ( <FILE> ) {
            next unless ( m/Cache Throttling Stats/ or $hit == 1);
            last if (m/Cache Partition Stats/);
            $hit = 1;
            print $_;                                                                                                                                                                                                                            
        }
        close FILE;
    }
}
#######################################################################


#######################################################################
sub mdt_305668_perf_failure {
    print "\npppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppp\n";
    print "p Performance IB Interconnect RX Error Cause PM Panic or Performance Degradation mdt_305668_perf_failure p\n";
    print "p Both Warndo-EX and Riptide use the IB interfaces (ib0 and ib1) for interconnect between Nodes. p\n";
    print "p There should not be any RX or TX error over these IB interfaces in normal cases.             p\n";
    print "p However, we have so far 2 cases where RX error was observed on the IB interfaces and         p\n";
    print "p  caused different symptoms:                                                                  p\n";
    print "p In TEE-1357, it caused periodical PM Panic on Node B with an interval of several hours       p\n";
    print "p  to serval days and led to Node reboot from time to time.                                    p\n";
    print "p In TEE-1665, it caused performance degradation of volumes on one Node.                       p\n";
    print "p Both issues have been addressed by replacing the problematic Node.                           p\n";
    print "p https://confluence.cec.lab.emc.com/display/ETS/IB+Interconnect+RX+Error+Cause+PM+Panic+or+Performance+Degradation p\n";
    print "p If ib interface rxerr or txerr is not clean, it probably may cause the problem!              p\n";
    print "pppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppp\n\n";
    
    print "[node-a node_a/command_output/sar_-n_EDEV.txt]\n";

    if ($node_a_sar_n_EDEV_txt_exist) {
        open(my $file,  "<",  $node_a_sar_n_EDEV_txt)  or die "Can't open $node_a_sar_n_EDEV_txt: $!";
        while (<$file>) {
            print "$_" if ( m/Average:/ or m/rxerr/ );
        }
        close $file;
    } 

    print "\n[node-b node_b/command_output/sar_-n_EDEV.txt]\n";

    if ($node_b_sar_n_EDEV_txt_exist) {
        open(my $file,  "<",  $node_b_sar_n_EDEV_txt)  or die "Can't open $node_b_sar_n_EDEV_txt: $!";
        while (<$file>) {
            print "$_" if ( m/Average:/ or m/rxerr/ );
        }
        close $file;
    }

}
#######################################################################


my $kb184530_desc = '';
my $kb184530_cate = '';
my $kb184530_match = 'No';
#######################################################################
sub kb_184530_icw_failure {
    print "\niiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii\n";
    print "i ICW or Login Failure Issue kb_184530_icw_failure                                             i\n";
    print "i Impact: If going through the Initial Configuration Wizard (ICW) using the service port,      i\n";
    print "i  the user may see a message saying \"Loading....\" on the Cluster Details step which           i\n";
    print "i  continues for a time. Eventually the UI may display \"The required appliance was not         i\n";
    print "i  found or Request timed out.\"                                                                i\n"; 
    print "i This prevents the user from proceeding with the ICW and initializing the system.             i\n";
    print "i PowerStore Manager UI is not accessible (users cannot log in) after a Nondisruptive          i\n";
    print "i  Upgrade (NDU) or node reboot.                                                               i\n";
    print "i Attempting to log in fails with error: \"Service unavailable. Please retry in a few           i\n";
    print "i  minutes. (0xE04040010004)\"                                                                  i\n";
    print "i Workaround:                                                                                  i\n";
    print "i https://www.dell.com/support/kbdoc/en-us/000184530/                                          i\n";
    print "iiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii\n\n";

    print "[node_a journal]\n";
    foreach ( @node_a_kb_184530 ) {
        print $_."\n";
    }

    print "\n[node_b journal]\n";
    foreach ( @node_b_kb_184530 ) {
        print $_."\n";  
    }

    $kb184530_desc = 'ICW or Login Failure Issue kb_184530';
    $kb184530_cate = 'Journal';
    $kb184530_match = 'Yes' if ( $#node_a_kb_184530 >= 0 or $#node_b_kb_184530 >= 0 );        
}
#######################################################################


my $kb131062_desc = '';
my $kb131062_cate = '';
my $kb131062_match = 'No';
#######################################################################
sub kb_131062_icw_failure {
    print "\niiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii\n";
    print "i ICW Failure Issue kb_131062_icw_failure                                                      i\n";
    print "i Fix: Fixed in SN SP3                                                                         i\n";
    print "i Impact is Create Cluster Failure.                                                            i\n";
    print "i  ICW may fail if appliance uptime is over 10 days                                            i\n";
    print "i https://confluence.cec.lab.emc.com/display/ETS/ICW+may+fail+if+unconfigured                  i\n";
    print "i  +appliance+uptime+is+over+10+days                                                           i\n";
    print "i https://www.dell.com/support/kbdoc/en-my/000131062                                           i\n";
    print "iiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii\n\n";

    print "[node_a journal]\n";
    foreach ( @node_a_kb_131062 ) {
        print $_."\n";
    }

    print "\n[node_b journal]\n";
    foreach ( @node_b_kb_131062 ) {
        print $_."\n";  
    }

    $kb131062_desc = 'ICW Failure Issue kb_131062_icw_failure';
    $kb131062_cate = 'Journal';
    $kb131062_match = 'Yes' if ( $#node_a_kb_131062 >= 0 or $#node_b_kb_131062 >= 0 );       
}
#######################################################################


my $kb130232_desc = '';
my $kb130232_cate = '';
my $kb130232_match = 'No';
#######################################################################
sub kb_130232_ndu_failure {
    print "\nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn\n";
    print "n NDU NAS Failure ICM Not Reachable Issue kb_130232_ndu_failure :                              n\n";
    print "n Impact is NDU Failure.                                                                       n\n";
    print "n  In SN-GA up to SN-SP2 the ICM IPv6 communication between the nodes is running through the ToR. n\n";
    print "n  (SN-SP2 and above will have the ICM running on the nodes internal interlink)                n\n";
    print "n  https://confluence.cec.lab.emc.com/display/ETS/ICW+NAS+install+fail+due+to+missing          n\n";
    print "n   +native+vlan+on+ToR                                                                        n\n";
    print "n  https://www.dell.com/support/kbdoc/000130232                                                n\n";
    print "n From version 1.0.2.0.5.003                                                                   n\n";
    print "n REVISE ICM NETWORK BEHAVIOR (SN SP2):                                                        n\n";
    print "n --Support for FC-Only Appliance                                                              n\n";
    print "n --For single Unified NAS systems only, this feature redirects ICM communications from the    n\n"; 
    print "n  requirement to pass through the System bond Ports 0 & 1 and the Top-of-Rack switches,       n\n";
    print "n  between the Nodes, to pass through the backplane interconnect                               n\n";    
    print "nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn\n\n";

    print "[node_a journal]\n";
    foreach ( @node_a_kb_130232 ) {
        print $_."\n";
    }

    print "\n[node_b journal]\n";
    foreach ( @node_b_kb_130232 ) {
        print $_."\n";  
    }

    $kb130232_desc = 'NDU NAS Failure ICM Not Reachable Issue kb_130232_ndu_failure';
    $kb130232_cate = 'Journal';
    $kb130232_match = 'Yes' if ( $#node_a_kb_130232 >= 0 or $#node_b_kb_130232 >= 0 );       
}
#######################################################################


my $mdt168926_desc = '';
my $mdt168926_cate = '';
my $mdt168926_match = 'No';
#######################################################################
sub mdt_168926_icw_failure {
    print "\niiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii\n";
    print "i ICW 3 DNS Warning Issue mdt_168926_icw_failure                                               i\n"; 
    print "i Fix: Fixed in SN SP2                                                                         i\n";
    print "i Impact is ICW validation warning when entering 3 DNS servers.                                i\n"; 
    print "i https://confluence.cec.lab.emc.com/display/ETS/ICW+validation+warning+when+                  i\n";
    print "i  entering+3+DNS+servers                                                                      i\n";
    print "iiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii\n\n";

    print "[node_a journal]\n";
    foreach ( @node_a_mdt_168926 ) {
        print $_."\n";
    }

    print "\n[node_b journal]\n";
    foreach ( @node_b_mdt_168926 ) {
        print $_."\n";  
    }

    $mdt168926_desc = 'ICW 3 DNS Warning Issue mdt_168926_icw_failure';
    $mdt168926_cate = 'Journal';
    $mdt168926_match = 'Yes' if ( $#node_a_mdt_168926 >= 0 or $#node_b_mdt_168926 >= 0 );       
}
#######################################################################


my $tee2388_desc = '';
my $tee2388_cate = '';
my $tee2388_match = 'No';
#######################################################################
sub tee_2388_icw_failure {
    print "\niiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii\n";
    print "i ICW Failure Issue because of wrong IP tee_2388_icw_failure :                                 i\n";
    print "i Impact is creating cluster failure.                                                          i\n";
    print "i  Wrong IP Example                                                                            i\n";
    print "i  Netmask: 255.255.255.192                                                                    i\n";
    print "i  Gateway: 172.30.200.128                                                                     i\n";
    print "iiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii\n\n";

    print "[node_a journal]\n";
    foreach ( @node_a_tee_2388 ) {
        print $_."\n";
    }

    print "\n[node_b journal]\n";
    foreach ( @node_b_tee_2388 ) {
        print $_."\n";  
    }

    $tee2388_desc = 'ICW Failure Issue because of wrong IP tee_2388_icw_failure';
    $tee2388_cate = 'Journal';
    $tee2388_match = 'Yes' if ( $#node_a_tee_2388 >= 0 or $#node_b_tee_2388 >= 0 );       
}
#######################################################################


my $mdt304388_desc = '';
my $mdt304388_cate = '';
my $mdt304388_match = 'No';
#######################################################################
sub mdt_304388_gsip_remove_failure {
    print "\ncccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc\n";
    print "c Unable to remove GSIP after NDU Issue mdt_304388_gsip_remove_failure :                       c\n"; 
    print "c Fix: Affected FHC, Fixed in Re-spin                                                          c\n";
    print "c Impact:                                                                                      c\n";
    print "c NDU Succeeds, however customer will not be able to map new storage interface and remove      c\n";
    print "c  or reconfigure global storage IP (GSIP) if the customer has GSIP configured                 c\n";
    print "c  in SN prior to NDU.                                                                         c\n";  
    print "c https://confluence.cec.lab.emc.com/display/ETS/Inability+to+remove+GSIP+and+scale+network+after+NDU+from+SN+to+FHC c\n";
    print "c https://confluence.cec.lab.emc.com/display/CYCLONE/Inability+to+remove+GSIP+and+scale+network+after+NDU+from+SN+to+FHC c\n";
    print "cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc\n\n";

    print "[node_a journal]\n";
    foreach ( @node_a_mdt_304388 ) {
        print $_."\n";
    }

    print "\n[node_b journal]\n";
    foreach ( @node_b_mdt_304388 ) {
        print $_."\n";  
    } 

    $mdt304388_desc = 'Unable to remove GSIP after NDU Issue mdt_304388_gsip_remove_failure';
    $mdt304388_cate = 'Journal';
    $mdt304388_match = 'Yes' if ( $#node_a_mdt_304388 >= 0 or $#node_b_mdt_304388 >= 0 );      
}
#######################################################################


my $mdt237350_desc = '';
my $mdt237350_cate = '';
my $mdt237350_match = 'No';
#######################################################################
sub mdt_237350_management_db_failure {
    print "\nssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssss\n";
    print "Service eVE docker Issue mdt_237350_management_db_failure: Fixed in SN-SP4                     s\n";
    print " Impact is the management database, CP and Pacemaker services will be stopped.                 s\n";
    print "  Due to Insufficient Space under /cyc_hacs.                                                   s\n";
    print " https://confluence.cec.lab.emc.com/display/ETS/Managementdb+stopped+in+SN+SP3+due+to+no+space s\n";
    print "  +left+on+device+cyc_hacs                                                                     s\n";
    print " Please check /cyc_hacs space usage from mdt_243089_242417_service_failure !                   s\n";
    print "Workaround:                                                                                    s\n";
    print " Once the symptom is observed, escalate to the CP RnD team via MDT ticket to apply the manual  s\n"; 
    print "  workaround remotely to reduce the size of problematic tables.                                s\n";
    print "ssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssss\n\n";

    print "[node_a journal]\n";
    foreach ( @node_a_mdt_237350 ) {
        print $_."\n";
    }

    print "\n[node_b journal]\n";
    foreach ( @node_b_mdt_237350 ) {
        print $_."\n";  
    }

    $mdt237350_desc = 'Service eVE docker Issue mdt_237350_management_db_failure';
    $mdt237350_cate = 'Journal';
    $mdt237350_match = 'Yes' if ( $#node_a_mdt_237350 >= 0 or $#node_b_mdt_237350 >= 0 );      
}
#######################################################################


#######################################################################
sub trif_822_perf_failure {
    print "\npppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppp\n";
    print "p Performance Unmap trif_822_perf_failure :                                                    p\n";
    print "p Unmap operations:                                                                            p\n";
    print "p https://jira.cec.lab.emc.com/browse/TRIF-822                                                 p\n";
    print "pppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppp\n\n";

    print "[node_a : node_a/command_output/dc-datapth-timestamp-logs/app.txt]\n";
    if ($node_a_dp_app_txt_exist) {
        open (FILE, $node_a_dp_app_txt) or die "Cannot open $node_a_dp_app_txt: $!\n";      
        while ( <FILE> ) {
            print $_ if ( m/unmap/ );                                                                                                                                                                                                                            
        }
        close FILE;
    }    

    print "\n[node_b : node_b/command_output/dc-datapth-timestamp-logs/app.txt]\n";
    if ($node_b_dp_app_txt_exist) {
        open (FILE, $node_b_dp_app_txt) or die "Cannot open $node_b_dp_app_txt: $!\n";      
        while ( <FILE> ) {
            print $_ if ( m/unmap/ );                                                                                                                                                                                                                            
        }
        close FILE;
    }
}
#######################################################################


#######################################################################
sub tee_1882_perf_failure {
    print "\npppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppp\n";
    print "p Performance Unmap tee_1882_perf_failure :                                                    p\n";
    print "p Unmap operations:                                                                            p\n";
    print "p The system is throttling unmap operations which cause io latency high                        p\n";
    print "p UnmapQosTokenRejects:               468997 (high number indicates unmap throttling)          p\n";
    print "pppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppp\n\n";

    print "[node_a : node_a/command_output/dc-datapth-timestamp-logs/mapper.txt]\n";
    if ($node_a_dp_mapper_txt_exist) {
        open (FILE, $node_a_dp_mapper_txt) or die "Cannot open $node_a_dp_mapper_txt: $!\n";      
        while ( <FILE> ) {
            print $_ if ( m/unmap/ or m/Unmap/ );                                                                                                                                                                                                                            
        }
        close FILE;
    }    

    print "\n[node_b : node_b/command_output/dc-datapth-timestamp-logs/mapper.txt]\n";
    if ($node_b_dp_mapper_txt_exist) {
        open (FILE, $node_b_dp_mapper_txt) or die "Cannot open $node_b_dp_mapper_txt: $!\n";      
        while ( <FILE> ) {
            print $_ if ( m/unmap/ or m/Unmap/ );                                                                                                                                                                                                                            
        }
        close FILE;
    }
}
#######################################################################


my $mdt227944_desc = '';
my $mdt227944_cate = '';
my $mdt227944_match = 'No';
#######################################################################
sub mdt_227944_loss_cluster_management_failure {
    print "\nssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssss\n";
    print "s Service Loss of cluster management (UI/REST) in multi appliance after shutdown and           s\n";
    print "s  startup mdt_227944_loss_cluster_management_failure:                                         s\n";
    print "s Impact is loss of cluster management (UI/REST) in multi appliance after shutdown and startup.s\n";
    print "s  Cluster mgmt of multi appliance failed to come up after shutdown.                           s\n";
    print "s   One appliance failed , no quorum.                                                          s\n";
    print "s  The pacemaker was not coming up because of the missing key file /cyc_hacs/master_slave_keyfile s\n";
    print "s  https://confluence.cec.lab.emc.com/pages/viewpage.action?pageId=379268381                   s\n";
    print "s Workaround only for EE:                                                                      s\n";
    print "s  executing the below from the BSC of the OFFLINE appliance:                                  s\n";
    print "s  sudo /cyc_bsc/scripts/dba/db_maintenance_mode.sh allclear                                   s\n";
    print "ssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssss\n\n";

    print "[node_a journal]\n";
    foreach ( @node_a_mdt_227944 ) {
        print $_."\n";
    }

    print "\n[node_b journal]\n";
    foreach ( @node_b_mdt_227944 ) {
        print $_."\n";  
    }

    $mdt227944_desc = 'Service Loss of cluster management (UI/REST) in multi appliance';
    $mdt227944_cate = 'Journal';
    $mdt227944_match = 'Yes' if ( $#node_a_mdt_227944 >= 0 or $#node_b_mdt_227944 >= 0 );        
}
#######################################################################


my $kb126293_desc = '';
my $kb126293_cate = '';
my $kb126293_match = 'No';
#######################################################################
sub kb_126293_metrics_inaccessible_failure {
    print "\nssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssss\n";
    print "s Service Metrics data can become inaccessible after Data Path transitions back to an online   s\n";
    print "s  state kb_126293_metrics_inaccessible_failure:                                               s\n";
    print "s Impact is Metrics data can become inaccessible after Data Path transitions back to           s\n";
    print "s  an online state.                                                                            s\n";
    print "s  https://confluence.cec.lab.emc.com/display/ETS/Metrics+data+can+become+inaccessible+        s\n";
    print "s   after+Data+Path+transitions+back+to+an+online+state                                        s\n";
    print "s Workaround:                                                                                  s\n";
    print "s  It is possible that restarting the primary node of the primary appliance will               s\n";
    print "s   resolve this condition (see details below).                                                s\n";
    print "s  If metrics data still cannot be accessed, this issue will need to be escalated to           s\n";
    print "s   development to try to repair the Metrics DB table.                                         s\n";
    print "ssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssss\n\n";

    print "[node_a journal]\n";
    foreach ( @node_a_kb_126293 ) {
        print $_."\n";
    }

    print "\n[node_b journal]\n";
    foreach ( @node_b_kb_126293 ) {
        print $_."\n";  
    }   

    $kb126293_desc = 'Service Metrics data can become inaccessible after Data Path transitions back to an online';
    $kb126293_cate = 'Journal';
    $kb126293_match = 'Yes' if ( $#node_a_kb_126293 >= 0 or $#node_b_kb_126293 >= 0 );     
}
#######################################################################


my $mdt291470_desc = '';
my $mdt291470_cate = '';
my $mdt291470_match = 'No';
#######################################################################
sub mdt_291470_iscsi_illegal_failure {
    print "\ncccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc\n";
    print "  iSCSI devcie in illegal status mdt_291470_iscsi_illegal_failure: vCenter 7.0.1 and above     c\n";
    print "  Impact is Unable to set MTU to 9000 after FHC ICW: There are iSCSI devices                   c\n";
    print "   in illegal state on Host xxx.                                                               c\n";
    print "   https://confluence.cec.lab.emc.com/display/ETS/MTU+settings+cannot+be+changed%3A+There+are+iSCSI+devices+in+illegal+state+on+Host+xxx c\n";
    print "   vSphere Cluster Services (vCLS) is a new feature in vSphere 7.0 Update 1, which is          c\n";
    print "    mandatory to be deployed on each vSphere cluster. ESXi host can be of any older version    c\n";
    print "    that is compatible with vCenter server 7.0 Update 1.                                       c\n";
    print "   If customer using vCenter with 7.0.1 or above, vCLS VMs are deployed after ICW.             c\n";
    print "   They are consuming PowerStoreX storage resources. Because reconfiguring storage network     c\n";
    print "   (including MTU changing) requires to unmount datastores, all User VMs consuming             c\n";
    print "   storage from storage containers or VMFS datastores have to be powered off.                  c\n";
    print "  Workaround:                                                                                  c\n";
    print "   Disable vCLS and re-try. After MTU change, enable vCLS again.                               c\n";
    print "   Unlike workload/application VMs, vCLS VMs should be treated like system VMs.                c\n"; 
    print "   Please follow VMWare KB article: https://kb.vmware.com/s/article/80472 to disable vCLS.     c\n";
    print "  https://www.dell.com/support/kbdoc/en-us/193406                                              c\n";
    print "cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc\n\n";

    print "[node_a journal]\n";
    my $count = 0;
    foreach ( @node_a_mdt_291470 ) {
        print $_."\n";
        $count++;
        last if ($count >= 10);
    }
    print "total: $#node_a_mdt_291470\n" if ($#node_a_mdt_291470 >= 0);

    $count = 0;
    print "\n[node_b journal]\n";
    foreach ( @node_b_mdt_291470 ) {
        print $_."\n";
        $count++;
        last if ($count >= 10);
    }
    print "total: $#node_b_mdt_291470\n" if ($#node_b_mdt_291470 >= 0);  

    $mdt291470_desc = 'iSCSI devcie in illegal status mdt_291470_iscsi_illegal_failure';
    $mdt291470_cate = 'Journal';
    $mdt291470_match = 'Yes' if ( $#node_a_mdt_291470 >= 0 or $#node_b_mdt_291470 >= 0 );      
}
#######################################################################


my $tee1414_desc = '';
my $tee1414_cate = '';
my $tee1414_match = 'No';
#######################################################################
sub tee_1414_ndu_failure {
    print "\nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn\n";
    print "n NDU NAS installation failure tee_1414_ndu_failure: Fixed in FHC                              n\n";
    print "n Impact is NDU failure.                                                                       n\n";
    print "n  NDU failed because ansible container didnt start on the primary node after the              n\n";
    print "n   failover of the HA stack.                                                                  n\n";
    print "n  This is due to the removal of sync point files in /cyc_tmp/cyc_sync by an unknown actor     n\n";
    print "n   triggered a corner case thought to be specific to the cyc_ansible_service that caused      n\n";
    print "n   it to wait for an event specific to reinit during NDU.                                     n\n";
    print "n  https://confluence.cec.lab.emc.com/pages/viewpage.action?pageId=459419848                   n\n";
    print "n Workaround:                                                                                  n\n";
    print "n  Engage EE/SDNAS EE                                                                          n\n";
    print "nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn\n\n";

    print "[node_a journal]\n";
    foreach ( @node_a_tee_1414 ) {
        print $_."\n";
    }

    print "\n[node_b journal]\n";
    foreach ( @node_b_tee_1414 ) {
        print $_."\n";  
    }

    $tee1414_desc = 'NDU NAS installation failure tee_1414_ndu_failure';
    $tee1414_cate = 'Journal';
    $tee1414_match = 'Yes' if ( $#node_a_tee_1414 >= 0 or $#node_b_tee_1414 >= 0 );        
}
#######################################################################


my $mdt180273_desc = '';
my $mdt180273_cate = '';
my $mdt180273_match = 'No';
#######################################################################
sub mdt_180273_ndu_failure {
    print "\nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn\n";
    print "n NDU NAS installation failure mdt_180273_ndu_failure: Fixed in FHC                            n\n";
    print "n  Impact is CP issue related to stale locks break NASNDU flow.                                n\n";
    print "n  https://confluence.cec.lab.emc.com/pages/viewpage.action?pageId=318107745                   n\n";
    print "n Workaround:                                                                                  n\n";
    print "n  Remove stale locks                                                                          n\n";
    print "n  https://www.dell.com/support/kbdoc/en-us/126773                                             n\n";
    print "nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn\n\n";

    print "[node_a journal]\n";
    my $count = 0;
    foreach ( @node_a_mdt_180273 ) {
        print $_."\n";
        $count++;
        last if ( $count >= 10 );
    }

    print "\n[node_b journal]\n";
    $count = 0;
    foreach ( @node_b_mdt_180273 ) {
        print $_."\n";  
        $count++;
        last if ( $count >= 10 );        
    }

    $mdt180273_desc = 'NDU NAS installation failure mdt_180273_ndu_failure';
    $mdt180273_cate = 'Journal';
    $mdt180273_match = 'Yes' if ( $#node_a_mdt_180273 >= 0 or $#node_b_mdt_180273 >= 0 );       
}
#######################################################################


my $mdt334812_desc = '';
my $mdt334812_cate = '';
my $mdt334812_match = 'No';
#######################################################################
sub mdt_334812_ndu_failure {
    print "\nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn\n";
    print "n NDU NAS installation failure tee_2064_ndu_failure: Affected all FHC                          n\n";
    print "n Impact is NDU failed, manual intervention may be needed to roll back SDNAS NDU..             n\n";
    print "n  PUHC failed the network check, then someone manually cleared the critical alert             n\n";
    print "n   The following intra-cluster data network addresses are not reachable via ICMP              n\n";
    print "n   from node network interfaces by using svc_alert.                                           n\n";
    print "n  Now, PUHC didnt report ICD network error anymore because FHC release                        n\n";
    print "n   re-uses the ONV result for network check.                                                  n\n";
    print "n  https://confluence.cec.lab.emc.com/display/ETS/NDU+failed+during+stage%3A                   n\n";
    print "n   +SYM_NDU_WAIT_FOR_CP_TO_PREPARE_SDNAS+due+to+network+issue                                 n\n";
    print "n Workaround:                                                                                  n\n";
    print "n  Fix the network issue before NDU.                                                           n\n";
    print "n  In case the SDNAS NDU failure already happened and rollback also failed, we need to         n\n";
    print "n   engage XF to roll back the SDNAS NDU manually (before or after the network issue is fixed) n\n";
    print "n From version 1.0.2.0.5.003                                                                   n\n";
    print "n REVISE ICM NETWORK BEHAVIOR (SN SP2):                                                        n\n";
    print "n --Support for FC-Only Appliance                                                              n\n";
    print "n --For single Unified NAS systems only, this feature redirects ICM communications from the    n\n"; 
    print "n  requirement to pass through the System bond Ports 0 & 1 and the Top-of-Rack switches,       n\n";
    print "n  between the Nodes, to pass through the backplane interconnect                               n\n";    
    print "nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn\n\n";

    print "[node_a journal]\n";
    foreach ( @node_a_mdt_334812 ) {
        print $_."\n";
    }

    print "\n[node_b journal]\n";
    foreach ( @node_b_mdt_334812 ) {
        print $_."\n";  
    }

    $mdt334812_desc = 'NDU NAS installation failure tee_2064_ndu_failure';
    $mdt334812_cate = 'Journal';
    $mdt334812_match = 'Yes' if ( $#node_a_mdt_334812 >= 0 or $#node_b_mdt_334812 >= 0 );       
}
#######################################################################


my $tee1898_desc = '';
my $tee1898_cate = '';
my $tee1898_match = 'No';
#######################################################################
sub tee_1898_perf_failure {
    print "\npppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppp\n";
    print "p Performance monitor is empty in PowerStore Manager tee_1898_perf_failure: Affected all FHC   p\n";
    print "p Impact is performance monitor is empty in GUI.                                               p\n";
    print "p  The specific metric value has a very large number which exceed the managementdb can         p\n";
    print "p   handle (for integer) and reported DataError in XMS.                                        p\n";
    print "p  It caused the subsequence performance metrics failed to writing to the managementdb.        p\n";
    print "p  TEE-1898                                                                                    p\n";
    print "p Workaround:                                                                                  p\n";
    print "p  Reboot node to clear the unexpected metric value                                            p.\n";
    print "pppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppp\n\n";

    print "[node_a journal]\n";
    foreach ( @node_a_tee_1898 ) {
        print $_."\n";
    }

    print "\n[node_b journal]\n";
    foreach ( @node_b_tee_1898 ) {
        print $_."\n";  
    } 

    $tee1898_desc = 'Performance monitor is empty in PowerStore Manager tee_1898';
    $tee1898_cate = 'Journal';
    $tee1898_match = 'Yes' if ( $#node_a_tee_1898 >= 0 or $#node_b_tee_1898 >= 0 );       
}
#######################################################################


my $tee2161_desc = '';
my $tee2161_cate = '';
my $tee2161_match = 'No';
#######################################################################
sub tee_2161_perf_failure {
    print "\npppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppp\n";
    print "p Performance monitor is empty in PowerStore Manager tee_2161_perf_failure: Affected all FHC   p\n";
    print "p Impact is performance monitor is empty in GUI.                                               p\n";
    print "p Issue is related to NTP probably.                                                            p\n";
    print "p TEE-2161                                                                                     p\n";
    print "p Workaround:                                                                                  p\n";
    print "p  restart CP                                                                                  p\n";
    print "p  or                                                                                          p\n";
    print "p  restart node                                                                                p\n";
    print "pppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppp\n\n";

    print "[node_a journal]\n";
    my $count = 0;
    foreach ( @node_a_tee_2161 ) {
        print $_."\n";
        $count++;
        last if ($count >= 10);
    }
    print "total: $#node_a_tee_2161\n" if ($#node_a_tee_2161 >= 0);

    print "\n[node_b journal]\n";
    $count = 0;
    foreach ( @node_b_tee_2161 ) {
        print $_."\n";
        $count++;
        last if ($count >= 10);
    }
    print "total: $#node_b_tee_2161\n" if ($#node_b_tee_2161 >= 0); 

    $tee2161_desc = 'Performance monitor is empty in PowerStore Manager tee_2161';
    $tee2161_cate = 'Journal';
    $tee2161_match = 'Yes' if ( $#node_a_tee_2161 >= 0 or $#node_b_tee_2161 >= 0 );      
}
#######################################################################


my $tee2249_desc = '';
my $tee2249_cate = '';
my $tee2249_match = 'No';
#######################################################################
sub tee_2249_ndu_failure {
    print "\nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn\n";
    print "n NDU failure tee_2249_ndu_failure:                                                            n\n";
    print "n Impact is NDU failure and rollback.                                                          n\n";
    print "n  Due to xxx(TBD), SSD is still marked as failed_in_rg even after rebuild for the             n\n";
    print "n   SSD has finished.                                                                          n\n";
    print "n  PUHC didnt report any issue, but it will be detected during                                 n\n"; 
    print "n   SYM_NDU_VERIFY_NDU_CAN_RUN stage. NDU will fail and rollback.                              n\n";
    print "n  TEE-2249, TEE-2250                                                                          n\n";
    print "n  https://www.dell.com/support/kbdoc/en-us/000192244/                                         n\n";
    print "nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn\n\n";

    print "[node_a journal]\n";
    foreach ( @node_a_tee_2249 ) {
        print $_."\n";
    }

    print "\n[node_b journal]\n";
    foreach ( @node_b_tee_2249 ) {
        print $_."\n";
    }

    $tee2249_desc = 'NDU failure tee_2249_ndu_failure';
    $tee2249_cate = 'Journal';
    $tee2249_match = 'Yes' if ( $#node_a_tee_2249 >= 0 or $#node_b_tee_2249 >= 0 );    
}
#######################################################################


my $tee1854_desc = '';
my $tee1854_cate = '';
my $tee1854_match = 'No';
#######################################################################
sub tee_1854_ndu_failure {
    print "\nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn\n";
    print "n NDU failure tee_1854_ndu_failure: Affected FHC                                               n\n";
    print "n Impact is Short DU, manual intervention is needed to finish NDU                              n\n";
    print "n NDU failed during stage NEW_SYM_NDU_TWO_NODES_CODE_COMMIT SYM due to unexpected sym          n\n";
    print "n  restart caused by ICM/MGMT interface down                                                   n\n";
    print "n https://confluence.cec.lab.emc.com/pages/viewpage.action?pageId=590421208                    n\n";
    print "nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn\n\n";

    print "[node_a journal]\n";
    foreach ( @node_a_tee_1854 ) {
        print $_."\n";
    }

    print "\n[node_b journal]\n";
    foreach ( @node_b_tee_1854 ) {
        print $_."\n";
    }

    $tee1854_desc = 'NDU failure tee_1854_ndu_failure: Affected FHC';
    $tee1854_cate = 'Journal';
    $tee1854_match = 'Yes' if ( $#node_a_tee_1854 >= 0 or $#node_b_tee_1854 >= 0 );     
}
#######################################################################


my $tee1021_desc = '';
my $tee1021_cate = '';
my $tee1021_match = 'No';
#######################################################################
sub tee_1021_ndu_failure {
    print "\nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn\n";
    print "n NDU failure tee_1021_ndu_failure:                                                            n\n";
    print "n Impact is NDU failure and rollback.                                                          n\n";
    print "n  Firmware upgrade stage of NDU may fail if PSU sensor cannot be read (stuck)                 n\n";
    print "n  Please check hardware status from sub array_sdr_hardware in report.                         n\n";
    print "n  Please check hardware status from sub array_reboot_info in report.                          n\n";  
    print "n  MDT-305037 (TEE-1633), MDT-306389 (TEE-1689), MDT-252811 (TEE-1021), MDT-304965 (TEE-1647)  n\n";
    print "nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn\n\n";

    print "[node_a journal]\n";
    foreach ( @node_a_tee_1021 ) {
        print $_."\n";
    }

    print "\n[node_b journal]\n";
    foreach ( @node_b_tee_1021 ) {
        print $_."\n";
    }

    $tee1021_desc = 'NDU failure tee_1021_ndu_failure';
    $tee1021_cate = 'Journal';
    $tee1021_match = 'Yes' if ( $#node_a_tee_1021 >= 0 or $#node_b_tee_1021 >= 0 );    
}
#######################################################################


my $kb189524_desc = '';
my $kb189524_cate = '';
my $kb189524_match = 'No';
#######################################################################
sub kb_189524_aix_access_failure {
    print "\ncccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc\n";
    print "c AIX lost access during NDU kb_189524_aix_access_failure: Fixed in FHC                        c\n";
    print "c Impact is AIX DU or NDU failure.                                                             c\n";
    print "c  DU or NDU failure due to node reboot where AIX host send LUN_RESET and logout to            c\n";
    print "c   the upgraded node.                                                                         c\n"; 
    print "c  MDT-306989                                                                                  c\n";
    print "c  https://confluence.cec.lab.emc.com/display/ETS/NDU+SN--%3E+FHC+failure+or+DU+due+to+node+reboot+and+impact+on+AIX+host c\n";
    print "c  https://www.dell.com/support/kbdoc/en-us/189524                                             c\n";
    print "cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc\n\n";

    print "[node_a journal]\n";
    foreach ( @node_a_kb_189524 ) {
        print $_."\n";
    }

    print "\n[node_b journal]\n";
    foreach ( @node_b_kb_189524 ) {
        print $_."\n";
    }

    $kb189524_desc = 'AIX lost access during NDU kb_189524_aix_access_failure';
    $kb189524_cate = 'Journal';
    $kb189524_match = 'Yes' if ( $#node_a_kb_189524 >= 0 or $#node_b_kb_189524 >= 0 );    
}
#######################################################################


my $tee2462_desc = '';
my $tee2462_cate = '';
my $tee2462_match = 'No';
#######################################################################
sub tee_2462_aix_boot_failure {
    print "\ncccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc\n";
    print "c AIX not able to boot from PST tee-2462                                                       c\n";
    print "c Impact:                                                                                      c\n";
    print "c  When AIX rebooted one LPAR as a test it did not come back up, per IBM this is because       c\n"; 
    print "c  the IBM logs for the LPAR show WRITE AND VERIFY(16) failed.                                 c\n";
    print "c  CLEAR ACA flag is valid only during error recovery of a check condition or                  c\n";
    print "c  command terminated at a command tag queuing.                                                c\n";
    print "cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc\n\n";

    print "[node_a journal]\n";
    my $count = 0;
    foreach ( @node_a_tee_2462 ) {
        print $_."\n";
        $count++;
        last if ( $count >= 20 );
    }

    print "\n[node_b journal]\n";
    $count = 0;
    foreach ( @node_b_tee_2462 ) {
        print $_."\n";
        $count++;
        last if ( $count >= 20 );        
    }

    $tee2462_desc = 'AIX not able to boot from PST tee-2462';
    $tee2462_cate = 'Journal';
    $tee2462_match = 'Yes' if ( $#node_a_tee_2462 >= 0 or $#node_b_tee_2462 >= 0 );    
}
#######################################################################


#######################################################################
sub kb_replica_header {
    print "\n######################################################################################################################\n";
    print "# Replication releated errors in journal                                                                             #\n";
    print "#                                                                                                                    #\n";
    print "######################################################################################################################\n\n";   
}
#######################################################################


my $kb187268_desc = '';
my $kb187268_cate = '';
my $kb187268_match = 'No';
#######################################################################
sub kb_187268_replica_failure {
    print "\nbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb\n";
    print " Async Replication Sessions are out of sync, System_Paused, not progressing, or impacting node stability b\n";      
    print " MTU must have a consistent configuration across the entire user's network.                    b\n";
    print " Creating an inconsistent MTU network breaks replication relation and impacts PowerStore       b\n"; 
    print "  stability as nodes eventually reboot as a result of this misconfiguration.                   b\n";
    print "bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb\n\n";

    print "[node_a journal]\n";
    my $count = 0;
    foreach ( @node_a_kb_187268 ) {
        $_ =~ s/^\s+//;
        print $_."\n";
        $count++;
        last if ( $count >= 5 );
    }

    print "\n[node_b journal]\n";
    $count = 0;
    foreach ( @node_b_kb_187268 ) {
        $_ =~ s/^\s+//;
        print $_."\n";
        $count++;
        last if ( $count >= 5 );        
    }

    $kb187268_desc = 'Async Replication Sessions are out of sync, System_Paused, not progressing, or impacting node stability';
    $kb187268_cate = 'Journal';
    $kb187268_match = 'Yes' if ( $#node_a_kb_187268 >= 0 or $#node_b_kb_187268 >= 0 );     
}
#######################################################################


#######################################################################
sub kb_reservation_conflict {
    print "\npppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppp\n";
    print "p SCSI reservation conflict statistic                                                          p\n";
    print "p https://www.dell.com/support/kbdoc/en-us/000191117                                           p\n";
    print "pppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppp\n\n";

    my %hostid_initiator;
    my %hostid_inittype;
    my %hostid_name;
    my %hostid_os;

    my $port_name = '';
    my $port_type = '';
    my $port_hostid = '';
    my $hostname = '';
    my $hostos = '';
    my $hostid = '';
    
    if ($node_a_config_item_json_exist) {            
        open (FILE, $node_a_config_item_json) or die "Cannot open $node_a_config_item_json: $!\n";      
        my $hit = 0;
        while ( <FILE> ) {  
            $_ =~ s/^\s+|\s+$//g;
            $hit = 1 if ( m/\"data\": \{/ );
            
            if ( $hit == 1 && m/\"host_id\":/ ) {
                $port_hostid = $_;
                my @tmp = split( /:\s+/, $port_hostid );
                $port_hostid = $tmp[1];
                chop $port_hostid;               
            }

            if ( $hit == 1 && m/\"port_name\":/ ) {
                $port_name = $_;
                my @tmp = split( /:\s+/, $port_name );
                $port_name = $tmp[1];
                chop $port_name;               
            }

            if ( $hit == 1 && m/\"port_type\":/ ) {
                $port_type = $_;
                my @tmp = split( /:\s+/, $port_type );
                $port_type = $tmp[1];
                chop $port_type;               
            }

            if ( $hit == 1 && m/\"name\":/ ) {
                $hostname = $_;
                my @tmp = split( /:\s+/, $hostname );
                $hostname = $tmp[1];
                chop $hostname;               
            }

            if ( $hit == 1 && m/\"os\":/ ) {
                $hostos = $_;
                my @tmp = split( /:\s+/, $hostos );
                $hostos = $tmp[1];
                chop $hostos;               
            }

            if ( $hit == 1 && m/\"id\":/ ) {
                $hostid = $_;
                my @tmp = split( /:\s+/, $hostid );
                $hostid = $tmp[1];
                chop $hostid;               
            }

            if ( $hit == 1 && m/\"type\": \"INITIATOR\"/ ) {
                $hit = 0;
                if ( defined $hostid_initiator{$port_hostid} ) {
                    $hostid_initiator{$port_hostid} = $hostid_initiator{$port_hostid}."   ".$port_name;
                }else{
                    $hostid_initiator{$port_hostid} = $port_name;
                }

                if ( defined $hostid_inittype{$port_hostid} ) {
                    $hostid_inittype{$port_hostid} = $hostid_inittype{$port_hostid}."   ".$port_type;
                }else{
                    $hostid_inittype{$port_hostid} = $port_type;
                }
                
                $port_name = '';
                $port_type = '';
                $port_hostid = '';
            }     

            if ( $hit == 1 && m/\"type\": \"HOST\"/ ) {
                $hit = 0;
                $hostid_name{$hostid} = $hostname;
                $hostid_os{$hostid} = $hostos;
                $hostname = '';
                $hostos = '';
                $hostid = '';
            }
                                                                                       
        }
    } elsif ($node_b_config_item_json_exist) {
        open (FILE, $node_b_config_item_json) or die "Cannot open $node_b_config_item_json: $!\n";      
        my $hit = 0;
        while ( <FILE> ) {  
            $_ =~ s/^\s+|\s+$//g;
            $hit = 1 if ( m/\"data\": \{/ );
            
            if ( $hit == 1 && m/\"host_id\":/ ) {
                $port_hostid = $_;
                my @tmp = split( /:\s+/, $port_hostid );
                $port_hostid = $tmp[1];
                chop $port_hostid;               
            }

            if ( $hit == 1 && m/\"port_name\":/ ) {
                $port_name = $_;
                my @tmp = split( /:\s+/, $port_name );
                $port_name = $tmp[1];
                chop $port_name;               
            }

            if ( $hit == 1 && m/\"port_type\":/ ) {
                $port_type = $_;
                my @tmp = split( /:\s+/, $port_type );
                $port_type = $tmp[1];
                chop $port_type;               
            }

            if ( $hit == 1 && m/\"name\":/ ) {
                $hostname = $_;
                my @tmp = split( /:\s+/, $hostname );
                $hostname = $tmp[1];
                chop $hostname;               
            }

            if ( $hit == 1 && m/\"os\":/ ) {
                $hostos = $_;
                my @tmp = split( /:\s+/, $hostos );
                $hostos = $tmp[1];
                chop $hostos;               
            }

            if ( $hit == 1 && m/\"id\":/ ) {
                $hostid = $_;
                my @tmp = split( /:\s+/, $hostid );
                $hostid = $tmp[1];
                chop $hostid;               
            }

            if ( $hit == 1 && m/\"type\": \"INITIATOR\"/ ) {
                $hit = 0;
                if ( defined $hostid_initiator{$port_hostid} ) {
                    $hostid_initiator{$port_hostid} = $hostid_initiator{$port_hostid}."   ".$port_name;
                }else{
                    $hostid_initiator{$port_hostid} = $port_name;
                }

                if ( defined $hostid_inittype{$port_hostid} ) {
                    $hostid_inittype{$port_hostid} = $hostid_inittype{$port_hostid}."   ".$port_type;
                }else{
                    $hostid_inittype{$port_hostid} = $port_type;
                }
                
                $port_name = '';
                $port_type = '';
                $port_hostid = '';
            }    

            if ( $hit == 1 && m/\"type\": \"HOST\"/ ) {
                $hit = 0;
                $hostid_name{$hostid} = $hostname;
                $hostid_os{$hostid} = $hostos;
                $hostname = '';
                $hostos = '';
                $hostid = '';
            }
        }
    }

    foreach my $hostid ( keys %hostid_initiator ) {
        $initiatorlist = $hostid_initiator{$hostid};
        my @initiators = split(/   /, $initiatorlist );
        foreach my $initiator ( @initiators ) {
            $initiator =~ s/^.//;
            chop $initiator;
            my $count = 0;
            foreach ( @node_a_reservation_conflict ) {
                if ( m/$initiator/ ) {
                    if ($count == 0) {
                        print "[Host Name: ".$hostid_name{$hostid}."   Initiator:".$initiator."   Reservation Conflicts on Node-A]\n"; 
                    }
                    $count++;
                    print $_ if ( $count <= 20 );
                }
            }
            print "Total reservation conflicts: $count\n\n" if ($count > 0);

            $count = 0;
            foreach ( @node_b_reservation_conflict ) {
                if ( m/$initiator/ ) {
                    if ($count == 0) {
                        print "[Host Name: ".$hostid_name{$hostid}."   Initiator:".$initiator."   Reservation Conflicts on Node-B]\n"; 
                    }
                    $count++;
                    print $_ if ( $count <= 20 );
                }
            }
            print "Total reservation conflicts: $count\n\n" if ($count > 0);
        }
    }
}
#######################################################################


#######################################################################
sub kb_vol_reservation_status {
    print "\npppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppp\n";
    print "p SCSI reservation status for volume                                                           p\n";
    print "p https://www.dell.com/support/kbdoc/en-us/000191117                                           p\n";
    print "pppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppp\n\n";

    if ($node_a_housemd_show_scsi_reservations_txt_exist) {
        open(my $file,  "<",  $node_a_housemd_show_scsi_reservations_txt)  or die "Can't open $node_a_housemd_show_scsi_reservations_txt: $!";
        while (<$file>) {
            print "$_";
        }
        close $file;
    }

    if ($node_b_housemd_show_scsi_reservations_txt_exist) {
        open(my $file,  "<",  $node_b_housemd_show_scsi_reservations_txt)  or die "Can't open $node_b_housemd_show_scsi_reservations_txt: $!";
        while (<$file>) {
            print "$_";
        }
        close $file;
    }

}
#######################################################################


#######################################################################
sub kb_st_io_counters {
    print "\npppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppp\n";
    print "p st_io_counters if completed io counter is increasing, it indicates node is handling external workload. p\n";
    print "pppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppp\n\n";

    print "[node_a journal]\n";
    my $count = 0;
    foreach ( sort { timeSort($b) cmp timeSort($a) } @node_a_kb_st_io_counters ) {
        print $_."\n" if ( $count <= 5 );
        $count++;
    }

    print "\n[node_b journal]\n";
    $count = 0;
    foreach ( sort { timeSort($b) cmp timeSort($a) } @node_b_kb_st_io_counters ) {
        print $_."\n" if ( $count <= 5 );
        $count++;
    }
}
#######################################################################


my $tee2213_desc = '';
my $tee2213_cate = '';
my $tee2213_match = 'No';
#######################################################################
sub tee_2213_ndu_failure {
    print "\nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn\n";
    print "n NDU to 2.0.1.2 stopping at 20% tee_2213_ndu_failure:                                         n\n";
    print "n Impact is NDU failure.                                                                       n\n";
    print "n  GUI show the Upgrade stop at 20% (prestage and health check completed, stop in 0%           n\n";
    print "n   of Upgrade) for hours and not timeout.                                                     n\n";
    print "n  Collecting DC may also fail with error Timed out receiving service data bundle              n\n";
    print "n   command response from container                                                            n\n";
    print "n  tee-2213, tee-2283                                                                          n\n";
    print "n  https://confluence.cec.lab.emc.com/pages/viewpage.action?pageId=555381417                   n\n";
    print "n Workaround:                                                                                  n\n";
    print "n  restart CP and NDU will resume successfully                                                 n\n";
    print "nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn\n\n";

    print "[node_a journal]\n";
    foreach ( @node_a_tee_2213 ) {
        print $_."\n";
    }

    print "\n[node_b journal]\n";
    foreach ( @node_b_tee_2213 ) {
        print $_."\n";
    }

    $tee2213_desc = 'NDU to 2.0.1.2 stopping at 20% tee_2213_ndu_failure';
    $tee2213_cate = 'Journal';
    $tee2213_match = 'Yes' if ( $#node_a_tee_2213 >= 0 or $#node_b_tee_2213 >= 0 );     
}
#######################################################################


#######################################################################
sub kb_ndu_header {
    print "\n######################################################################################################################\n";
    print "# NDU & PUHC releated errors in journal                                                                              #\n";
    print "#                                                                                                                    #\n";
    print "# PST-X Upgrade Guide                                                                                                #\n";
    print "#  https://dl.dell.com/topicspdf/pwrstr-upgrade_en-us.pdf                                                            #\n";
    print "#  To upgrade your PowerStore X model cluster to PowerStore version 2.0.1.1 (Build: 1471924):                        #\n";
    print "#  The PowerStore X 2.0.1.1(Build: 1471924)upgrade package consists of 4 sub-packages that are part of the ZIP file. #\n"; 
    print "#  Please refer to the Release Notes and the PowerStore Software Upgrade Guide or solve online.                      #\n"; 
    print "#  https://dl.dell.com/topicspdf/pwrstr-upgrade_en-us.pdf                                                            #\n";
    print "#  * PowerStoreX-PreUpgrade_Package-2.0.0.0-1345067-retail.tgz.bin   - PowerStore X PreUpgrade image                 #\n"; 
    print "#  * PowerStoreX-node_firmware-2.0.0.0-1345890-retail.tgz.bin        - PowerStore X Node firmware image              #\n";
    print "#  * ESXi670-202103001.zip                                           - ESXi 6.7 P05 upgrade image                    #\n";
    print "#  * PowerStoreX-2.0.1.1-1471924-retail.tgz.bin                      - PowerStore OS image                           #\n";
    print "# Build numbers and versions of VMware ESXi/ESX                                                                      #\n";
    print "#  https://kb.vmware.com/s/article/2143832                                                                           #\n";
    print "#                                                                                                                    #\n";
    print "# The puhc error message for esxi vib version IS NOT CORRECT for code 2.0.1.1                                        #\n";
    print "# The minimum esxi version for 2.0.1.1 should be 17700523 instead of 17499825                                        #\n";
    print "# ESXi 6.7 P05ESXi670-2021030012021/03/1817700523N/A                                                                 #\n";
    print "# ESXi 6.7 EP 18ESXi670-2021020012021/02/2317499825N/A                                                               #\n";
    print "# P05 is the minimum requirement.The customer still need to upgrade esxi even esxi running on 17499825               #\n";  
    print "#                                                                                                                    #\n";       
    print "# NDU & PUHC related kb_ndu_header :                                                                                 #\n";
    print "# 1. NDU to FHC SP1 may fail at a very late step                                                                     #\n";
    print "#  Workaround:                                                                                                       #\n"; 
    print "#  step1 Verify NDU status is Upgrade_Completed on both nodes, using                                                 #\n";
    print "#   /install/cyc_host/cyc_config/scripts/cyc_config_mgr.pl -r ndustatus in CoreOS                                    #\n";
    print "#  step2 Verify DP is running on both nodes, using /cyc_bsc/datapath/bin/cli.py app get_app_state in BSC container   #\n";
    print "#  step3 Run debuc command from BSC container of the SYM node                                                        #\n";
    print "#   \"echo 0 > /xtremapp/debuc/127.0.0.1\\:31001/commands/sym_ndu_clear_ndu_data\"                                      #\n";
    print "#  step4 Make sure the command succeeded, run: journalctl -f |grep \"sym_debuc_clear_ndu_data\" and you                #\n"; 
    print "#    should see the following log after few minutes                                                                  #\n";
    print "#   xtremapp[22910]: ... sym_debuc_clear_ndu_data:1528: TRINDU: Finished clearing all NDU data                       #\n";
    print "#  step5 Re-run NDU from GUI, no more reboot                                                                         #\n";
    print "# https://confluence.cec.lab.emc.com/display/ETS/NDU+to+FHC+SP1+Failed+at+NEW_SYM_NDU_WAIT_FOR_DP_READY              #\n";
    print "######################################################################################################################\n\n";   
}
#######################################################################


my $mdt205619_desc = '';
my $mdt205619_cate = '';
my $mdt205619_match = 'No';
#######################################################################
sub mdt_205619_hardware_failure {
    print "\nhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh\n";
    print "  Node enters service mode after replacement due to missing or improperly reseat embedded moddule h\n";
    print "  Node FRU may Fail due to BMC wrong strapping mdt_205619_hardware_failure:                    h\n";
    print "  Impact is Following Node FRU, node will enter service mode and cannot join cluster.          h\n";
    print "   Node FRU may fail if IOM (Mezz card) is inserted after node is inserted into DPE            h\n";
    print "  https://confluence.cec.lab.emc.com/display/ETS/Node+FRU+may+Fail%09due+to+BMC+wrong+strapping h\n";
    print "  https://www.dell.com/support/kbdoc/en-us/000182172                                           h\n";
    print "hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh\n\n";

    print "[node_a journal]\n";
    foreach ( @node_a_mdt_205619 ) {
        print $_."\n";
    }

    print "\n[node_b journal]\n";
    foreach ( @node_b_mdt_205619 ) {
        print $_."\n";
    }

    $mdt205619_desc = 'Node enters service mode after replacement due to missing or improperly reseat embedded moddule';
    $mdt205619_cate = 'Journal';
    $mdt205619_match = 'Yes' if ( $#node_a_mdt_205619 >= 0 or $#node_b_mdt_205619 >= 0 );    
}
#######################################################################


my $kb180125_desc = '';
my $kb180125_cate = '';
my $kb180125_match = 'No';
#######################################################################
sub kb_180125_node_reboot_failure {
    print "\nrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr\n";
    print "r Node reboot because Failure Of BSCFailHandler kb_180125_node_reboot_failure                  r\n";
    print "r Fix: All the versions prior to FHC SP1                                                       r\n";
    print "r Impact is node reboot or panic.                                                              r\n";
    print "r Due to a code defect, when a whitelisted service fails, the following loop is executed       r\n";
    print "r  in order every 30 seconds instead of only once:                                             r\n";
    print "r ha_monitor detects a whitelisted service cyc.xxx.service failed                              r\n";
    print "r ha_monitor start a service called \"BSCFailHandler\@xxx.service\" via systemd to               r\n";
    print "r  call the bsc_fail_handler                                                                   r\n";
    print "r bsc_fail_handler sees the service cyc.xxx.service in the whitelist                           r\n";
    print "r bsc_fail_handler ignores the cyc.xxx.service failure and returns immediately without         r\n";
    print "r  taking any action                                                                           r\n";
    print "r If there is no other failure, this loop would be executed happily over and over again withoutr\n";
    print "r  causing any issue.                                                                          r\n";
    print "r However, in case the service \"BSCFailHandler\@cyc.xxx.service\" initiated in the 2nd           r\n";
    print "r  step above fails due to timeout or any other reason, then ha_monitor will initiate another  r\n"; 
    print "r  service instance BSCFailHandler\@BSCFailHandler\@cyc.xxx.service which also calls             r\n";
    print "r  bsc_fail_handler to handle that.                                                            r\n"; 
    print "r Since BSCFailHandler\@cyc.xxx.service is not in the whitelist, and there is no                r\n";
    print "r  failure action predefined for BSCFailHandler\@cyc.xxx.service, so the only way to handle     r\n";
    print "r  its failure is to reboot the node as a recovery action.                                     r\n";
    print "r https://www.dell.com/support/kbdoc/000180125/powerstore-unexpected-node-reboot-              r\n";
    print "r  caused-by-cyc-db-space-check-service-failhandler                                            r\n";
    print "r https://www.dell.com/support/kbdoc/en-au/000129743/                                          r\n";
    print "rrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr\n\n";

    print "[node_a journal]\n";
    foreach ( @node_a_kb_180125 ) {
        print $_."\n";
    }

    print "\n[node_b journal]\n";
    foreach ( @node_b_kb_180125 ) {
        print $_."\n";
    }

    $kb180125_desc = 'Node reboot because Failure Of BSCFailHandler kb_180125';
    $kb180125_cate = 'Journal';
    $kb180125_match = 'Yes' if ( $#node_a_kb_180125 >= 0 or $#node_b_kb_180125 >= 0 );     
}
#######################################################################


my $mdt194042_desc = '';
my $mdt194042_cate = '';
my $mdt194042_match = 'No';
#######################################################################
sub mdt_194042_node_reboot_failure {
    print "\nrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr\n";
    print "r Node reboot mdt_194042_node_reboot_failure:                                                  r\n";
    print "r Impact is node reboot.                                                                       r\n";
    print "r Node Reboot with a kernel panic due to task md being blocked for more than 600 seconds       r\n";
    print "r https://confluence.cec.lab.emc.com/display/ETS/Node+Reboot+with+a+kernel+panic+due+to+       r\n";
    print "r  task+%27md%27+being+blocked+for+more+than+600+seconds                                       r\n";
    print "rrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr\n\n";

    print "[node_a journal]\n";
    foreach ( @node_a_mdt_194042 ) {
        print $_."\n";
    }

    print "\n[node_b journal]\n";
    foreach ( @node_b_mdt_194042 ) {
        print $_."\n";
    }

    $mdt194042_desc = 'Node reboot mdt_194042_node_reboot_failure';
    $mdt194042_cate = 'Journal';
    $mdt194042_match = 'Yes' if ( $#node_a_mdt_194042 >= 0 or $#node_b_mdt_194042 >= 0 );     
}
#######################################################################


my $tee711_desc = '';
my $tee711_cate = '';
my $tee711_match = 'No';
#######################################################################
sub tee_711_node_reboot_failure {
    print "\nrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr\n";
    print "r Node reboot tee_711_node_reboot_failure:                                                     r\n"; 
    print "r Fix: Affected All the versions prior to SN SP4                                               r\n";
    print "r Impact is node reboot.                                                                       r\n";
    print "r Node Reboot with a kernel panic due to debuc_client being blocked for more than 600 seconds  r\n";
    print "r https://confluence.cec.lab.emc.com/display/ETS/Node+Reboot+with+a+kernel+panic+due+to+       r\n";
    print "r task+debuc_client+being+blocked+for+more+than+600+seconds                                    r\n";
    print "rrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr\n\n";

    print "[node_a journal]\n";
    foreach ( @node_a_tee_711 ) {
        print $_."\n";
    }

    print "\n[node_b journal]\n";
    foreach ( @node_b_tee_711 ) {
        print $_."\n";
    }

    $tee711_desc = 'Node reboot tee_711_node_reboot_failure';
    $tee711_cate = 'Journal';
    $tee711_match = 'Yes' if ( $#node_a_tee_711 >= 0 or $#node_b_tee_711 >= 0 );    
}
#######################################################################


my $mdt195039_desc = '';
my $mdt195039_cate ='';
my $mdt195039_match = 'No';
#######################################################################
sub mdt_195039_lost_cluster_mgmt_failure {
    print "\nssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssss\n";
    print "s Service Loss of cluster management (UI/REST) mdt_195039_lost_cluster_mgmt_failure:           s\n";
    print "s Impact is Loss of cluster management (UI/REST) after dual node reboot of                     s\n";
    print "s  multiple appliances in a cluster.                                                           s\n";
    print "s  If multiple appliances in a cluster experience a dual node reboot at the same time,         s\n"; 
    print "s   then there may be a loss of management of the cluster even after the nodes come back up.   s\n";    
    print "s  https://confluence.cec.lab.emc.com/pages/viewpage.action?pageId=362624650                   s\n";
    print "s Workaround:                                                                                  s\n";
    print "s  It is possible that restarting the primary node of the primary appliance will               s\n";
    print "s   resolve the issue. If the cluster/appliance still cannot be managed, this issue will       s\n";
    print "s   need to be escalated to development.                                                       s\n";
    print "ssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssss\n\n";

    print "[node_a journal]\n";
    foreach ( @node_a_mdt_195039 ) {
        print $_."\n";
    }

    print "\n[node_b journal]\n";
    foreach ( @node_b_mdt_195039 ) {
        print $_."\n";
    }

    $mdt195039_desc = 'Service Loss of cluster management (UI/REST) mdt_195039';
    $mdt195039_cate = 'Journal';
    $mdt195039_match = 'Yes' if ( $#node_a_mdt_195039 >= 0 or $#node_b_mdt_195039 >= 0 );     
}
#######################################################################


my $mdt149702_desc = '';
my $mdt149702_cate = '';
my $mdt149702_match = 'No';
#######################################################################
sub mdt_149702_lost_mgmt_failure {
    print "\nssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssss\n";
    print "s Service Loss of management mdt_149702_lost_mgmt_failure:                                     s\n"; 
    print "s Impact is Loss of appliance management.                                                      s\n"; 
    print "s  If the Data Path volume (hafs) used to store historic meta data becomes corrupted           s\n";
    print "s   such that fsck fails or it cannot be mounted, then the Control Path stack will             s\n";
    print "s   not come up on that appliance.                                                             s\n";
    print "s  If this occurs on an appliance in a 1 or 2 appliance cluster, then the cluster              s\n";
    print "s   cannot be managed.  If this occurs to a secondary appliance in a 3 or 4 appliance cluster, s\n";
    print "s   then that appliance cannot be managed.                                                     s\n";
    print "s  https://confluence.cec.lab.emc.com/display/ETS/Old+-Loss+of+management+after+FS+corruption+on+metrics+data+volume s\n";
    print "s Workaround:                                                                                  s\n";
    print "s  If this occurs on the primary appliance in a 3 or 4 appliance cluster resulting in the      s\n";
    print "s  loss of cluster management, restarting the primary node of the appliance will trigger an    s\n";
    print "s  appliance failover (see steps for identifying primary appliance and node as well as         s\n";
    print "s  restarting a node in the “Internal Notes” section).  This will allow the cluster to be      s\n";
    print "s  managed, but the appliance with the corruption to the volume will remain unmanageable.      s\n";
    print "s  Repairing the data path volume will require escalating the issue to development.            s\n";
    print "ssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssss\n\n";

    print "[node_a journal]\n";
    foreach ( @node_a_mdt_149702 ) {
        print $_."\n";
    }

    print "\n[node_b journal]\n";
    foreach ( @node_b_mdt_149702 ) {
        print $_."\n";
    }

    $mdt149702_desc = 'Service Loss of management mdt_149702';
    $mdt149702_cate = 'Journal';
    $mdt149702_match = 'Yes' if ( $#node_a_mdt_149702 >= 0 or $#node_b_mdt_149702 >= 0 );    
}
#######################################################################


my $mdt283614_desc = '';
my $mdt283614_cate = '';
my $mdt283614_match = 'No';
#######################################################################
sub mdt_283614_cp_restart_failue {
    print "\nssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssss\n";
    print "s Service OOM events during Data collect generation & CP restarted mdt-283614                  s\n"; 
    print "s Fixed in FHC                                                                                 s\n";
    print "s  Impact is CP restart.                                                                       s\n";
    print "s  Java process is killed due to OOM during Data collect generation, CP is restarted as a result. s\n";
    print "s  During a Data Collect there is a request \"lsof\" and that request uses too much memory       s\n";
    print "s   because too many files in /cyc_cfs/service/telemetry_backup                                s\n";
    print "s  This leads to OOM, java process(CP) is killed even though it uses memory within the         s\n";
    print "s   budget because oom-killer picks up the process that consumes the most memory.              s\n";
    print "s  https://confluence.cec.lab.emc.com/display/ETS/OOM+events+during+Data+collect+generation+and+CP+restarted s\n";
    print "ssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssss\n\n";

    print "[node_a journal]\n";
    foreach ( @node_a_mdt_283614 ) {
        print $_."\n";
    }

    print "\n[node_b journal]\n";
    foreach ( @node_b_mdt_283614 ) {
        print $_."\n";
    }

    $mdt283614_desc = 'Service OOM events during Data collect generation & CP restarted mdt-283614';
    $mdt283614_cate = 'Journal';
    $mdt283614_match = 'Yes' if ( $#node_a_mdt_283614 >= 0 or $#node_b_mdt_283614 >= 0 );     
}
#######################################################################


my $mdt285220_desc = '';
my $mdt285220_cate = '';
my $mdt285220_match = 'No';
#######################################################################
sub mdt_285220_hardware_failure {
    print "\nhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh\n";
    print "h Hardware Persistent SSD Fake WWN mdt_285220_hardware_failure:                                h\n";
    print "h Impact is SSD FRU fail.                                                                      h\n";
    print "h  SSD Fake WWN found in system, it may cause SSD FRU failure.                                 h\n";
    print "h  https://confluence.cec.lab.emc.com/display/ETS/Persistent+SSD+Fake+WWN                      h\n";
    print "h Workaround:                                                                                  h\n";
    print "h  Engage EE                                                                                   h\n";
    print "hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh\n\n";

    print "[node_a journal]\n";
    foreach ( @node_a_mdt_285220 ) {
        print $_."\n";
    }

    print "\n[node_b journal]\n";
    foreach ( @node_b_mdt_285220 ) {
        print $_."\n";
    }

    $mdt285220_desc = 'Hardware Persistent SSD Fake WWN mdt_285220_hardware_failure';
    $mdt285220_cate = 'Journal';
    $mdt285220_match = 'Yes' if ( $#node_a_mdt_285220 >= 0 or $#node_b_mdt_285220 >= 0 );      
}
#######################################################################


my $tee688_desc = '';
my $tee688_cate = '';
my $tee688_match = 'No';
#######################################################################
sub kb_pstx_icw_ca_failure {
    print "\niiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii\n";
    print "i ICW PST-X Create Cluster failure kb_pstx_icw_ca_failure:                                     i\n";
    print "i Impact is CC failure (tee-688).                                                              i\n"; 
    print "i  The issue is caused by esxi host doesnt accept non-CA certificate pushed by vCenter         i\n";
    print "i   during deployment of certificate from vCenter to ESXi host as part of                      i\n";
    print "i   adding the host to vCenter.                                                                i\n";
    print "i  During cluster creation, when trying to pull ESXi host (Powerstore nodes) to vCenter,       i\n";
    print "i   vCenter will push the TRUST_ROOT cert into ESXi host’s trust store.                        i\n";
    print "i  If non-CA cert (i.e. self-signed cert) exists in vCenter’s trust store, the non-CA cert     i\n";
    print "i   will be pushed to ESXi hosts as well.  This cert will be rejected by ESXi hosts.           i\n";
    print "i   Therefore, the cluster creation will fail.                                                 i\n";
    print "i  https://confluence.cec.lab.emc.com/display/ETS/PowerStoreX+Creation+Failure+Due+            i\n";
    print "i   to+Unsupported+vCenter+Certificate+Configuration                                           i\n";
    print "i Workaround:                                                                                  i\n";
    print "i  MDT-224468 (SN SP4) Allow ESXi on the nodes to trust self-signed certificates.              i\n";
    print "i  This is done by doing ssh into the ESXi running on the nodes and running following          i\n";
    print "i   command before the cluster creation to make sure the esxihost allow non-CA certificate     i\n";
    print "i   got pushed to esxihost so that the create cluster operation can go through.                i\n";
    print "i  ./bin/vim-cmd hostsvc/advopt/update Config.HostAgent.ssl.keyStore.allowSelfSigned bool \"true\" i\n";
    print "i  MDT-224560(SN SP4) Validate vCenter Certificate Manager mode during ICW network validation. i\n"; 
    print "i   Warn the user if the Certificate Mode on the vCenter is not configured to VMCA mode.       i\n";
    print "i https://www.dell.com/support/kbdoc/en-us/180156                                              i\n";
    print "iiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii\n\n";

    print "[node_a journal]\n";
    foreach ( @node_a_kb_pstx_icw_ca ) {
        print $_."\n";
    }

    print "\n[node_b journal]\n";
    foreach ( @node_b_kb_pstx_icw_ca ) {
        print $_."\n";
    }

    $tee688_desc = 'ICW PST-X Create Cluster failure kb_pstx_icw_ca_failure tee-688';
    $tee688_cate = 'Journal';
    $tee688_match = 'Yes' if ( $#node_a_kb_pstx_icw_ca >= 0 or $#node_b_kb_pstx_icw_ca >= 0 );     
}
#######################################################################


my $tee1128_desc = '';
my $tee1128_cate = '';
my $tee1128_match = 'No';
#######################################################################
sub tee_1128_puhc_failure {
    print "\nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn\n";
    print "n NDU PUHC failure tee_1128_puhc_failure:                                                      n\n";
    print "n  Impact is PUHC warning.                                                                     n\n";
    print "n  PUHC passed, there is a warning \"unexpected cyc_net error occurred. Please call support.    n\n";
    print "n   (cyc_net_error)\" on primary node. This warning will disappear if PUHC is re-run.           n\n";
    print "n  https://confluence.cec.lab.emc.com/pages/viewpage.action?pageId=420245555                   n\n"; 
    print "n  If you see cyc_net_client -command get_l2_discovery_info and cyc_net error,                 n\n";
    print "n   it should be ignored and re-run puhc.                                                      n\n";
    print "nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn\n\n";

    print "[node_a journal]\n";
    foreach ( @node_a_tee_1128 ) {
        print $_."\n";
    }

    print "\n[node_b journal]\n";
    foreach ( @node_b_tee_1128 ) {
        print $_."\n";
    }

    $tee1128_desc = 'NDU PUHC failure tee_1128_puhc_failure';
    $tee1128_cate = 'Journal';
    $tee1128_match = 'Yes' if ( $#node_a_tee_1128 >= 0 or $#node_b_tee_1128 >= 0 );     
}
#######################################################################


my $mdt259371_desc = '';
my $mdt259371_cate = '';
my $mdt259371_match = 'No';
#######################################################################
sub mdt_259371_puhc_failure {
    print "\nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn\n";
    print "n NDU PUHC failure mdt_259371_puhc_failure:                                                    n\n";
    print "n  Impact is PUHC failure.                                                                     n\n";
    print "n  If customer has \"RecoverPoint for VMs\" plugin version 5.3.* installed on vCenter, and     n\n";
    print "n   enabled this plugin in the PowerStoreX-ESXi-cluster, the VIB \"emcjiraf\" will               n\n";
    print "n   be installed on the PowerStoreX-ESXi-node.                                                 n\n";
    print "n  PowerStoreX PUHC uses the Vendor ID of EMC to check for our PowerStoreX specific VIBs.      n\n";
    print "n   However, the RecoverPoint VIB also has the Vendor ID of EMC and doesn't pass the           n\n";
    print "n   version string regex we expect.                                                            n\n";
    print "n  https://confluence.cec.lab.emc.com/display/ETS/PUHC+-+Checking+ESXi+PowerStore              n\n";
    print "n   +VIB+versions............+Error                                                            n\n";
    print "n  Workaround:                                                                                 n\n";
    print "n   RnD: temp uninstall the VIB of recoverpoint on PowerStore ESX nodes and then NDU.          n\n";
    print "n    After NDU, reinstall the RecoverPoint VIB.                                                n\n";  
    print "nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn\n\n";

    print "[node_a journal]\n";
    foreach ( @node_a_mdt_259371 ) {
        print $_."\n";
    }

    print "\n[node_b journal]\n";
    foreach ( @node_b_mdt_259371 ) {
        print $_."\n";
    }

    $mdt259371_desc = 'NDU PUHC failure mdt_259371_puhc_failure';
    $mdt259371_cate = 'Journal';
    $mdt259371_match = 'Yes' if ( $#node_a_mdt_259371 >= 0 or $#node_b_mdt_259371 >= 0 );     
}
#######################################################################


my $mdt163197_desc = '';
my $mdt163197_cate = '';
my $mdt163197_match = 'No';
#######################################################################
sub mdt_163197_puhc_failure {
    print "\nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn\n";
    print "n NDU PUHC failure mdt_163197_puhc_failure:                                                    n\n";
    print "n  Impact is PUHC failure.                                                                     n\n";
    print "n  PUHC failed on RAID subsystem is not ready                                                  n\n";
    print "n  https://confluence.cec.lab.emc.com/pages/viewpage.action?pageId=279349171                   n\n";
    print "n  Workaround:                                                                                 n\n";
    print "n   re-seat the affacted drive. - if confirmed on the logs the drive is healthy and only       n\n";
    print "n    the Eval state is failed. please check sub_disk_eval in report                            n\n";
    print "n   replace the affected drive.                                                                n\n";
    print "n     - If above didn't help or found the drive is fauled in the logs.                         n\n";
    print "n   re-run PUHC +NDU                                                                           n\n";
    print "nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn\n\n";

    print "[node_a journal]\n";
    foreach ( @node_a_mdt_163197 ) {
        print $_."\n";
    }

    print "\n[node_b journal]\n";
    foreach ( @node_b_mdt_163197 ) {
        print $_."\n";
    }

    $mdt163197_desc = 'NDU PUHC failure mdt_163197_puhc_failure';
    $mdt163197_cate = 'Journal';
    $mdt163197_match = 'Yes' if ( $#node_a_mdt_163197 >= 0 or $#node_b_mdt_163197 >= 0 );    
}
#######################################################################


#######################################################################
sub array_disk_eval_hardware {
    print "\ncccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc\n";
    print "c Array Configuraiton Part: sub array_disk_eval_hardware: nodea & nodeb disk hardware status   c\n";
    print "c log location: {DC_Filename}/node_*/command_output/dc-datapath-[timestamp]-logs/raid.txt      c\n";
    print "c both snap_state and eval status need be Ready !!                                             c\n";
    print "cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc\n\n";

    print "[node-a RAID status]\n";
    if ($node_a_dp_raid_txt_exist) {
        open(my $file,  "<",  $node_a_dp_raid_txt)  or die "Can't open $node_a_dp_raid_txt: $!";
        my $hit = 0;
        while (<$file>) {
            next unless ( m/- device info -/ or $hit == 1);
            last if (m/- device count by type -/);
            $hit = 1;
            print "$_";
        }
        close $file;
    }

    print "\n[node-b RAID status]\n";
    if ($node_b_dp_raid_txt_exist) {
        open(my $file,  "<",  $node_b_dp_raid_txt)  or die "Can't open $node_b_dp_raid_txt: $!";
        my $hit = 0;
        while (<$file>) {
            next unless ( m/- device info -/ or $hit == 1);
            last if (m/- device count by type -/);
            $hit = 1;
            print "$_";
        }
        close $file;
    }
}
#######################################################################


#######################################################################
sub array_hardware_pn {
    print "\ncccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc\n";
    print "c Array Configuraiton Part: sub array_hardware_pn: hardware part number info                   c\n";
    print "cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc\n\n";

    print "[Array Hardware Part Number]\n";

    if ($node_a_housemd_show_nodes_txt_exist) {
        open(my $file,  "<",  $node_a_housemd_show_nodes_txt)  or die "Can't open $node_a_housemd_show_nodes_txt: $!";
        while (<$file>) {
            print "$_";
        }
        close $file;
    }
    
    if ($node_a_housemd_show_base_enclosure_txt_exist) {
        open(my $file,  "<",  $node_a_housemd_show_base_enclosure_txt)  or die "Can't open $node_a_housemd_show_base_enclosure_txt: $!";
        while (<$file>) {
            print "$_";
        }
        close $file;
    }

    if ($node_a_housemd_show_exp_encls_txt_exist) {
        open(my $file,  "<",  $node_a_housemd_show_exp_encls_txt)  or die "Can't open $node_a_housemd_show_exp_encls_txt: $!";
        while (<$file>) {
            print "$_";
        }
        close $file;
    }

    if ($node_a_housemd_show_dimms_txt_exist) {
        open(my $file,  "<",  $node_a_housemd_show_dimms_txt)  or die "Can't open $node_a_housemd_show_dimms_txt: $!";
        while (<$file>) {
            print "$_";
        }
        close $file;
    } 

    if ($node_a_housemd_show_localdisks_txt_exist) {
        open(my $file,  "<",  $node_a_housemd_show_localdisks_txt)  or die "Can't open $node_a_housemd_show_localdisks_txt: $!";
        while (<$file>) {
            print "$_";
        }
        close $file;
    }

    if ($node_a_housemd_show_lccs_basic_txt_exist) {
        open(my $file,  "<",  $node_a_housemd_show_lccs_basic_txt)  or die "Can't open $node_a_housemd_show_lccs_basic_txt: $!";
        while (<$file>) {
            print "$_";
        }
        close $file;
    }

    if ($node_a_housemd_show_ioms_txt_exist) {
        open(my $file,  "<",  $node_a_housemd_show_ioms_txt)  or die "Can't open $node_a_housemd_show_ioms_txt: $!";
        while (<$file>) {
            print "$_";
        }
        close $file;
    }  

    if ($node_a_housemd_show_sfps_txt_exist) {
        open(my $file,  "<",  $node_a_housemd_show_sfps_txt)  or die "Can't open $node_a_housemd_show_sfps_txt: $!";
        while (<$file>) {
            print "$_";
        }
        close $file;
    }  

    if ($node_a_housemd_show_drives_basic_txt_exist) {
        open(my $file,  "<",  $node_a_housemd_show_drives_basic_txt)  or die "Can't open $node_a_housemd_show_drives_basic_txt: $!";
        while (<$file>) {
            print "$_";
        }
        close $file;
    }           

    if ($node_a_housemd_show_fanpacks_txt_exist) {
        open(my $file,  "<",  $node_a_housemd_show_fanpacks_txt)  or die "Can't open $node_a_housemd_show_fanpacks_txt: $!";
        while (<$file>) {
            print "$_";
        }
        close $file;
    }

    if ($node_a_xmcli_x_c_show_storage_controllers_txt_exist) {
        open(my $file,  "<",  $node_a_xmcli_x_c_show_storage_controllers_txt)  or die "Can't open $node_a_xmcli_x_c_show_storage_controllers_txt: $!";
        while (<$file>) {
            print "$_";
        }
        close $file;
    }
    
    if ($node_a_xmcli_x_c_show_enclosures_txt_exist) {
        open(my $file,  "<",  $node_a_xmcli_x_c_show_enclosures_txt)  or die "Can't open $node_a_xmcli_x_c_show_enclosures_txt: $!";
        while (<$file>) {
            print "$_";
        }
        close $file;
    }

    if ($node_a_xmcli_x_c_show_daes_txt_exist) {
        open(my $file,  "<",  $node_a_xmcli_x_c_show_daes_txt)  or die "Can't open $node_a_xmcli_x_c_show_daes_txt: $!";
        while (<$file>) {
            print "$_";
        }
        close $file;
    }

    if ($node_a_xmcli_x_c_show_dimms_txt_exist) {
        open(my $file,  "<",  $node_a_xmcli_x_c_show_dimms_txt)  or die "Can't open $node_a_xmcli_x_c_show_dimms_txt: $!";
        while (<$file>) {
            print "$_";
        }
        close $file;
    } 

    if ($node_a_xmcli_x_c_show_local_disks_txt_exist) {
        open(my $file,  "<",  $node_a_xmcli_x_c_show_local_disks_txt)  or die "Can't open $node_a_xmcli_x_c_show_local_disks_txt: $!";
        while (<$file>) {
            print "$_";
        }
        close $file;
    }

    if ($node_a_xmcli_x_c_show_ioms_txt_exist) {
        open(my $file,  "<",  $node_a_xmcli_x_c_show_ioms_txt)  or die "Can't open $node_a_xmcli_x_c_show_ioms_txt: $!";
        while (<$file>) {
            print "$_";
        }
        close $file;
    }  

    if ($node_a_xmcli_x_c_show_sfps_txt_exist) {
        open(my $file,  "<",  $node_a_xmcli_x_c_show_sfps_txt)  or die "Can't open $node_a_xmcli_x_c_show_sfps_txt: $!";
        while (<$file>) {
            print "$_";
        }
        close $file;
    }  

    if ($node_a_xmcli_x_c_show_slots_txt_exist) {
        open(my $file,  "<",  $node_a_xmcli_x_c_show_slots_txt)  or die "Can't open $node_a_xmcli_x_c_show_slots_txt: $!";
        while (<$file>) {
            print "$_";
        }
        close $file;
    }           

    if ($node_a_xmcli_x_c_show_ssds_txt_exist) {
        open(my $file,  "<",  $node_a_xmcli_x_c_show_ssds_txt)  or die "Can't open $node_a_xmcli_x_c_show_ssds_txt: $!";
        while (<$file>) {
            print "$_";
        }
        close $file;
    }

    if ($node_a_xmcli_x_c_show_ssds_diagnostic_txt_exist) {
        open(my $file,  "<",  $node_a_xmcli_x_c_show_ssds_diagnostic_txt)  or die "Can't open $node_a_xmcli_x_c_show_ssds_diagnostic_txt: $!";
        while (<$file>) {
            print "$_";
        }
        close $file;
    }

    if ($node_a_xmcli_x_c_show_fanpacks_txt_exist) {
        open(my $file,  "<",  $node_a_xmcli_x_c_show_fanpacks_txt)  or die "Can't open $node_a_xmcli_x_c_show_fanpacks_txt: $!";
        while (<$file>) {
            print "$_";
        }
        close $file;
    }

    if ($node_b_housemd_show_nodes_txt_exist) {
        open(my $file,  "<",  $node_b_housemd_show_nodes_txt)  or die "Can't open $node_b_housemd_show_nodes_txt: $!";
        while (<$file>) {
            print "$_";
        }
        close $file;
    }
    
    if ($node_b_housemd_show_base_enclosure_txt_exist) {
        open(my $file,  "<",  $node_b_housemd_show_base_enclosure_txt)  or die "Can't open $node_b_housemd_show_base_enclosure_txt: $!";
        while (<$file>) {
            print "$_";
        }
        close $file;
    }

    if ($node_b_housemd_show_exp_encls_txt_exist) {
        open(my $file,  "<",  $node_b_housemd_show_exp_encls_txt)  or die "Can't open $node_b_housemd_show_exp_encls_txt: $!";
        while (<$file>) {
            print "$_";
        }
        close $file;
    }

    if ($node_b_housemd_show_dimms_txt_exist) {
        open(my $file,  "<",  $node_b_housemd_show_dimms_txt)  or die "Can't open $node_b_housemd_show_dimms_txt: $!";
        while (<$file>) {
            print "$_";
        }
        close $file;
    } 

    if ($node_b_housemd_show_localdisks_txt_exist) {
        open(my $file,  "<",  $node_b_housemd_show_localdisks_txt)  or die "Can't open $node_b_housemd_show_localdisks_txt: $!";
        while (<$file>) {
            print "$_";
        }
        close $file;
    }

    if ($node_b_housemd_show_lccs_basic_txt_exist) {
        open(my $file,  "<",  $node_b_housemd_show_lccs_basic_txt)  or die "Can't open $node_b_housemd_show_lccs_basic_txt: $!";
        while (<$file>) {
            print "$_";
        }
        close $file;
    }

    if ($node_b_housemd_show_ioms_txt_exist) {
        open(my $file,  "<",  $node_b_housemd_show_ioms_txt)  or die "Can't open $node_b_housemd_show_ioms_txt: $!";
        while (<$file>) {
            print "$_";
        }
        close $file;
    }  

    if ($node_b_housemd_show_sfps_txt_exist) {
        open(my $file,  "<",  $node_b_housemd_show_sfps_txt)  or die "Can't open $node_b_housemd_show_sfps_txt: $!";
        while (<$file>) {
            print "$_";
        }
        close $file;
    }  

    if ($node_b_housemd_show_drives_basic_txt_exist) {
        open(my $file,  "<",  $node_b_housemd_show_drives_basic_txt)  or die "Can't open $node_b_housemd_show_drives_basic_txt: $!";
        while (<$file>) {
            print "$_";
        }
        close $file;
    } 

    if ($node_b_housemd_show_fanpacks_txt_exist) {
        open(my $file,  "<",  $node_b_housemd_show_fanpacks_txt)  or die "Can't open $node_b_housemd_show_fanpacks_txt: $!";
        while (<$file>) {
            print "$_";
        }
        close $file;
    }

    if ($node_b_xmcli_x_c_show_storage_controllers_txt_exist) {
        open(my $file,  "<",  $node_b_xmcli_x_c_show_storage_controllers_txt)  or die "Can't open $node_b_xmcli_x_c_show_storage_controllers_txt: $!";
        while (<$file>) {
            print "$_";
        }
        close $file;
    }
    
    if ($node_b_xmcli_x_c_show_enclosures_txt_exist) {
        open(my $file,  "<",  $node_b_xmcli_x_c_show_enclosures_txt)  or die "Can't open $node_b_xmcli_x_c_show_enclosures_txt: $!";
        while (<$file>) {
            print "$_";
        }
        close $file;
    }

    if ($node_b_xmcli_x_c_show_daes_txt_exist) {
        open(my $file,  "<",  $node_b_xmcli_x_c_show_daes_txt)  or die "Can't open $node_b_xmcli_x_c_show_daes_txt: $!";
        while (<$file>) {
            print "$_";
        }
        close $file;
    }

    if ($node_b_xmcli_x_c_show_dimms_txt_exist) {
        open(my $file,  "<",  $node_b_xmcli_x_c_show_dimms_txt)  or die "Can't open $node_b_xmcli_x_c_show_dimms_txt: $!";
        while (<$file>) {
            print "$_";
        }
        close $file;
    } 

    if ($node_b_xmcli_x_c_show_local_disks_txt_exist) {
        open(my $file,  "<",  $node_b_xmcli_x_c_show_local_disks_txt)  or die "Can't open $node_b_xmcli_x_c_show_local_disks_txt: $!";
        while (<$file>) {
            print "$_";
        }
        close $file;
    }

    if ($node_b_xmcli_x_c_show_ioms_txt_exist) {
        open(my $file,  "<",  $node_b_xmcli_x_c_show_ioms_txt)  or die "Can't open $node_b_xmcli_x_c_show_ioms_txt: $!";
        while (<$file>) {
            print "$_";
        }
        close $file;
    }  

    if ($node_b_xmcli_x_c_show_sfps_txt_exist) {
        open(my $file,  "<",  $node_b_xmcli_x_c_show_sfps_txt)  or die "Can't open $node_b_xmcli_x_c_show_sfps_txt: $!";
        while (<$file>) {
            print "$_";
        }
        close $file;
    }  

    if ($node_b_xmcli_x_c_show_slots_txt_exist) {
        open(my $file,  "<",  $node_b_xmcli_x_c_show_slots_txt)  or die "Can't open $node_b_xmcli_x_c_show_slots_txt: $!";
        while (<$file>) {
            print "$_";
        }
        close $file;
    }           

    if ($node_b_xmcli_x_c_show_ssds_txt_exist) {
        open(my $file,  "<",  $node_b_xmcli_x_c_show_ssds_txt)  or die "Can't open $node_b_xmcli_x_c_show_ssds_txt: $!";
        while (<$file>) {
            print "$_";
        }
        close $file;
    }

    if ($node_b_xmcli_x_c_show_ssds_diagnostic_txt_exist) {
        open(my $file,  "<",  $node_b_xmcli_x_c_show_ssds_diagnostic_txt)  or die "Can't open $node_b_xmcli_x_c_show_ssds_diagnostic_txt: $!";
        while (<$file>) {
            print "$_";
        }
        close $file;
    }

    if ($node_b_xmcli_x_c_show_fanpacks_txt_exist) {
        open(my $file,  "<",  $node_b_xmcli_x_c_show_fanpacks_txt)  or die "Can't open $node_b_xmcli_x_c_show_fanpacks_txt: $!";
        while (<$file>) {
            print "$_";
        }
        close $file;
    }        
}
#######################################################################


#######################################################################
sub array_sfp_power_hardware {
    print "\ncccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc\n";
    print "c Array Configuraiton Part: sub array_sfp_power_hardware: sfp info and power status            c\n";
    print "c log location: node_a/command_output/pmcli/sfpinfo.txt                                        c\n";
    print "c for eth port if specifc port rx or tx power is lower than other ports, this sfp has problem. c\n";
    print "c how to check sfp power status online:                                                        c\n";
    print "c please log into HouseMD first (refer to command guide part in report)                        c\n";
    print "c  hqm.idebuc.clients[8].cmd.PmCommands.pmcli('sfpinfo')   <<< node_a                          c\n";
    print "c  hqm.idebuc.clients[9].cmd.PmCommands.pmcli('sfpinfo')   <<< node_b                          c\n";
    print "c if the customer doesn't report any perf issue or client access issue or io aborts on         c\n";
    print "c  the specific port with unpexected dbm sfp, please ignore the finding.                       c\n";
    print "c                                                                                              c\n";
    print "c please refer to previous hardware part number info to find physical location for sfp         c\n";
    print "c iom slot index and port index is listed in the previous hardware part number info report     c\n";
    print "c sfp inserted 0 -> indicates no sfp installed                                                 c\n";
    print "cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc\n\n";

    print "[node-a sfp status]\n";
    if ($node_a_sfpinfo_txt_exist) {
        open(my $file,  "<",  $node_a_sfpinfo_txt)  or die "Can't open $node_a_sfpinfo_txt: $!";
        while (<$file>) {
            print "\n"."$_" if ( m/SFP ready / );
            print $_ if ( m/SFP inserted / );
            print $_ if ( m/SFP port index / );
            print $_ if ( m/SFP slot index / );
            print $_ if ( m/SFP Protocol / );
            print $_ if ( m/SFP Rx power / );
            print $_ if ( m/SFP Tx power/ );
        }
        close $file;
    }

    print "\n[node-b sfp status]\n";
    if ($node_b_sfpinfo_txt_exist) {
        open(my $file,  "<",  $node_b_sfpinfo_txt)  or die "Can't open $node_b_sfpinfo_txt: $!";
        while (<$file>) {
            print "\n"."$_" if ( m/SFP ready / );
            print $_ if ( m/SFP inserted / );
            print $_ if ( m/SFP port index / );
            print $_ if ( m/SFP slot index / );
            print $_ if ( m/SFP Protocol / );
            print $_ if ( m/SFP Rx power / );
            print $_ if ( m/SFP Tx power/ );
        }
        close $file;
    }
    
}
#######################################################################


my $tee834_desc = '';
my $tee834_cate = '';
my $tee834_match = 'No';
#######################################################################
sub tee_834_puhc_failure {
    print "\nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn\n";
    print "n NDU PUHC failure tee_834_puhc_failure:                                                       n\n";
    print "n Fix: Fixed in SN-SP4                                                                         n\n";
    print "n Impact is PUHC failure.                                                                      n\n";
    print "n  PUHC to SP3 fails with Platform DARE CDR drives check failed.                               n\n";
    print "n  NDU to SN SP3 might fail PUHC CDR check when there is mgmt IP change.                       n\n";
    print "n  https://confluence.cec.lab.emc.com/pages/viewpage.action?pageId=402311754                   n\n";
    print "n Workaround for L2/EE:                                                                        n\n";
    print "n  1. Connect to the Primary node via SSH                                                      n\n";
    print "n  2. Inject root and elevate using svc_service_shell                                          n\n";
    print "n  3. View the current Cluster IP in the cluster_info.json file:                               n\n";
    print "n   cat /cyc_var/security/clusterInfo.json                                                     n\n";
    print "n   {\"clusterIp\":\"10.241.7.100\"                                                            n\n";
    print "n  4. Use vi to edit the /cyc_var/security/clusterInfo.json to update the clusterIP to the current IP n\n";
    print "n  5. Access the CoreOS container and sudo su to root:                                         n\n";
    print "n  6. Run the following script:                                                                n\n";
    print "n   core # ssh -p 23 root\@localhost /cyc_host/cyc_bsc/scripts/cyc_rsync/cyc_rsync_syncfile.sh -m sysconfig -p /cyc_var/security -f clusterInfo.json n\n";
    print "n  7. Exit CoreOS and verify that the clusterInfo IP has not reverted back to the original IP. n\n";
    print "n  8. Perform HEALTH CHECK & UPGRADE                                                           n\n";
    print "nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn\n\n";

    print "[node_a journal]\n";
    foreach ( @node_a_tee_834 ) {
        print $_."\n";
    }

    print "\n[node_b journal]\n";
    foreach ( @node_b_tee_834 ) {
        print $_."\n";
    }

    $tee834_desc = 'NDU PUHC failure tee_834_puhc_failure';
    $tee834_cate = 'Journal';
    $tee834_match = 'Yes' if ( $#node_a_tee_834 >= 0 or $#node_b_tee_834 >= 0 );     
}
#######################################################################


my $tee2543_desc = '';
my $tee2543_cate = '';
my $tee2543_match = 'No';
#######################################################################
sub tee_2543_prestage_failure {
    print "\nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn\n";
    print "n NDU Prestage failure tee_2543_prestage_failure:                                              n\n";
    print "n Impact: NDU prestage failure                                                                 n\n";
    print "n 0xE04030010001 The system encountered unexpected backend errors.                             n\n";
    print "n 0xE0101001000C The system encountered unexpected backend errors.                             n\n";
    print "n https://www.dell.com/support/kbdoc/en-us/000192404/                                          n\n";
    print "n Please check space usage in mdt_243089_242417_service_failure of this report                 n\n";
    print "nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn\n\n";

    print "[node_a journal]\n";
    foreach ( @node_a_tee_2543 ) {
        print $_."\n";
    }

    print "\n[node_b journal]\n";
    foreach ( @node_b_tee_2543 ) {
        print $_."\n";
    }

    $tee2543_desc = 'NDU Prestage failure tee_2543_prestage_failure';
    $tee2543_cate = 'Journal';
    $tee2543_match = 'Yes' if ( $#node_a_tee_2543 >= 0 or $#node_b_tee_2543 >= 0 );    
}
#######################################################################


#######################################################################
sub kb_node_cpu_usage_performance {
    print "\npppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppp\n";
    print "p performance sub kb_node_cpu_usage_performance: array node-a and node-b cpu usage             p\n";
    print "p log location: {DC_Filename}/node_*/command_output/housemd/show_xenv.txt                      p\n";
    print "pppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppp\n\n";

    print "[node-a CPU usage]\n";
    if ($node_a_housemd_show_xenv_txt_exist) {
        open(my $file,  "<",  $node_a_housemd_show_xenv_txt)  or die "Can't open $node_a_housemd_show_xenv_txt: $!";
        while (<$file>) {
            print "$_";
        }
        close $file;
    }

    print "\n[node-b CPU usage]\n";
    if ($node_b_housemd_show_xenv_txt_exist) {
        open(my $file,  "<",  $node_b_housemd_show_xenv_txt)  or die "Can't open $node_b_housemd_show_xenv_txt: $!";
        while (<$file>) {
            print "$_";
        }
        close $file;
    }
}
#######################################################################


#######################################################################
sub array_vol_status {
    print "\ncccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc\n";
    print "c Array Configuraiton Part: sub array_vol_status: array block volume status                    c\n";
    print "c log location: {DC_Filename}/node_*/config_capture_management_data/volume.json                c\n";
    print "c                                                                                              c\n";
    print "c how node_affinity works: please re-banalce system selected node to optmize performance!!     c\n";
    print "c  https://confluence.cec.lab.emc.com/display/CYCLONE/How+Node+Affinity+works+in+a+volume+family c\n";
    print "c  For a block volume (primary or clone),                                                      c\n";
    print "c  node_affinity is set to SYSTEM_SELECT_AT_ATTACH when the volume is created. Note: Clones    c\n";
    print "c   DO NOT inherit the node affinity of the parent volume. However node affinity of parent     c\n";
    print "c   volume will be used for executing the clone operation in Datapath.                         c\n"; 
    print "c  A user may modify the node_affinity of a volume at any point to one of PREFERRED_NODE_A or  c\n";
    print "c   PREFERRED_NODE_B or even back to SYSTEM_SELECT_AT_ATTACH. Any snapshots created prior to   c\n";
    print "c   this user action will not be affected. However, snapshots created after this user action   c\n";
    print "c   will be affected (see below for clone and snapshot behavior).                              c\n";
    print "c  During the first map (attach) operation, if node_affinity is set to SYSTEM_SELECT_AT_ATTACH,c\n";
    print "c   we ask Resource Balancer which node to use and node affinity is set to either              c\n"; 
    print "c   SYSTEM_SELECTED_NODE_A or SYSTEM_SELECTED_NODE_B.                                          c\n";
    print "c  node_affinity remains the same for any subsequent map (attach) operations.                  c\n";
    print "c  The last unmap (detach) on the volume sets the node_affinity back to SYSTEM_SELECT_AT_ATTACHc\n";
    print "c   if it was one of the SYSTEM_SELECTED_* values. If it was set to one of the PREFERRED_*     c\n";
    print "c   values, it remains unchanged. Future attach calls will use this same PREFERRED_* value     c\n"; 
    print "c   without going to Resource Balancer.                                                        c\n";
    print "c  For a snapshot of a volume,                                                                 c\n";
    print "c  All read-only snapshots have an affinity of System_Select_At_Attach.                        c\n";
    print "c  All read-write snapshots inherit the node_affinity of the parent volume.                    c\n";
    print "c  Node affinity of the parent volume is used to determine where to execute the snapshot       c\n";
    print "c   operation in Datapath.                                                                     c\n";   
    print "c  In Foothills Prime release, we will be adding a new enum value to node_affinity called      c\n";
    print "c  BOTH_NODES to allow users to use both nodes as the optimized IO path for the volume         c\n";
    print "c                                                                                              c\n";
    print "c state:                                                                                       c\n";
    print "c  expected - Ready                                                                            c\n";
    print "cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc\n\n";

    my $appliance_id = '';
    my $creation_timestamp = '';
    my $creator_type = '';
    my $datapath_volume_id = '';
    my $family_id = '';
    my $description = '';
    my $is_internal = '';
    my $is_importing = '';
    my $is_read_only = '';
    my $is_replication_destination = '';
    my $name = '';
    my $node_affinity = '';
    my $performance_policy_id = '';
    my $size = '';
    my $state = '';
    my $storage_type = '';
    my $type = '';
    my $wwn = '';
    my $parent_id = '';
    my $source_id = '';
    my $source_timestamp = '';

    if ($node_a_volume_json_exist) {        
        print "\n---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------\n";        
        print "| name                       | state    | node_affinity             | is_read_only | creator_type | wwn                                     | creation_timestamp                           | description | is_replication_destination |\n";
        print "---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------\n";        
    
        open (FILE, $node_a_volume_json) or die "Cannot open $node_a_volume_json: $!\n";      
        while ( <FILE> ) {
            $_ =~ s/^\s+|\s+$//g;
            $appliance_id = $_ if ( m/\"appliance_id\":/ );
            $creation_timestamp = $_ if ( m/\"creation_timestamp\":/ ); 
            $creator_type = $_ if ( m/\"creator_type\":/ ); 
            $datapath_volume_id = $_ if ( m/\"datapath_volume_id\":/ );
            $description = $_ if ( m/\"description\":/ );
            $family_id = $_ if ( m/\"family_id\":/ );
            $is_internal = $_ if ( m/\"is_internal\":/ );
            $is_importing = $_ if ( m/\"is_importing\":/ );
            $is_read_only = $_ if ( m/\"is_read_only\":/ );
            $is_replication_destination = $_ if ( m/\"is_replication_destination\":/ );
            $name = $_ if ( m/\"name\":/ );
            $node_affinity = $_ if ( m/\"node_affinity\":/ );
            $performance_policy_id = $_ if ( m/\"performance_policy_id\":/ );
            $size = $_ if ( m/\"size\":/ );
            $state = $_ if ( m/\"state\":/ );
            $storage_type = $_ if ( m/\"storage_type\":/ );
            $type = $_ if ( m/\"type\":/ );
            $parent_id = $_ if ( m/\"parent_id\":/ );
            $source_id = $_ if ( m/\"source_id\":/ );
            $source_timestamp = $_ if ( m/\"source_timestamp\":/ );
                                                                                                                                            
            if ( m/\"wwn\":/ ) {
                $wwn = $_;
                #print $state." ".$node_affinity." ".$is_read_only." ".$creator_type." ".$wwn." ".$creation_timestamp." ".$name." ".$description." ".$is_replication_destination."\n"; 
                my @tmp = split( /:\s+/, $state );
                $state = $tmp[1];
                chop $state;
                
                @tmp = split( /:\s+/, $node_affinity );
                $node_affinity = $tmp[1];
                chop $node_affinity;

                @tmp = split( /:\s+/, $is_read_only );
                $is_read_only = $tmp[1];
                chop $is_read_only;

                @tmp = split( /:\s+/, $creator_type );
                $creator_type = $tmp[1];
                chop $creator_type;

                @tmp = split( /:\s+/, $wwn );
                $wwn = $tmp[1];

                @tmp = split( /:\s+/, $name );
                $name = $tmp[1];
                chop $name;
                
                @tmp = split( /:\s+/, $creation_timestamp );
                $creation_timestamp = $tmp[1];
                chop $creation_timestamp;

                @tmp = split( /:\s+/, $description );
                $description = $tmp[1];
                chop $description;

                @tmp = split( /:\s+/, $is_replication_destination );
                $is_replication_destination = $tmp[1];
                chop $is_replication_destination;

                $~ = VOLUMEA;
                                
                format VOLUMEA =
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------         
| ^<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<< | ^<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<< | ^<<<<<<<<<<< | ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<< | ^<<<<<<<<<<<<<<<<<<<<<<<<< |
$name, $state, $node_affinity, $is_read_only, $creator_type, $wwn, $creation_timestamp, $description, $is_replication_destination
| ^<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<< | ^<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<< | ^<<<<<<<<<<< | ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<< | ^<<<<<<<<<<<<<<<<<<<<<<<<< |
$name, $state, $node_affinity, $is_read_only, $creator_type, $wwn, $creation_timestamp, $description, $is_replication_destination
| ^<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<< | ^<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<< | ^<<<<<<<<<<< | ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<< | ^<<<<<<<<<<<<<<<<<<<<<<<<< |
$name, $state, $node_affinity, $is_read_only, $creator_type, $wwn, $creation_timestamp, $description, $is_replication_destination                                    
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
.
                write; 
                                        
                $appliance_id = '';
                $creation_timestamp = '';
                $creator_type = '';
                $datapath_volume_id = '';
                $family_id = '';
                $description = '';
                $is_internal = '';
                $is_importing = '';
                $is_read_only = '';
                $is_replication_destination = '';
                $name = '';
                $node_affinity = '';
                $performance_policy_id = '';
                $size = '';
                $state = '';
                $storage_type = '';
                $type = '';
                $wwn = '';
                $parent_id = '';
                $source_id = '';
                $source_timestamp = '';
            }
        }
        close FILE;
    }

    if ($node_b_volume_json_exist) { 
        print "\n---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------\n";        
        print "| name                       | state    | node_affinity             | is_read_only | creator_type | wwn                                     | creation_timestamp                           | description | is_replication_destination |\n";
        print "---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------\n";        
             
        open (FILE, $node_b_volume_json) or die "Cannot open $node_b_volume_json: $!\n";      
        while ( <FILE> ) {
            $_ =~ s/^\s+|\s+$//g;
            $appliance_id = $_ if ( m/\"appliance_id\":/ );
            $creation_timestamp = $_ if ( m/\"creation_timestamp\":/ ); 
            $creator_type = $_ if ( m/\"creator_type\":/ ); 
            $datapath_volume_id = $_ if ( m/\"datapath_volume_id\":/ );
            $description = $_ if ( m/\"description\":/ );
            $family_id = $_ if ( m/\"family_id\":/ );
            $is_internal = $_ if ( m/\"is_internal\":/ );
            $is_importing = $_ if ( m/\"is_importing\":/ );
            $is_read_only = $_ if ( m/\"is_read_only\":/ );
            $is_replication_destination = $_ if ( m/\"is_replication_destination\":/ );
            $name = $_ if ( m/\"name\":/ );
            $node_affinity = $_ if ( m/\"node_affinity\":/ );
            $performance_policy_id = $_ if ( m/\"performance_policy_id\":/ );
            $size = $_ if ( m/\"size\":/ );
            $state = $_ if ( m/\"state\":/ );
            $storage_type = $_ if ( m/\"storage_type\":/ );
            $type = $_ if ( m/\"type\":/ );
            $parent_id = $_ if ( m/\"parent_id\":/ );
            $source_id = $_ if ( m/\"source_id\":/ );
            $source_timestamp = $_ if ( m/\"source_timestamp\":/ );
                                                                                                                                            
            if ( m/\"wwn\":/ ) {
                $wwn = $_;
                #print $state." ".$node_affinity." ".$is_read_only." ".$creator_type." ".$wwn." ".$creation_timestamp." ".$name." ".$description." ".$is_replication_destination."\n"; 
                my @tmp = split( /:\s+/, $state );
                $state = $tmp[1];
                chop $state;
                
                @tmp = split( /:\s+/, $node_affinity );
                $node_affinity = $tmp[1];
                chop $node_affinity;

                @tmp = split( /:\s+/, $is_read_only );
                $is_read_only = $tmp[1];
                chop $is_read_only;

                @tmp = split( /:\s+/, $creator_type );
                $creator_type = $tmp[1];
                chop $creator_type;

                @tmp = split( /:\s+/, $wwn );
                $wwn = $tmp[1];

                @tmp = split( /:\s+/, $name );
                $name = $tmp[1];
                chop $name;
                
                @tmp = split( /:\s+/, $creation_timestamp );
                $creation_timestamp = $tmp[1];
                chop $creation_timestamp;

                @tmp = split( /:\s+/, $description );
                $description = $tmp[1];
                chop $description;

                @tmp = split( /:\s+/, $is_replication_destination );
                $is_replication_destination = $tmp[1];
                chop $is_replication_destination;

                $~ = VOLUMEB;
                
                format VOLUMEB =
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------         
| ^<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<< | ^<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<< | ^<<<<<<<<<<< | ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<< | ^<<<<<<<<<<<<<<<<<<<<<<<<< |
$name, $state, $node_affinity, $is_read_only, $creator_type, $wwn, $creation_timestamp, $description, $is_replication_destination
| ^<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<< | ^<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<< | ^<<<<<<<<<<< | ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<< | ^<<<<<<<<<<<<<<<<<<<<<<<<< |
$name, $state, $node_affinity, $is_read_only, $creator_type, $wwn, $creation_timestamp, $description, $is_replication_destination                  
| ^<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<< | ^<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<< | ^<<<<<<<<<<< | ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<< | ^<<<<<<<<<<<<<<<<<<<<<<<<< |
$name, $state, $node_affinity, $is_read_only, $creator_type, $wwn, $creation_timestamp, $description, $is_replication_destination                  
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
.
                write;

                $appliance_id = '';
                $creation_timestamp = '';
                $creator_type = '';
                $datapath_volume_id = '';
                $family_id = '';
                $description = '';
                $is_internal = '';
                $is_importing = '';
                $is_read_only = '';
                $is_replication_destination = '';
                $name = '';
                $node_affinity = '';
                $performance_policy_id = '';
                $size = '';
                $state = '';
                $storage_type = '';
                $type = '';
                $wwn = '';
                $parent_id = '';
                $source_id = '';
                $source_timestamp = '';
            }
        }
        close FILE;
    }

}
#######################################################################


#######################################################################
sub array_vvol_status {

}
#######################################################################


#######################################################################
sub array_host_status {
    print "\ncccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc\n";
    print "c Array Configuraiton Part: sub array_host_status: host group and host list                    c\n";
    print "c log location: {DC_Filename}/node_*/config_capture_management_data/host_*.json                c\n";
    print "c                                                                                              c\n";
    print "cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc\n\n";

    my %hstgrp_id_name;
    my %hstgrp_id_name2;
    my %hst_id_attri;
    my %hst_id_attri2;

    my $description = '';
    my $esxi_build = '';
    my $esxi_version = '';
    my $host_group_id = '';
    my $id = '';
    my $is_internal = '';
    my $name = '';
    my $os_type = '';
    my $type = '';

    if ($node_a_host_json_exist) {            
        open (FILE, $node_a_host_json) or die "Cannot open $node_a_host_json: $!\n";      
        
        while ( <FILE> ) {  
            $_ =~ s/^\s+|\s+$//g;
            if ( m/\"description\":/ ) {
                $description = $_;
                my @tmp = split( /:\s+/, $description );
                $description = $tmp[1];
                chop $description;              
            }

            if ( m/\"esxi_build\":/ ) {
                $esxi_build = $_;
                my @tmp = split( /:\s+/, $esxi_build );
                $esxi_build = $tmp[1];
                chop $esxi_build;               
            }       

            if ( m/\"esxi_version\":/ ) {
                $esxi_version = $_;
                my @tmp = split( /:\s+/, $esxi_version );
                $esxi_version = $tmp[1];
                chop $esxi_version;             
            }

            if ( m/\"host_group_id\":/ ) {
                $host_group_id = $_;
                my @tmp = split( /:\s+/, $host_group_id );
                $host_group_id = $tmp[1];
                chop $host_group_id;                
            }

            if ( m/\"id\":/ ) {
                $id = $_;
                my @tmp = split( /:\s+/, $id );
                $id = $tmp[1];
                chop $id;               
            }   

            if ( m/\"is_internal\":/ ) {
                $is_internal = $_;
                my @tmp = split( /:\s+/, $is_internal );
                $is_internal = $tmp[1];
                chop $is_internal;              
            }   

            if ( m/\"name\":/ ) {
                $name = $_;
                my @tmp = split( /:\s+/, $name );
                $name = $tmp[1];
                chop $name;             
            }   

            if ( m/\"os_type\":/ ) {
                $os_type = $_;
                my @tmp = split( /:\s+/, $os_type );
                $os_type = $tmp[1];
                chop $os_type;              
            }   

            if ( m/\"type\":/ ) {
                $type = $_;
                my @tmp = split( /:\s+/, $type );
                $type = $tmp[1];
                chop $type;    

                $hst_id_attri{$id}{'description'} = $description;
                $hst_id_attri{$id}{'esxi_build'} = $esxi_build;
                $hst_id_attri{$id}{'esxi_version'} = $esxi_version;
                $hst_id_attri{$id}{'host_group_id'} = $host_group_id;
                $hst_id_attri{$id}{'is_internal'} = $is_internal;
                $hst_id_attri{$id}{'name'} = $name;
                $hst_id_attri{$id}{'os_type'} = $os_type;
                $hst_id_attri{$id}{'type'} = $type;

                $hst_id_attri2{$id}{'description'} = $description;
                $hst_id_attri2{$id}{'esxi_build'} = $esxi_build;
                $hst_id_attri2{$id}{'esxi_version'} = $esxi_version;
                $hst_id_attri2{$id}{'host_group_id'} = $host_group_id;
                $hst_id_attri2{$id}{'is_internal'} = $is_internal;
                $hst_id_attri2{$id}{'name'} = $name;
                $hst_id_attri2{$id}{'os_type'} = $os_type;
                $hst_id_attri2{$id}{'type'} = $type;

                $description = '';
                $esxi_build = '';
                $esxi_version = '';
                $host_group_id = '';
                $id = '';
                $is_internal = '';
                $name = '';
                $os_type = '';
                $type = '';
            }                                                                                             
        }
    } elsif ($node_b_host_json_exist) {
        open (FILE, $node_b_host_json) or die "Cannot open $node_b_host_json: $!\n";      
        while ( <FILE> ) {  
            $_ =~ s/^\s+|\s+$//g;
            if ( m/\"description\":/ ) {
                $description = $_;
                my @tmp = split( /:\s+/, $description );
                $description = $tmp[1];
                chop $description;              
            }

            if ( m/\"esxi_build\":/ ) {
                $esxi_build = $_;
                my @tmp = split( /:\s+/, $esxi_build );
                $esxi_build = $tmp[1];
                chop $esxi_build;               
            }       

            if ( m/\"esxi_version\":/ ) {
                $esxi_version = $_;
                my @tmp = split( /:\s+/, $esxi_version );
                $esxi_version = $tmp[1];
                chop $esxi_version;             
            }

            if ( m/\"host_group_id\":/ ) {
                $host_group_id = $_;
                my @tmp = split( /:\s+/, $host_group_id );
                $host_group_id = $tmp[1];
                chop $host_group_id;                
            }

            if ( m/\"id\":/ ) {
                $id = $_;
                my @tmp = split( /:\s+/, $id );
                $id = $tmp[1];
                chop $id;               
            }   

            if ( m/\"is_internal\":/ ) {
                $is_internal = $_;
                my @tmp = split( /:\s+/, $is_internal );
                $is_internal = $tmp[1];
                chop $is_internal;              
            }   

            if ( m/\"name\":/ ) {
                $name = $_;
                my @tmp = split( /:\s+/, $name );
                $name = $tmp[1];
                chop $name;             
            }   

            if ( m/\"os_type\":/ ) {
                $os_type = $_;
                my @tmp = split( /:\s+/, $os_type );
                $os_type = $tmp[1];
                chop $os_type;              
            }   

            if ( m/\"type\":/ ) {
                $type = $_;
                my @tmp = split( /:\s+/, $type );
                $type = $tmp[1];
                chop $type;    

                $hst_id_attri{$id}{'description'} = $description;
                $hst_id_attri{$id}{'esxi_build'} = $esxi_build;
                $hst_id_attri{$id}{'esxi_version'} = $esxi_version;
                $hst_id_attri{$id}{'host_group_id'} = $host_group_id;
                $hst_id_attri{$id}{'is_internal'} = $is_internal;
                $hst_id_attri{$id}{'name'} = $name;
                $hst_id_attri{$id}{'os_type'} = $os_type;
                $hst_id_attri{$id}{'type'} = $type;

                $hst_id_attri2{$id}{'description'} = $description;
                $hst_id_attri2{$id}{'esxi_build'} = $esxi_build;
                $hst_id_attri2{$id}{'esxi_version'} = $esxi_version;
                $hst_id_attri2{$id}{'host_group_id'} = $host_group_id;
                $hst_id_attri2{$id}{'is_internal'} = $is_internal;
                $hst_id_attri2{$id}{'name'} = $name;
                $hst_id_attri2{$id}{'os_type'} = $os_type;
                $hst_id_attri2{$id}{'type'} = $type;

                $description = '';
                $esxi_build = '';
                $esxi_version = '';
                $host_group_id = '';
                $id = '';
                $is_internal = '';
                $name = '';
                $os_type = '';
                $type = '';
            }                               
        }
    }  

    if ($node_a_host_group_json_exist) {            
        open (FILE, $node_a_host_group_json) or die "Cannot open $node_a_host_group_json: $!\n";      
        my $id = '';
        my $name = '';
        while ( <FILE> ) {  
            $_ =~ s/^\s+|\s+$//g;
            if ( m/\"id\":/ ) {
                $id = $_;
                my @tmp = split( /:\s+/, $id );
                $id = $tmp[1];
                chop $id;               
            }

            if ( m/\"name\":/ ) {
                $name = $_;
                my @tmp = split( /:\s+/, $name );
                $name = $tmp[1];

                $hstgrp_id_name{$id} = $name;
                $hstgrp_id_name2{$id} = $name;
                $id = '';
                $name = '';             
            }                       
        }
    } elsif ($node_b_host_group_json_exist) {
        open (FILE, $node_b_host_group_json) or die "Cannot open $node_a_host_group_json: $!\n";      
        my $id = '';
        my $name = '';
        while ( <FILE> ) {  
            $_ =~ s/^\s+|\s+$//g;
            if ( m/\"id\":/ ) {
                $id = $_;
                my @tmp = split( /:\s+/, $id );
                $id = $tmp[1];
                chop $id;               
            }

            if ( m/\"name\":/ ) {
                $name = $_;
                my @tmp = split( /:\s+/, $name );
                $name = $tmp[1];

                $hstgrp_id_name{$id} = $name;
                $hstgrp_id_name2{$id} = $name;   
                $id = '';
                $name = '';                         
            }           
        }
    }

    print "[Host Group List]\n";
    print "\n------------------------------------------------------------------------\n";
    print "| host group name       | host group id                                |\n";
    print "------------------------------------------------------------------------\n";

    foreach my $hstgrp_id ( keys %hstgrp_id_name ) {
        $~ = HSTGRP;
        format HSTGRP =
------------------------------------------------------------------------         
| ^<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< |
$hstgrp_id_name{$hstgrp_id}, $hstgrp_id
------------------------------------------------------------------------
.
        write;
    }

    print "\n[Host Group and Host List]\n";
    print "\n-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------\n";
    print "| host group name       | host name                  | os_type        | type         | esxi_build        | esxi_version      | hst_id                                       |\n";
    print "-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------\n";

    foreach my $hstgrp_id ( keys %hstgrp_id_name2 ) {
        foreach my $hst_id ( keys %hst_id_attri ) {
            next if ( $hst_id_attri{$hst_id}{'host_group_id'} ne $hstgrp_id );
            $~ = HGRPHSTATTR;
            format HGRPHSTATTR =
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------         
| ^<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<<< | ^<<<<<<<<<<< | ^<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< |
$hstgrp_id_name2{$hstgrp_id}, $hst_id_attri{$hst_id}{'name'}, $hst_id_attri{$hst_id}{'os_type'}, $hst_id_attri{$hst_id}{'type'}, $hst_id_attri{$hst_id}{'esxi_build'}, $hst_id_attri{$hst_id}{'esxi_version'}, $hst_id
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
.
            write;
        }
    }

    print "\n[Host List not in Host Group]\n";
    print "\n-----------------------------------------------------------------------------------------------------------------------------------------------------\n";
    print "| host name                  | os_type        | type         | esxi_build        | esxi_version      | hst_id                                       |\n";
    print "-----------------------------------------------------------------------------------------------------------------------------------------------------\n";

    foreach my $hst_id ( keys %hst_id_attri2 ) {
        next if ( $hst_id_attri2{$hst_id}{'host_group_id'} ne 'null' );
        $~ = HSTATTR;
        format HSTATTR =
-----------------------------------------------------------------------------------------------------------------------------------------------------         
| ^<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<<< | ^<<<<<<<<<<< | ^<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< |
$hst_id_attri2{$hst_id}{'name'}, $hst_id_attri2{$hst_id}{'os_type'}, $hst_id_attri2{$hst_id}{'type'}, $hst_id_attri2{$hst_id}{'esxi_build'}, $hst_id_attri2{$hst_id}{'esxi_version'}, $hst_id
-----------------------------------------------------------------------------------------------------------------------------------------------------
.
        write;
    }
}
#######################################################################


#######################################################################
sub array_host_initiators {
    print "\ncccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc\n";
    print "c Array Configuraiton Part: sub array_host_initiators: host and initiators                     c\n";
    print "c log location: {DC_Filename}/node_*/config_capture_management_data/config_item.json           c\n";
    print "c                                                                                              c\n";
    print "cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc\n\n";

    my %hostid_initiator;
    my %hostid_inittype;
    my %hostid_name;
    my %hostid_os;

    my $port_name = '';
    my $port_type = '';
    my $port_hostid = '';
    my $hostname = '';
    my $hostos = '';
    my $hostid = '';
    
    if ($node_a_config_item_json_exist) {            
        open (FILE, $node_a_config_item_json) or die "Cannot open $node_a_config_item_json: $!\n";      
        my $hit = 0;
        while ( <FILE> ) {  
            $_ =~ s/^\s+|\s+$//g;
            $hit = 1 if ( m/\"data\": \{/ );
            
            if ( $hit == 1 && m/\"host_id\":/ ) {
                $port_hostid = $_;
                my @tmp = split( /:\s+/, $port_hostid );
                $port_hostid = $tmp[1];
                chop $port_hostid;               
            }

            if ( $hit == 1 && m/\"port_name\":/ ) {
                $port_name = $_;
                my @tmp = split( /:\s+/, $port_name );
                $port_name = $tmp[1];
                chop $port_name;               
            }

            if ( $hit == 1 && m/\"port_type\":/ ) {
                $port_type = $_;
                my @tmp = split( /:\s+/, $port_type );
                $port_type = $tmp[1];
                chop $port_type;               
            }

            if ( $hit == 1 && m/\"name\":/ ) {
                $hostname = $_;
                my @tmp = split( /:\s+/, $hostname );
                $hostname = $tmp[1];
                chop $hostname;               
            }

            if ( $hit == 1 && m/\"os\":/ ) {
                $hostos = $_;
                my @tmp = split( /:\s+/, $hostos );
                $hostos = $tmp[1];
                chop $hostos;               
            }

            if ( $hit == 1 && m/\"id\":/ ) {
                $hostid = $_;
                my @tmp = split( /:\s+/, $hostid );
                $hostid = $tmp[1];
                chop $hostid;               
            }

            if ( $hit == 1 && m/\"type\": \"INITIATOR\"/ ) {
                $hit = 0;
                if ( defined $hostid_initiator{$port_hostid} ) {
                    $hostid_initiator{$port_hostid} = $hostid_initiator{$port_hostid}."   ".$port_name;
                }else{
                    $hostid_initiator{$port_hostid} = $port_name;
                }

                if ( defined $hostid_inittype{$port_hostid} ) {
                    $hostid_inittype{$port_hostid} = $hostid_inittype{$port_hostid}."   ".$port_type;
                }else{
                    $hostid_inittype{$port_hostid} = $port_type;
                }
                
                $port_name = '';
                $port_type = '';
                $port_hostid = '';
            }     

            if ( $hit == 1 && m/\"type\": \"HOST\"/ ) {
                $hit = 0;
                $hostid_name{$hostid} = $hostname;
                $hostid_os{$hostid} = $hostos;
                $hostname = '';
                $hostos = '';
                $hostid = '';
            }
                                                                                       
        }
    } elsif ($node_b_config_item_json_exist) {
        open (FILE, $node_b_config_item_json) or die "Cannot open $node_b_config_item_json: $!\n";      
        my $hit = 0;
        while ( <FILE> ) {  
            $_ =~ s/^\s+|\s+$//g;
            $hit = 1 if ( m/\"data\": \{/ );
            
            if ( $hit == 1 && m/\"host_id\":/ ) {
                $port_hostid = $_;
                my @tmp = split( /:\s+/, $port_hostid );
                $port_hostid = $tmp[1];
                chop $port_hostid;               
            }

            if ( $hit == 1 && m/\"port_name\":/ ) {
                $port_name = $_;
                my @tmp = split( /:\s+/, $port_name );
                $port_name = $tmp[1];
                chop $port_name;               
            }

            if ( $hit == 1 && m/\"port_type\":/ ) {
                $port_type = $_;
                my @tmp = split( /:\s+/, $port_type );
                $port_type = $tmp[1];
                chop $port_type;               
            }

            if ( $hit == 1 && m/\"name\":/ ) {
                $hostname = $_;
                my @tmp = split( /:\s+/, $hostname );
                $hostname = $tmp[1];
                chop $hostname;               
            }

            if ( $hit == 1 && m/\"os\":/ ) {
                $hostos = $_;
                my @tmp = split( /:\s+/, $hostos );
                $hostos = $tmp[1];
                chop $hostos;               
            }

            if ( $hit == 1 && m/\"id\":/ ) {
                $hostid = $_;
                my @tmp = split( /:\s+/, $hostid );
                $hostid = $tmp[1];
                chop $hostid;               
            }

            if ( $hit == 1 && m/\"type\": \"INITIATOR\"/ ) {
                $hit = 0;
                if ( defined $hostid_initiator{$port_hostid} ) {
                    $hostid_initiator{$port_hostid} = $hostid_initiator{$port_hostid}."   ".$port_name;
                }else{
                    $hostid_initiator{$port_hostid} = $port_name;
                }

                if ( defined $hostid_inittype{$port_hostid} ) {
                    $hostid_inittype{$port_hostid} = $hostid_inittype{$port_hostid}."   ".$port_type;
                }else{
                    $hostid_inittype{$port_hostid} = $port_type;
                }
                
                $port_name = '';
                $port_type = '';
                $port_hostid = '';
            }    

            if ( $hit == 1 && m/\"type\": \"HOST\"/ ) {
                $hit = 0;
                $hostid_name{$hostid} = $hostname;
                $hostid_os{$hostid} = $hostos;
                $hostname = '';
                $hostos = '';
                $hostid = '';
            }
        }
    }

    print "\n[Host and Initiators List]\n";

    print "\n-----------------------------------------------------------------------------------------------------------------------------------------------------\n";
    print "| host name                         | host os            | initiator type            | initiator                                                    |\n";
    print "-----------------------------------------------------------------------------------------------------------------------------------------------------\n";

    foreach my $hostid ( keys %hostid_initiator ) {
        $initiatorlist = $hostid_initiator{$hostid};
        $initiatortypelist = $hostid_inittype{$hostid};
        my @initiators = split(/   /, $initiatorlist );
        my @types = split(/   /, $initiatortypelist);
        for ( my $i=0; $i<@initiators; $i++ ) {
            $~ = HSTINIT;
            format HSTINIT =
-----------------------------------------------------------------------------------------------------------------------------------------------------        
| ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< |
$hostid_name{$hostid}, $hostid_os{$hostid}, $types[$i], $initiators[$i]
| ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< |
$hostid_name{$hostid}, $hostid_os{$hostid}, $types[$i], $initiators[$i]
-----------------------------------------------------------------------------------------------------------------------------------------------------
.
            write;
        }
    }
     
}
#######################################################################


#######################################################################
sub array_host_vol_mapping {
    print "\ncccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc\n";
    print "c Array Configuraiton Part: sub array_host_vol_mapping: host and volume mapping                c\n";
    print "c log location: {DC_Filename}/node_*/config_capture_management_data/host_*.json                c\n";
    print "c                                                                                              c\n";
    print "c What is HLU:                                                                                 c\n";
    print "c https://www.dell.com/support/kbdoc/en-us/00094610                                            c\n";
    print "c For PST, Raid ctrl lun is similar as LUNZ with host ID 0.                                    c\n";
    print "c ESXi host may report PDL errors on Raid ctrl lun because non support scsi operations.        c\n";
    print "c It is harmless. tee-1527.                                                                    c\n";
    print "c Known KB list:                                                                               c\n";
    print "c  1.Logical Unit Number changes when a volume is migrated                                     c\n";
    print "c   https://www.dell.com/support/kbdoc/en-us/000188476                                         c\n";
    print "c  2.Host may experience access issue with LUN 0 after nondisruptive upgrade (NDU) or          c\n"; 
    print "c   PowerStore Node reboot                                                                     c\n";
    print "c   https://www.dell.com/support/kbdoc/en-us/000189081                                         c\n";
    print "cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc\n\n";

    my %vol_id_name;
    my %host_id_name;
    my %host_group_id_name;
    my %host_id_vol_attr;
    my %host_group_id_vol_attr;
    my %vol_id_hstattached;
    my %vol_id_hstgrpattached;
    
    if ($node_a_volume_json_exist) {          
        open (FILE, $node_a_volume_json) or die "Cannot open $node_a_volume_json: $!\n";      
        while ( <FILE> ) {
            $_ =~ s/^\s+|\s+$//g;                                                                                                                                            
            if ( m/\"datapath_volume_id\":/ ) {
                $id = $_;
                my @tmp = split( /:\s+/, $id );
                $id = $tmp[1];
                chop $id;                                 
            }

            if ( m/\"name\":/ ) {
                $name = $_;
                my @tmp = split( /:\s+/, $name );
                $name = $tmp[1];
                chop $name;
                $vol_id_name{$id} = $name;
                $id = '';
                $name = '';                                      
            }            
        }
    } elsif ($node_b_volume_json_exist) {
        open (FILE, $node_b_volume_json) or die "Cannot open $node_b_volume_json: $!\n";      
        while ( <FILE> ) {
            $_ =~ s/^\s+|\s+$//g;                                                                                                                                            
            if ( m/\"datapath_volume_id\":/ ) {
                $id = $_;
                my @tmp = split( /:\s+/, $id );
                $id = $tmp[1];
                chop $id;                                   
            }

            if ( m/\"name\":/ ) {
                $name = $_;
                my @tmp = split( /:\s+/, $name );
                $name = $tmp[1];
                chop $name; 
                $vol_id_name{$id} = $name;
                $id = '';
                $name = '';                                    
            }            
        }
    }

    if ($node_a_host_json_exist) {            
        open (FILE, $node_a_host_json) or die "Cannot open $node_a_host_json: $!\n";      
        my $id = '';
        my $name = '';
        while ( <FILE> ) {  
            $_ =~ s/^\s+|\s+$//g;

            if ( m/\"id\":/ ) {
                $id = $_;
                my @tmp = split( /:\s+/, $id );
                $id = $tmp[1];
                chop $id;               
            }       

            if ( m/\"name\":/ ) {
                $name = $_;
                my @tmp = split( /:\s+/, $name );
                $name = $tmp[1];
                chop $name;     
                $host_id_name{$id} = $name;
                $id = '';
                $name = '';     
            }                                                                                           
        }
    } elsif ($node_b_host_json_exist) {
        open (FILE, $node_b_host_json) or die "Cannot open $node_b_host_json: $!\n";  
        my $id = '';
        my $name = '';            
        while ( <FILE> ) {  
            $_ =~ s/^\s+|\s+$//g;

            if ( m/\"id\":/ ) {
                $id = $_;
                my @tmp = split( /:\s+/, $id );
                $id = $tmp[1];
                chop $id;               
            }       

            if ( m/\"name\":/ ) {
                $name = $_;
                my @tmp = split( /:\s+/, $name );
                $name = $tmp[1];
                chop $name;     
                $host_id_name{$id} = $name;
                $id = '';
                $name = '';                         
            }       
        }
    }  

    if ($node_a_host_group_json_exist) {            
        open (FILE, $node_a_host_group_json) or die "Cannot open $node_a_host_group_json: $!\n";      
        my $id = '';
        my $name = '';
        while ( <FILE> ) {  
            $_ =~ s/^\s+|\s+$//g;
            if ( m/\"id\":/ ) {
                $id = $_;
                my @tmp = split( /:\s+/, $id );
                $id = $tmp[1];
                chop $id;               
            }

            if ( m/\"name\":/ ) {
                $name = $_;
                my @tmp = split( /:\s+/, $name );
                $name = $tmp[1];

                $host_group_id_name{$id} = $name;
                $id = '';
                $name = '';             
            }                       
        }
    } elsif ($node_b_host_group_json_exist) {
        open (FILE, $node_b_host_group_json) or die "Cannot open $node_a_host_group_json: $!\n";      
        my $id = '';
        my $name = '';
        while ( <FILE> ) {  
            $_ =~ s/^\s+|\s+$//g;
            if ( m/\"id\":/ ) {
                $id = $_;
                my @tmp = split( /:\s+/, $id );
                $id = $tmp[1];
                chop $id;               
            }

            if ( m/\"name\":/ ) {
                $name = $_;
                my @tmp = split( /:\s+/, $name );
                $name = $tmp[1];

                $host_group_id_name{$id} = $name;   
                $id = '';
                $name = '';                         
            }           
        }
    }

    if ($node_a_host_volume_mapping_json_exist) {            
        open (FILE, $node_a_host_volume_mapping_json) or die "Cannot open $node_a_host_volume_mapping_json: $!\n";      
        my $host_group_id = '';
        my $host_id = '';
        my $logical_unit_number = '';
        my $volume_id = '';
        
        while ( <FILE> ) {  
            $_ =~ s/^\s+|\s+$//g;

            if ( m/\"host_group_id\":/ ) {
                $host_group_id = $_;
                my @tmp = split( /:\s+/, $host_group_id );
                $host_group_id = $tmp[1];
                chop $host_group_id;    
            }

            if ( m/\"host_id\":/ ) {
                $host_id = $_;
                my @tmp = split( /:\s+/, $host_id );
                $host_id = $tmp[1];
                chop $host_id;  
            }

            if ( m/\"logical_unit_number\":/ ) {
                $logical_unit_number = $_;
                my @tmp = split( /:\s+/, $logical_unit_number );
                $logical_unit_number = $tmp[1];
                chop $logical_unit_number;              
            }   

            if ( m/\"volume_id\":/ ) {
                $volume_id = $_;
                my @tmp = split( /:\s+/, $volume_id );
                $volume_id = $tmp[1];
                chop $volume_id;        

                #$host_id_vol_attr{$host_id}{'logical_unit_number'} = $logical_unit_number if ( $host_id ne 'null' );
                #$host_id_vol_attr{$host_id}{'volume_id'} = $volume_id if ( $host_id ne 'null' );
                $host_id_vol_attr{$host_id}{$volume_id}{'logical_unit_number'} = $logical_unit_number if ( $host_id ne 'null' );
                $vol_id_hstattached{$volume_id} = 'y' if ( $host_id ne 'null' );

                #$host_group_id_vol_attr{$host_group_id}{'logical_unit_number'} = $logical_unit_number if ( $host_group_id ne 'null' );
                #$host_group_id_vol_attr{$host_group_id}{'volume_id'} = $volume_id if ( $host_group_id ne 'null' );
                $host_group_id_vol_attr{$host_group_id}{$volume_id}{'logical_unit_number'} = $logical_unit_number if ( $host_group_id ne 'null' );
                $vol_id_hstgrpattached{$volume_id} = 'y' if ( $host_group_id ne 'null' );
                                
                $host_group_id = '';
                $host_id = '';
                $logical_unit_number = '';
                $volume_id = '';
            }                   
        }
    } elsif ( $node_b_host_volume_mapping_json_exist ) {
        open (FILE, $node_b_host_volume_mapping_json) or die "Cannot open $node_b_host_volume_mapping_json: $!\n";      
        my $host_group_id = '';
        my $host_id = '';
        my $logical_unit_number = '';
        my $volume_id = '';
        
        while ( <FILE> ) {  
            $_ =~ s/^\s+|\s+$//g;

            if ( m/\"host_group_id\":/ ) {
                $host_group_id = $_;
                my @tmp = split( /:\s+/, $host_group_id );
                $host_group_id = $tmp[1];
                chop $host_group_id;    
            }

            if ( m/\"host_id\":/ ) {
                $host_id = $_;
                my @tmp = split( /:\s+/, $host_id );
                $host_id = $tmp[1];
                chop $host_id;  
            }

            if ( m/\"logical_unit_number\":/ ) {
                $logical_unit_number = $_;
                my @tmp = split( /:\s+/, $logical_unit_number );
                $logical_unit_number = $tmp[1];
                chop $logical_unit_number;              
            }   

            if ( m/\"volume_id\":/ ) {
                $volume_id = $_;
                my @tmp = split( /:\s+/, $volume_id );
                $volume_id = $tmp[1];
                chop $volume_id;        

                $host_id_vol_attr{$host_id}{'logical_unit_number'} = $logical_unit_number if ( $host_id ne 'null' );
                #$host_id_vol_attr{$host_id}{'volume_id'} = $volume_id if ( $host_id ne 'null' );
                $host_id_vol_attr{$host_id}{$volume_id}{'logical_unit_number'} = $logical_unit_number if ( $host_id ne 'null' );
                $vol_id_hstattached{$volume_id} = 'y' if ( $host_id ne 'null' );
                
                #$host_group_id_vol_attr{$host_group_id}{'logical_unit_number'} = $logical_unit_number if ( $host_group_id ne 'null' );
                #$host_group_id_vol_attr{$host_group_id}{'volume_id'} = $volume_id if ( $host_group_id ne 'null' );
                $host_group_id_vol_attr{$host_group_id}{$volume_id}{'logical_unit_number'} = $logical_unit_number if ( $host_group_id ne 'null' );
                $vol_id_hstgrpattached{$volume_id} = 'y' if ( $host_group_id ne 'null' );
                                
                $host_group_id = '';
                $host_id = '';
                $logical_unit_number = '';
                $volume_id = '';
            }                   
        }
    }

    print "[Host Volume Mapping List]\n";
        
    foreach my $vol_id ( keys %vol_id_name ) {

        if ( defined $vol_id_hstattached{$vol_id} && $vol_id_hstattached{$vol_id} eq 'y' ) {
            print "\n-------------------------------------------------------------------------------------------------------------------\n";
            print "| volume name                            | logical_unit_number   | host name                                      |\n";
            print "-------------------------------------------------------------------------------------------------------------------\n";
        }
   
        foreach my $hst_id ( keys %host_id_vol_attr ) {
            foreach my $hstvol_id ( keys %{$host_id_vol_attr{$hst_id}} ) {
                next if ( $hstvol_id ne $vol_id );
                
                my $vol_name = $vol_id_name{$vol_id};
                my $logic_unit_num = $host_id_vol_attr{$hst_id}{$hstvol_id}{'logical_unit_number'};
                my $host_name = $host_id_name{$hst_id};
                format HSTVOLMAP =
#-------------------------------------------------------------------------------------------------------------------
#| ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< |
#$vol_id_name{$vol_id}, $host_id_vol_attr{$hst_id}{$hstvol_id}{'logical_unit_number'}, $host_id_name{$hst_id}
#| ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< |
#$vol_id_name{$vol_id}, $host_id_vol_attr{$hst_id}{$hstvol_id}{'logical_unit_number'}, $host_id_name{$hst_id}
#| ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< |
#$vol_id_name{$vol_id}, $host_id_vol_attr{$hst_id}{$hstvol_id}{'logical_unit_number'}, $host_id_name{$hst_id}
#-------------------------------------------------------------------------------------------------------------------
#.
-------------------------------------------------------------------------------------------------------------------
| ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< |
$vol_name, $logic_unit_num, $host_name
| ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< |
$vol_name, $logic_unit_num, $host_name
| ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< |
$vol_name, $logic_unit_num, $host_name
-------------------------------------------------------------------------------------------------------------------
.
                $~ = HSTVOLMAP;
                write;
            }
        }
    }

    
    print "\n[Host Group Volume Mapping List]\n";
    #print "\n-------------------------------------------------------------------------------------------------------------------\n";
    #print "| volume name                            | logical_unit_number   | host group name                                |\n";
    #print "-------------------------------------------------------------------------------------------------------------------\n";
        
    foreach my $vol_id ( keys %vol_id_name ) {
    
        if ( defined $vol_id_hstgrpattached{$vol_id} && $vol_id_hstgrpattached{$vol_id} eq 'y' ) {
            print "\n-------------------------------------------------------------------------------------------------------------------\n";
            print "| volume name                            | logical_unit_number   | host group name                                |\n";
            print "-------------------------------------------------------------------------------------------------------------------\n";
        }    

        foreach my $hstgrp_id ( keys %host_group_id_vol_attr ) {
            foreach my $hstvol_id ( keys %{$host_group_id_vol_attr{$hstgrp_id}} ) {
                next if ( $hstvol_id ne $vol_id );

                my $vol_name = $vol_id_name{$vol_id};
                my $logic_unit_num = $host_group_id_vol_attr{$hstgrp_id}{$hstvol_id}{'logical_unit_number'};
                my $hstgrp_name = $host_group_id_name{$hstgrp_id};

                format HSTGRPVOLMAP =
-------------------------------------------------------------------------------------------------------------------
| ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< |
$vol_name, $logic_unit_num, $hstgrp_name
| ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< |
$vol_name, $logic_unit_num, $hstgrp_name
| ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< |
$vol_name, $logic_unit_num, $hstgrp_name
-------------------------------------------------------------------------------------------------------------------
.
                $~ = HSTGRPVOLMAP;
                write;
            }
        }
    }       
}
#######################################################################


#######################################################################
sub array_fe_port_info {
    print "\ncccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc\n";
    print "c Array Configuraiton Part: sub array_fe_port_info: Front Ports Info                           c\n";
    print "c log location: {DC_Filename}/node_*/command_output/housemd/show_feport.txt                c\n";
    print "cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc\n\n";

    if ($node_a_housemd_show_feport_txt_exist) {
        open(my $file,  "<",  $node_a_housemd_show_feport_txt)  or die "Can't open $node_a_housemd_show_feport_txt: $!";
        while (<$file>) {
            print "$_";
        }
        close $file;
    }
    
    if ($node_b_housemd_show_feport_txt_exist) {
        open(my $file,  "<",  $node_b_housemd_show_feport_txt)  or die "Can't open $node_b_housemd_show_feport_txt: $!";
        while (<$file>) {
            print "$_";
        }
        close $file;
    }
}
#######################################################################


#######################################################################
sub array_initiator_target_conn {
    print "\ncccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc\n";
    print "c Array Configuraiton Part: sub array_initiator_target_conn: initiator target active sessions  c\n";
    print "c log location: {DC_Filename}/node_*/command_output/housemd/show_initiators_connectivity.txt   c\n";
    print "cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc\n\n";

    if ($node_a_housemd_show_initiators_connectivity_txt_exist) {
        open(my $file,  "<",  $node_a_housemd_show_initiators_connectivity_txt)  or die "Can't open $node_a_housemd_show_initiators_connectivity_txt: $!";
        while (<$file>) {
            print "$_";
        }
        close $file;
    }
    
    if ($node_b_housemd_show_initiators_connectivity_txt_exist) {
        open(my $file,  "<",  $node_b_housemd_show_initiators_connectivity_txt)  or die "Can't open $node_b_housemd_show_initiators_connectivity_txt: $!";
        while (<$file>) {
            print "$_";
        }
        close $file;
    }
}
#######################################################################


my $tee2432_desc = '';
my $tee2432_cate = '';
my $tee2432_match = 'No';
#######################################################################
sub tee_2432_puhc_failure {
    print "\nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn\n";
    print "n NDU PUHC failure PST-X tee_2432_puhc_failure: Management IP not pingable between two nodes   n\n";
    print "n Impact is PUHC failure.                                                                      n\n";
    print "n For PST-X,                                                                                   n\n";
    print "n  The customer is required to connect the first two ports of the Mezzanine to his             n\n";
    print "n   Top-of-Rack switch.                                                                        n\n";
    print "n  Different from PowerStoreT, he should not configure LACP nor VLTi on the switch.            n\n";
    print "n Example PST-X                                                                                n\n";
    print "n  10.20.1.32 nodea coreos                                                                     n\n";
    print "n  10.20.1.33 nodeb coreos                                                                     n\n";
    print "n  10.20.1.34 esx host 1                                                                       n\n";
    print "n  10.20.1.35 esx host 2                                                                       n\n";
    print "n  10.20.1.31 appliance                                                                        n\n";
    print "n  10.20.1.30 cluster                                                                          n\n";
    print "n journal alert: Oct 08 12:20:16 APM01210308694-A control-path[18904]: Alert Notification :    n\n";
    print "n  ONV_ICC_MGMT_PING_STATUS_UNREACHABLE (0x01802B02) ObjectId:N2 Type:node ApplianceSN:A1      n\n";
    print "n  Raised:2021-10-08T12:09:40.391Z Severity:Major The following management network addresses   n\n";
    print "n  are not reachable via ICMP from node network interfaces:                                    n\n"; 
    print "n  (from 10.20.1.33 : 10.20.1.30, 10.20.1.32).                                                 n\n";
    print "n coreos/container troubleshooting:                                                            n\n";
    print "n esx host troubleshooting:                                                                    n\n";
    print "n  root\@PWRSTRCLTR4-host-1:~] esxcli network ip interface ipv4 get                             n\n";
    print "n  Name IPv4 Address IPv4 Netmask IPv4 Broadcast Address Type Gateway DHCP DNS                 n\n";
    print "n  ----- ------------- --------------- -------------- ------------ --------- --------          n\n";
    print "n  vmk0 10.20.1.34 255.255.255.0 10.20.1.255 STATIC 0.0.0.0 false                              n\n";
    print "n  vmk10 128.221.255.1 255.255.255.252 128.221.255.3 STATIC 0.0.0.0 false                      n\n";
    print "n  vmk1 10.20.4.72 255.255.255.0 10.20.4.255 STATIC 10.20.4.1 false                            n\n";
    print "n  vmk2 10.20.4.74 255.255.255.0 10.20.4.255 STATIC 10.20.4.1 false                            n\n";
    print "n  vmk3 10.20.7.105 255.255.255.0 10.20.7.255 STATIC 0.0.0.0 false                             n\n";
    print "n  [root\@PWRSTRCLTR4-host-1:~] ping -I vmk0 10.20.1.33                                         n\n";
    print "n  PING 10.20.1.33 (10.20.1.33): 56 data bytes                                                 n\n";
    print "n  64 bytes from 10.20.1.33: icmp_seq=0 ttl=128 time=5.275 ms                                  n\n";
    print "n  64 bytes from 10.20.1.33: icmp_seq=1 ttl=128 time=9.217 ms                                  n\n";
    print "n                                                                                              n\n";
    print "n  [root\@PWRSTRCLTR4-host-1:~] esxcli network nic list                                         n\n";
    print "n  Name PCI Device Driver Admin Status Link Status Speed Duplex MAC Address MTU Description    n\n";
    print "n  ------ ------------ ------- ------------ ----------- ----- ------ ----------------- ----    n\n";
    print "n  vmnic2 0000:0b:00.0 qedentv Up Down 0 Half 0c:48:c6:71:a4:94 1500 QLogic Corp. QLogic FastLinQ QL41xxx 1/10/25 GbE Ethernet Adapter   n\n";
    print "n  vmnic3 0000:0b:00.1 qedentv Up Down 0 Half 0c:48:c6:71:a4:95 1500 QLogic Corp. QLogic FastLinQ QL41xxx 1/10/25 GbE Ethernet Adapter   n\n";
    print "n  vmnic4 0000:0b:00.2 qedentv Up Up 10000 Full 0c:48:c6:71:a4:96 1500 QLogic Corp. QLogic FastLinQ QL41xxx 1/10/25 GbE Ethernet Adapter n\n";
    print "n  vmnic5 0000:0b:00.3 qedentv Up Up 10000 Full 0c:48:c6:71:a4:97 1500 QLogic Corp. QLogic FastLinQ QL41xxx 1/10/25 GbE Ethernet Adapter n\n";
    print "n                                                                                              n\n";
    print "n switch: show lldp neighbor                                                                   n\n";
    print "n  Te 1/17        PWRSTRCLTR4-hos...0c:48:c6:71:a4:96                  vmnic4                  n\n";             
    print "n  Te 1/18        PWRSTRCLTR4-hos...0c:48:c6:71:a3:a7                  vmnic5                  n\n";
    print "n vmnic5, vmnic4 are mezz0 first port 0 and 1                                                  n\n";
    print "n physical port mac address could be discovered by switch via lldp                             n\n";
    print "n In coreos/container, mac for coreos ip and appliance , cluster ip are virtual                n\n";
    print "n  10.20.1.32 -> 10.20.1.33                                                                    n\n";
    print "n  00:0c:29:fc:bb:f9 -> 00:0c:29:87:b8:9a                                                      n\n";
    print "nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn\n\n";

    my $count = 0;
    print "[node_a journal]\n";
    foreach ( @node_a_tee_2432 ) {
        print $_."\n";
        $count++;
        last if ($count >= 10);
    }

    $count = 0;
    print "\n[node_b journal]\n";
    foreach ( @node_b_tee_2432 ) {
        print $_."\n";
        $count++;
        last if ($count >= 10);
    }

    $tee2432_desc = 'NDU PUHC failure PST-X tee_2432_puhc_failure';
    $tee2432_cate = 'Journal';
    $tee2432_match = 'Yes' if ( $#node_a_tee_2432 >= 0 or $#node_b_tee_2432 >= 0 );     
}
#######################################################################


my $tee2345_desc = '';
my $tee2345_cate = '';
my $tee2345_match = 'No';
#######################################################################
sub tee_2345_hardware_failure {
    print "\nhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh\n";
    print "h Hardware Enclosure Mis-cable and SSD Drives not recognized in Enclosure tee_2345_hardware_failure h\n";
    print "h tee-2345, tee-2361                                                                           h\n";
    print "h 1. Enclosure connection reference:                                                           h\n";
    print "  -------------------------------------------|                                                 h\n";
    print "  |                                        --]--------------------|                            h\n";
    print "  |                                        | |                    |                            h\n";
    print "  |          ==============================|=|===============     |                            h\n";
    print "  |      B  |   - -   |         O          O O               |    |                            h\n";
    print "  |         |    -    |                    A B               |    |                            h\n";
    print "  |Expansion|================================================     |                            h\n";
    print "  |         |               B A                    |    _    |    |                            h\n";
    print "  |      A  |               O O          O         |   - -   |    |                            h\n";
    print "  |          ===============|=|==============================     |                            h\n";
    print "  |                         |-]---------------------              |                            h\n";
    print "  |                           |                    |              |                            h\n";
    print "  |   |------------------------                    |              |                            h\n";
    print "  |   |                                          |-[---------------                            h\n";
    print "  |   |     =====================================|=|=========                                  h\n";
    print "  |   |  B  |   - -   |  |OOOO|   |OOOO|      O  O O  |OOOO| |                                 h\n";
    print "  |   |     |    -    |                          B A         |                                 h\n";
    print "  |   |     |================================================                                  h\n";
    print "  |   |     |  ____   A B  O       ____     ____   |    -    |                                 h\n";
    print "  |   |  A  | |OOOO|  O O  O      |OOOO|   |OOOO|  |   - -   |                                 h\n";
    print "  |   |      =========|=|====================================                                  h\n";
    print "  |---[---------------| |                                                                      h\n";
    print "      ------------------|                                                                      h\n";
    print "h                                                                                              h\n";    
    print "h NOTE When adding an expansion enclosure to a running system, you must power on the expansion h\n";
    print "h enclosure before attaching the back-end cables.                                              h\n"; 
    print "h Please refer to solveonline. https://solveonline.emc.com/solve/home/70                       h\n"; 
    print "h mis-cable error log may not indicate real cable issue. it is still hardware related.         h\n";
    print "h reboot node is worth to try.                                                                 h\n";
    print "hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh\n\n";

    print "[node_a journal]\n";
    my $count = 0;
    foreach ( @node_a_tee_2345 ) {
        print $_."\n";
        $count++;
        last if ( $count >= 20 );
    }

    print "\n[node_b journal]\n";
    $count = 0;
    foreach ( @node_b_tee_2345 ) {
        print $_."\n";
        $count++;
        last if ( $count >= 20 );        
    }

    $tee2345_desc = 'Hardware Enclosure Mis-cable and SSD Drives not recognized in Enclosure tee_2345';
    $tee2345_cate = 'Journal';
    $tee2345_match = 'Yes' if ( $#node_a_tee_2345 >= 0 or $#node_b_tee_2345 >= 0 );     
}
#######################################################################


#######################################################################
sub tee_1673_hardware_failure {
    print "\nhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh\n";
    print "h Expansion enclosure is not supported, tee_1844, tee_2345, tee_1673_hardware_failure:         h\n";
    print "h Impact is alert for enclosure.                                                               h\n";
    print "h Alert example:                                                                               h\n";
    print "h  ACTIVE Major ExpansionEnclosure_1_1 false 0x0030ca02 Expansion enclosure lifecycle          h\n";
    print "h   compatibility status has changed. (unsupported) Expansion enclosure 1 at                   h\n";
    print "h   bus 1 is not supported for this system.                                                    h\n"; 
    print "h From node_x/command_output/pmcli/enclmgmt.txt                                                h\n";
    print "h   Enclosure P/N is probably missing from one node. Both nodes enclousre part number          h\n";
    print "h    should be recoganized and same on two sides.                                              h\n";
    print "h  example:                                                                                    h\n";
    print "h  Bus 1 Enclosure 0 Side 1 Info:                                                              h\n";
    print "h    enclosure part number:   <---missing                                                      h\n";
    print "h  Bus 1 Enclosure 0 Side 2 Info:                                                              h\n";
    print "h    enclosure part number:100-566-114-01                                                      h\n";  
    print "h Root Cause: Failed to read the resume prom failed, the chassis ffid and DST were missing.    h\n";
    print "h Workaround:                                                                                  h\n";
    print "h  Reboot each node one at time                                                                h\n";
    print "h https://www.dell.com/support/kbdoc/en-us/000192167                                           h\n";
    print "hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh\n\n";

    print "[node_a journal]\n";
    foreach ( @node_a_tee_1673 ) {
        print $_."\n";
    }

    print "\n[node_b journal]\n";
    foreach ( @node_b_tee_1673 ) {
        print $_."\n";
    }

    print "\n[node-a enclmgmt.txt]\n";
    if ($node_a_enclmgmt_txt_exist) {
        open(my $file,  "<",  $node_a_enclmgmt_txt)  or die "Can't open $node_a_enclmgmt_txt: $!";
        while (<$file>) {
            print "$_" if ( m/Enclosure/ );
            print "$_" if ( m/enclosure part/ );
        }
        close $file;
    }

    print "\n[node-b enclmgmt.txt]\n";
    if ($node_b_enclmgmt_txt_exist) {
        open(my $file,  "<",  $node_b_enclmgmt_txt)  or die "Can't open $node_b_enclmgmt_txt: $!";
        while (<$file>) {
            print "$_" if ( m/Enclosure/ );
            print "$_" if ( m/enclosure part/ );
        }
        close $file;
    }
}
#######################################################################


#######################################################################
sub kb_scsi_perf_statistic {
    print "\npppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppp\n";
    print "p SCSI Statistic Report kb_scsi_perf_statistic:                                                p\n";
    print "p -----------------                                                                            p\n";
    print "p SCSI Status Code                                                                             p\n";
    print "p  SCSI Status codes appear in the Status byte returned when the processing of a SCSI command completes. p\n";
    print "p  00h GOOD                                                                                    p\n";
    print "p  02h CHECK CONDITION                                                                         p\n";
    print "p  04h CONDITION MET                                                                           p\n";
    print "p  08h BUSY                                                                                    p\n";
    print "p  18h RESERVATION CONFLICT                                                                    p\n";
    print "p  28h TASK SET FULL                                                                           p\n";
    print "p  30h ACA ACTIVE                                                                              p\n";
    print "p  40h TASK ABORTED                                                                            p\n";
    print "p -----------------                                                                            p\n";
    print "pppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppp\n\n";
    
    my %node_a_initiator_0x28 = ();
    my %node_b_initiator_0x28 = ();
    
    foreach ( @node_a_scsi_status_0x28 ) {
        my @params = split( /\s+/, $_ );
        my $hit = 0;
        foreach my $param ( @params ) {
            if ( $param =~ m/Initiator/ ) {
                $hit = 1;
                next;
            }
            $hit = 0 if ( $param =~ m/opcode/ );
            $node_a_initiator_0x28{$param} ++ if ( $hit == 1 );
        }
    }

    foreach ( @node_b_scsi_status_0x28 ) {
        my @params = split( /\s+/, $_ );
        my $hit = 0;
        foreach my $param ( @params ) {
            if ( $param =~ m/Initiator/ ) {
                $hit = 1;
                next;
            }
            $hit = 0 if ( $param =~ m/opcode/ );
            $node_b_initiator_0x28{$param} ++ if ( $hit == 1 );
        }
    }

    print "[node_a journal]\n";
    foreach my $initiator (keys %node_a_initiator_0x28) {
        print "Initiator: $initiator   0x28: $node_a_initiator_0x28{$initiator} \n";
    }
    
    print "\n[node_b journal]\n";
    foreach my $initiator (keys %node_b_initiator_0x28) {
        print "Initiator: $initiator   0x28: $node_b_initiator_0x28{$initiator} \n";
    }
}
#######################################################################


#######################################################################
sub kb_ats_scsi2_conflict_failure {
    print "\npppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppp\n";
    print "p SCSI Reservation Conflict Statistic Report MDT-240046 kb_ats_scsi2_conflict_failure:         p\n";
    print "p Impact:                                                                                      p\n"; 
    print "p Mix of ATS and SCSI2 reservation on the same volume may resulted in deadlock                 p\n";
    print "p  of CAW and SCSI2 reservation.                                                               p\n";
    print "p As a result, the affected Node will reboot due to the deadlock which cause the CAW and       p\n";
    print "p  SCSI2 reservation staying outstanding for too long.                                         p\n";
    print "p The most direct evidence of this issue is that if you search SCSI commands where are in      p\n";
    print "p  EXEC_CHECK_BLOCKING status, you will see there are a lot of SCSI commands                   p\n";
    print "p  in this EXEC_CHECK_BLOCKING.                                                                p\n";
    print "p And they are COMPARE AND WRITE (CAW for ATS) and RESERVE (stands for SCSI2 reservation).     p\n";
    print "p  Their proc time is very large (it could be several hundred secs to more than 1000,          p\n";
    print "p  in the following examples, they are more than 1000 sec), which is way more than             p\n";
    print "p  the timeout 60 sec.                                                                         p\n";
    print "p These CAW and RESERVE may come from a same host or from different hosts.                     p\n";
    print "p https://confluence.cec.lab.emc.com/display/ETS/Mix+of+ATS+Compare+And+Write+and+SCSI2+Reservation+Cause+Node+Reboot p\n";
    print "p What is ATS reservation and SCSI2 reservation:                                               p\n";
    print "p  please refer to mdt_218936_perf_failure in report.                                          p\n";
    print "p Attention: statistic covers all journal log time range. It is better to run report for two   p\n";
    print "p  support materials then compare the number.                                                  p\n";
    print "pppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppp\n\n";

    my %node_a_target_initiator_ats = ();
    my %node_b_target_initiator_ats = ();
    my %node_a_target_initiator_scsi2 = ();
    my %node_b_target_initiator_scsi2 = ();
    
    foreach ( @node_a_ats_lock_block ) {
        my @params = split( /\s+/, $_ );
        my $ihit = 0;
        my $thit = 0;
        my $initiator = '';
        my $target = '';
        foreach my $param ( @params ) {
            if ( $param eq 'initiator' or $param eq 'ini') {
                $ihit = 1;
                next;
            }

            if ( $param eq 'target' or $param eq 'tgt') {
                $thit = 1;
                next;
            }           
            
            if ( $ihit == 1 ) {
                $initiator = $param;
                $ihit = 0;
            }

            if ( $thit == 1 ) {
                $target = $param;
                $thit = 0;
            }
        }

        if ( $initiator ne '' and $target ne '' ) {
            $node_a_target_initiator_ats{$target}{$initiator}++;
        }
    }

    foreach ( @node_b_ats_lock_block ) {
        my @params = split( /\s+/, $_ );
        my $ihit = 0;
        my $thit = 0;
        my $initiator = '';
        my $target = '';
        foreach my $param ( @params ) {
            if ( $param eq 'initiator' or $param eq 'ini') {
                $ihit = 1;
                next;
            }

            if ( $param eq 'target' or $param eq 'tgt') {
                $thit = 1;
                next;
            }           
            
            if ( $ihit == 1 ) {
                $initiator = $param;
                $ihit = 0;
            }

            if ( $thit == 1 ) {
                $target = $param;
                $thit = 0;
            }
        }

        if ( $initiator ne '' and $target ne '' ) {
            $node_b_target_initiator_ats{$target}{$initiator}++;
        }
    }

    foreach ( @node_a_scsi_lock_block ) {
        my @params = split( /\s+/, $_ );
        my $ihit = 0;
        my $thit = 0;
        my $initiator = '';
        my $target = '';
        foreach my $param ( @params ) {
            if ( $param eq 'initiator' or $param eq 'ini') {
                $ihit = 1;
                next;
            }

            if ( $param eq 'target' or $param eq 'tgt') {
                $thit = 1;
                next;
            }           
            
            if ( $ihit == 1 ) {
                $initiator = $param;
                $ihit = 0;
            }

            if ( $thit == 1 ) {
                $target = $param;
                $thit = 0;
            }
        }

        if ( $initiator ne '' and $target ne '' ) {
            $node_a_target_initiator_scsi2{$target}{$initiator}++;
        }
    }

    foreach ( @node_b_scsi_lock_block ) {
        my @params = split( /\s+/, $_ );
        my $ihit = 0;
        my $thit = 0;
        my $initiator = '';
        my $target = '';
        foreach my $param ( @params ) {
            if ( $param eq 'initiator' or $param eq 'ini') {
                $ihit = 1;
                next;
            }

            if ( $param eq 'target' or $param eq 'tgt') {
                $thit = 1;
                next;
            }           
            
            if ( $ihit == 1 ) {
                $initiator = $param;
                $ihit = 0;
            }

            if ( $thit == 1 ) {
                $target = $param;
                $thit = 0;
            }
        }

        if ( $initiator ne '' and $target ne '' ) {
            $node_b_target_initiator_scsi2{$target}{$initiator}++;
        }
    }

    print "[node_a ats reservation block]\n"; 
    foreach my $target ( keys %node_a_target_initiator_ats ) {
        print "Target: $target \n";
        foreach my $initiator ( keys %{$node_a_target_initiator_ats{$target}} ) {
            print " initiator: $initiator   ats_reservation_block: $node_a_target_initiator_ats{$target}{$initiator}\n";
        }
    }
    
    print "\n[node_b ats reservation block]\n"; 
    foreach my $target ( keys %node_b_target_initiator_ats ) {
        print "Target: $target \n";
        foreach my $initiator ( keys %{$node_b_target_initiator_ats{$target}} ) {
            print " initiator: $initiator   ats_reservation_block: $node_b_target_initiator_ats{$target}{$initiator}\n";
        }
    }

    print "\n[node_a scsi2 reservation block]\n"; 
    foreach my $target ( keys %node_a_target_initiator_scsi2 ) {
        print "Target: $target \n";
        foreach my $initiator ( keys %{$node_a_target_initiator_scsi2{$target}} ) {
            print " initiator: $initiator   scsi2_reservation_block: $node_a_target_initiator_scsi2{$target}{$initiator}\n";
        }
    }
    
    print "\n[node_b scsi2 reservation block]\n"; 
    foreach my $target ( keys %node_b_target_initiator_scsi2 ) {
        print "Target: $target \n";
        foreach my $initiator ( keys %{$node_b_target_initiator_scsi2{$target}} ) {
            print " initiator: $initiator   scsi2_reservation_block: $node_b_target_initiator_scsi2{$target}{$initiator}\n";
        }
    }   

    print "\n[node_a state EXEC_CHECK_BLOCKING: journal]\n";
    my $count = 0;
    foreach (@node_a_reservation_block) {
        print $_."\n";
        $count++;
        last if ($count >= 10);
    }

    print "\n[node_b state EXEC_CHECK_BLOCKING: journal]\n";
    $count = 0;
    foreach (@node_b_reservation_block) {
        print $_."\n";
        $count++;
        last if ($count >= 10);
    }   
}
#######################################################################


#######################################################################
sub kb_abort_statistic {
    print "\npppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppp\n";
    print "p Performance Abort Statistic Report kb_abort_statistic:                                       p\n";
    print "p http://www.t10.org/lists/2op.htm                                                             p\n";
    print "p https://en.wikipedia.org/wiki/SCSI_command                                                   p\n";
    print "p 00  TEST UNIT READY                                                                          p\n";
    print "p 01  REWIND                                                                                   p\n";
    print "p 03  REQUEST SENSE                                                                            p\n";
    print "p 04  FORMAT                                                                                   p\n";
    print "p 05  READ BLOCK LIMITS                                                                        p\n";
    print "p 07  REASSIGN BLOCKS                                                                          p\n";
    print "p 07  INITIALIZE ELEMENT STATUS                                                                p\n";
    print "p 08  READ(6)                                                                                  p\n";
    print "p 0A  WRITE(6)                                                                                 p\n";
    print "p 0B  SEEK(6)                                                                                  p\n";
    print "p 0F  READ REVERSE(6)                                                                          p\n";
    print "p 10  WRITE FILEMARKS(6)                                                                       p\n";
    print "p 11  SPACE(6)                                                                                 p\n";
    print "p 12  INQUIRY                                                                                  p\n";
    print "p 13  VERIFY(6)                                                                                p\n";
    print "p 14  RECOVER BUFFERED DATA                                                                    p\n";
    print "p 15  MODE SELECT(6)                                                                           p\n";
    print "p 16  RESERVE(6)                                                                               p\n";
    print "p 17  RELEASE(6)                                                                               p\n";
    print "p 18  COPY                                                                                     p\n";
    print "p 19  ERASE (6)                                                                                p\n";
    print "p 1A  MODE SENSE (6)                                                                           p\n";
    print "p 1B  START STOP UNIT                                                                          p\n";
    print "p 1B  LOAD UNLOAD                                                                              p\n";
    print "p 1C  RECEIVE DIAGNOSTIC RESULTS                                                               p\n";
    print "p 1D  SEND DIAGNOSTIC                                                                          p\n";
    print "p 1E  PREVENT ALLOW MEDIUM REMOVAL                                                             p\n";
    print "p 23  READ FORMAT CAPACITIES                                                                   p\n";
    print "p 25  READ CAPACITY(10)                                                                        p\n";
    print "p 28  READ(10)                                                                                 p\n";
    print "p 29  READ GENERATION                                                                          p\n";
    print "p 2A  WRITE(10)                                                                                p\n";
    print "p 2B  SEEK(10)                                                                                 p\n";
    print "p 2B  LOCATE(10)                                                                               p\n";
    print "p 2C  ERASE(10)                                                                                p\n";
    print "p 2D  READ UPDATED BLOCK                                                                       p\n";
    print "p 2E  WRITE AND VERIFY(10)                                                                     p\n";
    print "p 2F  VERIFY(10)                                                                               p\n";
    print "p 33  SET LIMITS(10)                                                                           p\n";
    print "p 34  PRE-FETCH(10)                                                                            p\n";
    print "p 34  READ POSITION                                                                            p\n";
    print "p 35  SYNCHRONIZE CACHE(10)                                                                    p\n";
    print "p 36  LOCK UNLOCK CACHE(10)                                                                    p\n";
    print "p 37  READ DEFECT DATA(10)                                                                     p\n";
    print "p 37  INITIALIZE ELEMENT STATUS WITH RANGE                                                     p\n";
    print "p 38  MEDIUM SCAN                                                                              p\n";
    print "p 39  COMPARE                                                                                  p\n";
    print "p 3A  COPY AND VERIFY                                                                          p\n";
    print "p 3B  WRITE BUFFER                                                                             p\n";
    print "p 3C  READ BUFFER                                                                              p\n";
    print "p 3D  UPDATE BLOCK                                                                             p\n";
    print "p 3E  READ LONG(10)                                                                            p\n";
    print "p 3F  WRITE LONG(10)                                                                           p\n";
    print "p 40  CHANGE DEFINITION                                                                        p\n";
    print "p 41  WRITE SAME(10)                                                                           p\n";
    print "p 42  UNMAP                                                                                    p\n";
    print "p 43  READ TOC/PMA/ATIP                                                                        p\n";
    print "p 44  REPORT DENSITY SUPPORT                                                                   p\n";
    print "p 4B  PAUSE/RESUME                                                                             p\n";
    print "p 4C  LOG SELECT                                                                               p\n";
    print "p 4D  LOG SENSE                                                                                p\n";
    print "p 50  XDWRITE(10)                                                                              p\n";
    print "p 51  XPWRITE(10)                                                                              p\n";
    print "p 51  READ DISC INFORMATION                                                                    p\n";
    print "p 52  XDREAD(10)                                                                               p\n";
    print "p 53  XDWRITEREAD(10)                                                                          p\n";
    print "p 54  SEND OPC INFORMATION                                                                     p\n";
    print "p 55  MODE SELECT(10)                                                                          p\n";
    print "p 5A  MODE SENSE(10)                                                                           p\n";
    print "p 5B  CLOSE TRACK/SESSION                                                                      p\n";
    print "p 5C  READ BUFFER CAPACITY                                                                     p\n";
    print "p 5D  SEND CUE SHEET                                                                           p\n";
    print "p 5E  PERSISTENT RESERVE IN                                                                    p\n";
    print "p 5F  PERSISTENT RESERVE OUT                                                                   p\n";
    print "p 80  XDWRITE EXTENDED(16)                                                                     p\n";
    print "p 80  WRITE FILEMARKS(16)                                                                      p\n";
    print "p 81  READ REVERSE(16)                                                                         p\n";
    print "p 83  Third-party Copy OUT commands                                                            p\n";
    print "p 84  Third-party Copy IN commands                                                             p\n";
    print "p 85  ATA PASS-THROUGH(16)                                                                     p\n";
    print "p 86  ACCESS CONTROL IN                                                                        p\n";
    print "p 87  ACCESS CONTROL OUT                                                                       p\n";
    print "p 88  READ(16)                                                                                 p\n";
    print "p 89  COMPARE AND WRITE                                                                        p\n";
    print "p 8A  WRITE(16)                                                                                p\n";
    print "p 8B  ORWRITE                                                                                  p\n";
    print "p 8C  READ ATTRIBUTE                                                                           p\n";
    print "p 8D  WRITE ATTRIBUTE                                                                          p\n";
    print "p 8E  WRITE AND VERIFY(16)                                                                     p\n";
    print "p 8F  VERIFY(16)                                                                               p\n";
    print "p 90  PRE-FETCH(16)                                                                            p\n";
    print "p 91  SYNCHRONIZE CACHE(16)                                                                    p\n";
    print "p 91  SPACE(16)                                                                                p\n";
    print "p 92  LOCK UNLOCK CACHE(16)                                                                    p\n";
    print "p 92  LOCATE(16)                                                                               p\n";
    print "p 93  WRITE SAME(16)                                                                           p\n";
    print "p 93  ERASE(16)                                                                                p\n";
    print "p A0  REPORT LUNS                                                                              p\n";
    print "p A1  ATA PASS-THROUGH(12)                                                                     p\n";
    print "p A2  SECURITY PROTOCOL IN                                                                     p\n";
    print "p A3  MAINTENANCE IN                                                                           p\n";
    print "p A4  MAINTENANCE OUT                                                                          p\n";
    print "p A4  REPORT KEY                                                                               p\n";
    print "p A5  MOVE MEDIUM                                                                              p\n";
    print "p A5  PLAY AUDIO 12                                                                            p\n";
    print "p A6  EXCHANGE MEDIUM                                                                          p\n";
    print "p A7  MOVE MEDIUM ATTACHED                                                                     p\n";
    print "p A8  READ(12)                                                                                 p\n";
    print "p A9  SERVICE ACTION OUT(12)                                                                   p\n";
    print "p AA  WRITE(12)                                                                                p\n";
    print "p Attention: statistic covers all journal log time range. It is better to run report for two   p\n";
    print "p  support materials then compare the number.                                                  p\n";    
    print "pppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppp\n\n";

    my %node_a_io_operation_failure_initiator_op = ();
    my %node_b_io_operation_failure_initiator_op = ();
    
    foreach ( @node_a_io_operation_failure ) {
        my @params = split( /\s+/, $_ );
        my $ihit = 0;
        my $thit = 0;
        my $initiator = '';
        my $cdbop = '';
        foreach my $param ( @params ) {
            if ( $param =~ m/CDBOp/ ) {
                $cdbop = $param;
                $ihit = 1;
            }
            
            if ( $param =~ m/initiator_name/ ) {
                $initiator = $param;
                $thit = 1; 
            }

            if ( $ihit == 1 and $thit == 1 ) {
                $node_a_io_operation_failure_initiator_op{$initiator}{$cdbop}++;
            }
        }
    }

    foreach ( @node_b_io_operation_failure ) {
        my @params = split( /\s+/, $_ );
        my $ihit = 0;
        my $thit = 0;
        my $initiator = '';
        my $cdbop = '';
        foreach my $param ( @params ) {
            if ( $param =~ m/CDBOp/ ) {
                $cdbop = $param;
                $ihit = 1;
            }
            
            if ( $param =~ m/initiator_name/ ) {
                $initiator = $param;
                $thit = 1; 
            }

            if ( $ihit == 1 and $thit == 1 ) {
                $node_b_io_operation_failure_initiator_op{$initiator}{$cdbop}++;
            }
        }
    }

    print "[node_a journal]\n";
    foreach my $initiator ( keys %node_a_io_operation_failure_initiator_op ) {
        print "initiator: $initiator \n";
        foreach my $cdbop ( keys %{$node_a_io_operation_failure_initiator_op{$initiator}} ) {
            print " operation: $cdbop   total aborts -> $node_a_io_operation_failure_initiator_op{$initiator}{$cdbop}\n";
        }
    }
    
    print "\n[node_b journal]\n";
    foreach my $initiator ( keys %node_b_io_operation_failure_initiator_op ) {
        print "initiator: $initiator \n";
        foreach my $cdbop ( keys %{$node_b_io_operation_failure_initiator_op{$initiator}} ) {
            print " operation: $cdbop   total aborts -> $node_b_io_operation_failure_initiator_op{$initiator}{$cdbop}\n";
        }
    }
}
#######################################################################


#######################################################################
sub kb_scsi_sense_statistic {
    print "\npppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppp\n";
    print "p                                      SCSI Sense Keys                                         p\n";
    print "p SCSI Sense Keys appear in the Sense Data available when a command completes with a CHECK CONDITION status p\n";
    print "p Code        Name                                                                             p\n";
    print "p 0h       NO SENSE                                                                            p\n";
    print "p 1h       RECOVERED ERROR                                                                     p\n";
    print "p 2h       NOT READY                                                                           p\n";
    print "p 3h       MEDIUM ERROR                                                                        p\n";
    print "p 4h       HARDWARE ERROR                                                                      p\n";
    print "p 5h       ILLEGAL REQUEST                                                                     p\n";
    print "p 6h       UNIT ATTENTION                                                                      p\n";
    print "p 7h       DATA PROTECT                                                                        p\n";
    print "p 8h       BLANK CHECK                                                                         p\n";
    print "p 9h       VENDOR SPECIFIC                                                                     p\n";
    print "p Ah       COPY ABORTED                                                                        p\n";
    print "p Bh       ABORTED COMMAND                                                                     p\n";
    print "p Dh       VOLUME OVERFLOW                                                                     p\n";
    print "p Eh       MISCOMPARE                                                                          p\n";
    print "p Fh       COMPLETED                                                                           p\n";
    print "p http://www.t10.org/lists/2sensekey.htm                                                       p\n";
    print "p Attention: statistic covers all journal log time range. It is better to run report for two   p\n";
    print "p  support materials then compare the number.                                                  p\n";    
    print "pppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppp\n\n";

    my %node_a_checkcondition_initiator = ();
    my %node_b_checkcondition_initiator = ();
    
    foreach ( @node_a_initiator_cc ) {
        my @params = split( /\s+/, $_ );
        my $ihit = 0;
        my $thit = 0;
        my $initiator = '';
        my $sensekey = '';
        foreach my $param ( @params ) {
            if ( $param eq 'Initiator' ) {
                $ihit = 1;
                next;
            }
            
            if ( $param eq 'Condition' ) {
                $thit = 1; 
                next;
            }

            if ( $ihit == 1 ) {
                $initiator = $param;
                $ihit = 0;
            }

            if ( $thit == 1 ) {
                $sensekey = $param;
                $thit = 0;
            }

            if ( $initiator ne '' and $sensekey ne '' ) {
                $node_a_checkcondition_initiator{$sensekey}{$initiator}++;
            }
        }
    }

    foreach ( @node_b_initiator_cc ) {
        my @params = split( /\s+/, $_ );
        my $ihit = 0;
        my $thit = 0;
        my $initiator = '';
        my $sensekey = '';
        foreach my $param ( @params ) {
            if ( $param eq 'Initiator' ) {
                $ihit = 1;
                next;
            }
            
            if ( $param eq 'Condition' ) {
                $thit = 1; 
                next;
            }

            if ( $ihit == 1 ) {
                $initiator = $param;
                $ihit = 0;
            }

            if ( $thit == 1 ) {
                $sensekey = $param;
                $thit = 0;
            }

            if ( $initiator ne '' and $sensekey ne '' ) {
                $node_b_checkcondition_initiator{$sensekey}{$initiator}++;
            }
        }
    }

    print "[node_a journal]\n";
    print "Target Command Check Condition: SK=0x00\n";
    foreach my $sensekey ( keys %node_a_checkcondition_initiator ) {
        if ( $sensekey =~ m/^00\// ) {
            foreach my $initiator ( keys %{$node_a_checkcondition_initiator{$sensekey}} ) {
                print " initiator: $initiator   total number -> $node_a_checkcondition_initiator{$sensekey}{$initiator}\n";
            }
        }
    }

    print "\nTarget Command Check Condition: SK=0x01\n";
    foreach my $sensekey ( keys %node_a_checkcondition_initiator ) {
        if ( $sensekey =~ m/^01\// ) {
            foreach my $initiator ( keys %{$node_a_checkcondition_initiator{$sensekey}} ) {
                print " initiator: $initiator   total number -> $node_a_checkcondition_initiator{$sensekey}{$initiator}\n";
            }
        }
    }   

    print "\nTarget Command Check Condition: SK=0x02\n";
    foreach my $sensekey ( keys %node_a_checkcondition_initiator ) {
        if ( $sensekey =~ m/^02\// ) {
            foreach my $initiator ( keys %{$node_a_checkcondition_initiator{$sensekey}} ) {
                print " initiator: $initiator   total number -> $node_a_checkcondition_initiator{$sensekey}{$initiator}\n";
            }
        }
    }

    print "\nTarget Command Check Condition: SK=0x03\n";
    foreach my $sensekey ( keys %node_a_checkcondition_initiator ) {
        if ( $sensekey =~ m/^03\// ) {
            foreach my $initiator ( keys %{$node_a_checkcondition_initiator{$sensekey}} ) {
                print " initiator: $initiator   total number -> $node_a_checkcondition_initiator{$sensekey}{$initiator}\n";
            }
        }
    }   

    print "\nTarget Command Check Condition: SK=0x04\n";
    foreach my $sensekey ( keys %node_a_checkcondition_initiator ) {
        if ( $sensekey =~ m/^04\// ) {
            foreach my $initiator ( keys %{$node_a_checkcondition_initiator{$sensekey}} ) {
                print " initiator: $initiator   total number -> $node_a_checkcondition_initiator{$sensekey}{$initiator}\n";
            }
        }
    }   

    print "\nTarget Command Check Condition: SK=0x05\n";
    foreach my $sensekey ( keys %node_a_checkcondition_initiator ) {
        if ( $sensekey =~ m/^05\// ) {
            foreach my $initiator ( keys %{$node_a_checkcondition_initiator{$sensekey}} ) {
                print " initiator: $initiator   total number -> $node_a_checkcondition_initiator{$sensekey}{$initiator}\n";
            }
        }
    }   

    print "\n[SK = 0x05 ASC/Q = 2400]\n";
    print "Possible cause: https://community.emc.com/docs/DOC-24267\n\n"; 
    foreach my $sensekey ( keys %node_a_checkcondition_initiator ) {
        if ( $sensekey =~ m/05\/24\/00/ ) {
            foreach my $initiator ( keys %{$node_a_checkcondition_initiator{$sensekey}} ) {
                print " initiator: $initiator   total number -> $node_a_checkcondition_initiator{$sensekey}{$initiator}\n";
            }
        }
    }   

    print "\n[SK = 0x05 ASC/Q = 2500]\n";
    print "[1. Possible cause VMware https://kb.vmware.com/kb/2133286 \n";
    print " In this specific scenario, a ESXi host has sent a request for SMART data to a storage array,\n";
    print " and the array has responded with an unexpected illegal request error. The response received by\n";
    print " the host triggers a Permanent Device Loss (PDL) detection, and the kernel performs a path \n";
    print " evaluation to determine if there is need to fail the link in question.\n";
    print " In ESXi 6.0 Update 2, a change to the PDL response behavior can result in this condition blocking\n";
    print "  additional IO operations, resulting in the aborts and timeouts described in the Symptoms section.\n";
    print " This is also covered in the ESXi 6.0 Update 2 release notes.]\n\n";
    foreach my $sensekey ( keys %node_a_checkcondition_initiator ) {
        if ( $sensekey =~ m/05\/25\/00/ ) {
            foreach my $initiator ( keys %{$node_a_checkcondition_initiator{$sensekey}} ) {
                print " initiator: $initiator   total number -> $node_a_checkcondition_initiator{$sensekey}{$initiator}\n";
            }
        }
    }

    print "\nTarget Command Check Condition: SK=0x06\n";
    foreach my $sensekey ( keys %node_a_checkcondition_initiator ) {
        if ( $sensekey =~ m/^06\// ) {
            foreach my $initiator ( keys %{$node_a_checkcondition_initiator{$sensekey}} ) {
                print " initiator: $initiator   total number -> $node_a_checkcondition_initiator{$sensekey}{$initiator}\n";
            }
        }
    }

    print "\n[SK = 0x06 ASC/Q = 2a09]\n";
    print "Possible cause: reservation conflict\n\n"; 
    foreach my $sensekey ( keys %node_a_checkcondition_initiator ) {
        if ( $sensekey =~ m/06\/2a\/09/ ) {
            foreach my $initiator ( keys %{$node_a_checkcondition_initiator{$sensekey}} ) {
                print " initiator: $initiator   total number -> $node_a_checkcondition_initiator{$sensekey}{$initiator}\n";
            }
        }
    } 

    print "\nTarget Command Check Condition: SK=0x0e\n";
    foreach my $sensekey ( keys %node_a_checkcondition_initiator ) {
        if ( $sensekey =~ m/^0e\// or $sensekey =~ m/^0E\// ) {
            foreach my $initiator ( keys %{$node_a_checkcondition_initiator{$sensekey}} ) {
                print " initiator: $initiator   total number -> $node_a_checkcondition_initiator{$sensekey}{$initiator}\n";
            }
        }
    }

    print "\n[SK = 0x0e ASC/Q = 1d00]\n";
    print "Possible cause: https://community.emc.com/docs/DOC-24267\n\n"; 
    foreach my $sensekey ( keys %node_a_checkcondition_initiator ) {
        if ( $sensekey =~ m/0e\/1d\/00/ or $sensekey =~ m/0E\/1D\/00/ ) {
            foreach my $initiator ( keys %{$node_a_checkcondition_initiator{$sensekey}} ) {
                print " initiator: $initiator   total number -> $node_a_checkcondition_initiator{$sensekey}{$initiator}\n";
            }
        }
    }
    
    print "\n[node_b journal]\n";
    print "Target Command Check Condition: SK=0x00\n";
    foreach my $sensekey ( keys %node_b_checkcondition_initiator ) {
        if ( $sensekey =~ m/^00\// ) {
            foreach my $initiator ( keys %{$node_b_checkcondition_initiator{$sensekey}} ) {
                print " initiator: $initiator   total number -> $node_b_checkcondition_initiator{$sensekey}{$initiator}\n";
            }
        }
    }

    print "\nTarget Command Check Condition: SK=0x01\n";
    foreach my $sensekey ( keys %node_b_checkcondition_initiator ) {
        if ( $sensekey =~ m/^01\// ) {
            foreach my $initiator ( keys %{$node_b_checkcondition_initiator{$sensekey}} ) {
                print " initiator: $initiator   total number -> $node_b_checkcondition_initiator{$sensekey}{$initiator}\n";
            }
        }
    }   

    print "\nTarget Command Check Condition: SK=0x02\n";
    foreach my $sensekey ( keys %node_b_checkcondition_initiator ) {
        if ( $sensekey =~ m/^02\// ) {
            foreach my $initiator ( keys %{$node_b_checkcondition_initiator{$sensekey}} ) {
                print " initiator: $initiator   total number -> $node_b_checkcondition_initiator{$sensekey}{$initiator}\n";
            }
        }
    }

    print "\nTarget Command Check Condition: SK=0x03\n";
    foreach my $sensekey ( keys %node_b_checkcondition_initiator ) {
        if ( $sensekey =~ m/^03\// ) {
            foreach my $initiator ( keys %{$node_b_checkcondition_initiator{$sensekey}} ) {
                print " initiator: $initiator   total number -> $node_b_checkcondition_initiator{$sensekey}{$initiator}\n";
            }
        }
    }   

    print "\nTarget Command Check Condition: SK=0x04\n";
    foreach my $sensekey ( keys %node_b_checkcondition_initiator ) {
        if ( $sensekey =~ m/^04\// ) {
            foreach my $initiator ( keys %{$node_b_checkcondition_initiator{$sensekey}} ) {
                print " initiator: $initiator   total number -> $node_b_checkcondition_initiator{$sensekey}{$initiator}\n";
            }
        }
    }   

    print "\nTarget Command Check Condition: SK=0x05\n";
    foreach my $sensekey ( keys %node_b_checkcondition_initiator ) {
        if ( $sensekey =~ m/^05\// ) {
            foreach my $initiator ( keys %{$node_b_checkcondition_initiator{$sensekey}} ) {
                print " initiator: $initiator   total number -> $node_b_checkcondition_initiator{$sensekey}{$initiator}\n";
            }
        }
    }   

    print "\n[SK = 0x05 ASC/Q = 2400]\n";
    print "Possible cause: https://community.emc.com/docs/DOC-24267\n\n"; 
    foreach my $sensekey ( keys %node_b_checkcondition_initiator ) {
        if ( $sensekey =~ m/05\/24\/00/ ) {
            foreach my $initiator ( keys %{$node_b_checkcondition_initiator{$sensekey}} ) {
                print " initiator: $initiator   total number -> $node_b_checkcondition_initiator{$sensekey}{$initiator}\n";
            }
        }
    }   

    print "\n[SK = 0x05 ASC/Q = 2500]\n";
    print "[1. Possible cause VMware https://kb.vmware.com/kb/2133286 \n";
    print " In this specific scenario, a ESXi host has sent a request for SMART data to a storage array,\n";
    print " and the array has responded with an unexpected illegal request error. The response received by\n";
    print " the host triggers a Permanent Device Loss (PDL) detection, and the kernel performs a path \n";
    print " evaluation to determine if there is need to fail the link in question.\n";
    print " In ESXi 6.0 Update 2, a change to the PDL response behavior can result in this condition blocking\n";
    print "  additional IO operations, resulting in the aborts and timeouts described in the Symptoms section.\n";
    print " This is also covered in the ESXi 6.0 Update 2 release notes.]\n\n";
    foreach my $sensekey ( keys %node_b_checkcondition_initiator ) {
        if ( $sensekey =~ m/05\/25\/00/ ) {
            foreach my $initiator ( keys %{$node_b_checkcondition_initiator{$sensekey}} ) {
                print " initiator: $initiator   total number -> $node_b_checkcondition_initiator{$sensekey}{$initiator}\n";
            }
        }
    }   

    print "\nTarget Command Check Condition: SK=0x06\n";
    foreach my $sensekey ( keys %node_b_checkcondition_initiator ) {
        if ( $sensekey =~ m/^06\// ) {
            foreach my $initiator ( keys %{$node_b_checkcondition_initiator{$sensekey}} ) {
                print " initiator: $initiator   total number -> $node_b_checkcondition_initiator{$sensekey}{$initiator}\n";
            }
        }
    }

    print "\n[SK = 0x06 ASC/Q = 2a09]\n";
    print "Possible cause: reservation conflict\n\n"; 
    foreach my $sensekey ( keys %node_b_checkcondition_initiator ) {
        if ( $sensekey =~ m/06\/2a\/09/ ) {
            foreach my $initiator ( keys %{$node_b_checkcondition_initiator{$sensekey}} ) {
                print " initiator: $initiator   total number -> $node_b_checkcondition_initiator{$sensekey}{$initiator}\n";
            }
        }
    }

    print "\nTarget Command Check Condition: SK=0x0e\n";
    foreach my $sensekey ( keys %node_b_checkcondition_initiator ) {
        if ( $sensekey =~ m/^0e\// or $sensekey =~ m/^0E\// ) {
            foreach my $initiator ( keys %{$node_b_checkcondition_initiator{$sensekey}} ) {
                print " initiator: $initiator   total number -> $node_b_checkcondition_initiator{$sensekey}{$initiator}\n";
            }
        }
    }

    print "\n[SK = 0x0e ASC/Q = 1d00]\n";
    print "Possible cause: https://community.emc.com/docs/DOC-24267\n\n"; 
    foreach my $sensekey ( keys %node_b_checkcondition_initiator ) {
        if ( $sensekey =~ m/0e\/1d\/00/ or $sensekey =~ m/0E\/1D\/00/ ) {
            foreach my $initiator ( keys %{$node_b_checkcondition_initiator{$sensekey}} ) {
                print " initiator: $initiator   total number -> $node_b_checkcondition_initiator{$sensekey}{$initiator}\n";
            }
        }
    }   
}
#######################################################################


#######################################################################
sub kb_fc_initiator_login_logout {
    print "\npppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppp\n";
    print "  Host FC Login & Logout Statistic Report                                                      p\n";
    print "  kernel message: node_x/command_output/dmesg_-T.txt:                                          p\n";
    print "  kernel message is also integreated into the journal                                          p\n"; 
    print "  example: 0000:bd:00.0   0000:bd:00 -> slic   .0 -> port0, .1 -> port1, .2 -> port 2          p\n";
    print "  node_x/command_output/lspci_-v.txt has fcid info                                             p\n";       
    print "pppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppp\n\n";

    my %hostid_initiator;
    my %hostid_inittype;
    my %hostid_name;
    my %hostid_os;

    my $port_name = '';
    my $port_type = '';
    my $port_hostid = '';
    my $hostname = '';
    my $hostos = '';
    my $hostid = '';
    
    if ($node_a_config_item_json_exist) {            
        open (FILE, $node_a_config_item_json) or die "Cannot open $node_a_config_item_json: $!\n";      
        my $hit = 0;
        while ( <FILE> ) {  
            $_ =~ s/^\s+|\s+$//g;
            $hit = 1 if ( m/\"data\": \{/ );
            
            if ( $hit == 1 && m/\"host_id\":/ ) {
                $port_hostid = $_;
                my @tmp = split( /:\s+/, $port_hostid );
                $port_hostid = $tmp[1];
                chop $port_hostid;               
            }

            if ( $hit == 1 && m/\"port_name\":/ ) {
                $port_name = $_;
                my @tmp = split( /:\s+/, $port_name );
                $port_name = $tmp[1];
                chop $port_name;               
            }

            if ( $hit == 1 && m/\"port_type\":/ ) {
                $port_type = $_;
                my @tmp = split( /:\s+/, $port_type );
                $port_type = $tmp[1];
                chop $port_type;               
            }

            if ( $hit == 1 && m/\"name\":/ ) {
                $hostname = $_;
                my @tmp = split( /:\s+/, $hostname );
                $hostname = $tmp[1];
                chop $hostname;               
            }

            if ( $hit == 1 && m/\"os\":/ ) {
                $hostos = $_;
                my @tmp = split( /:\s+/, $hostos );
                $hostos = $tmp[1];
                chop $hostos;               
            }

            if ( $hit == 1 && m/\"id\":/ ) {
                $hostid = $_;
                my @tmp = split( /:\s+/, $hostid );
                $hostid = $tmp[1];
                chop $hostid;               
            }

            if ( $hit == 1 && m/\"type\": \"INITIATOR\"/ ) {
                $hit = 0;
                if ( defined $hostid_initiator{$port_hostid} ) {
                    unless ( $hostid_initiator{$port_hostid} =~ /$port_name/) {
                        $hostid_initiator{$port_hostid} = $hostid_initiator{$port_hostid}."   ".$port_name;
                        $hostid_inittype{$port_hostid} = $hostid_inittype{$port_hostid}."   ".$port_type;
                    }
                }else{
                    $hostid_initiator{$port_hostid} = $port_name;
                    $hostid_inittype{$port_hostid} = $port_type;
                }
                
                $port_name = '';
                $port_type = '';
                $port_hostid = '';
            }     

            if ( $hit == 1 && m/\"type\": \"HOST\"/ ) {
                $hit = 0;
                $hostid_name{$hostid} = $hostname;
                $hostid_os{$hostid} = $hostos;
                $hostname = '';
                $hostos = '';
                $hostid = '';
            }
                                                                                       
        }
    } elsif ($node_b_config_item_json_exist) {
        open (FILE, $node_b_config_item_json) or die "Cannot open $node_b_config_item_json: $!\n";      
        my $hit = 0;
        while ( <FILE> ) {  
            $_ =~ s/^\s+|\s+$//g;
            $hit = 1 if ( m/\"data\": \{/ );
            
            if ( $hit == 1 && m/\"host_id\":/ ) {
                $port_hostid = $_;
                my @tmp = split( /:\s+/, $port_hostid );
                $port_hostid = $tmp[1];
                chop $port_hostid;               
            }

            if ( $hit == 1 && m/\"port_name\":/ ) {
                $port_name = $_;
                my @tmp = split( /:\s+/, $port_name );
                $port_name = $tmp[1];
                chop $port_name;               
            }

            if ( $hit == 1 && m/\"port_type\":/ ) {
                $port_type = $_;
                my @tmp = split( /:\s+/, $port_type );
                $port_type = $tmp[1];
                chop $port_type;               
            }

            if ( $hit == 1 && m/\"name\":/ ) {
                $hostname = $_;
                my @tmp = split( /:\s+/, $hostname );
                $hostname = $tmp[1];
                chop $hostname;               
            }

            if ( $hit == 1 && m/\"os\":/ ) {
                $hostos = $_;
                my @tmp = split( /:\s+/, $hostos );
                $hostos = $tmp[1];
                chop $hostos;               
            }

            if ( $hit == 1 && m/\"id\":/ ) {
                $hostid = $_;
                my @tmp = split( /:\s+/, $hostid );
                $hostid = $tmp[1];
                chop $hostid;               
            }

            if ( $hit == 1 && m/\"type\": \"INITIATOR\"/ ) {
                $hit = 0;
                if ( defined $hostid_initiator{$port_hostid} ) {
                    unless ( $hostid_initiator{$port_hostid} =~ /$port_name/) {
                        $hostid_initiator{$port_hostid} = $hostid_initiator{$port_hostid}."   ".$port_name;
                        $hostid_inittype{$port_hostid} = $hostid_inittype{$port_hostid}."   ".$port_type;
                    }
                }else{
                    $hostid_initiator{$port_hostid} = $port_name;
                    $hostid_inittype{$port_hostid} = $port_type;
                }
                
                $port_name = '';
                $port_type = '';
                $port_hostid = '';
            }    

            if ( $hit == 1 && m/\"type\": \"HOST\"/ ) {
                $hit = 0;
                $hostid_name{$hostid} = $hostname;
                $hostid_os{$hostid} = $hostos;
                $hostname = '';
                $hostos = '';
                $hostid = '';
            }
        }
    }

    foreach my $hostid ( keys %hostid_initiator ) {
        $initiatorlist = $hostid_initiator{$hostid};
        my @initiators = split(/   /, $initiatorlist );
        foreach my $initiator ( @initiators ) {
            $initiator =~ s/^.//;
            chop $initiator;
            my $count = 0;
            foreach ( @node_a_kb_fc_login ) {
                if ( m/$initiator/ ) {
                    if ($count == 0) {
                        print "[Host Name: ".$hostid_name{$hostid}."   Initiator:".$initiator."   Login Events on Node-A]\n"; 
                    }
                    $count++;
                    print $_ if ( $count <= 10 );
                }
            }
            print "Total Login Number: $count\n\n" if ($count > 0);

            $count = 0;
            foreach ( @node_a_kb_fc_logout ) {
                if ( m/$initiator/ ) {
                    if ($count == 0) {
                        print "[Host Name: ".$hostid_name{$hostid}."   Initiator:".$initiator."   Logout Events on Node-A]\n"; 
                    }
                    $count++;
                    print $_ if ( $count <= 10 );
                }
            }
            print "Total Logout Number: $count\n\n" if ($count > 0);

            $count = 0;
            foreach ( @node_b_kb_fc_login ) {
                if ( m/$initiator/ ) {
                    if ($count == 0) {
                        print "[Host Name: ".$hostid_name{$hostid}."   Initiator:".$initiator."   Login Events on Node-B]\n"; 
                    }
                    $count++;
                    print $_ if ( $count <= 10 );
                }
            }
            print "Total Login Number: $count\n\n" if ($count > 0);

            $count = 0;
            foreach ( @node_b_kb_fc_logout ) {
                if ( m/$initiator/ ) {
                    if ($count == 0) {
                        print "[Host Name: ".$hostid_name{$hostid}."   Initiator:".$initiator."   Logout Events on Node-B]\n"; 
                    }
                    $count++;
                    print $_ if ( $count <= 10 );
                }
            }
            print "Total Logout Number: $count\n\n" if ($count > 0);                                    
        }
    }
    
}
#######################################################################


#######################################################################
sub kb_abts_ {
    print "\ncccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc\n";
    print "c Access DU Issue mdt_201561_fabric_rscn_failure                                               c\n";
    print "c Fix: Fixed in FHC-SP1                                                                        c\n";
    print "c Impact is Hosts may disconnect during fabric changes (zone changes) in a Cisco FC switch     c\n"; 
    print "c  configured with RSCN-3 format (default from NX-OS 6.2).                                     c\n";
    print "c  Hosts will disconnect from the array and will not be able to re-login resulting in a DU.    c\n";
    print "c  https://confluence.cec.lab.emc.com/display/ETS/Fabric+change+on+Cisco+FC+switches+may+lead+to+DU#FabricchangeonCiscoFCswitchesmayleadtoDU-Impact c\n";
    print "c  https://www.dell.com/support/kbdoc/en-us/000181461/                                         c\n";
    print "cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc\n\n";

    print "[node_a journal]\n";
    foreach ( @node_a_mdt_201561 ) {
        print $_."\n";
    }

    print "\n[node_b journal]\n";
    foreach ( @node_b_mdt_201561 ) {
        print $_."\n";  
    }   
}
#######################################################################


#######################################################################
sub timeSort {
    my @tmp = split( /\s+/, $_[0] );
    my $time = $tmp[0]." ".$tmp[1]." ".$tmp[2];
    my @months =('jan','feb','mar','apr','may','jun','jul','aug','sep','oct','nov','dec');
    my ($mon,$day,$hms) = split(' ',lc($time));
    my %month_hash;
    @month_hash{@months} = (1 .. 12);
    return "$month_hash{$mon}-$day $hms";
}
#######################################################################


#######################################################################
sub kb_ndu_process {
    print "\nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn\n";
    print "n NDU Basic Journal Log kb_ndu_process:                                                        n\n";  
    print "n SDNAS NDU Playbook                                                                           n\n";
    print "n  Rollback indicates NDU failure. Rollback may fail as well.                                  n\n";
    print "n How to validate NDU status                                                                   n\n";
    print "n  /cyc_host/cyc_service/bin/unapproved_scripts/svc_upgrade -s                                 n\n";
    print "n  /install/cyc_host/cyc_config/scripts/cyc_config_mgr.pl -req \"ndustatus\"                     n\n";
    print "n  If ndu running is no and percent is completed, but gui shows ndu failure.                   n\n";
    print "n   Please check further                                                                       n\n";
    print "n 1. Run command below on both nodes from BSC container to verify DP is up running             n\n";
    print "n  /cyc_bsc/datapath/bin/cli.py app get_app_state                                              n\n";
    print "n  all 1 indicates dp running                                                                  n\n";
    print "n 2. Run the debuc command to clear SYM NDU data from BSC container on primary node:           n\n";
    print "n  echo 0 > /xtremapp/debuc/127.0.0.1\\:31001/commands/sym_ndu_clear_ndu_data                   n\n";
    print "n  To make sure the command succeeded, wait few minutes and log                                n\n";
    print "n   for \"Finished clearing all NDU data\" in SYM node after calling this command.               n\n";
    print "n 3. Run the following command from service container on primary node, b is primary for example n\n";
    print "n  svc_nas_ndu --getv1v2                                                                       n\n";
    print "n  svc_nas_ndu --op=pu --node=b                                                                n\n";
    print "n  svc_nas_ndu --op=v1v2 --node=b                                                              n\n";
    print "n  svc_nas_ndu --op=bu --node=b                                                                n\n";
    print "n  svc_nas_ndu --op=precommit                                                                  n\n";
    print "n  svc_nas_ndu --op=commit                                                                     n\n";
    print "n 4. Re-run the upgrade from GUI                                                               n\n";
    print "nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn\n\n";

    print "[node_a journal]\n";
    foreach ( sort { timeSort($a) cmp timeSort($b) } @node_a_kb_ndu_proc ) {
        print $_."\n";
    }

    print "\n[node_b journal]\n";
    foreach ( sort { timeSort($a) cmp timeSort($b) } @node_b_kb_ndu_proc ) {
        print $_."\n";
    }

    print "\n[node_a var/log/sdnas/sdnas_logs/sdnas_upgrade_playbook_status.txt]\n";
    if ($node_a_sdnas_upgrade_playbook_status_txt_exist) {
        open(my $file,  "<",  $node_a_sdnas_upgrade_playbook_status_txt)  or die "Can't open $node_a_sdnas_upgrade_playbook_status_txt: $!";
        while (<$file>) {
            print "$_";
        }
        close $file;
    }

    print "\n[node_b var/log/sdnas/sdnas_logs/sdnas_upgrade_playbook_status.txt]\n";
    if ($node_b_sdnas_upgrade_playbook_status_txt_exist) {
        open(my $file,  "<",  $node_b_sdnas_upgrade_playbook_status_txt)  or die "Can't open $node_b_sdnas_upgrade_playbook_status_txt: $!";
        while (<$file>) {
            print "$_";
        }
        close $file;
    }   
}
#######################################################################


my $tee2450_desc = '';
my $tee2450_cate = '';
my $tee2450_match = 'No';
#######################################################################
sub tee_2450_upload_ndu_image_failure {
    print "\nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn\n";
    print "n NDU Upload NDU image failure tee_2450                                                        n\n";
    print "n NDU package upload failed with error: Failed to process the package (0xE04030010036)         n\n";
    print "n Due to a software issue with the RSYSLOG, /dev/log is removed after remote syslog server     n\n";
    print "n  is disabled or deleted. This will cause the first attempt to upload NDU package failed with n\n";
    print "n  error: Failed to process the package (0xE04030010036).                                      n\n";
    print "n The second attempt of package upload will fail with error \"This package is already uploaded n\n";
    print "n  on the system (0xE04030010035)\"                                                            n\n";
    print "n CP restart after the /dev/log missing issue happens will fail, node will be rebooted as      n\n";
    print "n  a result of CP restart failure.                                                             n\n";
    print "nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn\n\n";

    print "[node_a journal]\n";
    foreach ( @node_a_tee_2450 ) {
        print $_."\n";
    }

    print "\n[node_b journal]\n";
    foreach ( @node_b_tee_2450 ) {
        print $_."\n";
    }

    $tee2450_desc = 'NDU Upload NDU image failure tee_2450';
    $tee2450_cate = 'Journal';
    $tee2450_match = 'Yes' if ( $#node_a_tee_2450 >= 0 or $#node_b_tee_2450 >= 0 );     
}
#######################################################################


my $tee2434_desc = '';
my $tee2434_cate = '';
my $tee2434_match = 'No';
#######################################################################
sub tee_2434_puhc_failure {
    print "\nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn\n";
    print "n NDU PUHC SDNAS failure kb188422, see-140, tee_2434_puhc_failure                              n\n";
    print "n Environment connectivity issue                                                               n\n";
    print "n Impact is NDU or PUHC failure.                                                               n\n";
    print "n Need to check icm, icd connectivity                                                          n\n";
    print "n From version 1.0.2.0.5.003                                                                   n\n";
    print "n REVISE ICM NETWORK BEHAVIOR (SN SP2):                                                        n\n";
    print "n --Support for FC-Only Appliance                                                              n\n";
    print "n --For single Unified NAS systems only, this feature redirects ICM communications from the    n\n"; 
    print "n  requirement to pass through the System bond Ports 0 & 1 and the Top-of-Rack switches,       n\n";
    print "n  between the Nodes, to pass through the backplane interconnect                               n\n";                                                        #\n";    
    print "nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn\n\n";

    print "[node_a journal]\n";
    foreach ( @node_a_tee_2434 ) {
        print $_."\n";
    }

    print "\n[node_b journal]\n";
    foreach ( @node_b_tee_2434 ) {
        print $_."\n";
    }

    $tee2434_desc = 'NDU PUHC SDNAS failure kb188422, see-140, tee_2434_puhc_failure';
    $tee2434_cate = 'Journal';
    $tee2434_match = 'Yes' if ( $#node_a_tee_2434 >= 0 or $#node_b_tee_2434 >= 0 );     
}
#######################################################################


my $tee2433_desc = '';
my $tee2433_cate = '';
my $tee2433_match = 'No';
#######################################################################
sub tee_2433_ndu_failure {
    print "\nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn\n";
    print "n NDU failure Node Panic tee_2433_ndu_failure: Node Panic                                      n\n";
    print "n Impact is NDU failure.                                                                       n\n";
    print "n Workaround:                                                                                  n\n";
    print "n  If node panic caused the NDU failure, please verify ndu status from both nodes              n\n";
    print "n  /install/cyc_host/cyc_config/scripts/cyc_config_mgr.pl -req \"ndustatus\"                   n\n";
    print "n  please refer to ap in tee-2433                                                              n\n";
    print "nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn\n\n";

    print "[node_a journal]\n";
    foreach ( @node_a_tee_2433 ) {
        print $_."\n";
    }

    print "\n[node_b journal]\n";
    foreach ( @node_b_tee_2433 ) {
        print $_."\n";
    }

    $tee2433_desc = 'NDU failure Node Panic tee_2433_ndu_failure: Node Panic';
    $tee2433_cate = 'Journal';
    $tee2433_match = 'Yes' if ( $#node_a_tee_2433 >= 0 or $#node_b_tee_2433 >= 0 );     
}
#######################################################################


my $kb192316_desc = '';
my $kb192316_cate = '';
my $kb192316_match = 'No';
#######################################################################
sub kb_192316_ndu_failure {
    print "\nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn\n";
    print "n NDU failure kb_192316_ndu_failure:                                                           n\n";
    print "n During the SDNAS part of the upgrade, the SDNAS system Virtual Data Mover (VDM) needs to     n\n";
    print "n  access its volume via iSCSI connection to the peer node, but the iSCSI connection           n\n";
    print "n  cannot be established due to the network issues.                                            n\n";
    print "n This may result in SDNAS upgrade failure.                                                    n\n";
    print "n Connection timed out ip address is node icd ipv6 address                                     n\n";
    print "n  https://www.dell.com/support/kbdoc/en-us/000192316                                          n\n";    
    print "nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn\n\n";

    print "[node_a journal]\n";
    my $count = 0;
    foreach ( @node_a_kb_192316 ) {
        print $_."\n";
        $count++;
        last if ( $count >= 20 );
    }

    print "\n[node_b journal]\n";
    $count = 0;
    foreach ( @node_b_kb_192316 ) {
        print $_."\n";
        $count++;
        last if ( $count >= 20 );        
    }

    $kb192316_desc = 'NDU failure kb_192316_ndu_failure';
    $kb192316_cate = 'Journal';
    $kb192316_match = 'Yes' if ( $#node_a_kb_192316 >= 0 or $#node_b_kb_192316 >= 0 );    
}
#######################################################################


my $kb193396_desc;
my $kb193396_cate;
my $kb193396_match = 'No';
#######################################################################
sub kb_193396_node_reboot_failure {
    print "\nrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr\n";
    print "  Node reboot kb_193396_node_reboot_failure: Fix in FHC SP1                                    r\n";
    print "  https://www.dell.com/support/kbdoc/en-us/000193396/                                          r\n";    
    print "rrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr\n\n";

    print "[node_a journal]\n";
    foreach ( @node_a_kb_193396 ) {
        print $_."\n";
    }

    print "\n[node_b journal]\n";
    foreach ( @node_b_kb_193396 ) {
        print $_."\n";
    }

    $kb193396_desc = 'Node reboot kb_193396_node_reboot_failure';
    $kb193396_cate = 'Journal';
    $kb193396_match = 'Yes' if ( $#node_a_kb_193396 >= 0 or $#node_b_kb_193396 >= 0 );
}
#######################################################################


my $tee2107_desc;
my $tee2107_cate;
my $tee2107_match = 'No';
#######################################################################
sub tee_2107_sym_panic_failure {
    print "\nrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr\n";
    print "r Service Unexpected Internal Software Module Restart May Occur tee_2107_sym_panic_failure:    r\n";
    print "r An alert of IO is not ready on the node may be displayed within PowerStore Manager.          r\n";
    print "r A permanent fix to this issue is available as part of 2.0.1.1 (2.0.1.1-1471924) and greater. r\n";
    print "r https://www.dell.com/support/kbdoc/en-us/000191594/                                          r\n";    
    print "rrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr\n\n";

    print "[node_a journal]\n";
    foreach ( @node_a_tee_2107 ) {
        print $_."\n";
    }

    print "\n[node_b journal]\n";
    foreach ( @node_b_tee_2107 ) {
        print $_."\n";
    }

    $tee2107_desc = 'Service Unexpected Internal Software Module Restart tee_2107';
    $tee2107_cate = 'Journal';
    $tee2107_match = 'Yes' if ( $#node_a_tee_2107 >= 0 or $#node_b_tee_2107 >= 0 );    
}
#######################################################################


my $kb191693_desc = '';
my $kb191693_cate = '';
my $kb191693_match = 'No';
#######################################################################
sub kb_191693_node_reboot_failure {
    print "\nrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr\n";
    print "r Node Reboot or Internal Software Module Restart May Occur kb_191693_node_reboot_failure:     r\n";
    print "r Cause:                                                                                       r\n";
    print "r  Concurrently adding a quantity of NVMe SSDs greater than the number in the existing base    r\n";
    print "r  enclosure may introduce an internal metadata structure issue.                               r\n";
    print "r  Example: Concurrently adding 8 NVMe SSDs to an existing base enclosure containing           r\n";
    print "r  6 NVMe SSDs may introduce an internal metadata structure issue.                             r\n";
    print "r  This issue does not occur when adding SAS SSDs to an existing expansion enclosure.          r\n";
    print "r Workaround:                                                                                  r\n";
    print "r  When adding multiple drives to an existing base enclosure, wait 1 - 2 minutes between       r\n";
    print "r  sliding each drive into position.                                                           r\n";
    print "r  Waiting 1 - 2 minutes between adding each drive will prevent introducing issues to          r\n";
    print "r  internal metadata structures.                                                               r\n";
    print "r  https://www.dell.com/support/kbdoc/en-us/000191693/                                         r\n";    
    print "rrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr\n\n";

    print "[node_a journal]\n";
    foreach ( @node_a_kb_191693 ) {
        print $_;
    }

    print "\n[node_b journal]\n";
    foreach ( @node_b_kb_191693 ) {
        print $_;
    }

    $kb191693_desc = 'Node Reboot or Internal Software Module Restart May Occur kb_191693';
    $kb191693_cate = 'Journal';
    $kb191693_match = 'Yes' if ( $#node_a_kb_191693 >= 0 or $#node_b_kb_191693 >= 0 );    
}
#######################################################################


my $kb192483_desc = '';
my $kb192483_cate = '';
my $kb192483_match = 'No';
#######################################################################
sub kb_192483_ndu_failure {
    print "\nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn\n";
    print "n NDU failure Update to 2.0.1.0 fails with \"Resume replication session(*)\" kb_192483_ndu_failure: n\n";
    print "n TEE-2255 TEE-2267 MDT-344024 MDT-344396                                                      n\n";
    print "n Cause:                                                                                       n\n";
    print "n  The NDU process fails to pause all replications when RPO is reached. The replication        n\n";
    print "n   pause commands eventually timeout causing the NDU to fail.                                 n\n";
    print "n How to verify:                                                                               n\n";
    print "n  Check for stuck replication sessions in managementdb.                                       n\n";
    print "n  From BSC container run:                                                                     n\n";
    print "n   psql -U cmduser -p 5433 managementdb -c \"select id, status from internal.work_unit where NOT status='COMPLETED' AND NOT status='FAILED' ; \" n\n";
    print "n   If there are jobs in a pending state manual cleanup from engineering is required to        n\n";
    print "n    allow restarting the NDU.                                                                 n\n";
    print "n   Escalate to ETS by creating a TEE.                                                         n\n";
    print "n  Include all relevant logs and analysis.                                                     n\n";
    print "n  Include service credentials if a connection to the system via SRS is allowed & open.        n\n";
    print "n  If there are no jobs listed, proceed to the workaround section.                             n\n";
    print "n Workaround:                                                                                  n\n";
    print "n  Check that the NDU is not in a running state (no) via coreOS on both nodes:                 n\n";
    print "n  /install/cyc_host/cyc_config/scripts/cyc_config_mgr.pl -req \"ndustatus\"                   n\n";
    print "n  Restart Control Path on the primary node:                                                   n\n";
    print "n  svc_container_mgmt restart CP                                                               n\n";
    print "n  Verify that NDU status is clear and not running by repeating the command in 1.a. above.     n\n";
    print "n  Pause all replication sessions from the GUI.                                                n\n";
    print "n  Start NDU again via GUI and monitor:                                                        n\n";
    print "n  svc_journalctl -f MARKER=NDU                                                                n\n";    
    print "n https://www.dell.com/support/kbdoc/en-us/000192483/                                          n\n";
    print "nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn\n\n";

    print "[node_a journal]\n";
    foreach ( @node_a_kb_192483 ) {
        print $_."\n";
    }

    print "\n[node_b journal]\n";
    foreach ( @node_b_kb_192483 ) {
        print $_."\n";
    }

    $kb192483_desc = 'NDU failure Update to 2.0.1.0 fails with Resume replication session(*) kb_192483';
    $kb192483_cate = 'Journal';
    $kb192483_match = 'Yes' if ( $#node_a_kb_192483 >= 0 or $#node_b_kb_192483 >= 0 );    
}
#######################################################################


my $kb130333_desc = '';
my $kb130333_cate = '';
my $kb130333_match = 'No';
#######################################################################
sub kb_130333_node_reboot_failure {
    print "\nrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr\n";
    print "r Node Panic or Disk Offline Cause DU kb_130333_node_reboot_failure :                          r\n";
    print "r MDT-124831, MDT-306294, TEE-1682, TEE-1201,TEE-2160                                          r\n";
    print "r Fix in PowerStoreOS FHC 2.0.0.0 build 1371720 and later                                      r\n";     
    print "r Cause:                                                                                       r\n";
    print "r  SAS controller (SASPMC) hardware lockup causes a single node panic/failover and in some     r\n";
    print "r  rare instances disks offline with DU.                                                       r\n";
    print "r Workaround:                                                                                  r\n";
    print "r  https://www.dell.com/support/kbdoc/en-us/000130333/                                         r\n"; 
    print "rrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr\n\n";

    print "[node_a journal]\n";
    my $count = 0;
    foreach ( @node_a_kb_130333 ) {
        print $_."\n";
        $count++;
        last if ( $count >= 20 );
    }

    $count = 0;
    print "\n[node_b journal]\n";
    foreach ( @node_b_kb_130333 ) {
        print $_."\n";
        $count++;
        last if ( $count >= 20 );        
    }

    $kb130333_desc = 'Node Panic or Disk Offline Cause DU kb_130333_node_reboot_failure';
    $kb130333_cate = 'Journal';
    $kb130333_match = 'Yes' if ( $#node_a_kb_130333 >= 0 or $#node_b_kb_130333 >= 0 );     
}
#######################################################################


my $kb_fc_abts_desc = '';
my $kb_fc_abts_cate = '';
my $kb_fc_abts_match = 'No';
#######################################################################
sub kb_fc_abts_unknown_address {
    print "\npppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppp\n";
    print "p Performance kb_fc_abts_unknown_address :                                                     p\n";
    print "p How to identify port or wwn from the fabric id?                                              p\n";
    print "p example: 0000:bd:00.0   0000:bd:00 -> slic   .0 -> port0, .1 -> port1, .2 -> port 2          p\n";
    print "p node_x/command_output/lspci_-v.txt has fcid info                                             p\n"; 
    print "p Please compare with the fc login logout report                                               p\n";
    print "p This kind of error usually indicates connectivity problem. need to check switch logs         p\n";
    print "p  and host logs. Disable suspect host port or switch port then monitor the performance.       p\n";
    print "pppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppp\n\n";

    my $count = 0;
    print "[node_a journal]\n";
    foreach ( @node_a_kb_fc_abts_unknown_address ) {
        print $_."\n" if ($count <= 20);
        $count++;
    }
    print "Total ABTS number: $count\n";

    print "\n[node_b journal]\n";
    $count = 0;
    foreach ( @node_b_kb_fc_abts_unknown_address ) {
        print $_."\n" if ($count <= 20);
        $count++;    
    }
    print "Total ABTS number: $count\n"; 

    $kb_fc_abts_desc = 'Performance kb_fc_abts_unknown_address';
    $kb_fc_abts_cate = 'Journal';
    $kb_fc_abts_match = 'Yes' if ( $#node_a_kb_fc_abts_unknown_address >= 0 or $#node_b_kb_fc_abts_unknown_address >= 0 );       
}
#######################################################################


sub kb_fc_session_logout {
    print "\npppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppp\n";
    print "p Performance kb_fc_session_logout :                                                           p\n";
    print "p Initiator reported with the most number of session logout events may have some problem.      p\n";
    print "p Target reported with the most number of session logout events may have some problem.         p\n";
    print "p Need to engage switch and host team to verify connectivity issue.                            p\n";
    print "p Disable suspicious port and monitor improvement is worth to try.                             p\n";
    print "p example: 0000:bd:00.0   0000:bd:00 -> slic   .0 -> port0, .1 -> port1, .2 -> port 2          p\n";
    print "p node_x/command_output/lspci_-v.txt has fcid info                                             p\n";     
    print "pppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppppp\n\n";

    my %hostid_initiator;
    my %hostid_inittype;
    my %hostid_name;
    my %hostid_os;

    my $port_name = '';
    my $port_type = '';
    my $port_hostid = '';
    my $hostname = '';
    my $hostos = '';
    my $hostid = '';
    
    if ($node_a_config_item_json_exist) {            
        open (FILE, $node_a_config_item_json) or die "Cannot open $node_a_config_item_json: $!\n";      
        my $hit = 0;
        while ( <FILE> ) {  
            $_ =~ s/^\s+|\s+$//g;
            $hit = 1 if ( m/\"data\": \{/ );
            
            if ( $hit == 1 && m/\"host_id\":/ ) {
                $port_hostid = $_;
                my @tmp = split( /:\s+/, $port_hostid );
                $port_hostid = $tmp[1];
                chop $port_hostid;               
            }

            if ( $hit == 1 && m/\"port_name\":/ ) {
                $port_name = $_;
                my @tmp = split( /:\s+/, $port_name );
                $port_name = $tmp[1];
                chop $port_name;               
            }

            if ( $hit == 1 && m/\"port_type\":/ ) {
                $port_type = $_;
                my @tmp = split( /:\s+/, $port_type );
                $port_type = $tmp[1];
                chop $port_type;               
            }

            if ( $hit == 1 && m/\"name\":/ ) {
                $hostname = $_;
                my @tmp = split( /:\s+/, $hostname );
                $hostname = $tmp[1];
                chop $hostname;               
            }

            if ( $hit == 1 && m/\"os\":/ ) {
                $hostos = $_;
                my @tmp = split( /:\s+/, $hostos );
                $hostos = $tmp[1];
                chop $hostos;               
            }

            if ( $hit == 1 && m/\"id\":/ ) {
                $hostid = $_;
                my @tmp = split( /:\s+/, $hostid );
                $hostid = $tmp[1];
                chop $hostid;               
            }

            if ( $hit == 1 && m/\"type\": \"INITIATOR\"/ ) {
                $hit = 0;
                if ( defined $hostid_initiator{$port_hostid} ) {
                    unless ( $hostid_initiator{$port_hostid} =~ /$port_name/) {
                        $hostid_initiator{$port_hostid} = $hostid_initiator{$port_hostid}."   ".$port_name;
                        $hostid_inittype{$port_hostid} = $hostid_inittype{$port_hostid}."   ".$port_type;
                    }
                }else{
                    $hostid_initiator{$port_hostid} = $port_name;
                    $hostid_inittype{$port_hostid} = $port_type;
                }
                
                $port_name = '';
                $port_type = '';
                $port_hostid = '';
            }     

            if ( $hit == 1 && m/\"type\": \"HOST\"/ ) {
                $hit = 0;
                $hostid_name{$hostid} = $hostname;
                $hostid_os{$hostid} = $hostos;
                $hostname = '';
                $hostos = '';
                $hostid = '';
            }
                                                                                       
        }
    } elsif ($node_b_config_item_json_exist) {
        open (FILE, $node_b_config_item_json) or die "Cannot open $node_b_config_item_json: $!\n";      
        my $hit = 0;
        while ( <FILE> ) {  
            $_ =~ s/^\s+|\s+$//g;
            $hit = 1 if ( m/\"data\": \{/ );
            
            if ( $hit == 1 && m/\"host_id\":/ ) {
                $port_hostid = $_;
                my @tmp = split( /:\s+/, $port_hostid );
                $port_hostid = $tmp[1];
                chop $port_hostid;               
            }

            if ( $hit == 1 && m/\"port_name\":/ ) {
                $port_name = $_;
                my @tmp = split( /:\s+/, $port_name );
                $port_name = $tmp[1];
                chop $port_name;               
            }

            if ( $hit == 1 && m/\"port_type\":/ ) {
                $port_type = $_;
                my @tmp = split( /:\s+/, $port_type );
                $port_type = $tmp[1];
                chop $port_type;               
            }

            if ( $hit == 1 && m/\"name\":/ ) {
                $hostname = $_;
                my @tmp = split( /:\s+/, $hostname );
                $hostname = $tmp[1];
                chop $hostname;               
            }

            if ( $hit == 1 && m/\"os\":/ ) {
                $hostos = $_;
                my @tmp = split( /:\s+/, $hostos );
                $hostos = $tmp[1];
                chop $hostos;               
            }

            if ( $hit == 1 && m/\"id\":/ ) {
                $hostid = $_;
                my @tmp = split( /:\s+/, $hostid );
                $hostid = $tmp[1];
                chop $hostid;               
            }

            if ( $hit == 1 && m/\"type\": \"INITIATOR\"/ ) {
                $hit = 0;
                if ( defined $hostid_initiator{$port_hostid} ) {
                    unless ( $hostid_initiator{$port_hostid} =~ /$port_name/) {
                        $hostid_initiator{$port_hostid} = $hostid_initiator{$port_hostid}."   ".$port_name;
                        $hostid_inittype{$port_hostid} = $hostid_inittype{$port_hostid}."   ".$port_type;
                    }
                }else{
                    $hostid_initiator{$port_hostid} = $port_name;
                    $hostid_inittype{$port_hostid} = $port_type;
                }
                
                $port_name = '';
                $port_type = '';
                $port_hostid = '';
            }    

            if ( $hit == 1 && m/\"type\": \"HOST\"/ ) {
                $hit = 0;
                $hostid_name{$hostid} = $hostname;
                $hostid_os{$hostid} = $hostos;
                $hostname = '';
                $hostos = '';
                $hostid = '';
            }
        }
    }

    foreach my $hostid ( keys %hostid_initiator ) {
        $initiatorlist = $hostid_initiator{$hostid};
        my @initiators = split(/   /, $initiatorlist );
        foreach my $initiator ( @initiators ) {
            $initiator =~ s/^.//;
            chop $initiator;
            my $count = 0;
            foreach ( @node_a_kb_session_logout ) {
                if ( m/$initiator/ ) {
                    if ($count == 0) {
                        print "[Host Name: ".$hostid_name{$hostid}."   Initiator:".$initiator."   Session Logout Events on Node-A]\n"; 
                    }
                    $count++;
                    print $_ if ( $count <= 20 );
                }
            }
            print "Total Session Logout Events Number: $count\n\n" if ($count > 0);

            $count = 0;
            foreach ( @node_b_kb_session_logout ) {
                if ( m/$initiator/ ) {
                    if ($count == 0) {
                        print "[Host Name: ".$hostid_name{$hostid}."   Initiator:".$initiator."   Session Logout Events on Node-B]\n"; 
                    }
                    $count++;
                    print $_ if ( $count <= 20 );
                }
            }
            print "Total Session Logout Events Number: $count\n\n" if ($count > 0);                                   
        }
    } 
}


my $kb_user_reboot_desc = '';
my $kb_user_reboot_cate = '';
my $kb_user_reboot_match = 'No';
#######################################################################
sub kb_user_action_reboot_events {
    print "\neeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee\n";
    print "e User Action Events kb_user_action_reboot_events :                                                   e\n";
    print "e 1, node reboot                                                                               e\n";
    print "e  USER=root ; COMMAND=/cyc_host/cyc_service/bin/svc_node reboot local -f                      e\n";
    print "e  Client IP: 10.84.100.201. Server IP: 10.121.0.158 Application type: Mozilla/5.0             e\n";
    print "e   (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.75   e\n";
    print "e   Safari/537.36. Method: POST. Processing route: /api/rest/service_action/Reboot/execute.    e\n";
    print "eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee\n\n";

    print "[node_a journal]\n";
    foreach ( @node_a_kb_user_reboot_actions ) {
        print $_."\n";
    }

    print "\n[node_b journal]\n";
    foreach ( @node_b_kb_user_reboot_actions ) {
        print $_."\n";        
    }

    $kb_user_reboot_desc = 'User Action Events kb_user_action_reboot_events';
    $kb_user_reboot_cate = 'Journal';
    $kb_user_reboot_match = 'Yes' if ( $#node_a_kb_user_reboot_actions >= 0 or $#node_b_kb_user_reboot_actions >= 0 );    
}
#######################################################################


#######################################################################
sub pstscan_report_summary {
    print "\n\n######################################################################################################################\n";
    print "# PSTScan Report Summary: pstscan_report_summary                                                                     #\n";
    print "# How to read report:                                                                                                #\n";
    print "#  https://confluence.cec.lab.emc.com/pages/viewpage.action?pageId=603104469                                         #\n";
    print "######################################################################################################################\n\n";

    print "\n-------------------------------------------------------------------------------------------------------------\n";
    print "| Function (you can search the keywords to check detailed info in report)    | Categary      | Issue        |\n";
    print "-------------------------------------------------------------------------------------------------------------\n";  
    print "-------------------------------------------------------------------------------------------------------------\n";  
    print "| Important Notice                                                           |               | manual check |\n";         
    print "-------------------------------------------------------------------------------------------------------------\n";
    print "-------------------------------------------------------------------------------------------------------------\n";         
    print "|                                                                            |               |              |\n";
    print "-------------------------------------------------------------------------------------------------------------\n";     
    print "-------------------------------------------------------------------------------------------------------------\n";
    print "| Procedures                                                                 |               |              |\n";
    print "-------------------------------------------------------------------------------------------------------------\n";    
    print "-------------------------------------------------------------------------------------------------------------\n";
    print "| Procedures list and useful websites                                        | Procedure     | manual check |\n";                                  
    print "-------------------------------------------------------------------------------------------------------------\n";
    print "| Code Release and Known Issues                                              | Procedure     | manual check |\n";                                  
    print "-------------------------------------------------------------------------------------------------------------\n";
    print "| Powerstore Terms                                                           | Procedure     | manual check |\n";                                  
    print "-------------------------------------------------------------------------------------------------------------\n";
    print "| Useful online command sets                                                 | Procedure     | manual check |\n";                                  
    print "-------------------------------------------------------------------------------------------------------------\n";
    print "| Support Material log files location                                        | Procedure     | manual check |\n";                                  
    print "-------------------------------------------------------------------------------------------------------------\n";
    print "-------------------------------------------------------------------------------------------------------------\n";
    print "|                                                                            |               |              |\n";
    print "-------------------------------------------------------------------------------------------------------------\n";    
    print "-------------------------------------------------------------------------------------------------------------\n";
    print "| Configurations                                                             |               |              |\n";
    print "-------------------------------------------------------------------------------------------------------------\n";
    print "-------------------------------------------------------------------------------------------------------------\n";
    print "| Array Configuraiton Part: sub array_basic_info                             | Config        | manual check |\n";                  
    print "-------------------------------------------------------------------------------------------------------------\n";
    print "| Array Configuraiton Part: sub array_dp_status, data path status            | Config        | manual check |\n";                        
    print "-------------------------------------------------------------------------------------------------------------\n";
    print "| Array Configuraiton Part: sub array_hardware                               | Config        | manual check |\n";                                  
    print "-------------------------------------------------------------------------------------------------------------\n";
    print "| Array Configuraiton Part: sub array_sdr_hardware                           | Config        | manual check |\n";                                  
    print "-------------------------------------------------------------------------------------------------------------\n";
    print "| Array Configuraiton Part: sub array_disk_eval_hardware                     | Config        | manual check |\n";                                  
    print "-------------------------------------------------------------------------------------------------------------\n";
    print "| Array Configuraiton Part: sub array_hardware_pn (part nubmer)              | Config        | manual check |\n";                                  
    print "-------------------------------------------------------------------------------------------------------------\n";
    print "| Array Configuraiton Part: sub array_sfp_power_hardware                     | Config        | manual check |\n";                                  
    print "-------------------------------------------------------------------------------------------------------------\n";
    print "| Array Configuraiton Part: sub array_vol_status                             | Config        | manual check |\n";                                  
    print "-------------------------------------------------------------------------------------------------------------\n";
    print "| Array Configuraiton Part: sub array_host_status                            | Config        | manual check |\n";                                  
    print "-------------------------------------------------------------------------------------------------------------\n";
    print "| Array Configuraiton Part: sub array_host_initiators                        | Config        | manual check |\n";                                  
    print "-------------------------------------------------------------------------------------------------------------\n";
    print "| Array Configuraiton Part: sub array_host_vol_mapping                       | Config        | manual check |\n";
    print "-------------------------------------------------------------------------------------------------------------\n";
    print "| Array Configuraiton Part: sub array_fe_port_info                           | Config        | manual check |\n";
    print "-------------------------------------------------------------------------------------------------------------\n";   
    print "| Array Configuraiton Part: sub array_initiator_target_conn                  | Config        | manual check |\n";
    print "-------------------------------------------------------------------------------------------------------------\n";   
    print "| Array Configuraiton Part: sub array_drr_status: compression and drr status | Config        | manual check |\n";
    print "-------------------------------------------------------------------------------------------------------------\n";  
    print "| Array Configuraiton Part: sub array_replication_status                     | Config        | manual check |\n";
    print "-------------------------------------------------------------------------------------------------------------\n";  
    print "| sub array_reboot_info: array node reboot info bmc sel log                  | BMC Sel       | manual check |\n";
    print "-------------------------------------------------------------------------------------------------------------\n";
    print "| Dump log list                                                              | Json          | manual check |\n";
    print "-------------------------------------------------------------------------------------------------------------\n"; 
    print "| Alert list                                                                 | Json          | manual check |\n";
    print "-------------------------------------------------------------------------------------------------------------\n";                
    print "|                                                                            |               |              |\n";
    print "-------------------------------------------------------------------------------------------------------------\n";
    print "-------------------------------------------------------------------------------------------------------------\n";
    print "| Journal Log Time Range                                                     |               |              |\n";
    print "-------------------------------------------------------------------------------------------------------------\n";
    print "-------------------------------------------------------------------------------------------------------------\n";    
    print "| sub dump_journal_to_txt: dump node journal log to txt (journal time range) |               | manual check |\n";            
    print "-------------------------------------------------------------------------------------------------------------\n";
    print "|                                                                            |               |              |\n";    
    print "-------------------------------------------------------------------------------------------------------------\n";
    print "-------------------------------------------------------------------------------------------------------------\n";    
    print "| Node Reboot                                                                |               |              |\n";
    print "-------------------------------------------------------------------------------------------------------------\n";    
    print "-------------------------------------------------------------------------------------------------------------\n";    
    print "| node reboot or internal software module restart                            | Guide         | manual check |\n";
    print "-------------------------------------------------------------------------------------------------------------\n";    
    
    format SUMMARY_REBOOT =    
------------------------------------------------------------------------------------------------------------- 
| ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<< | ^<<<<<<<<<<< |
$kb193396_desc, $kb193396_cate, $kb193396_match                                  
-------------------------------------------------------------------------------------------------------------
| ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<< | ^<<<<<<<<<<< |
$tee2107_desc, $tee2107_cate, $tee2107_match                                  
-------------------------------------------------------------------------------------------------------------
| ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<< | ^<<<<<<<<<<< |
$tee2064_desc, $tee2064_cate, $tee2064_match                                  
-------------------------------------------------------------------------------------------------------------
| ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<< | ^<<<<<<<<<<< |
$tee1987_desc, $tee1987_cate, $tee1987_match                                  
-------------------------------------------------------------------------------------------------------------
| ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<< | ^<<<<<<<<<<< |
$kb180125_desc, $kb180125_cate, $kb180125_match                                  
-------------------------------------------------------------------------------------------------------------
| ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<< | ^<<<<<<<<<<< |
$kb130333_desc, $kb130333_cate, $kb130333_match                                  
-------------------------------------------------------------------------------------------------------------
| ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<< | ^<<<<<<<<<<< |
$mdt342762_desc, $mdt342762_cate, $mdt342762_match                                 
-------------------------------------------------------------------------------------------------------------
| ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<< | ^<<<<<<<<<<< |
$mdt335078_desc, $mdt335078_cate, $mdt335078_match                                
-------------------------------------------------------------------------------------------------------------
| ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<< | ^<<<<<<<<<<< |
$mdt329167_desc, $mdt329167_cate, $mdt329167_match                                
-------------------------------------------------------------------------------------------------------------
| ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<< | ^<<<<<<<<<<< |
$mdt305828_desc, $mdt305828_cate, $mdt305828_match                                
-------------------------------------------------------------------------------------------------------------
| ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<< | ^<<<<<<<<<<< |
$mdt239421_desc, $mdt239421_cate, $mdt239421_match                                
-------------------------------------------------------------------------------------------------------------
| ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<< | ^<<<<<<<<<<< |
$mdt194042_desc, $mdt194042_cate, $mdt194042_match                                
-------------------------------------------------------------------------------------------------------------
| ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<< | ^<<<<<<<<<<< |
$kb191693_desc, $kb191693_cate, $kb191693_match                                
-------------------------------------------------------------------------------------------------------------
| ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<< | ^<<<<<<<<<<< |
$tee979_desc, $tee979_cate, $tee979_match                                
-------------------------------------------------------------------------------------------------------------
| ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<< | ^<<<<<<<<<<< |
$tee711_desc, $tee711_cate, $tee711_match                                
-------------------------------------------------------------------------------------------------------------
| ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<< | ^<<<<<<<<<<< |
$tee703_desc, $tee703_cate, $tee703_match                                
-------------------------------------------------------------------------------------------------------------
|                                                                            |               |              |
-------------------------------------------------------------------------------------------------------------
.
    $~ = SUMMARY_REBOOT;
    write;

    format SUMMARY_HARDWARE =    
-------------------------------------------------------------------------------------------------------------
| Hardware                                                                   |               |              |
-------------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------------
| hardware related errors                                                    | Guide         | manual check |
-------------------------------------------------------------------------------------------------------------
| ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<< | ^<<<<<<<<<<< |
$tee2239_desc, $tee2239_cate, $tee2239_match                                
-------------------------------------------------------------------------------------------------------------
| ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<< | ^<<<<<<<<<<< |
$tee2184_desc, $tee2184_cate, $tee2184_match                                
-------------------------------------------------------------------------------------------------------------
| ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<< | ^<<<<<<<<<<< |
$tee1393_desc, $tee1393_cate, $tee1393_match                                
-------------------------------------------------------------------------------------------------------------
| ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<< | ^<<<<<<<<<<< |
$mdt285220_desc, $mdt285220_cate, $mdt285220_match                                
-------------------------------------------------------------------------------------------------------------
| ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<< | ^<<<<<<<<<<< |
$mdt205619_desc, $mdt205619_cate, $mdt205619_match                                
-------------------------------------------------------------------------------------------------------------
| ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<< | ^<<<<<<<<<<< |
$tee2345_desc, $tee2345_cate, $tee2345_match                                
-------------------------------------------------------------------------------------------------------------
| Expansion enclosure is not supported, tee_1844, tee_2345, tee_1673         | Journal       | manual check |
-------------------------------------------------------------------------------------------------------------
| ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<< | ^<<<<<<<<<<< |
$mdt173900_desc, $mdt173900_cate, $mdt173900_match                                
-------------------------------------------------------------------------------------------------------------
| ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<< | ^<<<<<<<<<<< |
$tee_x_corrupt_desc, $tee_x_corrupt_cate, $tee_x_corrupt_match                                
-------------------------------------------------------------------------------------------------------------
|                                                                            |               |              |
-------------------------------------------------------------------------------------------------------------
.
    $~ = SUMMARY_HARDWARE;
    write;


    format SUMMARY_FACTORY = 
-------------------------------------------------------------------------------------------------------------
| Factory                                                                    |               |              |
-------------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------------
| factory related errors                                                     | Guide         | manual check |
-------------------------------------------------------------------------------------------------------------
| factory completes and node up log                                          | Journal       | manual check |
-------------------------------------------------------------------------------------------------------------
| ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<< | ^<<<<<<<<<<< |
$mdt307082_desc, $mdt307082_cate, $mdt307082_match                                
-------------------------------------------------------------------------------------------------------------
|                                                                            |               |              |
-------------------------------------------------------------------------------------------------------------
.
    $~ = SUMMARY_FACTORY;
    write;

    format SUMMARY_ICW =
-------------------------------------------------------------------------------------------------------------
| ICW                                                                        |               |              |
-------------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------------
| icw related errors                                                         | Guide         | manual check |
-------------------------------------------------------------------------------------------------------------
| ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<< | ^<<<<<<<<<<< |
$tee2091_desc, $tee2091_cate, $tee2091_match                                
-------------------------------------------------------------------------------------------------------------
| ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<< | ^<<<<<<<<<<< |
$tee2388_desc, $tee2388_cate, $tee2388_match                                
-------------------------------------------------------------------------------------------------------------
| ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<< | ^<<<<<<<<<<< |
$tee688_desc, $tee688_cate, $tee688_match                                
-------------------------------------------------------------------------------------------------------------
| ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<< | ^<<<<<<<<<<< |
$kb184530_desc, $kb184530_cate, $kb184530_match                                
-------------------------------------------------------------------------------------------------------------
| ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<< | ^<<<<<<<<<<< |
$kb131062_desc, $kb131062_cate, $kb131062_match                                
-------------------------------------------------------------------------------------------------------------
| ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<< | ^<<<<<<<<<<< |
$mdt168926_desc, $mdt168926_cate, $mdt168926_match                                
-------------------------------------------------------------------------------------------------------------
|                                                                            |               |              |
-------------------------------------------------------------------------------------------------------------
.
    $~ = SUMMARY_ICW;
    write;         

    format SUMMARY_PUHC =
-------------------------------------------------------------------------------------------------------------
| PUHC & NDU                                                                 |               |              |
-------------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------------
| NDU & PUHC releated errors in journal                                      | Guide         | manual check |
-------------------------------------------------------------------------------------------------------------
| ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<< | ^<<<<<<<<<<< |
$tee2450_desc, $tee2450_cate, $tee2450_match                                
-------------------------------------------------------------------------------------------------------------
| ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<< | ^<<<<<<<<<<< |
$tee2434_desc, $tee2434_cate, $tee2434_match                                
-------------------------------------------------------------------------------------------------------------
| ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<< | ^<<<<<<<<<<< |
$tee2432_desc, $tee2432_cate, $tee2432_match                                
-------------------------------------------------------------------------------------------------------------
| ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<< | ^<<<<<<<<<<< |
$tee2325_desc, $tee2325_cate, $tee2325_match                                
-------------------------------------------------------------------------------------------------------------
| ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<< | ^<<<<<<<<<<< |
$tee1128_desc, $tee1128_cate, $tee1128_match                                
-------------------------------------------------------------------------------------------------------------
| ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<< | ^<<<<<<<<<<< |
$mdt259371_desc, $mdt259371_cate, $mdt259371_match                                
-------------------------------------------------------------------------------------------------------------
| ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<< | ^<<<<<<<<<<< |
$mdt163197_desc, $mdt163197_cate, $mdt163197_match                                
-------------------------------------------------------------------------------------------------------------
| ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<< | ^<<<<<<<<<<< |
$tee834_desc, $tee834_cate, $tee834_match                                
-------------------------------------------------------------------------------------------------------------
| ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<< | ^<<<<<<<<<<< |
$tee2543_desc, $tee2543_cate, $tee2543_match                                
.
    $~ = SUMMARY_PUHC;
    write; 

    format SUMMARY_NDU =    
-------------------------------------------------------------------------------------------------------------
| kb_ndu_process (ndu process steps)                                         | Journal       | manual check |
-------------------------------------------------------------------------------------------------------------
| ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<< | ^<<<<<<<<<<< |
$kb193399_desc, $kb193399_cate, $kb193399_match                                
-------------------------------------------------------------------------------------------------------------
| ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<< | ^<<<<<<<<<<< |
$kb193397_desc, $kb193397_cate, $kb193397_match                                
-------------------------------------------------------------------------------------------------------------
| ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<< | ^<<<<<<<<<<< |
$tee2255_desc, $tee2255_cate, $tee2255_match                                
-------------------------------------------------------------------------------------------------------------
| ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<< | ^<<<<<<<<<<< |
$mdt344382_desc, $mdt344382_cate, $mdt344382_match                                
-------------------------------------------------------------------------------------------------------------
| ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<< | ^<<<<<<<<<<< |
$mdt334812_desc, $mdt334812_cate, $mdt334812_match                                
-------------------------------------------------------------------------------------------------------------
| ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<< | ^<<<<<<<<<<< |
$mdt305100_desc, $mdt305100_cate, $mdt305100_match                                
-------------------------------------------------------------------------------------------------------------
| ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<< | ^<<<<<<<<<<< |
$mdt304895_desc, $mdt304895_cate, $mdt304895_match                                
-------------------------------------------------------------------------------------------------------------
| ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<< | ^<<<<<<<<<<< |
$mdt304623_desc, $mdt304623_cate, $mdt304623_match                                
-------------------------------------------------------------------------------------------------------------
| ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<< | ^<<<<<<<<<<< |
$mdt180273_desc, $mdt180273_cate, $mdt180273_match                                
-------------------------------------------------------------------------------------------------------------
| ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<< | ^<<<<<<<<<<< |
$tee2213_desc, $tee2213_cate, $tee2213_match                                
-------------------------------------------------------------------------------------------------------------
| ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<< | ^<<<<<<<<<<< |
$tee2433_desc, $tee2433_cate, $tee2433_match                                
-------------------------------------------------------------------------------------------------------------
| ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<< | ^<<<<<<<<<<< |
$tee2249_desc, $tee2249_cate, $tee2249_match                                
-------------------------------------------------------------------------------------------------------------
| ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<< | ^<<<<<<<<<<< |
$tee1854_desc, $tee1854_cate, $tee1854_match                                
-------------------------------------------------------------------------------------------------------------
| ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<< | ^<<<<<<<<<<< |
$tee1021_desc, $tee1021_cate, $tee1021_match                                
-------------------------------------------------------------------------------------------------------------
| ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<< | ^<<<<<<<<<<< |
$tee1414_desc, $tee1414_cate, $tee1414_match                                
-------------------------------------------------------------------------------------------------------------
| ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<< | ^<<<<<<<<<<< |
$kb192316_desc, $kb192316_cate, $kb192316_match                                
-------------------------------------------------------------------------------------------------------------
| ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<< | ^<<<<<<<<<<< |
$kb192483_desc, $kb192483_cate, $kb192483_match                                
-------------------------------------------------------------------------------------------------------------
| ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<< | ^<<<<<<<<<<< |
$kb130232_desc, $kb130232_cate, $kb130232_match                                
-------------------------------------------------------------------------------------------------------------
|                                                                            |               |              |
-------------------------------------------------------------------------------------------------------------
.
    $~ = SUMMARY_NDU;
    write; 

    format SUMMARY_SERVICE =
-------------------------------------------------------------------------------------------------------------
| Servicibility                                                              |               |              |
-------------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------------
| Service releated errors in journal                                         | Guide         | manual check |
-------------------------------------------------------------------------------------------------------------
| ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<< | ^<<<<<<<<<<< |
$kb185738_desc, $kb185738_cate, $kb185738_match                                
-------------------------------------------------------------------------------------------------------------
| ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<< | ^<<<<<<<<<<< |
$tee2524_desc, $tee2524_cate, $tee2524_match                                
-------------------------------------------------------------------------------------------------------------
| ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<< | ^<<<<<<<<<<< |
$mdt347737_desc, $mdt347737_cate, $mdt347737_match                                
-------------------------------------------------------------------------------------------------------------
| data collections list and status (mdt_242417_service_failure)              | Json          | manual check |                               
-------------------------------------------------------------------------------------------------------------
| disk partition space usage (mdt_243089_242417_service_failure)             | Log           | manual check |                               
-------------------------------------------------------------------------------------------------------------
| ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<< | ^<<<<<<<<<<< |
$mdt342774_desc, $mdt342774_cate, $mdt342774_match                                
-------------------------------------------------------------------------------------------------------------
| ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<< | ^<<<<<<<<<<< |
$mdt312975_desc, $mdt312975_cate, $mdt312975_match                                
-------------------------------------------------------------------------------------------------------------
| ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<< | ^<<<<<<<<<<< |
$mdt247214_desc, $mdt247214_cate, $mdt247214_match                                
-------------------------------------------------------------------------------------------------------------
| ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<< | ^<<<<<<<<<<< |
$mdt283614_desc, $mdt283614_cate, $mdt283614_match                                
-------------------------------------------------------------------------------------------------------------
| ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<< | ^<<<<<<<<<<< |
$mdt237350_desc, $mdt237350_cate, $mdt237350_match                                
-------------------------------------------------------------------------------------------------------------
| ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<< | ^<<<<<<<<<<< |
$mdt227944_desc, $mdt227944_cate, $mdt227944_match                                
-------------------------------------------------------------------------------------------------------------
| ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<< | ^<<<<<<<<<<< |
$kb126293_desc, $kb126293_cate, $kb126293_match                                
-------------------------------------------------------------------------------------------------------------
| ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<< | ^<<<<<<<<<<< |
$mdt195039_desc, $mdt195039_cate, $mdt195039_match                                
-------------------------------------------------------------------------------------------------------------
| ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<< | ^<<<<<<<<<<< |
$mdt149702_desc, $mdt149702_cate, $mdt149702_match                                
-------------------------------------------------------------------------------------------------------------
| ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<< | ^<<<<<<<<<<< |
$mdt303484_desc, $mdt303484_cate, $mdt303484_match                                
-------------------------------------------------------------------------------------------------------------
| switch related alert (mdt_183942_switch_alert)                             | Json          | manual check |                             
-------------------------------------------------------------------------------------------------------------
|                                                                            |               |              |
-------------------------------------------------------------------------------------------------------------
.
    $~ = SUMMARY_SERVICE;
    write; 

    format SUMMARY_CLIENT =  
-------------------------------------------------------------------------------------------------------------
| Client Access                                                              |               |              |
-------------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------------
| Host I/O or connectivity releated errors in journal                        | Guide         | manual check |
-------------------------------------------------------------------------------------------------------------
| ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<< | ^<<<<<<<<<<< |
$kb_int_flap_desc, $kb_int_flap_cate, $kb_int_flap_match                                
-------------------------------------------------------------------------------------------------------------
| ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<< | ^<<<<<<<<<<< |
$mdt294054_desc, $mdt294054_cate, $mdt294054_match                                
-------------------------------------------------------------------------------------------------------------
| ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<< | ^<<<<<<<<<<< |
$mdt201561_desc, $mdt201561_cate, $mdt201561_match                                
-------------------------------------------------------------------------------------------------------------
| ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<< | ^<<<<<<<<<<< |
$kb182665_desc, $kb182665_cate, $kb182665_match                                
-------------------------------------------------------------------------------------------------------------
| ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<< | ^<<<<<<<<<<< |
$mdt304388_desc, $mdt304388_cate, $mdt304388_match                                
-------------------------------------------------------------------------------------------------------------
| ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<< | ^<<<<<<<<<<< |
$mdt291470_desc, $mdt291470_cate, $mdt291470_match                                
-------------------------------------------------------------------------------------------------------------
| ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<< | ^<<<<<<<<<<< |
$kb189524_desc, $kb189524_cate, $kb189524_match                                
-------------------------------------------------------------------------------------------------------------
| ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<< | ^<<<<<<<<<<< |
$tee2462_desc, $tee2462_cate, $tee2462_match                                
-------------------------------------------------------------------------------------------------------------
|                                                                            |               |              |
-------------------------------------------------------------------------------------------------------------
.
    $~ = SUMMARY_CLIENT;
    write;

    format SUMMARY_REP =    
-------------------------------------------------------------------------------------------------------------
| Replication                                                                |               |              |
-------------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------------
| Replication releated errors in journal                                     | Guide         | manual check |
-------------------------------------------------------------------------------------------------------------
| ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<< | ^<<<<<<<<<<< |
$kb187268_desc, $kb187268_cate, $kb187268_match                                
-------------------------------------------------------------------------------------------------------------
|                                                                            |               |              |
-------------------------------------------------------------------------------------------------------------
.
    $~ = SUMMARY_REP;
    write;

    format SUMMARY_PERF =
-------------------------------------------------------------------------------------------------------------
| Performance                                                                |               |              |
-------------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------------
| Performance related kb_performance_header                                  | Guide         | manual check |
-------------------------------------------------------------------------------------------------------------
| kb_node_cpu_usage_performance                                              | Log           | manual check |
-------------------------------------------------------------------------------------------------------------
| ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<< | ^<<<<<<<<<<< |
$tee1627_desc, $tee1627_cate, $tee1627_match                                
-------------------------------------------------------------------------------------------------------------
| Performance Unmap trif_822_perf_failure                                    | Log           | manual check |
-------------------------------------------------------------------------------------------------------------
| Performance Unmap tee_1882_perf_failure                                    | Log           | manual check |                                
-------------------------------------------------------------------------------------------------------------
| Performance IB Interconnect RX Error mdt_305668                            | Log           | manual check |                            
-------------------------------------------------------------------------------------------------------------
| ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<< | ^<<<<<<<<<<< |
$tee1898_desc, $tee1898_cate, $tee1898_match                                
-------------------------------------------------------------------------------------------------------------
| ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<< | ^<<<<<<<<<<< |
$tee2161_desc, $tee2161_cate, $tee2161_match                                
-------------------------------------------------------------------------------------------------------------
| Performance Cache, ATS related mdt_218936_perf_failure                     | Log           | manual check |                               
-------------------------------------------------------------------------------------------------------------
| SCSI Reservation Conflict Statistic Report MDT-240046                      | Log           | manual check |
-------------------------------------------------------------------------------------------------------------  
| SCSI Statistic Report kb_scsi_perf_statistic (0x28 task set full etc)      | Log           | manual check |
-------------------------------------------------------------------------------------------------------------  
| Performance Abort Statistic Report kb_abort_statistic                      | Log           | manual check |
-------------------------------------------------------------------------------------------------------------  
| SCSI Sense Keys (check condition)                                          | Log           | manual check |
------------------------------------------------------------------------------------------------------------- 
| Host FC Login & Logout Statistic Report                                    | Json          | manual check |
------------------------------------------------------------------------------------------------------------- 
| ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<< | ^<<<<<<<<<<< |
$kb_fc_abts_desc, $kb_fc_abts_cate, $kb_fc_abts_match                                
------------------------------------------------------------------------------------------------------------- 
| Performance kb_fc_session_logout                                           | Log           | manual check |
------------------------------------------------------------------------------------------------------------- 
| SCSI reservation conflict statistic                                        | Log           | manual check |
------------------------------------------------------------------------------------------------------------- 
| SCSI reservation status for volume                                         | Log           | manual check |
------------------------------------------------------------------------------------------------------------- 
| st_io_counters if completed io counter is increasing                       | Journal       | manual check |
------------------------------------------------------------------------------------------------------------- 
|                                                                            |               |              |
-------------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------------
| Unknown Issues                                                             |               |              |
-------------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------------
| ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<< | ^<<<<<<<<<<< |
$mdt185460_desc, $mdt185460_cate, $mdt185460_match                                
------------------------------------------------------------------------------------------------------------- 
|                                                                            |               |              |
-------------------------------------------------------------------------------------------------------------
.
    $~ = SUMMARY_PERF;
    write;

    format SUMMARY_USER =
-------------------------------------------------------------------------------------------------------------
| User Actions                                                               |               |              |
-------------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------------
| ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< | ^<<<<<<<<<<<< | ^<<<<<<<<<<< |
$kb_user_reboot_desc, $kb_user_reboot_cate, $kb_user_reboot_match                                
-------------------------------------------------------------------------------------------------------------          
.
    $~ = SUMMARY_USER;
    write;                                     
}
#######################################################################



#######################################################################
sub MainLoop {
    &print_header;
    &array_important_notice;
    &array_procedure_list;
    &array_code_known_issues;

    &array_pst_terms;
    &array_useful_commands;
    &array_logs_location_list;
    &initialize_array_logs_exist;

    &array_configuration_header;
    &array_basic_info;
    &array_dp_status;  
    #&array_docker_status;  
    &array_hardware;
    &array_sdr_hardware;
    &array_disk_eval_hardware;
    &array_hardware_pn;
    &array_sfp_power_hardware;
    &array_vol_status;  
    #&array_vvol_status;      
    &array_host_status;
    &array_host_initiators;
    &array_host_vol_mapping;
    &array_fe_port_info;
    &array_initiator_target_conn;
    #&array_capacity_status;
    &array_drr_status;
    #&array_nas_status;
    &array_replication_status;
    &array_reboot_info;
    &array_dump_list;   
    &array_alert_list;

    &initialize_dump_journal_to_txt;
    &initialize_scan_journal_known_issues;

    #node reboot
    &kb_node_reboot_header;
    #&kb_panic_detect_list;
    #&kb_du_related_event;
    &kb_193396_node_reboot_failure;
    &tee_2107_sym_panic_failure;    
    &tee_2064_node_reboot_failure;
    &tee_1987_node_reboot_failure;    
    &kb_180125_node_reboot_failure;    
    &kb_130333_node_reboot_failure;                
    &mdt_342762_node_reboot_failure;
    &mdt_335078_node_reboot_mapper_corruption_failure;  
    &mdt_329167_node_reboot_corruption_failure;
    &mdt_305828_node_reboot_failure;    
    &mdt_239421_node_reboot_failure;
    &mdt_194042_node_reboot_failure;    
    &kb_191693_node_reboot_failure;    
    &tee_979_node_reboot_failure;       
    &tee_711_node_reboot_failure;
    &tee_703_node_reboot_failure;    

    #hardware
    &kb_hardware_header;
    #kb_hardware_replacement;
    &tee_2239_hardware_failure;
    &tee_2184_hardware_failure;
    &tee_1393_hardware_failure;
    &mdt_285220_hardware_failure;    
    &mdt_205619_hardware_failure;
    &tee_2345_hardware_failure;
    &tee_1673_hardware_failure;
    &mdt_173900_halt_vault_corruption;
    &tee_x_corruptions_detect;
    
    #factory
    &kb_factory_header;
    &kb_factory_complete;
    &mdt_307082_init_failure;
    
    #icw
    &kb_icw_header;
    &tee_2091_icw_failure;    
    &tee_2388_icw_failure;  
    &kb_pstx_icw_ca_failure;
    &kb_184530_icw_failure;      
    &kb_131062_icw_failure;
    &mdt_168926_icw_failure;

    #puhc && ndu
    &kb_ndu_header;
    &tee_2450_upload_ndu_image_failure;
    &tee_2434_puhc_failure;    
    &tee_2432_puhc_failure;    
    &tee_2325_puhc_datapath_failure;
    &tee_1128_puhc_failure;
    &mdt_259371_puhc_failure;
    &mdt_163197_puhc_failure;
    &tee_834_puhc_failure; 
    &tee_2543_prestage_failure;
    &kb_ndu_process;  
    &kb_193399_ndu_failure;   
    &kb_193397_ndu_failure;            
    &tee_2255_ndu_failure;
    &mdt_344382_ndu_failure;
    &mdt_334812_ndu_failure;    
    &mdt_305100_ndu_failure;
    &mdt_304895_ndu_failure;
    &mdt_304623_ndu_failure;
    &mdt_180273_ndu_failure;
    &tee_2213_ndu_failure;
    &tee_2433_ndu_failure;    
    &tee_2249_ndu_failure;
    &tee_1854_ndu_failure;
    &tee_1021_ndu_failure;
    &tee_1414_ndu_failure;    
    &kb_192316_ndu_failure;
    &kb_192483_ndu_failure;
    &kb_130232_ndu_failure;
        
    #service
    &kb_service_header;
    &kb_185738_alert;
    &tee_2524_service_failure;
    &mdt_347737_service_failure;
    &mdt_242417_service_failure;
    &mdt_243089_242417_service_failure;
    &mdt_342774_service_failure;
    &mdt_312975_dc_failure;
    &mdt_247214_dc_failure;
    &mdt_283614_cp_restart_failue;    
    &mdt_237350_management_db_failure;
    &mdt_227944_loss_cluster_management_failure;
    &kb_126293_metrics_inaccessible_failure;
    &mdt_195039_lost_cluster_mgmt_failure;
    &mdt_149702_lost_mgmt_failure;
    &mdt_303484_eve_failure;
    &mdt_183942_switch_alert;
        
    #client access
    &kb_client_access_header;
    &kb_interface_flapping;    
    &mdt_294054_ndu_vol_du_failure;
    &mdt_201561_fabric_rscn_failure;
    &kb_182665_max_transfer_size;
    &mdt_304388_gsip_remove_failure;
    &mdt_291470_iscsi_illegal_failure;
    &kb_189524_aix_access_failure;
    &tee_2462_aix_boot_failure;

    #replication
    &kb_replica_header;
    &kb_187268_replica_failure;
    
    #import
    #&kb_import_header;
    
    #performance
    &kb_performance_header;
    &kb_node_cpu_usage_performance;
    &tee_1627_perf_failure;
    &trif_822_perf_failure;
    &tee_1882_perf_failure;
    &mdt_305668_perf_failure;
    &tee_1898_perf_failure;
    &tee_2161_perf_failure;
    &mdt_218936_perf_failure;
    &kb_ats_scsi2_conflict_failure;
    &kb_scsi_perf_statistic;
    &kb_abort_statistic;
    &kb_scsi_sense_statistic;
    &kb_fc_initiator_login_logout;
    &kb_fc_abts_unknown_address;
    &kb_fc_session_logout;
    &kb_reservation_conflict;
    &kb_vol_reservation_status;
    &kb_st_io_counters;
            
    #unknown
    &mdt_185460_unknown_failure;    

    #user action
    &kb_user_action_reboot_events;

    #report summary
    &pstscan_report_summary;
}
#######################################################################

&MainLoop;


exit;