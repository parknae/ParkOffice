from excel_report.common import generate_excel_report_from_list_of_dict
from data_normalizer.host_virtual_volume_mapping_info_normalizer import normalize_virtual_volume_mapping_info

def sort_host_virtual_volume_mapping(a_dict):
    return [a_dict['host_name'], a_dict['volume'], a_dict["vvoltype"]]


def report_virtual_volume_mapping_info(dc_folder, wb, ws_index, ws_name):
    header, list_of_dict = normalize_virtual_volume_mapping_info(dc_folder)
    generate_excel_report_from_list_of_dict(wb, ws_index, ws_name, list_of_dict, header, vertical=False, sort_func=sort_host_virtual_volume_mapping, tab_color=None)
