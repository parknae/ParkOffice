from excel_report.common import generate_excel_report_from_list_of_dict
from data_normalizer.host_volume_mapping_info_normalizer import normalize_volume_mapping_info

def sort_host_volume_mapping(a_dict):
    return [a_dict['name'], a_dict["logical_unit_number"]]


def report_volume_mapping_info(dc_folder, wb, ws_index, ws_name):
    header, list_of_dict = normalize_volume_mapping_info(dc_folder)
    generate_excel_report_from_list_of_dict(wb, ws_index, ws_name, list_of_dict, header, vertical=False, sort_func=sort_host_volume_mapping, tab_color=None)
