import os
import json
from infra.utils import TOOL_NAME, get_tmp_file_path, bytes_to_capacity_string, handle_exceptions
import logging

logger = logging.getLogger('.'.join([TOOL_NAME, __name__]))

@handle_exceptions
def normalize_applaince_space_stats_info(dc_folder):
    ns_sa_tenant_file_path = get_tmp_file_path(dc_folder, "ns_sa_tenant.json")
    system_space_usage_stats_file_path = get_tmp_file_path(dc_folder, "system_space_usage_stats.json")
    list_of_dict = dict()
    header = list()
    space_stats = dict()
    applaince_space_stat_list = list()
    if ns_sa_tenant_file_path:
        with open(ns_sa_tenant_file_path, 'r') as f:
            list_of_dict = json.load(f)
            for i, record in enumerate(list_of_dict):
                if 'Compression Ratio' not in record:
                    list_of_dict[i]['Compression Ratio'] = None
                if 'Dedup Ratio' not in record:
                    list_of_dict[i]['Dedup Ratio'] = None
                if 'Overall Ratio (DRR)' not in record:
                    list_of_dict[i]['Overall Ratio (DRR)'] = None
        # header = ['Tenant Id', 'Logical Space', 'Compression Ratio', 'Dedup Ratio', 'Overall Ratio (DRR)', 'Physical Space']
                # Looks like Tenant Id 5 represent the total physical capacity and the total space consumption
                if record['Tenant Id'] == '5':
                    space_stats['Logical Used(User)'] = record['Logical Space']
                    space_stats['Compression Ratio(User)'] = record['Compression Ratio']
                    space_stats['Dedup Ratio(User)'] = record['Dedup Ratio']
                    space_stats['Overall Ratio (User)'] = record['Overall Ratio (DRR)']
                    space_stats['Physical Used(User)'] = record['Physical Space']
                    header = ['Logical Used(User)', 'Compression Ratio(User)', 'Dedup Ratio(User)', 'Overall Ratio (User)', 'Physical Used(User)']
    if system_space_usage_stats_file_path:
        with open(system_space_usage_stats_file_path, 'r') as f:
            a_dict = json.load(f)
            # if 'logical_total_space' in a_dict:
            #     space_stats['Logical Total(User)'] = bytes_to_capacity_string(int(a_dict['logical_total_space']))
            #     header.insert(0, 'Logical Total(User)')
            if 'physical_used_space' in a_dict:
                space_stats['Physical Used(Total)'] = bytes_to_capacity_string(int(a_dict['physical_used_space']))
                header.insert(0, 'Physical Used(Total)')
            if 'physical_total_space' in a_dict:
                space_stats['Physical Total'] = bytes_to_capacity_string(int(a_dict['physical_total_space']))
                header.insert(0, 'Physical Total')
            if 'physical_used_space' in a_dict and 'physical_total_space' in a_dict:
                usage = int(a_dict['physical_used_space'])/int(a_dict['physical_total_space']) * 100
                space_stats['Used(%)'] = "{0:.2f}".format(usage)
                header.insert(2, 'Used(%)')
    # space_stats can be empty
    if space_stats:
        applaince_space_stat_list.append(space_stats)
    return header, applaince_space_stat_list

# node_a/command_output/cli.py_namespace_spacestats_enumtenants.txt
# Logical Space:        11552350208 (0x2b092e000) 10.8GB
# Compressed Space:     3919155238 (0xe9999026) 3.6GB
# Compression Ratio:       2.95
# Deduped Space:        4307845120 (0x100c48000) 4.0GB
# Dedup Ratio:             2.68
# Physical Space:       3885073016 (0xe7918278) 3.6GB   
# Overall Ratio (DRR):     2.97
# ....
# Tenant Id:            5
# Logical Space:        2717777358848 (0x278c8277000) 2.5TB  <----- Logical space used by volumes
# Compressed Space:     2511432638948 (0x248bd0ce1e4) 2.3TB
# Compression Ratio:       1.08
# Deduped Space:        2717193707520 (0x278a55da000) 2.5TB
# Dedup Ratio:             1.00
# Physical Space:       2511420453165 (0x248bc52f12d) 2.3TB   <------ Used physical space
# Overall Ratio (DRR):     1.08

# node_a/command_output/cli.py_stats_system_space_usage_stats.txt
# stats {
#   cmd: DP_STATS_CMD_GET_SYSTEM_SPACE_STATS
#   system_space_usage {
#     usage_update_time {
#       second: 1588728789
#       nano_second: 432615000
#     }
#     physical_total_space: 6949428871168
#     physical_used_space: 6783979538135
#     logical_total_space: 4503599627370496   <--- Total logical space provisioned to volumes
#     logical_used_space: 2729329709056   <----- similar to 'Logical Space' in teant 5, but count the space used by tenant 1 in.
#     efficiency_ratio: 92
#   }
# }
