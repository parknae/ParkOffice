from infra.utils import TOOL_NAME, handle_exceptions
import os
import json
import logging

logger = logging.getLogger('.'.join([TOOL_NAME, __name__]))

@handle_exceptions
def normalize_dc_inventory_info(dc_folder):
    dc_inventory_file_path = os.path.join(dc_folder, 'inventory.json')
    list_of_dc = list()
    data_collection_info_dict = dict()
    if os.path.exists(dc_inventory_file_path):
        logger.debug(dc_inventory_file_path)
        with open(dc_inventory_file_path, 'r') as f:
            data = json.load(f)
            data_collection_info_dict = data['data_collection_info']
            data_collection_info_dict['profiles'] = ",".join(data_collection_info_dict['profiles'])
            list_of_dc.append(data_collection_info_dict)
    header = ['found_core', 'profiles', 'description']
    return header, list_of_dc