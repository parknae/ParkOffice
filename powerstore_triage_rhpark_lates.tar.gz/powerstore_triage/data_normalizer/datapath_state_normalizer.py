import os
import json
from infra.utils import TOOL_NAME, TOOL_OUTPUT_FOLDER, TOOL_TMP_FOLDER, get_sym_node_command_output_file_path, get_dc_datapath_file, handle_exceptions
import logging
import re

logger = logging.getLogger('.'.join([TOOL_NAME, __name__]))

@handle_exceptions
def normalize_datapath_state_info(dc_folder):
    datapath_state_list = list()
    # ns_stats_file_path = get_sym_node_command_output_file_path(dc_folder, 'cli.py_dc_plugin_dump_ns_stats.txt')
    # # namespace getnsstate is not collected, thus only guess the offline state from cli.py_dc_plugin_dump_ns_stats.txt
    # if ns_stats_file_path:
    #     logger.debug(ns_stats_file_path)
    #     with open(ns_stats_file_path, 'r') as f:
    #         for line in f:
    #             if 'STATUS_OFFLINE' in line:
    #                 datapath_state_dict['namespace state'] = 'offline'
    #                 break
    datapath_state_dict = dict()
    for node_name in ['node_a', 'node_b']:
        datapath_state_dict.setdefault('node', []).append(node_name)
        app_file_path = get_dc_datapath_file(dc_folder, node_name, 'app.txt')
        if app_file_path:
            with open(app_file_path, 'r') as f:
                for line in f:
                    if 'state' in line and ":" in line:
                        k, v = line.split(":")
                        datapath_state_dict.setdefault(k.strip(),[]).append(v.strip())
                    elif "Monitor" in line:
                        break
        else:
            logger.warning("{0}/command_output/dc-datapath-*/app.txt is not found".format(node_name))
            datapath_state_dict.setdefault('app state',[]).append('N/A')
            datapath_state_dict.setdefault('raid state',[]).append('N/A')
            datapath_state_dict.setdefault('mapper state',[]).append('N/A')
            datapath_state_dict.setdefault('cache state',[]).append('N/A')
            datapath_state_dict.setdefault('data path state',[]).append('N/A')
    # convert the list of dict to a list of list
    attibutes = ["node", "app state", "raid state", "mapper state", "cache state", "data path state"]
    for attr in attibutes:
        if attr in datapath_state_dict:
            li = datapath_state_dict[attr]
            li.insert(0,attr)
            datapath_state_list.append(li)
    logger.debug(datapath_state_list)
    return datapath_state_list


# [['node', 'node_a', 'node_b'], ['app state', '1 (running)', '1 (running)'], ['raid state', '1 (running)', '1 (running)'], 
# ['mapper state', '1 (running)', '1 (running)'], ['cache state', '1 (running)', '1 (running)'], 
# ['data path state', '0 (initting)', '1 (running)']]

# in case ./cli.py  namespace getnsstate returns "Namespace state is offline", 
# dc_plugin_dump_ns_stats will return nothing with command status: STATUS_OFFLINE
# 
# 2020-05-31 08:59:47,616 - PyCycloneDp - INFO - logging in PyCycloneDp.__init__
# server: localhost
# starting cli
# command_id: "4"
# command: DP_COMMAND_NAMESPACE
# status: STATUS_OFFLINE
# ns {
#   cmd: DP_NS_COMMAND_ENUMERATE_OP_STATS
#   enumerate_op_stats {
#   }
# }
# session_identifier: 1590694823272

# server: localhost
# starting cli
# 2020-03-27 06:25:54,471 - INFO - event_client init() address: localhost node: A
# 2020-03-27 06:25:54,572 - INFO -  PyCycloneDp.init localhost
# 2020-03-27 06:25:54,587 - PyCycloneDp - INFO - logging in PyCycloneDp.__init__
# Namespace state is online

# node_b/command_output/dc-datapath-2020-05-31T09-03-46-logs/app.txt
# get app state successful.
#  app state      : 1 (running)
#  raid state     : 1 (running)
#  mapper state   : 1 (running)
#  cache state    : 1 (running)
#  data path state: 1 (running)
#  system type:     HW_BM
#  app PID:         4611

# Monitor Thread Ran      :    776 ms ago
# Run Queue Thread[ 0] Ran:     46 ms ago
# Run Queue Thread[ 1] Ran:     47 ms ago
