import os
import json
from infra.utils import TOOL_NAME, get_sym_node_command_output_file_path
import logging
import re

logger = logging.getLogger('.'.join([TOOL_NAME, __name__]))

def normalize_appliance_dare_status_info(dc_folder):
    dare_status_file_path = get_sym_node_command_output_file_path(dc_folder, 'xmcli_-x__-c_query-dare-status.txt')
    dare_status = dict()
    if dare_status_file_path:
        logger.debug(dare_status_file_path)
        with open(dare_status_file_path, 'r') as f:
            for line in f:
                if "Dare status" in line:
                    k,v = line.split(":")
                    k = k.strip()
                    v = v.strip()
                    dare_status[k] = v
                    break
    return dare_status
