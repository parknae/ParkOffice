import os
from infra.utils import TOOL_NAME, system, TOOL_OUTPUT_FOLDER, TOOL_TMP_FOLDER
from infra.process_journal import get_journactl_cmd_pre, generate_journal_time_option
import logging

logger = logging.getLogger('.'.join([TOOL_NAME, __name__]))


def filter_create_cluster_related_log(dc_folder, from_time=None, to_time=None):
    start_time_option, end_time_option = generate_journal_time_option(from_time, to_time)
    journal_cmd_pre = get_journactl_cmd_pre(dc_folder, start_time_option, end_time_option)
    journalc_cmd = journal_cmd_pre + r'-t control-path MARKER=CC MARKER=AA -o short-iso-precise|grep -E "Create Cluster \w+ after|Add Appliance \w+ after|Error from Create Cluster|Error from Add Appliance|error during joinCluster"|tail -1' + r"|awk '{print $1}'"
    logger.debug(journalc_cmd)
    stdout, stderr, ret_code = system(journalc_cmd, shell=True)
    # must do a rstrip
    end_time_str = stdout.rstrip()
    logger.debug("Cluster creation end time: {0}".format(end_time_str))
    output_file = os.path.join(dc_folder, TOOL_OUTPUT_FOLDER, 'create_cluster.txt')
    if not end_time_str:
        with open(output_file, 'w+') as output_fp:
            output_fp.writelines(
                "No cluster creation related message is found. This is probably because the messages are rolled up")
    else:
        pattern_str = r'do_reinit\(\) REINIT: SUMMARY:|cyc_backend_get_drive_config:|\[CC\]|\[AA\]|PANIC|svc_hardware_check_command_handler|svc_diag underline script returned|factory half-reinited state|Registering service:|reinit_install|nvme_dev_disable|nvme reset|No qualified NVMe|Package version|labmode flags|CCU program started|Sync Point|sync point|exceeded while executing|Inconsistency found for SCSI targets'
        tmp_file = os.path.join(dc_folder, TOOL_OUTPUT_FOLDER, TOOL_TMP_FOLDER, 'tmp_cc.txt')
        # save the result to a temp file instead loading it into memeory to avoid deadlock in system()
        # journalc_cmd = journal_cmd_pre + r'-o short-iso-precise|grep -E "{0}" > {1}'.format(pattern_str, tmp_file)
        journal_a = os.path.join(dc_folder, TOOL_OUTPUT_FOLDER, 'journal_a.txt')
        journal_b = os.path.join(dc_folder, TOOL_OUTPUT_FOLDER, 'journal_b.txt')
        journalc_cmd = r'grep -h -E "{0}" {1} {2} |sort > {3}'.format(pattern_str, journal_a, journal_b, tmp_file)
        logger.debug(journalc_cmd)
        stdout, stderr, ret_code = system(journalc_cmd, shell=True, show_progress=True)
        if ret_code != 0:
            logger.error(stderr)
        else:
            # result = stdout.rstrip().split("\n")
            with open(output_file, 'w+') as output_fp, open(tmp_file, 'r') as input_file:
                for line in input_file:
                    time_str = line.split()[0]
                    output_fp.write(line)
                    if time_str == end_time_str:
                        break



