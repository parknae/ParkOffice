import json
import os
import logging
from infra.utils import TOOL_NAME

DC_INVENTORY_FILE_NAME = "inventory.json"
# the parent logger will be the logger with name defined by TOOL_NAME
logger = logging.getLogger('.'.join([TOOL_NAME, __name__]))


def parse_dc_inventory(dc_folder):
    inventory_dict = dict()
    inventory_dict['config_capture_exists'] = False
    with open(os.path.join(dc_folder, DC_INVENTORY_FILE_NAME), "r") as f:
        inventory = json.load(f)
        for success in inventory['success']:
            try:
                entry = success['command'][0]
            except KeyError:
                entry = success['commands'][0]  # old style of inventory.json
            except:
                raise
            if 'destination' in entry and "config_capture_management_data" in entry['destination']:
                logger.debug(success['full_dest_path'])
                logger.debug("Control Path primary node: {0}".format(success['node']))
                # path str looks like: node_a/config_capture_management_data
                config_capture_path = success['full_dest_path']
                inventory_dict['config_capture_path'] = config_capture_path
                inventory_dict['cp_primary_node'] = success['node']
                # Even if cluster is not created successfully,
                # the DC still contains "config_capture_management_data" folder
                if os.path.exists(os.path.join(dc_folder, success['full_dest_path'], "appliance.json")) and \
                   os.path.exists(os.path.join(dc_folder, success['full_dest_path'], "volume.json")):
                    logger.info("config capture management data folder: {0}".format(config_capture_path))
                    inventory_dict['config_capture_exists'] = True

    # Sometimes, inventory.json is not reliable, has to check if
    # config_capture_management_data folder exists and if there is files in it
    if not inventory_dict['config_capture_exists']:
        for node_name in ['node_a', 'node_b']:
            config_capture_management_data = os.path.join(dc_folder, node_name, "config_capture_management_data")
            if os.path.exists(config_capture_management_data):
                if os.path.exists(os.path.join(config_capture_management_data, "appliance.json")) and \
                   os.path.exists(os.path.join(config_capture_management_data, "volume.json")):
                    config_capture_path = os.path.join(node_name, "config_capture_management_data")
                    inventory_dict['config_capture_path'] = config_capture_path
                    inventory_dict['cp_primary_node'] = node_name
                    inventory_dict['config_capture_exists'] = True
                    return inventory_dict
        else:
            logger.warning("config capture management data is empty!")

    return inventory_dict
