import os
import json
import subprocess
import yaml
from infra.utils import TOOL_NAME, TOOL_OUTPUT_FOLDER, TOOL_TMP_FOLDER, get_node_file, handle_exceptions
import logging

logger = logging.getLogger('.'.join([TOOL_NAME, __name__]))

@handle_exceptions
def parse_cyc_hw_info(dc_folder):
    for node_name in ["node_a", "node_b"]:
        cyc_hw_info = dict()
        cyc_hw_file_path = get_node_file(dc_folder, node_name, os.path.join("cyc_var", "cyc-hw.txt"))
        if cyc_hw_file_path:
            logger.debug("%s: %s" %(node_name,cyc_hw_file_path))
            with open(cyc_hw_file_path) as f:
                for line in f:
                    kv = line.split('=')
                    if len(kv) == 2:
                        k,v = kv
                        k = k.replace("export ", "").replace("local_", "").strip()
                        v = v.replace('"', "").strip()
                        cyc_hw_info[k] = v
            with open(os.path.join(dc_folder, TOOL_OUTPUT_FOLDER, TOOL_TMP_FOLDER, "{0}_cyc_hw_appliance_info.json".format(node_name)), 'w+') as out_fp:
                json.dump(cyc_hw_info, out_fp)

# export local_system_type="Virtual-Warnado-EX"
# export local_system_class="virtual"
# export local_system_mode="unified"
# export local_node_sn="FCNSP201500103"
# export local_appliance_sn="CKM00202300728"
# export local_appliance_hci="1"
# export local_board_name="440BX Desktop Reference Platform"
# export local_bios_vendor="VMware, Inc."
# export local_bios_version="VMW71.00V.11599183.B64.1901030933"
# export local_appliance_dst="6BY7MX2"
# export local_vmx_id=""
# export local_vmx_path=""
# export esxi_scratch_path_local="/scratch"
# export esxi_scratch_path_peer="/scratch"
# export local_hardware_name="EX-1"
# export local_cp_power="7200"

# export local_system_type="BM-Warnado-EX"
# export local_system_class="bare_metal"
# export local_system_mode="block"
# export local_node_sn="FCNSP195100127"
# export local_appliance_sn="DE401202395607"
# export local_appliance_hci="0"
# export local_board_name="110-558-910A-10"
# export local_bios_vendor="American Megatrends Inc."
# export local_bios_version="62.87"
# export local_appliance_dst="C3X5143"
# export local_hardware_name="EX-1"
# export local_cp_power="7205"
