import logging
from infra.utils import TOOL_NAME, handle_exceptions
from parser.ipmitool_fru_list import parse_ipmitool_fru_list
from parser.nvme_list import parse_nvme_list
from parser.nvme_drive import parse_nvme_drive
from parser.cyc_net_discovery_info import parse_cyc_net_discovery_info_list
from parser.datapath_ns_objects import parse_datapath_ns_objects
from parser.datapath_ns_sa_tenant import parse_datapath_ns_sa_tenant
from parser.datapath_ns_sa_snapgroups import parse_datapath_ns_sa_snapgroups
from parser.system_space_usage_stats import parse_datapath_system_space_usage_stats
from parser.config_item import parse_config_item
from parser.volume_info_parser import parse_volume_info
from parser.datapath_ns_sa_objects import parse_datapath_ns_sa_objects
from parser.nas_cbr_cluster_postgresdb_dump import parse_nas_cbr_cluster_postgresdb_dump
from parser.appliance import parse_cyc_hw_info
logger = logging.getLogger('.'.join([TOOL_NAME, __name__]))

@handle_exceptions
def run_parsers(dc_folder):
    logger.info("Parsing files...")
    parse_ipmitool_fru_list(dc_folder)
    parse_config_item(dc_folder)
    parse_volume_info(dc_folder)
    parse_nvme_list(dc_folder)
    parse_nvme_drive(dc_folder)
    parse_cyc_net_discovery_info_list(dc_folder)
    parse_datapath_ns_objects(dc_folder)
    parse_datapath_ns_sa_tenant(dc_folder)
    parse_datapath_system_space_usage_stats(dc_folder)
    parse_datapath_ns_sa_snapgroups(dc_folder)
    parse_datapath_ns_sa_objects(dc_folder)
    parse_nas_cbr_cluster_postgresdb_dump(dc_folder)
    parse_cyc_hw_info(dc_folder)

