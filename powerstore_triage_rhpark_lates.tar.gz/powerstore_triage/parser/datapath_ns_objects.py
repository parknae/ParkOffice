import os
import json
from infra.utils import TOOL_NAME, TOOL_OUTPUT_FOLDER, TOOL_TMP_FOLDER, get_sym_node_command_output_file_path, handle_exceptions
import logging
import re

logger = logging.getLogger('.'.join([TOOL_NAME, __name__]))

@handle_exceptions
def parse_datapath_ns_objects(dc_folder):
    ns_objects_file_path = get_sym_node_command_output_file_path(dc_folder, 'cli.py_dc_plugin_dump_ns_objects.txt')
    if ns_objects_file_path:
        logger.debug(ns_objects_file_path)
        obj_listing_pattern = re.compile(r'Object Listing of')
        obj_name_pattern = re.compile(r'Object Name')
        attr_pattern = re.compile(r"\S+:")
        # first level key is the folder name (like /, /LayeredService)
        # 2nd level key is object name
        # 3rd level key is attribute
        ns_objs = dict()
        volume_id_to_object_handle = dict()
        obj_folder = None
        obj_name = None
        with open(ns_objects_file_path, 'r') as f:
            for line in f:
                if obj_listing_pattern.search(line):
                    obj_folder = line.split(":")[-1].strip()
                    ns_objs[obj_folder] = dict()
                elif obj_name_pattern.search(line):
                    obj_name = line.split(":")[-1].strip()
                    if obj_folder:
                        ns_objs[obj_folder][obj_name] = dict()
                elif attr_pattern.search(line):
                    if obj_folder and obj_name:
                        attr, value = line.split(":", 1)
                        ns_objs[obj_folder][obj_name][attr.strip()] = value.strip()

        # k is namespace object name which is also the volume datapath id
        # v is the attributes of the namespace object
        if '/' in ns_objs:
            for k, v in ns_objs['/'].items():
                volume_id_to_object_handle[k] = v['Handle']

        with open(os.path.join(dc_folder, TOOL_OUTPUT_FOLDER, TOOL_TMP_FOLDER, "ns_objects.json"), 'w+') as out_fp:
            json.dump(ns_objs, out_fp)
        with open(os.path.join(dc_folder, TOOL_OUTPUT_FOLDER, TOOL_TMP_FOLDER, "volume_id_to_object_handle.json"), 'w+') as out_fp:
            json.dump(volume_id_to_object_handle, out_fp)

        # Object Listing of :/

        #     Object Name: .
        #         Type:                    Dir
        #         Object Usage:            Base
        #         Priority:                High
        #         Handle:                  1ef0f958-0edb-46ab-b828-00eb0132a655:0:0
        #         Family Id:               00000000-0000-0000-0000-000000000000
        #         Snap Group Id:           0
        #         Create Time:             2020-03-06 15:36:55.052162047
        #         Size:                    34359738368
        #         Data Extent:             0x0000010000000000 : 0x0000018000000000 ExtentId 0x000000000006
        #         Attr Extent:             0x0000000000000000 : 0x0000000000000000 ExtentId 0x000000000000
        #         Tenant Id:               1
        #         Container Id:            5
        #         WWN:
        #         UUID:
        #         Link Count:              39
        #         Data Source:
        #         Data Source Time:
        #         Object Service Id:       12
        #         Target Service Id:       12
        #         Target Service Handle:   1ef0f958-0edb-46ab-b828-00eb0132a655:0:0


