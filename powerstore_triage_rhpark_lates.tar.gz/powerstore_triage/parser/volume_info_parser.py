import os
import json
from infra.utils import TOOL_NAME, TOOL_OUTPUT_FOLDER,TOOL_TMP_FOLDER, get_mgmt_data_file_path, get_tmp_file_path, get_mgmt_data_internal_file_path, handle_exceptions
import logging

logger = logging.getLogger('.'.join([TOOL_NAME, __name__]))

def parse_volume_info(dc_folder):
    volume_id_to_volume_name = dict()
    nas_volume_file_path = get_mgmt_data_file_path(dc_folder, 'nas_volume.json')
    volume_file_path = get_mgmt_data_file_path(dc_folder, 'volume.json')

    if not volume_file_path:
        volume_file_path = get_mgmt_data_internal_file_path(dc_folder, 'volume.json')

    if volume_file_path:
        logger.debug(volume_file_path)
        with open(volume_file_path, 'r') as f:
            data = json.load(f)
            for record in data['data']:
                vol_id = record['id']
                vol_name = record["name"]
                volume_id_to_volume_name[vol_id] = vol_name
    
    if nas_volume_file_path:
        logger.debug(nas_volume_file_path)
        with open(nas_volume_file_path, 'r') as fp:
            data = json.load(fp)
            for record in data['data']:
                vol_id = record['id']
                vol_name = record["name"]
                volume_id_to_volume_name[vol_id] = vol_name

    with open(os.path.join(dc_folder, TOOL_OUTPUT_FOLDER, TOOL_TMP_FOLDER, "volume_id_to_volume_name.json"), 'w+') as out_fp:
        json.dump(volume_id_to_volume_name, out_fp)


    # {
    #     "appliance_id": "A1",
    #     "creation_timestamp": "2020-03-06 15:44:27.013435+00:00",
    #     "datapath_family_id": 8,
    #     "datapath_volume_id": "810e21a3-5ce4-410a-880a-fe90d288b577",
    #     "description": "LUN cluster_vdm_volume for volume key",
    #     "id": "810e21a3-5ce4-410a-880a-fe90d288b577",
    #     "import_metadata": null,
    #     "is_importing": false,
    #     "is_internal": false,
    #     "is_read_only": false,
    #     "is_replication_destination": false,
    #     "migration_session_id": null,
    #     "name": "NASLUN_1090352_cluster_vdm",
    #     "node_affinity": "System_Selected_Node_A",
    #     "performance_policy_id": "default_medium",
    #     "protection_policy_id": null,
    #     "sector_size": 512,
    #     "size": 8589934592,
    #     "state": "Ready",
    #     "storage_type": "File",
    #     "type": "Primary",
    #     "wwn": "naa.68ccf098001982bdac57d5652e0c6faf"


    # {
    #     "appliance_id": "A1",
    #     "copy_signature": "4f2201ea-e112-42ba-97f7-be3ad9ec4e22",
    #     "created_by_rule_id": "fd020255-7299-4b31-9ee4-06c0582b7cae",
    #     "creation_timestamp": "2020-03-19 09:35:00.176592+00:00",
    #     "creator_type": "Scheduler",
    #     "datapath_family_id": 34,
    #     "datapath_volume_id": "4f2201ea-e112-42ba-97f7-be3ad9ec4e22",
    #     "description": "",
    #     "expiration_timestamp": "2020-03-19 13:35:00.039000+00:00",
    #     "family_id": "fb28ea5b-b877-4dee-9f54-fb807cef4bf1",
    #     "id": "4f2201ea-e112-42ba-97f7-be3ad9ec4e22",
    #     "import_metadata": null,
    #     "is_app_consistent": null,
    #     "is_importing": false,
    #     "is_internal": false,
    #     "is_read_only": true,
    #     "is_replication_destination": false,
    #     "migration_session_id": null,
    #     "name": "snap_5_min.vol_fs.2020-03-19T09:35:00Z 518716825",
    #     "node_affinity": "System_Select_At_Attach",
    #     "parent_id": "fb28ea5b-b877-4dee-9f54-fb807cef4bf1",
    #     "performance_policy_id": "default_medium",
    #     "platform_volume_guid": null,
    #     "platform_volume_id": -1,
    #     "protection_policy_id": null,
    #     "sector_size": 512,
    #     "size": 107374182400,
    #     "source_id": "fb28ea5b-b877-4dee-9f54-fb807cef4bf1",
    #     "source_timestamp": "2020-03-19 09:35:00.176592+00:00",
    #     "state": "Ready",
    #     "storage_type": "Block",
    #     "type": "Snapshot",
    #     "wwn": null
