import os
import json
from infra.utils import TOOL_NAME, TOOL_OUTPUT_FOLDER, TOOL_TMP_FOLDER, get_sym_node_command_output_file_path
import logging
import re

logger = logging.getLogger('.'.join([TOOL_NAME, __name__]))

def parse_datapath_system_space_usage_stats(dc_folder):
    system_space_usage_stats_file_path = get_sym_node_command_output_file_path(dc_folder, 'cli.py_stats_system_space_usage_stats.txt')
    if system_space_usage_stats_file_path:
        logger.debug(system_space_usage_stats_file_path)
        attr_pattern = re.compile(r"\S+:")
        system_space_usage_stats = dict()
        with open(system_space_usage_stats_file_path, 'r') as f:
            for line in f:
                if attr_pattern.search(line):
                    attr, value = line.split(":", 1)
                    value = value.split()[-1]
                    system_space_usage_stats[attr.strip()] = value.strip()
        with open(os.path.join(dc_folder, TOOL_OUTPUT_FOLDER, TOOL_TMP_FOLDER, "system_space_usage_stats.json"), 'w+') as out_fp:
            json.dump(system_space_usage_stats, out_fp)
        # command: DP_COMMAND_STATS
        # status: STATUS_OK
        # stats {
        #   cmd: DP_STATS_CMD_GET_SYSTEM_SPACE_STATS
        #   system_space_usage {
        #     usage_update_time {
        #       second: 1584619810
        #       nano_second: 926439000
        #     }
        #     physical_total_space: 75290013142220
        #     physical_used_space: 43638500337292
        #     logical_total_space: 4503599627370496
        #     logical_used_space: 95995560476672
        #     efficiency_ratio: 42
        #   }
        # }

        # import time
        # UTC
        # time_str = time.strftime("%Y-%m-%d %H:%M:%S", time.gmtime(1584619810))