import os
import json
from infra.utils import TOOL_NAME, TOOL_OUTPUT_FOLDER, TOOL_TMP_FOLDER, get_sym_node_command_output_file_path
import logging
import re

logger = logging.getLogger('.'.join([TOOL_NAME, __name__]))

def parse_datapath_ns_sa_tenant(dc_folder):
    ns_sa_tenant_file_path = get_sym_node_command_output_file_path(dc_folder, 'cli.py_namespace_spacestats_enumtenants.txt')
    if ns_sa_tenant_file_path:
        logger.debug(ns_sa_tenant_file_path)
        tenant_id_pattern = re.compile(r'Tenant Id')
        attr_pattern = re.compile(r"\S+:")
        no_more_data_pattern = re.compile(r"No More Data")
        # key is tenant id. 5 is the tenenant for user volumes?
        ns_sa_tenant = list()
        record = None
        tenant_id = None
        with open(ns_sa_tenant_file_path, 'r') as f:
            for line in f:
                if tenant_id_pattern.search(line):
                    tenant_id = line.split(":")[-1].strip()
                    if record:
                        ns_sa_tenant.append(record)
                    # reset record
                    record = dict()
                if attr_pattern.search(line):
                    if tenant_id:
                        attr, value = line.split(":", 1)
                        value = value.split()[-1]
                        record[attr.strip()] = value.strip()
                # append the last record
                if no_more_data_pattern.search(line):
                    ns_sa_tenant.append(record)
        with open(os.path.join(dc_folder, TOOL_OUTPUT_FOLDER, TOOL_TMP_FOLDER, "ns_sa_tenant.json"), 'w+') as out_fp:
            json.dump(ns_sa_tenant, out_fp)

            # Tenant Id:            5
            # Logical Space:        75356354166784 (0x448944b8c000) 68.5TB
            # Compressed Space:     31901757097663 (0x1d03b4e646bf) 29.0TB
            # Compression Ratio:       2.36
            # Deduped Space:        75352759746560 (0x44886e7a4000) 68.5TB
            # Dedup Ratio:             1.00
            # Physical Space:       31900995577136 (0x1d0387826530) 29.0TB
            # Overall Ratio (DRR):     2.36


            # No More Data:  True
            # Cursor:        9

            # Total Tenants: 8


