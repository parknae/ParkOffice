from infra.extract import extract_dump_data_file, get_dump_info
from infra.utils import TOOL_NAME, system, decompress_file, handle_exceptions
from infra.process_xtrace import get_tlogger_cmd
import logging
import os
import glob
from pathlib import Path

# the parent logger will be the logger with name defined by TOOL_NAME
logger = logging.getLogger('.'.join([TOOL_NAME, __name__]))


@handle_exceptions
def analyze_dump(dc_work_space_folder, dc_file_name):
    # The dump file name that corresponds to a dc file will be:
    dump_file_name = dc_file_name.split('_service')[0] + "_dump-data.tgz"
    # dump_data_folder: where the dump-data.tgz and the DC file is located
    dump_file_folder = os.path.dirname(dc_work_space_folder)
    # if there is a dump, the corresponding dump data file name is as below
    dump_data_file_full_path = os.path.join(dump_file_folder, dump_file_name)
    logger.debug(dump_data_file_full_path)
    if os.path.exists(dump_data_file_full_path):
        logger.info("Analyzing dump file %s ..." % dump_data_file_full_path)
        powerstore_triage_folder = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))
        dump_analyzer = os.path.join(powerstore_triage_folder, "scripts", "ps_dump_analyzer.py")
        cmd = "python3 %s --automatic --xtrace --dump_file %s" %(dump_analyzer, dump_data_file_full_path)
        logger.debug(cmd)
        os.system(cmd)

# def dump_xtrace_to_text(tlogger_cmd, dump_work_space):
#     dump_analysis_output_folder = os.path.join(dump_work_space, 'triage_analysis')
#     # in case cyc_triage.pl is not found, there will be no triage_analysis folder
#     # thus need to create the folder
#     if not os.path.exists(dump_analysis_output_folder):
#         os.mkdir(dump_analysis_output_folder)
#     if tlogger_cmd:
#         for node_name in ['node_a', 'node_b']:
#             trace_folders = glob.glob('{0}/tracedump*'.format(os.path.join(dump_work_space, node_name)))
#             for trace_folder in trace_folders:
#                 trace_output_dir_full_path = os.path.join(dump_analysis_output_folder, node_name, os.path.basename(trace_folder))
#                 trace_binary_files = os.path.join(trace_folder, r'traces_*')
#                 cmd = "{0} dump --outdir {1} {2}".format(tlogger_cmd, trace_output_dir_full_path, trace_binary_files)
#                 logger.info("Dumping XTraces of {0} to text files into folder {1}".format(node_name,
#                                                                                               trace_output_dir_full_path))
#                 logger.info(cmd)
#                 stdout, stderr, ret_code = system(cmd, shell=True, show_progress=True)
#                 if ret_code != 0:
#                     logger.error("Error is encountered during analyzing dump file")
#                     logger.error(stderr)
#     else:
#         logger.warning("tlogger.py is not found")


# def get_dump_files_path(work_space_folder):
#     dump_files = []
#     cmd = r'find {0} -type f -regex ".*\.dump\.tgz\|.*KDUMP\.tgz"'.format(work_space_folder)
#     stdout, stderr, ret_code = system(cmd, shell=True)
#     if ret_code != 0:
#         logger.error("Error is encountered during finding dump file")
#         logger.error(stderr)
#     else:
#         dump_files = stdout.split()
#     return dump_files

# @handle_exceptions
# def analyze_dump(dc_work_space_folder, dc_file_name=None):
#     if dc_file_name:
#         # This is for the case where this function is invoked by powerstore_triage.py after Data Collection analysis
#         dump_data_file_name = dc_file_name.split('_service')[0] + "_dump-data.tgz"
#         # dump_data_folder: where the dump-data.tgz is located
#         dump_data_folder = os.path.dirname(dc_work_space_folder)
#         # if there is a dump, the corresponding dump data file name is as below
#         dump_data_file_full_path = os.path.join(dump_data_folder, dump_data_file_name)
#         logger.debug("The expected dump data file is {0} if there is any".format(dump_data_file_full_path))
#         if os.path.exists(dump_data_file_full_path):
#             logger.info("Analyzing dump file...")
#             # dump_work_space_folder: where the extracted dump_data is located
#             dump_work_space_folder = os.path.join(dump_data_folder, dump_data_file_name.split(".")[0])
#             extract_dump_data_file(dump_work_space_folder, dump_data_file_name)
#             dump_files = get_dump_files_path(dump_work_space_folder)
#             gdb_cmd = os.path.join(dump_work_space_folder, 'cyc_triage.pl')
#             for dump_file in dump_files:
#                 node_name, file_name = dump_file.split("/")[-2:]
#                 dump_file = os.path.join(node_name, file_name)
#                 if 'KDUMP' in dump_file:
#                     # no Xtraces in Kernel dump file.
#                     dump_file_full_path = os.path.join(dump_work_space_folder, dump_file)
#                     decompress_file(dump_file_full_path, os.path.join(dump_work_space_folder, node_name))
#                     logger.info("Please cd into folder {0} and run the following command to analyze kernel dump:".format(dump_work_space_folder))
#                     logger.info("./cyc_triage.pl -c {0}".format(dump_file_full_path.rstrip('.tgz')))
#                 else:
#                     if os.path.exists(gdb_cmd):
#                         # create a empty file to pass to cyc_triage.pl so that it will not stay in gdb
#                         tmp_file = os.path.join(dump_work_space_folder, 'tmp.txt')
#                         if not os.path.exists(tmp_file):
#                             Path(tmp_file).touch()
#                         # need to change into the folder where the dump data file is extracted to execute cyc_triage.pl
#                         cmd = "cd {0};./cyc_triage.pl -c {1} -r tmp.txt".format(dump_work_space_folder, dump_file)
#                         logger.info(cmd)
#                         _, stderr, ret_code = system(cmd, shell=True, show_progress=True)
#                         if ret_code != 0:
#                             logger.error("Error is encountered during analyzing dump file")
#                             logger.error(stderr)
#                         else:
#                             logger.info("Dump analysis result is in folder {0}".format(os.path.join(dump_work_space_folder,
#                                                                                                     'triage_analysis')))
#                             logger.info("To analyze the dump interactively, please cd into folder {0} and run:".format(dump_work_space_folder))
#                             logger.info("./cyc_triage.pl -c {0}".format(dump_file))
#                     else:
#                         logger.warning("No cyc_triage.pl file is in folder {0}".format(dump_work_space_folder))
#                         logger.warning("You can copy cyc_triage.pl into folder {0} and run:".format(dump_work_space_folder))
#                         logger.warning("./cyc_triage.pl -c {0}".format(dump_file))
#                     tlogger_cmd = get_tlogger_cmd(dc_work_space_folder)
#                     dump_xtrace_to_text(tlogger_cmd, dump_work_space_folder)
#         else:
#             logger.info("No corresponding dump file is found in {0}".format(dc_work_space_folder))

#     else:
#         # assuming function is used by a script dedicated to perform dump file analysis
#         work_space, dump_data_file_name = get_dump_info()
#         extract_dump_data_file(work_space, dump_data_file_name)