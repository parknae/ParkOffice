from __future__ import print_function
import subprocess
import glob
import os
import re
from datetime import datetime, timedelta
import time
import sys
import shlex
import logging
# from joblib import Parallel, delayed
import concurrent.futures
import tqdm
from functools import total_ordering
from enum import Enum
from collections import namedtuple
import traceback

TOOL_NAME = "powerstore-triage"
TOOL_OUTPUT_FOLDER = "powerstore-triage"
TOOL_TMP_FOLDER = "tmp_folder"
FILTERED_LOG_FOLDER = 'filtered_logs'
# the following actually depend on the settings in export_journals_journactl
JOURNAL_A_TEXT = "journal_a.txt"
JOURNAL_B_TEXT = "journal_b.txt"

def get_my_logger(debug=False, log_folder=None):
    logger = logging.getLogger(TOOL_NAME)
    logger.setLevel(logging.DEBUG)

    # create formatter
    fmt_for_file = "%(asctime)-15s %(levelname)s %(filename)s [line:%(lineno)d] %(process)d %(message)s"
    if debug:
        fmt = "%(asctime)-15s %(levelname)s %(filename)s [line:%(lineno)d] %(process)d %(message)s"
    else:
        fmt = "%(asctime)-15s %(levelname)s %(message)s"
    # fmt = "%(asctime)-15s %(levelname)s %(filename)s %(message)s"
    # datefmt = "%a %d %b %Y %H:%M:%S"
    # formatter = logging.Formatter(fmt, datefmt)
    console_formatter = logging.Formatter(fmt)
    file_formatter = logging.Formatter(fmt_for_file)

    # create console handler and set log level to INFO
    console_handler = logging.StreamHandler()
    if debug:
        console_handler.setLevel(logging.DEBUG)
    else:
        console_handler.setLevel(logging.INFO)

    # create console handler and set log level to DEBUG
    timestamp_str = datetime.strftime(datetime.now(), "%Y-%m-%d_%H-%M-%S-%f")
    log_file_name = "{0}-{1}.log".format(TOOL_NAME, timestamp_str)
    if log_folder:
        log_file_name = os.path.join(log_folder, log_file_name)
    file_handler = logging.FileHandler(log_file_name, 'w+')
    file_handler.setLevel(logging.DEBUG)

    # add formatter to handlers
    file_handler.setFormatter(file_formatter)
    console_handler.setFormatter(console_formatter)

    # add  handlers to logger
    logger.addHandler(console_handler)
    logger.addHandler(file_handler)
    return logger


# the parent logger will be the logger with name defined by TOOL_NAME
logger = logging.getLogger('.'.join([TOOL_NAME, __name__]))

# decorator to handle exceptions
def handle_exceptions(func):
    def inner(*args, **kargs):
        try:
            return func(*args, **kargs)
        except:
            traceback.print_exc()
    return inner


def system(cmd, shell=False, show_progress=False):
    """
    run shell commands
    :param : cmd: command string, it will be split into a list using shlex.split()
    :return: stdout, stderr, ret_code
    """
    if shell:
        p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, universal_newlines=True, shell=True)
    else:
        args = shlex.split(cmd)
        # universal_newlines=True: converts the output to a string instead of a byte array
        p = subprocess.Popen(args, stdout=subprocess.PIPE, stderr=subprocess.PIPE, universal_newlines=True)
    # It will deadlock if too much output to the subprocess.PIPE and the output is not read out.
    # io.DEFAULT_BUFFER_SIZE is 8192 on CentOS 7.3.1611
    # https://stackoverflow.com/questions/39607172/python-subprocess-popen-poll-seems-to-hang-but-communicate-works
    # Possible workaround: 
    # 1. set the stderr, stdout to file object, later check the content in the file.
    # 2. read out p.stdout and p.stderr every time p.poll() is run?
    if show_progress:
        i = 0
        while p.poll() is None:
            # Must use flush=True option, otherwise the output is buffered
            print("#", end='', flush=True)
            time.sleep(3)  # print "#" every 3 seconds, this can prolong the run time of the sub process for at most 3 seconds
            i += 1
        # print "\n" only if at least one "#" was printed out.
        if i > 0:
            print()
    try:
        stdout, stderr = p.communicate(timeout=7200)
    except subprocess.TimeoutExpired:
        p.kill()
        stdout, stderr = p.communicate()
    ret_code = p.poll() # poll() can be executed after p.communicate()
    return stdout, stderr, ret_code


def get_compressed_file_names(folder=""):
    files = []
    # glob,  files starting with . they won't be matched by default
    files.extend([f for f in glob.glob(os.path.join(folder, '*.bz2')) if os.path.isfile(f)])
    files.extend([f for f in glob.glob(os.path.join(folder, '*.zip')) if os.path.isfile(f)])
    files.extend([f for f in glob.glob(os.path.join(folder, '*.gz')) if os.path.isfile(f)])
    files.extend([f for f in glob.glob(os.path.join(folder, '*.tgz')) if os.path.isfile(f)])
    # in case the file is decompressed but not extracted
    files.extend([f for f in glob.glob(os.path.join(folder, '*.tar')) if os.path.isfile(f)])
    return files


def decompress_journal_files_in_parallel(file_paths):
    # ret = Parallel(n_jobs=-1, verbose=0)(delayed(decompress_file)(file_path)
    #                                      for file_path in file_paths)
    # with concurrent.futures.ThreadPoolExecutor(max_workers=4) as executor:
    #     executor.map(decompress_file, file_paths)
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as executor:
        to_do_map = dict() # can be used for error handling if needed
        for file_path in file_paths:
            future = executor.submit(decompress_file, file_path)
            to_do_map[future] = file_path
        done_iter = concurrent.futures.as_completed(to_do_map)
        #  tqdm.tqdm decorates an iterable object, returning an iterator which acts exactly
        #  like the original iterable, but prints a dynamically updating
        #  progressbar every time a value is requested.
        done_iter = tqdm.tqdm(done_iter, total=len(file_paths))
        for future in done_iter:
            logger.debug("Finished decompressing %s" % to_do_map[future])


# directory: the directory into which the files are extracted
def decompress_file(path, directory=None, data_collection=False):
    if path.endswith('tar.gz') or path.endswith('.tgz'):
        if directory is not None:
            command_str = 'tar -xzf {0} --directory={1}'.format(path, directory)
        else:
            command_str = 'tar -xzf {0}'.format(path)
    elif path.endswith('.tar'):
        if directory is not None:
            command_str = 'tar -xf {0} --directory={1}'.format(path, directory)
        else:
            command_str = 'tar -xf {0}'.format(path)
    elif path.endswith('.zip'):
        if directory is not None:
            command_str = 'unzip {0} -d {1}'.format(path, directory)
        else:
            command_str = 'unzip {0}'.format(path)
    elif path.endswith('.gz'):
        # it seems that gzip can do decompressing in place only
        command_str = 'gzip -df {0}'.format(path)
    elif path.endswith('.tar.bz2'):
        if directory is not None:
            command_str = 'tar -xjf {0} --directory={1}'.format(path, directory)
        else:
            command_str = 'tar -xjf {0}'.format(path)
    else:
        sys.exit("not sure how to extract " + path)
    
    if directory is not None:
        logger.info("Extracting file " + path + " into " + directory)
    else:
        logger.debug("Extracting file " + path)
    
    logger.debug(command_str)  
    if data_collection and "tar" in command_str:
        command_str = command_str.replace("-", "-v", 1)
        # If the file data collection, use the following method to provide porgress information to end user.
        # The reason of not using custom "system" function in utils.py is because it might get hung.
        command_str = command_str + r' 2>&1 | while read line; do x=$((x+1)); echo -en "$x files extracted...\r"; done'
        os.system(command_str)
    elif path.endswith('.gz'):
        _, stderr, ret_code = system(command_str, show_progress=False)
        if ret_code != 0:
            logger.error(stderr)
    else:
        stdout, stderr, ret_code = system(command_str, show_progress=True)
        if ret_code != 0:
            logger.error(stderr)
            sys.exit(1)


def get_dirs(folder):
    """
    get names of the directories under a given folder
    :param folder:
    :return: paths (full paths)
    """
    paths = []
    for path in os.listdir(folder):
        full_path = os.path.join(folder, path)
        if os.path.isdir(full_path):
            paths.append(full_path)
    logger.debug("The folders in {0} are {1}".format(folder, os.listdir(folder)))
    return paths


def cleanup_tmpfile(tmp_dir):
    _, stderr, retcode = system('rm -rf %s' % tmp_dir)
    if retcode != 0:
        logger.error('    Error encountered when trying to clean up the temp files.')
        # for v in stderr.split(os.linesep):
        logger.error(stderr)


# utc_offset(in seconds)
def get_utc_offset():
    is_dst = time.daylight and time.localtime().tm_isdst > 0
    utc_offset = - (time.altzone if is_dst else time.timezone)
    return utc_offset


# def datetime2epoch(date_time_str, pattern='%Y-%m-%d %H:%M:%S'):
#     epoch = int(time.mktime(time.strptime(date_time_str, pattern)))
#     return epoch


# convert string to timestamp
def datetime_str_to_timestamp(time_str, fmt="%Y-%m-%d %H:%M:%S"):
    a_datetime = datetime.strptime(time_str, fmt)
    timestamp = time.mktime(a_datetime.timetuple())  # *** this timestamp represents the timestamp in local timezone ***
    return timestamp


# convert string to timestamp
def datetime_str_to_utc_timestamp(time_str, fmt="%Y-%m-%d %H:%M:%S"):
    a_datetime = datetime.strptime(time_str, fmt)
    timestamp = (a_datetime - datetime(1970, 1, 1)) / timedelta(seconds=1)
    return timestamp


def datetime_str_to_journalctl_datetime_str(datetime_str):
    """
    when --utc is used together with since/until option, the timestamp specified in since/until option
    will be evaluated(i.e. minus timezone) by the journalctl to utc time according to the timezone of the
    computer where journalctl is run.
    for example: if the timezone of the computer where journalctl is run is UTC -4 and --utc is specified,
    then "2017-02-09 12:00:00" specified in since/until option will be converted by the journalctl to "2017-02-09 16:00:00")
    This function is to do the opposite of journalctl will do, it plus the timezone before the datetime str is passed to journalctl,
    this way the datetime str passed by user represents time in timezone UTC+0
    :param datetime_str:
    :return:
    """
    utc_offset = get_utc_offset()
    timestamp = datetime_str_to_timestamp(datetime_str) + utc_offset
    return datetime.fromtimestamp(timestamp).strftime("%Y-%m-%d %H:%M:%S")


def datetime_str_to_utc_datetime_str(datetime_str):
    # used by show_timeframe_of_journals to convert the datetime str which represents time in local timezone
    # to datetime str represent time in timezone UTC+0
    utc_offset = get_utc_offset()
    timestamp = datetime_str_to_timestamp(datetime_str) - utc_offset
    return datetime.fromtimestamp(timestamp).strftime("%Y-%m-%d %H:%M:%S")


# Check the given time string is in YYYY-MM-DD HH:MM:SS format
# This function doesn't check if the date time is valid or not. The validation will be handled in datetime_totimestamp()
def validate_time_str_format(time_str):
    pattern = re.compile(r'\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}')
    if not re.match(pattern, time_str):
        print("Date time must be in YYYY-MM-DD HH:MM:SS format")
        sys.exit(1)



def get_infra_folder_abs_path():
    return os.path.dirname(os.path.realpath(__file__))


def bytes_to_capacity_string(bytes):
    if bytes >= (1024 ** 4):
        capacity_string = "{0:.2f} TB".format(bytes / (1024 ** 4))
    elif bytes >= (1024 ** 3):
        capacity_string = "{0:.2f} GB".format(bytes / (1024 ** 3))
    elif bytes >= (1024 ** 2):
        capacity_string = "{0:.2f} MB".format(bytes / (1024 ** 2))
    else:
        capacity_string = "{0:.2f} KB".format(bytes / 1024)
    return capacity_string


def capacity_string_to_bytes(size):
    # 406.3 KB
    # 19.6 MB
    # 0.0 B
    # 29.5 GB
    # 7.3 TB
    units = {"B": 1, "KB": 10**3, "MB": 10**6, "GB": 10**9, "TB": 10**12, "PB": 10**15}
    number, unit = [string.strip() for string in size.split()]
    return int(float(number)*units[unit])


def convert_unit_as_needed(k, v):
    # all keys in this list need to be in lower case
    keys_need_unit_conversoin = ["logical_provisioned", "logical_used", "total_space", "provisioned", "logical used", "logicalused",
                                      "used_space", "free_space", "size", "uncompressed_size", "compressed_size", 
                                      "unique owned space", "shared logical used"]
    if k.lower() in keys_need_unit_conversoin:
        if not v:  # like: "free_space": null in the json file
            return "null"
        if isinstance(v, str):
            v = int(v)
        return bytes_to_capacity_string(v)
    else:
        return v


def get_cols_width(header, list_of_dict):
    cols_width = []
    for k in header:
        length_list = [len(str(d[k])) for d in list_of_dict]
        length_list.append(len(k))
        cols_width.append(max(length_list))
    return cols_width


def sort_drive_name(a_dict):
    # logger.debug(a_dict)
    return [int(y) for y in a_dict["name"].split("_")[1:]]


def sort_dimm_name(a_dict):
    # logger.debug(a_dict)
    # "BaseEnclosure-NodeA-DIMM13"
    a, b = a_dict["name"].split("DIMM")
    return [a, int(b)]

def get_dc_file_path(dc_folder, sub_folder, file_name):
    for node_name in ['node_a', 'node_b']:
        file_path = os.path.join(dc_folder, node_name, sub_folder, file_name)
        if os.path.exists(file_path):
            return file_path
    return None

def get_mgmt_data_file_path(dc_folder, file_name):
    return get_dc_file_path(dc_folder, "config_capture_management_data", file_name)


def get_mgmt_data_internal_file_path(dc_folder, file_name):
    return get_dc_file_path(dc_folder, "config_capture_management_internal_data", file_name)

def get_metrics_data_file_path(dc_folder, file_name):
    return get_dc_file_path(dc_folder, "config_capture_metrics_data", file_name)

# get the file path of the command output that only exists on one node (normally SYM node)
def get_sym_node_command_output_file_path(dc_folder, file_name):
    return get_dc_file_path(dc_folder, "command_output", file_name)

# node_b/command_output/dc-datapath-2020-05-31T09-03-46-logs/app.txt
def get_dc_datapath_file(dc_folder, node_name, file_name):
    files = glob.glob(os.path.join(dc_folder, node_name, "command_output", "dc-datapath-*", file_name))
    if files:
        return files[0]
    else:
        return None

def get_node_file(dc_folder, node_name, file_path):
    file_full_path = os.path.join(dc_folder, node_name, file_path)
    if os.path.exists(file_full_path):
        return file_full_path
    else:
        return None

def get_tmp_file_path(dc_folder, file_name):
    file_path = os.path.join(dc_folder, TOOL_OUTPUT_FOLDER, TOOL_TMP_FOLDER, file_name)
    if os.path.exists(file_path):
        return file_path
    return None


def get_timeframe_of_file(filename):
    # log example:
    # 2020-08-11T09:15:54.692490+0000 APM00202312440-A systemd[34091]: Stopped target Sockets.
    timestamp_pattern = re.compile(r'^(\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2})\.\d+')
    # set default value as file may be empty
    start = '1970-01-01T00-00-00'  
    end = '1970-01-01T00-00-00'
    #   lots of lines may have no timestamp, thus use -200
    if filename.endswith('.gz'):
        head_cmd = 'zcat ' + filename + '|head -200'
        tail_cmd = 'zcat ' + filename + '|tail -200'
    else:
        head_cmd = 'head -200 ' + filename
        tail_cmd = 'tail -200 ' + filename
    header, _ = subprocess.Popen(head_cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, universal_newlines=True, shell=True).communicate()
    header = header.strip().split("\n")
    for line in header:
        match = re.search(timestamp_pattern, line)
        if match:
            start = match.group(1).replace(":", "-")
            break
    footer, _ = subprocess.Popen(tail_cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, universal_newlines=True, shell=True).communicate()
    footer = footer.strip().split("\n")
    for i in range(len(footer)):
        i = -(i+1)
        match = re.search(timestamp_pattern, footer[i])
        if match:
            end = match.group(1).replace(":", "-")
            break
    return start, end

class Color:
    PURPLE = '\033[95m'
    BLUE = '\033[94m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    RED = '\033[91m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'
    CLEAR = '\033[0m'


class TestSeverity(Enum):
    INFO = 1
    WARNING = 2
    CRITICAL = 3


class TestResult(Enum):
    PASSED = 1
    FAILED = 2
    PARTIAL = 3  # test result is partial due to missing file
    SKIPPED = 4  # not able to perform the test due to reasons like files are missing

class ArrayHW(Enum):
    POWERSTORE1000 = 1
    POWERSTORE3000 = 2
    POWERSTORE5000 = 3
    POWERSTORE7000 = 4
    POWERSTORE9000 = 5
    ALL = 6
class ArrayModel(Enum):
    POWERSTORE = 1
    POWERSTOREX = 2
    ALL = 3

class ArrayMode(Enum):
    BLOCK = 1
    UNIFIED = 2
    ALL = 3

class InvalidVersion(ValueError):
    """
    An invalid version was found.
    """


def normalize_version_str(version_str, is_start_v, ver_spec):
    version_normalized = version_str
    ver_parts = version_str.split(".")
    all_either_digit_or_asterisk = all([x.isdigit() or x == "*" for x in ver_parts])

    if ver_spec == VersionSpec.POST_GA:
        number_of_part = 6
    elif ver_spec == VersionSpec.DEV:
        number_of_part = 4

    if len(version_str.split(".")) > number_of_part and not all_either_digit_or_asterisk:
        raise InvalidVersion("{0} is not a valid version string".format(version_str))

    if is_start_v:
        digit_str = "0"
    else:
        digit_str = "99999999"

    version_normalized = version_str.replace("*", digit_str)
    if len(ver_parts) < number_of_part:
        rest_part = ".".join([digit_str]*(number_of_part-len(ver_parts)))
        version_normalized = version_normalized + "." + rest_part
    return version_normalized


# 0.5.0.846330
DEV_VERSION_RE = re.compile(r'^(\d+)\.(\d+)\.(\d+)\.(\d+)$')
DevVersion = namedtuple('DevVersion', 'major, minor, sp, bi')
# Major.Minor.Service_Pack.BVI.Dist_type.Build_Iterator, like 1.0.1.0.5.007
# https://confluence.cec.lab.emc.com:8443/display/CYCLONE/Trident+Version+Schema
# major 1: Trident
# minor 0: SN, 1:FH, 2:Victory
# Service Pack 0: no SP, 1: SP1, 2: SP2, etc.
# Build Version Identifier, 0 for all external releases
# Distribution Type, 3:frozen build (retail), 4:Beta, 5:RTM, 6:Hotfix
# Build Iterator, incrementing number
POST_GA_VERSION_RE = re.compile(r'^(\d+)\.(\d+)\.(\d+)\.(\d+)\.(\d+)\.(\d+)$')
PostGaVersion = namedtuple('PostGaVersion', 'major, minor, sp, bvi, dist_type, bi')


class VersionSpec(Enum):
    DEV = 1
    POST_GA = 2


@total_ordering
class SoftwareVersion:
    def __init__(self, version_str, spec=VersionSpec.POST_GA):
        self.version_str = version_str
        self.spec = spec
        if spec == VersionSpec.POST_GA:
            self.ntuple = PostGaVersion(*(version_str.split('.')))
        elif spec == VersionSpec.DEV:
            self.ntuple = DevVersion(*(version_str.split('.')))

    def __gt__(self, other):
        if self.spec == VersionSpec.DEV:
            return self.version_str > other.version_str
        elif self.spec == VersionSpec.POST_GA:
            # may need to improve.
            # Not sure if the hotfix iteration number will be
            # larger than the version it is based off or not
            # compare: major, minor, sp, build iteration number
            self_version = [int(x) for x in self.version_str.split('.')]
            v1 = self_version[:3] + self_version[-1:]
            other_version = [int(x) for x in self.version_str.split('.')]
            v2 = other_version[:3] + other_version[-1:]
            return v1 > v2

    def __eq__(self, other):
        return self.version_str == other.version_str

    def __str__(self):
        version_info = []
        for k, v in self.ntuple._asdict().items():
            version_info.append("{0}:{1}".format(k,v))
        return "SoftwareVersion: " + ",".join(version_info)


