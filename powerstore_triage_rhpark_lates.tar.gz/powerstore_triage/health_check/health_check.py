import os
import re
import logging
from infra.utils import TOOL_NAME, TOOL_OUTPUT_FOLDER, TestSeverity, TestResult, Color,\
    ArrayModel, SoftwareVersion, VersionSpec, normalize_version_str, DEV_VERSION_RE,\
    POST_GA_VERSION_RE, handle_exceptions, get_tmp_file_path, get_mgmt_data_file_path,\
    get_sym_node_command_output_file_path, get_tmp_file_path, get_node_file
import inspect
from parser.dc_inventory import parse_dc_inventory
import json
import subprocess

#------------------------------------------------------------------------#
# Copyright (C) 2020 Dell Inc. and its subsidiaries. All Rights reserved #
#------------------------------------------------------------------------#
#--------------------------------------#
# Henry.An@dell.com                    #
# NGMR Engineering Technical Services  #
#--------------------------------------#

logger = logging.getLogger('.'.join([TOOL_NAME, __name__]))
# TODO: need to change this to VersionSpec.POST_GA after GA version schema is used
version_spec = VersionSpec.DEV


def get_cluster_info(dc_folder):
    cloudiq_view_file_path = get_mgmt_data_file_path(dc_folder, 'cloudiq_view.json')
    if cloudiq_view_file_path:
        with open(cloudiq_view_file_path, 'r') as f:
            data = json.load(f)
            cluster_info = data['data'][0]
    else:
        cluster_info = {}
    logger.debug(cluster_info)
    return cluster_info

def get_appliance_info(dc_folder):
    appliance_info = dict()
    for node_name in ["node_a", "node_b"]:
        appliance_info_file_path = get_tmp_file_path(dc_folder, "{0}_cyc_hw_appliance_info.json".format(node_name))
        if appliance_info_file_path:
            with open(appliance_info_file_path, 'r') as f:
                appliance_info = json.load(f)
                if appliance_info['system_type'].startswith("Virtual-"):
                    # Virtual-Warnado-EX
                    # BM-Warnado-EX
                    appliance_info['model'] = ArrayModel.POWERSTOREX
                else:
                    appliance_info['model'] = ArrayModel.POWERSTORE
            return appliance_info
    if "model" not in appliance_info:
        appliance_info['model'] = ArrayModel.ALL
    return appliance_info

# The problem is that dc_folder is a variable depends on user's selection!!
# cluster_info = get_cluster_info(dc_folder)
# if DEV_VERSION_RE.match(cluster_info['release_version']):
#     version_spec = VersionSpec.DEV
# elif POST_GA_VERSION_RE.match(cluster_info['release_version']):
#     version_spec = VersionSpec.POST_GA


def test_add_metadata(test, metadata_name, value):
    if not hasattr(test, metadata_name):
        setattr(test, metadata_name, [])
    if isinstance(value, list) or isinstance(value, tuple) or isinstance(value, set):
        getattr(test, metadata_name).extend(list(value))
    else:
        getattr(test, metadata_name).append(value)


def kb(test_print_name, kb_article=None, note=None):
    """Decorator to specify the test name, associated KB and note"""
    def kb_wrapper(func):
        func._test_print_name = test_print_name
        func._kb = kb_article
        func._note = note
        return func
    return kb_wrapper


def mode(model=ArrayModel.ALL, encrypted_only=False,
         is_grep_test=False, grep_list=[], grep_all=False, ee=True):
    def mode_wrapper(func):
        func._encrypted_only = encrypted_only
        # specify which cluster/appliance model the test is targeted
        func._model = model
        # the test is just a grep test
        func._is_grep_test = is_grep_test
        # list of key words to grep
        func._grep_list = grep_list
        # determine if all the key words need to be found for a match
        func._grep_all = grep_all
        # determine if the test is Escalation Engineering visible only
        func._ee = ee
        return func
    return mode_wrapper


def versions(start='*', end='*'):
    """Decorator to specify the array software versions the test is relevant for:
    The versions larger than start and lower than end are considered relevant (inclusive)
    If start/end is not specified, it is considered valid for all versions
    Acceptable version string can be something like:
        *, 1.*, 1.1.*, 1.0.1.*, 1.0.1.0.5.007, 1.0.1
    """
    def func_wrapper(func):
        start_v = normalize_version_str(start, True, version_spec)
        end_v = normalize_version_str(end, False, version_spec)
        func._start_ver = SoftwareVersion(start_v, version_spec)
        func._end_ver = SoftwareVersion(end_v, version_spec)
        return func
    return func_wrapper


def severity(sev):
    """Decorator to specify test severity"""
    def func_wrapper(func):
        func._severity = sev
        return func
    return func_wrapper


def tags(tag_list):
    """Decorator to specify tags for the test"""
    def func_wrapper(func):
        test_add_metadata(func, '_tags', tag_list)
        return func
    return func_wrapper


class HealthCheck:
    def __init__(self, dc_folder, fh=None):
        self.cluster_info =  get_cluster_info(dc_folder)
        self.appliance_info = get_appliance_info(dc_folder)
        self.dc_folder = dc_folder
        # store the warning, error messages of each test
        # so that the warning, error messages can be put into the output file
        self.message_dict = dict()
        self.output_fh = fh
        self.logger = logger

    # Tests
    @tags(['all', 'cp', 'platform'])
    @severity(TestSeverity.CRITICAL)
    @versions(start='*', end="*")
    @kb(test_print_name='No ACTIVE alert',
        note="Please check powerstore-triage/alert.txt for the details of those alerts in ACTIVE state")
    @mode()
    def test_no_active_alert(self):
        self.message_dict['test_no_active_alert'] = list()
        messages = self.message_dict['test_no_active_alert']
        test_result = TestResult.PASSED
        alert_json_file_path = get_mgmt_data_file_path(self.dc_folder, "alert.json")
        if alert_json_file_path:
            with open(alert_json_file_path, 'r') as f:
                data = json.load(f)
                list_of_dict = data['data']
                for alert in list_of_dict:
                    if alert["state"] == "ACTIVE" and alert['severity'] != 'Info':
                        test_result = TestResult.FAILED
        else:
            msg = "config_capture_management_data/alert.json is not found in node_a or node_b"
            self.logger.warning(msg)
            messages.append(msg)
            test_result = TestResult.SKIPPED
        return test_result


    @tags(['network', 'platform'])
    @severity(TestSeverity.CRITICAL)
    @versions(start='*', end="*")
    @kb(test_print_name='PowerStoreX NIC Capabilities on 4PortCard Ports',
        note="Please refer to https://confluence.cec.lab.emc.com/display/ETS/How+to+Detect+and+Fix+Missing+Interface+Capabilities+on+Management+Port")
    @mode(model=ArrayModel.POWERSTOREX)
    def test_nic_mgmt_capability(self):
        self.message_dict['test_nic_mgmt_capability'] = list()
        messages = self.message_dict['test_nic_mgmt_capability']
        test_result = TestResult.PASSED
        show_frontend_ports_file_path = get_sym_node_command_output_file_path(self.dc_folder, "xmcli_-x__-c_show-frontend-ports.txt")
        pattern = re.compile(r',\s+')
        if show_frontend_ports_file_path:
            with open(show_frontend_ports_file_path, 'r') as f:
                for line in f:
                    if '4PortCard-hFEPort' in line:
                        line = re.sub(pattern, ',', line)
                        attributes = line.split()
                        capabilities_str = attributes[-2]
                        port_name = attributes[0]
                        raw_capabilities_str = attributes[-4]
                        if 'Mgmt' not in capabilities_str:
                            test_result = TestResult.FAILED
                            msg = "Port %s's Capabilities:%s, Raw-Capabilities:%s" %(port_name, capabilities_str, raw_capabilities_str)
                            logger.error(msg)
                            messages.append(msg)
        else:
            msg = "xmcli_-x__-c_show-frontend-ports.txt is not found in node_a or node_b"
            self.logger.warning(msg)
            messages.append(msg)
            test_result = TestResult.SKIPPED
        return test_result


    # TODO: this test can be removed if test_svc_diag_icw_hardware always works
    @tags(['hardware', 'platform'])
    @severity(TestSeverity.CRITICAL)
    @versions(start='*', end="*")
    @kb(test_print_name='Hardware Fault Status Register Check',
        note="Please check node(a|b)/command_output/cyc_ipmitool_mrsoem_fsr_display.txt and cyc_peer_--fsr.txt")
    @mode()
    def test_hardware_mrsoem_fsr(self):
        # the key name(in this method 'test_mrsoem_fsr') has to be the same with the method name
        self.message_dict['test_hardware_mrsoem_fsr'] = list()
        messages = self.message_dict['test_hardware_mrsoem_fsr']
        test_result = TestResult.PASSED
        file_count = 0
        for node_name in ["node_a", "node_b"]:
            mrsoem_file = os.path.join(self.dc_folder,
                                       "{0}/command_output/cyc_ipmitool_mrsoem_fsr_display.txt".format(node_name))
            if os.path.exists(mrsoem_file):
                file_count += 1
                with open(mrsoem_file, 'r') as f:
                    for line in f:
                        if "FLT" in line:
                            test_result = TestResult.FAILED
                            msg = "{0} cyc_ipmitool_mrsoem_fsr_display.txt: {1}".format(node_name, line.strip())
                            self.logger.error(msg)
                            messages.append(msg)
            else:
                msg = "{0}: cyc_ipmitool_mrsoem_fsr_display.txt is not found".format(node_name)
                self.logger.warning(msg)
                messages.append(msg)
                if node_name == "node_a":
                    peer_node_name = "node_b"
                else:
                    peer_node_name = "node_a"
                mrsoem_peer_file =  os.path.join(self.dc_folder,
                                        "{0}/command_output/cyc_peer_--fsr.txt".format(peer_node_name))
                if os.path.exists(mrsoem_peer_file):
                    file_count += 1
                    with open(mrsoem_peer_file, 'r') as f:
                        for line in f:
                            if "FLT" in line:
                                test_result = TestResult.FAILED
                                msg = "{0} cyc_peer_--fsr.txt: {1}".format(peer_node_name, line.strip())
                                self.logger.error(msg)
                                messages.append(msg)
                else:
                    msg = "{0}: cyc_peer_--fsr.txt is not found".format(peer_node_name)
                    self.logger.warning(msg)
                    messages.append(msg)
        
        if file_count == 0:
            msg = "Neither cyc_ipmitool_mrsoem_fsr_display.txt nor cyc_peer_--fsr.txt is found in node_a or node_b"
            self.logger.warning(msg)
            messages.append(msg)
            test_result = TestResult.SKIPPED
        elif file_count == 1:
            test_result = TestResult.PARTIAL
        return test_result


    @tags(['hardware', 'platform'])
    @severity(TestSeverity.CRITICAL)
    @versions(start='*', end="*")
    @kb(test_print_name='No FW Upgrade needed(Drive FW is not included)',
        note="Please check node(a|b)/command_output/cyc_fwtool.sh_-showrev.txt")
    @mode()
    def test_no_fw_upgrade_needed(self):
        self.message_dict['test_no_fw_upgrade_needed'] = list()
        messages = self.message_dict['test_no_fw_upgrade_needed']
        test_result = TestResult.PASSED
        file_count = 0
        # https://jira.cec.lab.emc.com/browse/TEE-432
        for node_name in ["node_a", "node_b"]:
            cyc_fwtool_showrev_file_path = get_node_file(self.dc_folder, node_name, 'command_output/cyc_fwtool.sh_-showrev.txt')
            if cyc_fwtool_showrev_file_path:
                self.logger.debug(cyc_fwtool_showrev_file_path)
                # sed -n -e '/Running rev/,/SP CMD versions/p' node_a/command_output/cyc_fwtool.sh_-showrev.txt
                file_count += 1
                cmd = r"sed -n -e '/^$/d' -e '/Running rev/,/SP CMD versions/p' " + cyc_fwtool_showrev_file_path
                content = subprocess.getoutput(cmd)
                lines = content.split("\n")
                # self.logger.info(content)
                # with open(cyc_fwtool_showrev_file_path, 'r') as f:
                for line in lines:
                    attributes = line.split()
                    # self.logger.info(attributes)
                    # line could be empty line
                    if len(attributes) > 0 and 'yes' in attributes[-1].lower():
                        test_result = TestResult.FAILED
                        msg = "{0}: {1}".format(node_name, line.strip())
                        self.logger.error(msg)
                        messages.append(msg)
            else:
                msg = "{0}: command_output/cyc_fwtool.sh_-showrev.txt is not found".format(node_name)
                self.logger.warning(msg)
                messages.append(msg)
        if file_count == 0:
            msg = "command_output/cyc_fwtool.sh_-showrev.txt is not found in node_a or node_b"
            self.logger.warning(msg)
            messages.append(msg)
            test_result = TestResult.SKIPPED
        elif file_count == 1:
            test_result = TestResult.PARTIAL
        return test_result


    @tags(['hardware', 'platform'])
    @severity(TestSeverity.CRITICAL)
    @versions(start='*', end="*")
    @kb(test_print_name='Base Enclosure PSU Input Check(ipmitool view)',
        note="Please check node(a|b)/command_output/cyc_ipmitool_sensor_list.txt")
    @mode()
    def test_base_enclosure_powersupply_input(self):
        self.message_dict['test_base_enclosure_powersupply_input'] = list()
        messages = self.message_dict['test_base_enclosure_powersupply_input']
        test_result = TestResult.PASSED
        file_count = 0
        # https://jira.cec.lab.emc.com/browse/TEE-432
        # can be obtained from command_output/xmcli_-x__-c_show-storage-controllers-psus.txt as well.
        # xmcli_-x__-c_show-storage-controllers-psus.txt
        # xmcli (tech)> show-storage-controllers-psus
        # Name                     Index Serial-Number  Location-Index Power-Feed State   Comp-Status Enabled-State Input Location FW-Version Part-Number    FFID   Storage-Controller-Name Index Brick-Name Index Cluster-Name  Index
        # BaseEnclosure-NodeA-PSU0 1     AC2AC201523336 0              port_1     healthy ok          enabled       off   right    1.2        071-000-750-01 720975 BaseEnclosure-NodeA     1     X1         1     usmdcemcps001 1
        # BaseEnclosure-NodeB-PSU0 2     AC2AC201523171 1              port_2     healthy ok          enabled       on    left     1.2        071-000-750-01 720975 BaseEnclosure-NodeB     2     X1         1     usmdcemcps001 1
        for node_name in ["node_a", "node_b"]:
            file_path = get_node_file(self.dc_folder, node_name, 'command_output/cyc_ipmitool_sensor_list.txt')
            if file_path:
                self.logger.debug(file_path)
                file_count += 1
                with open(file_path, 'r') as f:
                    for line in f:
                        attributes = line.split('|')
                        # make sure to skip empty line
                        if len(attributes) > 0 and ('ps0_in_voltage' in attributes[0].lower() or 'ps1_in_voltage' in attributes[0].lower()) :
                            # PS1_Status       | 0x0        | discrete   | 0x0380| na        | na        | na        | na        | na        | na
                            # PS1_Input_Power  | 0.000      | Watts      | ok    | na        | na        | na        | na        | na        | na
                            # PS1_In_Voltage   | 0.000      | Volts      | ok    | na        | na        | na        | na        | na        | na
                            # https://jira.cec.lab.emc.com/browse/TEE-641
                            # PS0_Input_Power  | na         | Watts      | na    | na        | na        | na        | na        | na        | na
                            # PS0_In_Voltage   | na         | Volts      | na    | na        | na        | na        | na        | na        | na
                            # PS0_Temp0        | na         | degrees C  | na    | na        | na        | na        | na        | na        | na
                            # PS0_Temp1        | na         | degrees C  | na    | na        | na        | na        | na        | na        | na
                            input_voltage = attributes[1].strip()
                            if input_voltage == 'na' or float(input_voltage) < 1:
                                test_result = TestResult.FAILED
                                msg = "{0}: {1}".format(node_name, line.strip())
                                self.logger.error(msg)
                                messages.append(msg)
            else:
                msg = "{0}: command_output/cyc_ipmitool_sensor_list.txt is not found".format(node_name)
                self.logger.warning(msg)
                messages.append(msg)
        if file_count == 0:
            msg = "command_output/cyc_ipmitool_sensor_list.txt is not found in node_a or node_b"
            self.logger.warning(msg)
            messages.append(msg)
            test_result = TestResult.SKIPPED
        elif file_count == 1:
            test_result = TestResult.PARTIAL
        return test_result


    @tags(['hardware', 'platform'])
    @severity(TestSeverity.CRITICAL)
    @versions(start='*', end="*")
    @kb(test_print_name='Base Enclosure PSU State from Platform view',
        note="Please check node(a|b)/command_output/xmcli_-x__-c_show-storage-controllers-psus.txt for details")
    @mode()
    def test_base_enclosure_psu_state_xms_view_healthy(self):
        self.message_dict['test_base_enclosure_psu_state_xms_view_healthy'] = list()
        messages = self.message_dict['test_base_enclosure_psu_state_xms_view_healthy']
        test_result = TestResult.PASSED
        # xmcli output exists on one node only.
        # no xmcli command output since FootHill release
        file_path = get_sym_node_command_output_file_path(self.dc_folder, 'xmcli_-x__-c_show-storage-controllers-psus.txt')
        if os.path.exists(file_path):
            with open(file_path, 'r') as f:
                for line in f:
                    # exclude the first line and the header line
                    if "xmcli" not in line and "Serial-Number" not in line:
                        if " healthy" not in line:
                            # BaseEnclosure-NodeA-PSU0 ... port_1     disconnected ok      enabled       uninitialized right      0      BaseEnclosure-NodeA     1     X1         1     TECH-PS-CLS  1
                            test_result = TestResult.FAILED
                            msg = "{0}".format(line.strip())
                            self.logger.error(msg)
                            messages.append(msg)
        else:
            msg = "xmcli_-x__-c_show-storage-controllers-psus.txt file is not found in Data Collection"
            self.logger.warning(msg)
            messages.append(msg)
            test_result = TestResult.SKIPPED
        return test_result


    @tags(['hardware', 'platform'])
    @severity(TestSeverity.CRITICAL)
    @versions(start='*', end="*")
    @kb(test_print_name='SFP State from Platform view',
        note="Please check node(a|b)/command_output/xmcli_-x__-c_show-sfps.txt for details")
    @mode()
    def test_sfp_state_xms_view_healthy(self):
        self.message_dict['test_sfp_state_xms_view_healthy'] = list()
        messages = self.message_dict['test_sfp_state_xms_view_healthy']
        test_result = TestResult.PASSED
        # xmcli output exists on one node only.
        # no xmcli command output since FootHill release
        file_path = get_sym_node_command_output_file_path(self.dc_folder, 'xmcli_-x__-c_show-sfps.txt')
        if os.path.exists(file_path):
            with open(file_path, 'r') as f:
                for line in f:
                    # exclude the first line and the header line
                    if "xmcli" not in line and "Part-Number" not in line:
                        if " healthy" not in line and "empty" not in line:
                            # https://confluence.cec.lab.emc.com/display/ETS/SFP+modules+inserted+in+each+node+of+the+appliance+do+not+match+-+Alert+does+not+clear
                            # /disks/jiraproduction/0201000-0201999/MDT-201033/powerstore_7WZ7MX2_PSdb5f5d86fc59_CKM00203200872_2020-09-08_09-47-24_service-data
                            # BaseEnclosure-NodeB-4PortCard-SFP3      17    0                                          empty                                                                                  0          0        0          Unknown    []                               Unknown            Unknown        clear       2        3
                            # BaseEnclosure-NodeB-4PortCard-SFP1      19    1                                          healthy                  CISCO-TYCO       1-2053783-2      TED2310B8E9      U          0          0        0          Unknown    ['10_Gbps']                      Ethernet           Copper_Pigtail unsupported 2        1
                            # BaseEnclosure-NodeB-4PortCard-SFP0      20    1                                          healthy                  CISCO-TYCO       1-2053783-2      TED2310B8EB      U          0          0        0          Unknown    ['10_Gbps']                      Ethernet           Copper_Pigtail unsupported 2        0
                            # BaseEnclosure-NodeB-IoModule1-SFP0      21    0                                          disconnected                                                                           0          0        0          Unknown    []                               Unknown            Unknown        unknown     0        0
                            test_result = TestResult.FAILED
                            msg = "{0}".format(line.strip())
                            self.logger.error(msg)
                            messages.append(msg)
        else:
            msg = "xmcli_-x__-c_show-sfps.txt file is not found in Data Collection"
            self.logger.warning(msg)
            messages.append(msg)
            test_result = TestResult.SKIPPED
        return test_result


    @tags(['hardware', 'platform'])
    @severity(TestSeverity.CRITICAL)
    @versions(start='*', end="*")
    @kb(test_print_name='Node State from Platform view',
        note="Please check node(a|b)/command_output/xmcli_-x__-c_show-storage-controllers.txt for details")
    @mode()
    def test_node_state_xms_view_healthy(self):
        self.message_dict['test_node_state_xms_view_healthy'] = list()
        messages = self.message_dict['test_node_state_xms_view_healthy']
        test_result = TestResult.PASSED
        # xmcli output exists on one node only.
        # no xmcli command output since FootHill release
        file_path = get_sym_node_command_output_file_path(self.dc_folder, 'xmcli_-x__-c_show-storage-controllers.txt')
        if os.path.exists(file_path):
            with open(file_path, 'r') as f:
                for line in f:
                    # exclude the first line and the header line
                    if "xmcli" not in line and "Storage-Controller-Name" not in line:
                        if " healthy" not in line or "enabled" not in line:
                            # Not sure what Health-State means, do not check this for now.
                            # https://jira.cec.lab.emc.com/browse/TEE-596
                            # Storage-Controller-Name Index Mgr-Addr        IB-Bonded-Addr  Brick-Name Index Cluster-Name Index State   Comp-Status Health-State Enabled-State   Stop-Reason Conn-State
                            # BaseEnclosure-NodeA     1     128.221.255.113 128.221.255.113 X1         1     PivotPMX     1     healthy ok          degraded     enabled         ha_failure  connected
                            # BaseEnclosure-NodeB     2     128.221.255.116 128.221.255.116 X1         1     PivotPMX     1     healthy ok          degraded     system_disabled halt_node   connected
                            #
                            # BaseEnclosure-NodeA     1     128.221.255.113 128.221.255.113 X1         1     TECH-PS-CLS  1     healthy ok          healthy       enabled       none        connected
                            # BaseEnclosure-NodeB     2     128.221.255.116 128.221.255.116 X1         1     TECH-PS-CLS  1     healthy ok          partial_fault enabled       none        connected
                            test_result = TestResult.FAILED
                            msg = "{0}".format(line.strip())
                            self.logger.error(msg)
                            messages.append(msg)
        else:
            msg = "xmcli_-x__-c_show-storage-controllers.txt file is not found in Data Collection"
            self.logger.warning(msg)
            messages.append(msg)
            test_result = TestResult.SKIPPED
        return test_result


    @tags(['hardware', 'platform'])
    @severity(TestSeverity.CRITICAL)
    @versions(start='*', end="*")
    @kb(test_print_name='IO module State from Platform view',
        note="Please check node(a|b)/command_output/xmcli_-x__-c_show-ioms.txt for details. Check command_output/lspci_-v.txt to see if the IOM is recognized by OS.")
    @mode()
    def test_iom_state_xms_view_healthy(self):
        self.message_dict['test_iom_state_xms_view_healthy'] = list()
        messages = self.message_dict['test_iom_state_xms_view_healthy']
        test_result = TestResult.PASSED
        # xmcli output exists on one node only.
        # no xmcli command output since FootHill release
        file_path = get_sym_node_command_output_file_path(self.dc_folder, 'xmcli_-x__-c_show-ioms.txt')
        if os.path.exists(file_path):
            with open(file_path, 'r') as f:
                for line in f:
                    # exclude the first line and the header line
                    if "xmcli" not in line and "Storage-Controller-Name" not in line:
                        if "empty" not in line and (" healthy" not in line or "enabled" not in line):
                            # https://jira.cec.lab.emc.com/browse/TEE-596
                            # xmcli (tech)> show-ioms
                            # Name                               Index Serial-Number  IOM-Index State   Comp-Status Power-Status Enabled-State   Part-Number     FFID    Model                 IOM-Slot IOM-Type Storage-Controller-Name Index Brick-Name Index Cluster-Name Index
                            # BaseEnclosure-NodeA-IoModule0      1     CF2SP193200187 0         healthy ok          on           system_disabled 303-321-000C-02 2293777 32 Gb Fibre v1        0        slic     BaseEnclosure-NodeA     1     X1         1     PivotPMX     1
                            # BaseEnclosure-NodeA-IoModule1      2                    1         empty   ok          unknown      enabled                         0                             1        slic     BaseEnclosure-NodeA     1     X1         1     PivotPMX     1
                            # BaseEnclosure-NodeA-4PortCard      3     CF2VG201000045 2         healthy ok          on           enabled         105-001-101-03  3014657 25 GbE v1 OCP         0        ocp      BaseEnclosure-NodeA     1     X1         1     PivotPMX     1
                            # BaseEnclosure-NodeA-2PortCard      4                    3         empty   ok          unknown      enabled                         0                             1        ocp      BaseEnclosure-NodeA     1     X1         1     PivotPMX     1
                            # BaseEnclosure-NodeA-EmbeddedModule 5     FCNMD193500013 4         healthy ok          on           enabled         110-452-001C-04 2949163 IO Personality Module 0        iopm     BaseEnclosure-NodeA     1     X1         1     PivotPMX     1
                            test_result = TestResult.FAILED
                            msg = "{0}".format(line.strip())
                            self.logger.error(msg)
                            messages.append(msg)
        else:
            msg = "xmcli_-x__-c_show-ioms.txt file is not found in Data Collection"
            self.logger.warning(msg)
            messages.append(msg)
            test_result = TestResult.SKIPPED
        return test_result


    @tags(['hardware', 'platform'])
    @severity(TestSeverity.CRITICAL)
    @versions(start='*', end="*")
    @kb(test_print_name='NVMe Slot Status Check',
        note="Please check 'NVMe Slot Status' section in node_(a|b)/command_output/nvme_drive.py.txt for details")
    @mode()
    def test_nvme_slot_status_check(self):
        self.message_dict['test_nvme_slot_status_check'] = list()
        messages = self.message_dict['test_nvme_slot_status_check']
        test_result = TestResult.PASSED
        # use nvme_drive_slot_statuse.json that generated by parser/nvme_drive.py
        file_path = get_tmp_file_path(self.dc_folder, 'nvme_drive_slot_statuse.json')
        if file_path:
            with open(file_path) as fp:
                nvme_drive_slot_status = json.load(fp)
                for slot in nvme_drive_slot_status:
                    for node in ['a', 'b']:
                        fw_version = nvme_drive_slot_status[slot][node]['fw_version']
                        sn = nvme_drive_slot_status[slot][node]['sn']
                        if fw_version.lower() == 'none' and sn.lower() == 'none':
                            test_result = TestResult.FAILED
                            msg = "slot:{0}, node: {1}, fw_version:{2}, SN:{3}".format(slot, node, fw_version, sn)
                            self.logger.error(msg)
                            messages.append(msg)
        else:
            msg = "command_output/nvme_drive.py.txt is not found in Data Collection"
            self.logger.warning(msg)
            messages.append(msg)
            test_result = TestResult.SKIPPED
        return test_result


    @tags(['hardware', 'platform'])
    @severity(TestSeverity.CRITICAL)
    @versions(start='*', end="*")
    @kb(test_print_name='NVRAM Firmware Version Check',
        note="Please check 'node_(a|b)/core_os/nvme_list.txt for details")
    @mode()
    def test_nvram_fw_version_check(self):
        self.message_dict['test_nvram_fw_version_check'] = list()
        messages = self.message_dict['test_nvram_fw_version_check']
        test_result = TestResult.PASSED
        file_count = 0
        # check core_os/nvme_list.txt because nvme list works even if service container is not available
        for node_name in ["node_a", "node_b"]:
            file_path = get_node_file(self.dc_folder, node_name, 'core_os/nvme_list.txt')
            if file_path:
                self.logger.debug(file_path)
                file_count += 1
                with open(file_path, 'r') as f:
                    for line in f:
                        if 'MTC_8GBMN' in line:
                            # Node             SN                   Model                                    Namespace Usage                      Format           FW Rev
                            # ---------------- -------------------- ---------------------------------------- --------- -------------------------- ---------------- --------
                            # /dev/nvme0n1     VXNA0M900524         PB23F04T                                 1           3.84  TB /   3.84  TB    512   B +  0 B   GPJ99E5Q
                            # /dev/nvme4n1     VXNA0M900527         PB23F04T                                 1           3.84  TB /   3.84  TB    512   B +  0 B   GPJ99E5Q
                            # /dev/nvme5n1     VXNA0M900523         PB23F04T                                 1           3.84  TB /   3.84  TB    512   B +  0 B   GPJ99E5Q
                            # /dev/nvme14n1    9A27634B2AA          MTC_8GBMN                                1           0.00   B /   8.48  GB    512   B +  0 B   3.0.44.0
                            # /dev/nvme6n1     9A17634171B          MTC_8GBMN                                1           8.48  GB /   8.48  GB    512   B +  0 B   3.0.45.6
                            # /dev/nvme7n1     VXNA0M900875         PB23F04T                                 1           3.84  TB /   3.84  TB    512   B +  0 B   GPJ99E5Q
                            fw_version = line.split()[-1].strip()
                            fw_list = [int(x) for x in fw_version.split(".")]
                            if fw_list < [3, 0, 45, 6]:
                                test_result = TestResult.FAILED
                                msg = "Minimal NVRAM FW version should be 3.0.45.6"
                                self.logger.error(msg)
                                messages.append(msg)                                
                                msg = "{0}: {1}".format(node_name, line.strip())
                                self.logger.error(msg)
                                messages.append(msg)
            else:
                msg = "{0}: core_os/nvme_list.txt is not found".format(node_name)
                self.logger.warning(msg)
                messages.append(msg)
        if file_count == 0:
            msg = "core_os/nvme_list.txt is not found in node_a or node_b"
            self.logger.warning(msg)
            messages.append(msg)
            test_result = TestResult.SKIPPED
        elif file_count == 1:
            test_result = TestResult.PARTIAL
        return test_result


    # /disks/JIRATEE/0000000-0000999/TEE-606/2020-10-01_11-36/powerstore_B5Z7MX2_PSe05cda08c575_CKM00203700422_2020-10-01_15-18-15_service-data
    # https://jira.cec.lab.emc.com/browse/MDT-209855  Empty Chassis Product Part Number(PPN)
    @tags(['hardware', 'platform'])
    @severity(TestSeverity.CRITICAL)
    @versions(start='*', end="*")
    @kb(test_print_name='Chassis Product Part Number Check',
        note="Please check 'node_(a|b)/command_output/cyc_ipmitool_fru_list.txt for details")
    @mode()
    def test_chassis_ppn_check(self):
        self.message_dict['test_chassis_ppn_check'] = list()
        messages = self.message_dict['test_chassis_ppn_check']
        test_result = TestResult.PASSED
        file_count = 0
        for node_name in ["node_a", "node_b"]:
            file_path = get_tmp_file_path(self.dc_folder, '{0}_ipmitool_fru_list.json'.format(node_name))
            if file_path:
                self.logger.debug(file_path)
                file_count += 1
                with open(file_path, 'r') as f:
                    list_of_fru = json.load(f)
                    for fru in list_of_fru:
                        if fru['fru_name'] == 'Chassis':
                            if 'Product Part Number' not in fru:
                                test_result = TestResult.FAILED
                                msg = "{0} cyc_ipmitool_fru_list.txt: Product Part Number of Chassis doesn't exist".format(node_name)
                                self.logger.error(msg)
                                messages.append(msg)  
                            elif fru['Product Part Number'] == '':
                                test_result = TestResult.FAILED
                                msg = "{0} cyc_ipmitool_fru_list.txt: Product Part Number of Chassis is empty".format(node_name)
                                self.logger.error(msg)
                                messages.append(msg)                                
            else:
                msg = "{0}_ipmitool_fru_list.json is not found".format(node_name)
                self.logger.warning(msg)
                messages.append(msg)
        if file_count == 0:
            msg = "Neither node_a_ipmitool_fru_list.json or node_b_ipmitool_fru_list.json is found in powerstore-triage/tmp_folder"
            self.logger.warning(msg)
            messages.append(msg)
            test_result = TestResult.SKIPPED
        elif file_count == 1:
            test_result = TestResult.PARTIAL
        return test_result


    @tags(['hardware', 'platform'])
    @severity(TestSeverity.CRITICAL)
    @versions(start='*', end="*")
    @kb(test_print_name='svc_diag --icw_hardware',
        note="Please check command_output/svc_diag_list_--icw_hardware.txt for details")
    @mode()
    def test_svc_diag_icw_hardware(self):
        # https://confluence.cec.lab.emc.com/display/CYCLONE/ICW+HW+Check+Futures
        # https://confluence.cec.lab.emc.com/display/CYCLONE/C1602+Hardware+validation+in+ICW
        self.message_dict['test_svc_diag_icw_hardware'] = list()
        messages = self.message_dict['test_svc_diag_icw_hardware']
        test_result = TestResult.PASSED
        # svc_diag_list_--icw_hardware.txt output exists on one node only.
        file_path = get_sym_node_command_output_file_path(self.dc_folder, 'svc_diag_list_--icw_hardware.txt')
        if file_path:
            with open(file_path, 'r') as f:
                overall_status_section = False
                for line in f:
                    if line.startswith('OVERALL STATUS'):
                        overall_status_section = True
                    # Only need to check the OVERALL STATUS and the lines after it
                    # OVERALL STATUS: True, return_code 0
                    #   IOM Consistency Check     : Success
                    #   Node Consistency Check    : Success
                    #   Battery Check             : OK
                    #   Fault Status Register A   : Success
                    #   Fault Status Register B   : Success
                    #   Node A Accessible         : True
                    #   Node B Accessible         : True
                    #   Drive Check               : Success
                    #   Node Drives Compare Check : Success
                    #   Enclosure Check           : Success
                    #   IO Module Compare Check   : Success
                    if overall_status_section:
                        if line.startswith('OVERALL STATUS'):
                            if 'return_code 0' not in line:
                                msg = "'svc_diag list --icw_hardware' itself failed"
                                self.logger.error(msg)
                                messages.append(msg)
                                msg = "{0}".format(line.strip())
                                self.logger.error(msg)
                                messages.append(msg)
                        else:
                            attributes = line.split(':')
                            if len(attributes) == 2:
                                result = attributes[-1].strip()
                                if result.lower() not in ['success', 'ok', 'true']:
                                    test_result = TestResult.FAILED
                                    msg = "{0}".format(line.strip())
                                    self.logger.error(msg)
                                    messages.append(msg)
        else:
            msg = "svc_diag_list_--icw_hardware.txt is not found in Data Collection"
            self.logger.warning(msg)
            messages.append(msg)
            test_result = TestResult.SKIPPED
        return test_result


    @tags(['hardware', 'platform'])
    @severity(TestSeverity.CRITICAL)
    @versions(start='*', end="*")
    @kb(test_print_name="Mapped RAID Tier Status Check",
        note="Please check 'tier info summary' section in cli.py_dc_plugin_dump_raid_summary.txt for details")
    @mode()
    def test_mapped_raid_tier_status_healthy(self):
        self.message_dict['test_mapped_raid_tier_status_healthy'] = list()
        messages = self.message_dict['test_mapped_raid_tier_status_healthy']
        test_result = TestResult.PASSED
        # cli.py_dc_plugin_dump_raid_summary.txt exists on one node only.
        file_path = get_sym_node_command_output_file_path(self.dc_folder, 'cli.py_dc_plugin_dump_raid_summary.txt')
        if file_path:
            cmd = r"sed -n -e '/- tier info summary -/,/- slice pool md -/p; /- slice pool md -/q' " + file_path
            content = subprocess.getoutput(cmd)
            lines = content.split("\n")
            for line in lines:
                # exclude the header line
                if not line.startswith("---") and "tier_id" not in line:
                    attributes = line.split()
                    if len(attributes) > 0:
                        status = attributes[-1].strip()
                        expanded_uber_cnt = int(attributes[-9].strip())
                        # self.logger.info(attributes[-9])
                        if expanded_uber_cnt > 0 and status != "online":
                            test_result = TestResult.FAILED
                            msg = "{0:<30} {1}".format(" ".join(attributes[:-10]),status)
                            self.logger.error(msg)
                            messages.append(msg)
        else:
            msg = "cli.py_dc_plugin_dump_raid_summary.txt is not found in Data Collection"
            self.logger.warning(msg)
            messages.append(msg)
            test_result = TestResult.SKIPPED
        return test_result


    @tags(['hardware', 'platform'])
    @severity(TestSeverity.CRITICAL)
    @versions(start='*', end="*")
    @kb(test_print_name="Drive Healthy Status from Mapped RAID view",
        note="Please check cli.py_dc_plugin_dump_raid_summary.txt for details")
    @mode()
    def test_drive_mapped_raid_view_healthy(self):
        self.message_dict['test_drive_mapped_raid_view_healthy'] = list()
        messages = self.message_dict['test_drive_mapped_raid_view_healthy']
        test_result = TestResult.PASSED
        # cli.py_dc_plugin_dump_raid_summary.txt exists on one node only.
        file_path = get_sym_node_command_output_file_path(self.dc_folder, 'cli.py_dc_plugin_dump_raid_summary.txt')
        if file_path:
            # get the lines between '- device info -' and '- device count by type -', exclusive
            cmd = r"awk '/- device info -/{flag=1; next} /- device count by type -/{flag=0} flag' " + file_path
            content = subprocess.getoutput(cmd)
            lines = content.split("\n")
            for line in lines:
                # exclude the header line
                if "B_E_S" not in line:
                    attributes = line.split()
                    if len(attributes) > 0:
                        snap_state = attributes[5].strip()
                        eval_state = attributes[6].strip()
                        # rrs = attributes[-2].strip()
                        if snap_state.lower() != "ready" or eval_state.lower() != "ready":
                            test_result = TestResult.FAILED
                            msg = "{0}".format(line.strip())
                            self.logger.error(msg)
                            messages.append(msg)
        else:
            msg = "cli.py_dc_plugin_dump_raid_summary.txt is not found in Data Collection"
            self.logger.warning(msg)
            messages.append(msg)
            test_result = TestResult.SKIPPED
        return test_result


    @tags(['hardware', 'platform'])
    @severity(TestSeverity.CRITICAL)
    @versions(start='*', end="*")
    @kb(test_print_name='BBU State from Platform view',
        note="Please check node(a|b)/command_output/xmcli_-x__-c_show-nodebbus.txt for details")
    @mode()
    def test_bbu_state_xms_view_healthy(self):
        self.message_dict['test_bbu_state_xms_view_healthy'] = list()
        messages = self.message_dict['test_bbu_state_xms_view_healthy']
        test_result = TestResult.PASSED
        # xmcli output exists on one node only.
        # no xmcli command output since FootHill release
        file_path = get_sym_node_command_output_file_path(self.dc_folder, 'xmcli_-x__-c_show-nodebbus.txt')
        if os.path.exists(file_path):
            with open(file_path, 'r') as f:
                for line in f:
                    # exclude the first line and the header line
                    if "xmcli" not in line and "Serial-Number" not in line:
                        if " healthy" not in line:
                            # BaseEnclosure-NodeA-InternalBatteryBackupModule0 1     ACPV8192400103 0             healthy enabled       078-000-168-02 LITHIUM-ION, UNIVERSAL BOB 1.20       ready        ok                    BaseEnclosure-NodeA     1     X1         1     usmdcemcps001 1
                            test_result = TestResult.FAILED
                            msg = "{0}".format(line.strip())
                            self.logger.error(msg)
                            messages.append(msg)
        else:
            msg = "xmcli_-x__-c_show-nodebbus.txt file is not found in Data Collection"
            self.logger.warning(msg)
            messages.append(msg)
            test_result = TestResult.SKIPPED
        return test_result


    @tags(['hardware', 'platform'])
    @severity(TestSeverity.CRITICAL)
    @versions(start='*', end="*")
    @kb(test_print_name='Fanpacks State from Platform view',
        note="Please check node(a|b)/command_output/xmcli_-x__-c_show-fanpacks.txt for details")
    @mode()
    def test_fanpacks_state_xms_view_healthy(self):
        self.message_dict['test_fanpacks_state_xms_view_healthy'] = list()
        messages = self.message_dict['test_fanpacks_state_xms_view_healthy']
        test_result = TestResult.PASSED
        # xmcli output exists on one node only.
        # no xmcli command output since FootHill release
        file_path = get_sym_node_command_output_file_path(self.dc_folder, 'xmcli_-x__-c_show-fanpacks.txt')
        if os.path.exists(file_path):
            with open(file_path, 'r') as f:
                for line in f:
                    # exclude the first line and the header line
                    if "xmcli" not in line and "Serial-Number" not in line:
                        if " healthy" not in line:
                            # BaseEnclosure-NodeA-FanModule0 1     APM00202515758FPA0 0          healthy enabled       100-532-900-02 2           8880       9840       BaseEnclosure-NodeA     1     X1         1     usmdcemcps001 1
                            test_result = TestResult.FAILED
                            msg = "{0}".format(line.strip())
                            self.logger.error(msg)
                            messages.append(msg)
        else:
            msg = "xmcli_-x__-c_show-fanpacks.txt file is not found in Data Collection"
            self.logger.warning(msg)
            messages.append(msg)
            test_result = TestResult.SKIPPED
        return test_result


    @tags(['hardware', 'platform'])
    @severity(TestSeverity.CRITICAL)
    @versions(start='*', end="*")
    @kb(test_print_name='DAE controllers State from Platform view',
        note="Please check node(a|b)/command_output/xmcli_-x__-c_show-daes-controllers.txt for details")
    @mode()
    def test_dae_controllers_state_xms_view_healthy(self):
        self.message_dict['test_dae_controllers_state_xms_view_healthy'] = list()
        messages = self.message_dict['test_dae_controllers_state_xms_view_healthy']
        test_result = TestResult.PASSED
        # xmcli output exists on one node only.
        # no xmcli command output since FootHill release
        file_path = get_sym_node_command_output_file_path(self.dc_folder, 'xmcli_-x__-c_show-daes-controllers.txt')
        if os.path.exists(file_path):
            with open(file_path, 'r') as f:
                for line in f:
                    # exclude the first line and the header line
                    if "xmcli" not in line and "Serial-Number" not in line:
                        if " healthy" not in line:
                            # ExpansionEnclosure_1_0-LCCA 3     Tabasco LCC     CF2DD200500516  disconnected enabled       0238        0            bottom   2.38.6     303-396-000B-00 ExpansionEnclosure_1_0 2         X1         1     usmdcs001 1     1     0      0          sas
                            # ExpansionEnclosure_1_1-LCCA 5     Tabasco LCC     CF2DD183902184  healthy      enabled       0238        0            bottom   2.38.6     303-396-000B-00 ExpansionEnclosure_1_1 3         X1         1     usmdcs001 1     1     1      0          sas
                            test_result = TestResult.FAILED
                            msg = "{0}".format(line.strip())
                            self.logger.error(msg)
                            messages.append(msg)
        else:
            msg = "xmcli_-x__-c_show-daes-controllers.txt file is not found in Data Collection"
            self.logger.warning(msg)
            messages.append(msg)
            test_result = TestResult.SKIPPED
        return test_result


    @tags(['hardware', 'platform'])
    @severity(TestSeverity.CRITICAL)
    @versions(start='*', end="*")
    @kb(test_print_name='Expansion Enclosure PSU Status from Platform view',
        note="Please check node(a|b)/command_output/xmcli_-x__-c_show-daes-psus.txt for details")
    @mode()
    def test_expansion_enclosure_psu_status_xms_view_healthy(self):
        self.message_dict['test_expansion_enclosure_psu_status_xms_view_healthy'] = list()
        messages = self.message_dict['test_expansion_enclosure_psu_status_xms_view_healthy']
        test_result = TestResult.PASSED
        # xmcli output exists on one node only.
        # no xmcli command output since FootHill release
        node_a_dae_psus_file = os.path.join(self.dc_folder,
                                       "node_a/command_output/xmcli_-x__-c_show-daes-psus.txt")
        node_b_dae_psus_file = os.path.join(self.dc_folder,
                                       "node_b/command_output/xmcli_-x__-c_show-daes-psus.txt")
        if os.path.exists(node_a_dae_psus_file):
            dae_psus_file = node_a_dae_psus_file
        else:
            dae_psus_file = node_b_dae_psus_file

        if os.path.exists(dae_psus_file):
            with open(dae_psus_file, 'r') as f:
                for line in f:
                    # exclude the first line and the header line
                    if "xmcli" not in line and "Serial-Number" not in line:
                        if "No matches found" in line:
                            # No Expansion Enclosure
                            # xmcli (tech)> show-daes-psus
                            # No matches found
                            test_result = TestResult.PASSED
                        elif " healthy" not in line or "no_error" not in line:
                            # https://jira.cec.lab.emc.com/browse/TEE-633
                            # Name                        Index Serial-Number  Location-Index Power-Feed State   Power-State Input Location HW-Revision Part-Number    DAE-Name               DAE-Index Brick-Name Index Cluster-Name  Index Bus # Encl #
                            # ExpansionEnclosure_1_0-PSU0 1     AC7H7194502991 0              feed_a     healthy no_error    on    right    0916        071-000-602-01 ExpansionEnclosure_1_0 2         X1         1     usmdcemcps001 1     1     0
                            # ExpansionEnclosure_1_0-PSU1 2     AC7H7194402707 1              feed_b     healthy ac_lost     on    left     0916        071-000-602-01 ExpansionEnclosure_1_0 2         X1         1     usmdcemcps001 1     1     0
                            test_result = TestResult.FAILED
                            msg = "{0}".format(line.strip())
                            self.logger.error(msg)
                            messages.append(msg)
        else:
            msg = "xmcli_-x__-c_show-daes-psus.txt file is not found in Data Collection"
            self.logger.warning(msg)
            messages.append(msg)
            test_result = TestResult.SKIPPED
        return test_result


    @tags(['hardware', 'platform'])
    @severity(TestSeverity.CRITICAL)
    @versions(start='*', end="*")
    @kb(test_print_name='Base Enclosuer State from Platform view',
        note="Please check node(a|b)/command_output/xmcli_-x__-c_show-enclosures.txt for details")
    @mode()
    def test_base_enclosuer_state_xms_view_healthy(self):
        self.message_dict['test_base_enclosuer_state_xms_view_healthy'] = list()
        messages = self.message_dict['test_base_enclosuer_state_xms_view_healthy']
        test_result = TestResult.PASSED
        # xmcli output exists on one node only.
        # no xmcli command output since FootHill release
        file_path = get_sym_node_command_output_file_path(self.dc_folder, 'xmcli_-x__-c_show-enclosures.txt')
        if os.path.exists(file_path):
            with open(file_path, 'r') as f:
                for line in f:
                    # exclude the first line and the header line
                    if "xmcli" not in line and "Serial-Number" not in line:
                        if " healthy" not in line:
                            # Name          Index Serial-Number ENCLOSURE-Index State  Part-Number    Product-Serial-Number Product-Part-Number Brick-Name Index Cluster-Name Index Drive-Slots
                            # BaseEnclosure 1     2Q4KBX2       0               failed 100-566-112-00 APM00201308281                            X1         1     PS5KCluster  1     0
                            test_result = TestResult.FAILED
                            msg = "{0}".format(line.strip())
                            self.logger.error(msg)
                            messages.append(msg)
        else:
            msg = "xmcli_-x__-c_show-enclosures.txt file is not found in Data Collection"
            self.logger.warning(msg)
            messages.append(msg)
            test_result = TestResult.SKIPPED
        return test_result


    @tags(['hardware', 'platform'])
    @severity(TestSeverity.CRITICAL)
    @versions(start='*', end="*")
    @kb(test_print_name='Expansion Enclosure State from Platform view',
        note="Please check node(a|b)/command_output/xmcli_-x__-c_show-daes.txt")
    @mode()
    def test_enclosures_state_xms_view_healthy(self):
        self.message_dict['test_enclosures_state_xms_view_healthy'] = list()
        messages = self.message_dict['test_enclosures_state_xms_view_healthy']
        test_result = TestResult.PASSED
        # xmcli output exists on one node only.
        # no xmcli command output since FootHill release
        node_a_dae_psus_file = os.path.join(self.dc_folder,
                                       "node_a/command_output/xmcli_-x__-c_show-daes.txt")
        node_b_dae_psus_file = os.path.join(self.dc_folder,
                                       "node_b/command_output/xmcli_-x__-c_show-daes.txt")
        if os.path.exists(node_a_dae_psus_file):
            dae_file = node_a_dae_psus_file
        else:
            dae_file = node_b_dae_psus_file

        if os.path.exists(dae_file):
            with open(dae_file, 'r') as f:
                for line in f:
                    # exclude the first line and the header line
                    # The state of the base enclosure(ExpansionEnclosure_0_0) doesn't seem to reflect the actual state.(/disks/JIRATEE/0000000-0000999/TEE-588/)
                    if "xmcli" not in line and "Serial-Number" not in line:
                        if " healthy" not in line or "miscabled" in line:
                            # for SmuttyNose GA code, no column about the "miscabled"
                            # ExpansionEnclosure_0_0 1     Simulex Encl    CF2CY145100035 healthy 1.2.3      1234        X1         1     PS5KCluster  1     0123        0     0      25          1      none
                            # ExpansionEnclosure_1_0 2     Tabasco Encl    3RPLBX2        disconnected 00.01.     100-566-114-01 X1         1     usmdcemcps001 1     0001        1     0      25          0      none
                            # ExpansionEnclosure_1_1 3     Tabasco Encl    3RQKBX2        healthy      00.01.     100-566-114-01 X1         1     usmdcemcps001 1     0001        1     1      25          0      miscabled
                            test_result = TestResult.FAILED
                            msg = "{0}".format(line.strip())
                            self.logger.error(msg)
                            messages.append(msg)
        else:
            msg = "xmcli_-x__-c_show-daes.txt file is not found in Data Collection"
            self.logger.warning(msg)
            messages.append(msg)
            test_result = TestResult.SKIPPED
        return test_result


    @tags(['hardware', 'platform'])
    @severity(TestSeverity.CRITICAL)
    @versions(start='*', end="*")
    @kb(test_print_name='Drive Healthy Status from Platform view',
        note="Please check node(a|b)/command_output/xmcli_-x__-c_show-ssds.txt for details")
    @mode()
    def test_drive_xms_view_healthy(self):
        self.message_dict['test_drive_xms_view_healthy'] = list()
        messages = self.message_dict['test_drive_xms_view_healthy']
        test_result = TestResult.PASSED
        # xmcli output exists on one node only.
        # no xmcli command output since FootHill release
        node_a_ssd_file = os.path.join(self.dc_folder,
                                       "node_a/command_output/xmcli_-x__-c_show-ssds.txt")
        node_b_ssd_file = os.path.join(self.dc_folder,
                                       "node_b/command_output/xmcli_-x__-c_show-ssds.txt")
        if os.path.exists(node_a_ssd_file):
            ssd_file = node_a_ssd_file
        else:
            ssd_file = node_b_ssd_file

        if os.path.exists(ssd_file):
            with open(ssd_file, 'r') as f:
                for line in f:
                    # exclude the first line and the header line
                    if "xmcli" not in line and "Product-Model" not in line:
                        if " healthy" not in line:
                            test_result = TestResult.FAILED
                            msg = "{0}".format(line.strip())
                            self.logger.error(msg)
                            messages.append(msg)
        else:
            msg = "xmcli_-x__-c_show-ssds.txt file is not found in Data Collection"
            self.logger.warning(msg)
            messages.append(msg)
            test_result = TestResult.SKIPPED
        return test_result


    # TODO: this test can be removed if test_svc_diag_icw_hardware always works.
    # This could still be useful if service container is not running somehow 
    @tags(['hardware', 'platform'])
    @severity(TestSeverity.CRITICAL)
    @versions(start='*', end="*")
    @kb(test_print_name='Same number of NVMe SSD drives seen by both nodes',
        note="Please check node(a|b)/core_os/nvme_list.txt for details")
    @mode()
    def test_same_number_of_nvme_ssds_on_both_nodes(self):
        self.message_dict['test_same_number_of_nvme_ssds_on_both_nodes'] = list()
        messages = self.message_dict['test_same_number_of_nvme_ssds_on_both_nodes']
        test_result = TestResult.PASSED
        node_a_nvme_list_file = os.path.join(self.dc_folder,
                                       "node_a/core_os/nvme_list.txt")
        node_b_nvme_list_file = os.path.join(self.dc_folder,
                                       "node_b/core_os/nvme_list.txt")
        if os.path.exists(node_a_nvme_list_file) and os.path.exists(node_b_nvme_list_file):
            node_a_nvme_num = subprocess.getoutput('wc -l < {0}'.format(node_a_nvme_list_file))
            node_b_nvme_num = subprocess.getoutput('wc -l < {0}'.format(node_b_nvme_list_file))
            if node_a_nvme_num != node_b_nvme_num:
                test_result = TestResult.FAILED
                msg = "Two nodes see different number of NVMe devices"
                self.logger.error(msg)
                messages.append(msg)
        else:
            if not os.path.exists(node_a_nvme_list_file):
                msg = "%s is not found" % "node_a/core_os/nvme_list.txt"
                self.logger.warning(msg)
                messages.append(msg)
            if not os.path.exists(node_b_nvme_list_file):
                msg = "%s is not found" % "node_b/core_os/nvme_list.txt"
                self.logger.warning(msg)
                messages.append(msg)
            test_result = TestResult.SKIPPED
        return test_result


    @tags(['network', 'platform'])
    @severity(TestSeverity.CRITICAL)
    @versions(start='*', end="*")
    @kb(test_print_name='Switch port MTU matches appliance Ethernet port MTU',
        note="Please check powerstore-triage_analysis.txt for details")
    @mode()
    def test_swport_mtu_match_local_port_mtu_cyc_net(self):
        self.message_dict['test_swport_mtu_match_local_port_mtu_cyc_net'] = list()
        messages = self.message_dict['test_swport_mtu_match_local_port_mtu_cyc_net']
        test_result = TestResult.PASSED
        file_count = 0
        for node_name in ["node_a", "node_b"]:
            cyc_net_client_output_file_name = "cyc_net_client_-node_local_-realm_L2D_-command_get_l2_discovery_info_-verbose_1.txt"
            cyc_net_discovery_info_file_path = os.path.join(self.dc_folder, node_name, 
                    os.path.join("command_output", cyc_net_client_output_file_name))
            if os.path.exists(cyc_net_discovery_info_file_path):
                file_count += 1
            else:
                msg = "%s: %s is not found" %(node_name, cyc_net_client_output_file_name)
                self.logger.warning(msg)
                messages.append(msg)
        if file_count == 0:
            msg = "%s is not found in node_a or node_b" % cyc_net_client_output_file_name
            self.logger.warning(msg)
            messages.append(msg)
            test_result = TestResult.SKIPPED
        elif file_count == 1:
            test_result = TestResult.PARTIAL
        if file_count > 0:
            normalized_cyc_net_discovery_info_file_path = get_tmp_file_path(self.dc_folder, "normalized_cyc_net_discovery_info.json")
            if normalized_cyc_net_discovery_info_file_path:
                with open(normalized_cyc_net_discovery_info_file_path, 'r') as f:
                    cyc_net_discovery_info_list = json.load(f)
                    for record in cyc_net_discovery_info_list:
                        local_mtu = record['MTU']
                        sw_port_mtu = record['SwPortMTU']
                        if local_mtu and local_mtu != 0 and sw_port_mtu != 0 and sw_port_mtu != '--':
                            if sw_port_mtu < local_mtu:
                                    test_result = TestResult.FAILED
                                    msg = "The MTU value of the swtich port that corresponds to port {0} on node {1} is too small".format(record['NIC Name'], record['Node'])
                                    self.logger.error(msg)
                                    messages.append(msg)
            else:
                msg = "powerstore-triage/tmp/normalized_cyc_net_discovery_info.json is not found"
                self.logger.warning(msg)
                messages.append(msg)
                test_result = TestResult.SKIPPED
        return test_result


    @staticmethod
    def _is_test_func(method):
        return "_model" in method.__dict__

    def run_tests_by_mode(self):
        tests_to_run = [(method_name, method) for method_name, method in
                        inspect.getmembers(self, predicate=inspect.ismethod)
                        if HealthCheck._is_test_func(method) and (method._model == ArrayModel.ALL or method._model == self.appliance_info['model'])]
        test_name_max_length = max([len(v._test_print_name)
                                    for n, v in inspect.getmembers(self, predicate=inspect.ismethod)
                                    if HealthCheck._is_test_func(v)])
        failures = []
        for method_name, method in tests_to_run:
            test_name_formatted = (method._test_print_name + ":").ljust(test_name_max_length + 4, ".")
            self.logger.debug("{0}: executing...".format(method_name))
            try:
                test_result = method()
            except Exception as e:
                warning_str = " {0}: An exception is encountered while executing the test".format(method._test_print_name)
                self.logger.error(warning_str)
                self.output_fh.write(warning_str + '\n')
                self.logger.error("%s: An exception occurred while executing the test", method_name, exc_info=1)
                self.logger.error(e)
                test_result = TestResult.FAILED
            # put the warning/error message before each test result
            if test_result != TestResult.PASSED and method_name in self.message_dict and self.message_dict[method_name]:
                for msg in self.message_dict[method_name]:
                    self.output_fh.write(msg + '\n')

            if test_result == TestResult.PASSED:
                result_str = test_name_formatted + Color.GREEN + ' PASS ' + Color.CLEAR
                self.logger.info(result_str)
                self.output_fh.write(result_str + '\n')
            elif test_result == TestResult.FAILED:
                if method._note is not None:
                    self.logger.error(method._note)
                    self.output_fh.write(method._note + '\n')
                if method._kb is not None:
                    error_str = "{0} verification has failed. Refer to KB {1} for details".format(method._test_print_name, method._kb)
                    self.logger.error(error_str)
                    self.output_fh.write(error_str + '\n')
                result_str = test_name_formatted + Color.RED + ' FAIL ' + Color.CLEAR
                self.logger.info(result_str)
                self.output_fh.write(result_str + '\n')
                failures.append(method)
            elif test_result == TestResult.SKIPPED:
                result_str = test_name_formatted + Color.YELLOW + ' SKIPPED ' + Color.CLEAR
                self.logger.info(result_str)
                self.output_fh.write(result_str + '\n')
            elif test_result == TestResult.PARTIAL:
                result_str = test_name_formatted + Color.YELLOW + ' PARTIAL ' + Color.CLEAR
                self.logger.info(result_str)
                self.output_fh.write(result_str + '\n') 

@handle_exceptions
def run_health_check(dc_folder):
    health_check_report_file_name = 'powerstore-triage_health_check.txt'
    logger.info("Running Health Check...")
    logger.info('*'*60)
    with open(os.path.join(dc_folder, TOOL_OUTPUT_FOLDER, health_check_report_file_name), 'w+') as fh:
        hcs = HealthCheck(dc_folder, fh)
        hcs.run_tests_by_mode()
    logger.info('*'*60)
    logger.info("Finshed Health Check")



# TODO:
#  1.
#  /disks/JIRATEE/0000000-0000999/TEE-596/2020-10-08_18-34/powerstore_3FZKBX2_PSa3b24a6aee46_APM00202210908_2020-10-08_21-51-14_service-data
# node_b/command_output/lspci_-v.txt
# Node B can see Fibre Channel IOM, but node A cannot see it.
# 'IO module State from Platform view' check may be enough.
# 2. 