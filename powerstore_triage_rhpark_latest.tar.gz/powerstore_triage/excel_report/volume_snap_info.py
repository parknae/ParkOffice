from excel_report.common import generate_excel_report_from_list_of_dict
from data_normalizer.volume_snap_info_normalizer import normalize_volume_snap_info

def sort_volume_snap(a_dict):
    volume_group_name = a_dict['volume_group_name'] if a_dict['volume_group_name'] else ''
    if "parent_volume" in a_dict:
        parent_volume = a_dict['parent_volume'] if a_dict['parent_volume'] else ''
        return [parent_volume, volume_group_name, a_dict['creation_timestamp']]
    elif "datapath_family_id" in a_dict:
        return [a_dict["datapath_family_id"], volume_group_name, a_dict['creation_timestamp']]


def report_volume_snap_info(dc_folder, wb, ws_index, ws_name):
    header, list_of_dict = normalize_volume_snap_info(dc_folder)
    generate_excel_report_from_list_of_dict(wb, ws_index, ws_name, list_of_dict, header, vertical=False, sort_func=sort_volume_snap, tab_color=None)