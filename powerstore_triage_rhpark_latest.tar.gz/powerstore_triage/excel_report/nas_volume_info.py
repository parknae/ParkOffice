from excel_report.common import generate_excel_report_from_list_of_dict
from data_normalizer.nas_volume_info_normalizer import normalize_nas_volume_info


def report_nas_volume_info(dc_folder, wb, ws_index, ws_name):
    header, list_of_dict = normalize_nas_volume_info(dc_folder)
    generate_excel_report_from_list_of_dict(wb, ws_index, ws_name, list_of_dict, header, vertical=False, sort_func=None, tab_color=None)