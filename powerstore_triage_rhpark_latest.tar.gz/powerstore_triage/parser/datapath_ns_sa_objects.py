import os
import json
from infra.utils import TOOL_NAME, TOOL_OUTPUT_FOLDER, TOOL_TMP_FOLDER, get_sym_node_command_output_file_path
import logging
import re

logger = logging.getLogger('.'.join([TOOL_NAME, __name__]))

def parse_datapath_ns_sa_objects(dc_folder):
    ns_sa_bjects_file_path = get_sym_node_command_output_file_path(dc_folder, 'cli.py_namespace_spacestats_enumobjects.txt')
    if ns_sa_bjects_file_path:
        logger.debug(ns_sa_bjects_file_path)
        object_handle_pattern = re.compile(r'Object Handle')
        attr_pattern = re.compile(r"\S+:")
        end_pattern = re.compile(r"Total of")
        ns_sa_objects = list()
        record = None
        object_handle = None
        with open(ns_sa_bjects_file_path, 'r') as f:
            for line in f:
                if object_handle_pattern.search(line):
                    object_handle = line.split(":")[-1].strip()
                    # append the first through the (last - 1) record
                    if record:
                        ns_sa_objects.append(record)
                    # reset record
                    record = dict()
                if attr_pattern.search(line):
                    if object_handle:
                        attr, value = line.split(":", 1)
                        value = value.split()[0]
                        record[attr.strip()] = value.strip()
                # append the last record
                if end_pattern.search(line):
                    # in case namespace is offline, no object can be collected in spacestats_enumobjects
                    if record:
                        ns_sa_objects.append(record)
        object_id_to_logical_used_dict = dict()
        for record in ns_sa_objects:
            if 'Committed Space' in record:
                object_id_to_logical_used_dict[record['Object Name']] = record['Committed Space']
        # logger.debug(object_id_to_logical_used_dict)
        with open(os.path.join(dc_folder, TOOL_OUTPUT_FOLDER, TOOL_TMP_FOLDER, "ns_sa_objects.json"), 'w+') as out_fp:
            json.dump(object_id_to_logical_used_dict, out_fp)

        # Objects Space Stats List:
        # Object Handle:        1ef0f958-0edb-46ab-b828-00eb0132a655:249:4
        # Object Name:          000fca27-eb52-4c2a-9c97-a4d338206577
        # Logical Size:         1099511627776 (0x10000000000) 1.0TB
        # Committed Space:      33417445376 (0x7c7d5c000) 31.1GB
        # SnapGroupId:          30
        # Object Usage:         Snap


        # Object Handle:        1ef0f958-0edb-46ab-b828-00eb0132a655:216:0
        # Object Name:          fac4424f-07ea-490a-b406-c793cfeca2e7
        # Logical Size:         1099511627776 (0x10000000000) 1.0TB
        # Committed Space:      33417445376 (0x7c7d5c000) 31.1GB
        # SnapGroupId:          30
        # Object Usage:         Snap

        # Total of 256 objects
