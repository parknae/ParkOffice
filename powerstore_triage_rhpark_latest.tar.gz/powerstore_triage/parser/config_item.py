import json
import os
import logging
from infra.utils import TOOL_NAME, TOOL_OUTPUT_FOLDER, TOOL_TMP_FOLDER, get_mgmt_data_internal_file_path, get_mgmt_data_file_path

# the parent logger will be the logger with name defined by TOOL_NAME
logger = logging.getLogger('.'.join([TOOL_NAME, __name__]))


def parse_config_item(dc_folder):
    # 'H7' --> "IG_FNM00191600900_EXHOST_H7"
    # used to figure out the mapping of host uuid to IG_name_platform
    hostid_to_igname = dict()
    hostgroupid_to_igname = dict()
    # used by host_info_normalizer, it contains host_group_uuid --> igname mapping
    hostuuid_to_igname = dict()
    initiator_list = list()
    host_info = dict()
    host_uuid_to_host_info = dict()
    hostgroup_info = dict()
    hostconnection_info = dict()
    infra_service_list = list()
    host_config_id_to_initiator_group_name = dict()
    cluster_info = dict()
    config_item_file = get_mgmt_data_internal_file_path(dc_folder, "config_item.json")
    if not config_item_file:
        config_item_file = get_mgmt_data_file_path(dc_folder, "config_item.json")
    if config_item_file:
        logger.debug(config_item_file)
        with open(config_item_file, 'r') as f:
            data = json.load(f)
            list_of_config_item = data['data']
            for record in list_of_config_item:
                record_type = record["type"]
                if record_type == "HOST":
                    # "id": "H4"
                    host_info[record["id"]] = record
                    host_uuid_to_host_info[record['data']['host_uuid']] = record
                elif record_type == "HOST_GROUP":
                    hostgroup_info[record["id"]] = record
                elif record_type == "HOST_CONNECTION":
                    hostconnection_info[record["id"]] = record
                    host_config_id_to_initiator_group_name[record['data']["for_host"]] = record['data']['initiator_group_name']
                    # IG at Platform could correspond to one single host at ControlPath or
                    # a group of hosts at ControlPath (which is HostGroup at ControlPath)
                    # The value of "for_host" can be a HOST id like "H4" or a HOST_GROUP id like "HG1"
                    host_connection_type = record["data"]["host_connection_type"]
                    if host_connection_type == "HOST":
                        # host_id is H1, H2, ...
                        host_id = record["data"]["for_host"]
                        hostid_to_igname[host_id] = record["data"]["initiator_group_name"]
                    elif host_connection_type == "HOST_GROUP":
                        hostgroup_id = record["data"]["for_host"]
                        hostgroupid_to_igname[hostgroup_id] = record["data"]["initiator_group_name"]
                elif record_type == "INITIATOR":
                    initiator_list.append(record)
                elif record_type == "DNS" or record_type == "NTP":
                    infra_service_list.append(record)
                elif record_type == "CLUSTER":
                    cluster_info = record["data"]
                # logger.debug(hostid_to_igname)
                # logger.debug(hostgroupid_to_igname)

        hardware_uuid_to_host_name = dict()
        for host_id, record in host_info.items():
            host_uuid = record["data"]["host_uuid"]
            if record["data"]["host_group_id"]:
                host_group_id = record["data"]["host_group_id"]
                ig_name = hostgroupid_to_igname[host_group_id]
            else:
                ig_name = hostid_to_igname[host_id]
            hostuuid_to_igname[host_uuid] = ig_name
            # hardware uuid will be used to correlate which ESXi host the vvol is bound to
            # The hardware_uuid list of non ESXi host is empty
            hardware_uuid_list = record['data']['hardware_uuid']
            if hardware_uuid_list:
                hardware_uuid_to_host_name[hardware_uuid_list[0]] = record['data']['name']

        # put the host_group_uuid to ig_name mapping into hostuuid_to_igname
        # will be used by host_info_normalizer
        for hostgroup_id, record in hostgroup_info.items():
            host_group_uuid = record["data"]["host_group_uuid"]
            ig_name = hostgroupid_to_igname[hostgroup_id]
            hostuuid_to_igname[host_group_uuid] = ig_name

        # logger.debug(hostuuid_to_igname)

        for i, record in enumerate(initiator_list):
            # not sure if a initiator will show up in config_item.json if it is not associated with any host
            hostconneciton_id = record["parent"]
            host_id = record["data"]["host_id"]
            initiator_list[i]['appliance_id'] = record["data"]["appliance_id"]
            initiator_list[i]['host_name_cp'] = host_info[host_id]["data"]["name"]
            if hostconnection_info[hostconneciton_id]["data"]["host_connection_type"] =="HOST_GROUP":
                hostgroup_id = hostconnection_info[hostconneciton_id]["data"]["for_host"]
                initiator_list[i]['host_group_name'] = hostgroup_info[hostgroup_id]["data"]["name"]
            else:
                initiator_list[i]['host_group_name'] = 'N/A'
            initiator_list[i]['initiator_name_platform'] = record["data"]["name"]
            if hostconneciton_id:
                initiator_list[i]['IG_name_platform'] = hostconnection_info[hostconneciton_id]["data"]["initiator_group_name"]
            else:
                initiator_list[i]['IG_name_platform'] = 'N/A'
            initiator_list[i]["WWN/IQN"] = record["data"]["port_name"]
            initiator_list[i]["port_type"] = record["data"]["port_type"]


        with open(os.path.join(dc_folder, TOOL_OUTPUT_FOLDER, TOOL_TMP_FOLDER, "initiator.json"), 'w+') as out_fp:
            json.dump(initiator_list, out_fp)

        with open(os.path.join(dc_folder, TOOL_OUTPUT_FOLDER, TOOL_TMP_FOLDER, "hostuuid_to_igname.json"), 'w+') as out_fp:
            json.dump(hostuuid_to_igname, out_fp)

        with open(os.path.join(dc_folder, TOOL_OUTPUT_FOLDER, TOOL_TMP_FOLDER, "config_item_host_info.json"), 'w+') as out_fp:
            json.dump(host_info, out_fp)

        with open(os.path.join(dc_folder, TOOL_OUTPUT_FOLDER, TOOL_TMP_FOLDER, "config_item_host_uuid_to_host_info.json"), 'w+') as out_fp:
            json.dump(host_uuid_to_host_info, out_fp)

        with open(os.path.join(dc_folder, TOOL_OUTPUT_FOLDER, TOOL_TMP_FOLDER, "hardware_uuid_to_host_name.json"), 'w+') as out_fp:
            json.dump(hardware_uuid_to_host_name, out_fp)
            # import pprint
            # pprint.pprint(hardware_uuid_to_host_name)

        with open(os.path.join(dc_folder, TOOL_OUTPUT_FOLDER, TOOL_TMP_FOLDER, "host_config_id_to_initiator_group_name.json"), 'w+') as out_fp:
            json.dump(host_config_id_to_initiator_group_name, out_fp)

        with open(os.path.join(dc_folder, TOOL_OUTPUT_FOLDER, TOOL_TMP_FOLDER, "infra_service.json"), 'w+') as out_fp:
            json.dump(infra_service_list, out_fp)

        with open(os.path.join(dc_folder, TOOL_OUTPUT_FOLDER, TOOL_TMP_FOLDER, "config_item_cluster_info.json"), 'w+') as out_fp:
            json.dump(cluster_info, out_fp)

    # {
    #     "data": {
    #         "description": "",
    #         "hardware_uuid": [],
    #         "host_group_id": null,
    #         "host_type": "EXTERNAL",
    #         "host_uuid": "a704dae0-dfa3-49e5-9677-b62482ab4fc0",
    #         "name": "lghpk85",
    #         "os": "Linux",
    #         "serial_number": ""
    #     },
    #     "id": "H4",
    #     "parent": "C1",
    #     "path": "C1.H4",
    #     "type": "HOST"
    # },

    # {
    #     "data": {
    #         "global_id": "PSf4c3d5b6e823",
    #         "is_encryption_enabled": true,
    #         "master_appliance_id": "A1",
    #         "name": "PowerstoreCluster",
    #         "nameDelimiter": "-",
    #         "physical_mtu": 1500,
    #         "state": "CONFIGURED",
    #         "uuid": "f4c3d5b6-e823-4943-8d0f-d370f8f75e30"
    #     },
    #     "id": "C1",
    #     "parent": null,
    #     "path": "C1",
    #     "type": "CLUSTER"
    # },
