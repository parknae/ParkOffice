import os
import json
import glob
import subprocess
from infra.utils import TOOL_NAME, TOOL_OUTPUT_FOLDER, TOOL_TMP_FOLDER, handle_exceptions
import logging

logger = logging.getLogger('.'.join([TOOL_NAME, __name__]))

@handle_exceptions
def parse_nas_cbr_cluster_postgresdb_dump(dc_folder):
    file_interface_list = list()
    cluster_postgresdb_dump_files = list()
    for node_name in ["node_a", "node_b"]:
        cluster_postgresdb_dump_files.extend(glob.glob(os.path.join(dc_folder, "cyc_cfs", "nas_config_backup", node_name, "nas_config_data","*/cluster/sdnas_postgresDB_dump.sql")))
    logger.debug(cluster_postgresdb_dump_files)
    if cluster_postgresdb_dump_files:
        # ...nas_config_data/SDNAS_CBR_20200319_070001UTC/cluster/sdnas_postgresDB_dump.sql
        cluster_postgresdb_dump_files.sort(key=lambda x: x.split(os.sep)[-3])
        cluster_postgresdb_dump_file = cluster_postgresdb_dump_files[-1]
        cmd_str = r"sed -n '/Data for Name: fileInterface_instance/,/\\\./p' " + cluster_postgresdb_dump_file
        logger.debug(cmd_str)
        _, file_interface_str = subprocess.getstatusoutput(cmd_str)
        lines = file_interface_str.split("\n")
        for line in lines:
            if "{" in line:
                json_str = line.split("\t")[-1]
                file_interface_dict = json.loads(json_str)
                file_interface_list.append(file_interface_dict)
        logger.debug(file_interface_list)
        with open(os.path.join(dc_folder, TOOL_OUTPUT_FOLDER, TOOL_TMP_FOLDER, "file_interface_list.json"), 'w+') as out_fp:
            json.dump(file_interface_list, out_fp)
    # TODO: need a reliable way to tell if SDNAS is installed or not    
    # else:
    #     logger.warning("File sdnas_postgresDB_dump.sql is not found")

# sed -n '/Data for Name: fileInterface_instance/,/\\\./p' node_a/nas_config_data/SDNAS_CBR_20200319_070001UTC/cluster/sdnas_postgresDB_dump.sql
# --
# -- Data for Name: fileInterface_instance; Type: TABLE DATA; Schema: sdnas_rest_api; Owner: postgres
# --
#
# COPY sdnas_rest_api."fileInterface_instance" (id, token, "nasServer", created_timestamp, modified_timestamp, data) FROM stdin;
# 5e6b6053-632f-d486-6654-268719b17386    1       5e6b604c-eb3e-1388-b8e2-268719b17386    2020-03-13 10:28:35.517173      2020-03-13 10:28:35.517173      {"id": "5e6b6053-632f-d486-6654-268719b17386", "name": "PROD001_167f9907e042_4", "role": 0, "token": 1, "vlanId": 688, "gateway": "172.18.64.1", "netmask": "255.255.192.0", "ipAddress": "172.18.64.245", "nasServer": "5e6b604c-eb3e-1388-b8e2-268719b17386", "netDevice": "eth_data0", "isDisabled": false}
# 5e6c25a2-57a7-33bb-640d-268719b17386    1       5e6c2596-2e43-a3cc-1bcd-268719b17386    2020-03-14 00:30:26.866119      2020-03-14 00:30:26.866119      {"id": "5e6c25a2-57a7-33bb-640d-268719b17386", "name": "PROD001_a6cec83bc8c4_5", "role": 0, "token": 1, "vlanId": 688, "gateway": "172.18.64.1", "netmask": "255.255.192.0", "ipAddress": "172.18.64.246", "nasServer": "5e6c2596-2e43-a3cc-1bcd-268719b17386", "netDevice": "eth_data0", "isDisabled": false}
# 5e6c25d4-d2ac-5558-150a-268719b17386    1       5e6c25c9-745b-d70c-fec1-268719b17386    2020-03-14 00:31:16.858078      2020-03-14 00:31:16.858078      {"id": "5e6c25d4-d2ac-5558-150a-268719b17386", "name": "PROD001_167f9907e042_6", "role": 0, "token": 1, "vlanId": 688, "gateway": "172.18.64.1", "netmask": "255.255.192.0", "ipAddress": "172.18.64.248", "nasServer": "5e6c25c9-745b-d70c-fec1-268719b17386", "netDevice": "eth_data0", "isDisabled": false}
# 5e6b4f1b-7d5f-c6b4-4f73-268719b17386    2       5e6b4f14-d89b-3962-3b76-268719b17386    2020-03-13 09:15:08.268005      2020-03-15 10:01:03.914324      {"id": "5e6b4f1b-7d5f-c6b4-4f73-268719b17386", "name": "PROD001_a6cec83bc8c4_3", "role": 0, "token": 2, "vlanId": 688, "netmask": "255.255.192.0", "ipAddress": "172.18.64.244", "nasServer": "5e6b4f14-d89b-3962-3b76-268719b17386", "netDevice": "eth_data0", "isDisabled": false}
# \.

