import os
import json
import re
from infra.utils import TOOL_NAME, get_tmp_file_path, handle_exceptions, get_mgmt_data_file_path, TOOL_OUTPUT_FOLDER, TOOL_TMP_FOLDER
import logging

logger = logging.getLogger('.'.join([TOOL_NAME, __name__]))
copyright_pattern = re.compile(r'\s?Copyright.*All Rights Reserved\.\s?')
system_description_pattern = re.compile(r'System Description.*?\.')
tac_pattern = re.compile(r'TAC.*?tac ')
dell_real_time_os_pattern = re.compile(r'Dell.*Real Time Operating System Software. Dell.*Operating System Version 2.0. ')
tech_support_pattern = re.compile(r'Technical.*Inc\. ')
cisco_copyright_pattern = re.compile(r'Copyright.*Inc\. ')


@handle_exceptions
def normalize_cyc_net_discovery_info(dc_folder):
    # # not reliable because two port that belong to the same BOND has identical MAC address in eth_port.json
    # mac_to_name = dict()
    # eth_port_file_path = get_mgmt_data_file_path(dc_folder, 'eth_port.json')
    # if os.path.exists(eth_port_file_path):
    #     logger.debug(eth_port_file_path)
    #     with open(eth_port_file_path, 'r') as f:
    #         data = json.load(f)
    #         for record in data['data']:
    #             mac_to_name[record["mac_address"]] = record["name"]

    list_of_cyc_net_discovery_info = list()
    file_count = 0
    for node_name in ["node_a", "node_b"]:
        cyc_net_discovery_info_file_path = get_tmp_file_path(dc_folder, "%s_cyc_net_discovery_info.json" % node_name)
        if cyc_net_discovery_info_file_path:
            file_count += 1
            logger.debug(cyc_net_discovery_info_file_path)
            with open(cyc_net_discovery_info_file_path, 'r') as f:
                cyc_net_discovery_info = json.load(f)
                for _, v in cyc_net_discovery_info.items():
                    record = dict()
                    record["Node"] = node_name
                    record['NIC Name'] = v['Local info']['Name']
                    record['MAC'] = v['Local info']['MAC']
                    # mac_without_colon = v['Local info']['MAC'].replace(':','')
                    # if mac_without_colon in mac_to_name:
                    #     record['Name'] = mac_to_name[mac_without_colon].replace("BaseEnclosure-", '')
                    # else:
                    #     record['Name'] = '--'
                    record['Link status'] = v['Local info']['Link status']
                    record['Admin status'] = v['Local info']['Link status']
                    record['MTU'] = v['Local info']['MTU']
                    record['Speed'] = v['Local info']['Speed']
                    record['Location'] = v['Local info']['Physical location']
                    # only use CDP-specific discovery info if the switch is Cisco switch.
                    # DELL swtich may forward and show the Cisco CDP-specific discovery info as well which is not desired.
                    # https://jira.cec.lab.emc.com/browse/TEE-427 is an exmaple.
                    # https://jira.cec.lab.emc.com/browse/MDT-141049
                    # v['Common L2 discovery info']['System description'] could be None for Cisco switch (TEE-372)
                    # v['LLDP-specific discovery info']['LLDP common info']['System name'] could be None for Cisco switch (TEE-372)
                    # TODO: For Cisco switch, more informaiton can be retrieved from CDP-specific discovery info, however, it is not easy to 
                    # handle the issue described in https://jira.cec.lab.emc.com/browse/MDT-141049, 
                    # may need to use LLDP-specific discovery info only(will lose some information for Cisco switch)
                    if "CDP-specific discovery info" in v and v['CDP-specific discovery info']['Status'] == 'SUCCESS' and 'Common L2 discovery info' in v and ((v['Common L2 discovery info']['System description'] and 'cisco' in v['Common L2 discovery info']['System description'].lower())):
                    # if "CDP-specific discovery info" in v and v['CDP-specific discovery info']['Status'] == 'SUCCESS' and 'Common L2 discovery info' in v and ((v['Common L2 discovery info']['System description'] and 'cisco' in v['Common L2 discovery info']['System description'].lower()) or not v['Common L2 discovery info']['System description']):
                        # System name could be None
                        if v['CDP-specific discovery info']['CDP common info']['System name']:
                            record["Switch Name"] = v['CDP-specific discovery info']['CDP common info']['System name']
                        else:
                            record["Switch Name"] = v['CDP-specific discovery info']['CDP common info']['Switch ID']
                        record["SwPort ID"] = v['CDP-specific discovery info']['CDP common info']['Port ID']
                        record["SwPortMTU"] = v['CDP-specific discovery info']['CDP common info']['MTU']
                        record["SwPort NativeVLAN"] = v['CDP-specific discovery info']['CDP common info']['Native VLAN']
                        record['System description'] = v['CDP-specific discovery info']['CDP common info']['System description']
                    elif "LLDP-specific discovery info" in v:
                        if v['LLDP-specific discovery info']['LLDP common info']['System name']:
                            record["Switch Name"] = v['LLDP-specific discovery info']['LLDP common info']['System name']
                        else:
                            record["Switch Name"] = v['LLDP-specific discovery info']['LLDP common info']['Switch ID']
                        record["SwPort ID"] = v['LLDP-specific discovery info']['LLDP common info']['Port ID']
                        record["SwPortMTU"] = v['LLDP-specific discovery info']['LLDP common info']['MTU']
                        record["SwPort NativeVLAN"] = v['LLDP-specific discovery info']['LLDP common info']['Native VLAN']
                        record['System description'] = v['LLDP-specific discovery info']['LLDP common info']['System description']
                    else:
                        record["Switch Name"] = '--'
                        record["SwPort ID"] = '--'
                        record["SwPortMTU"] = '--'
                        record["SwPort NativeVLAN"] = '--'
                        record['System description'] = '--'
                    # record['System description'] could be None
                    if record['System description']:
                        # Dell EMC Networking OS10-Enterprise. Copyright (c) 1999-2019 by Dell Inc. All Rights Reserved. System Description OS10 Enterprise. OS Version 10.4.3.3. System Type S4148U-ON
                        # Cisco Nexus Operating System (NX-OS) Software 7.1(4)N1(1) TAC support http//www.cisco.com/tac Copyright (c) 2002-2016, Cisco Systems, Inc. All rights reserved.
                        # Dell EMC Real Time Operating System Software. Dell EMC Operating System Version 2.0. Dell EMC Application Software Version 9.14(2.4) Build Time Fri Nov  8 090748 2019
                        # Dell Real Time Operating System Software. Dell Operating System Version 2.0. Dell Application Software Version 9.11(2.1)Build Time Mon Jun  5 092523 2017
                        # cisco WS-C3750G-48PS Cisco IOS Software, C3750 Software (C3750-IPSERVICESK9-M), Version 12.2(55)SE3, RELEASE SOFTWARE (fc1) Technical Support http//www.cisco.com/techsupport Copyright (c) 1986-2011 by Cisco Systems, Inc. Compiled Thu 05-May-11 1629 by prod_rel_team
                        # cisco WS-C3750E-48TD Cisco IOS Software, C3750E Software (C3750E-UNIVERSALK9-M), Version 12.2(50)SE2, RELEASE SOFTWARE (fc2) Copyright (c) 1986-2009 by Cisco Systems, Inc. Compiled Fri 15-May-09 2149 by nachen
                        system_description = re.sub(copyright_pattern, "", record['System description'])
                        system_description = re.sub(system_description_pattern, "", system_description)
                        system_description = re.sub(tac_pattern, "", system_description)
                        system_description = re.sub(dell_real_time_os_pattern, "", system_description)
                        system_description = re.sub(tech_support_pattern, "", system_description)
                        system_description = re.sub(cisco_copyright_pattern, "", system_description)
                        record['System description'] = system_description
                    list_of_cyc_net_discovery_info.append(record)
    header = ['Node', 'NIC Name', 'Location', 'MAC', 'Link status', 'MTU', 'Speed',
                'Switch Name', 'SwPort ID', 'SwPortMTU', 'SwPort NativeVLAN','System description']
    # logger.info(list_of_cyc_net_discovery_info)
    # persist list_of_cyc_net_discovery_info for health check usage
    if file_count > 0:
        try:
            with open(os.path.join(dc_folder, TOOL_OUTPUT_FOLDER, TOOL_TMP_FOLDER, "normalized_cyc_net_discovery_info.json"), 'w+') as out_fp:
                json.dump(list_of_cyc_net_discovery_info, out_fp)
        except:
            logger.warning("Not able to perist normalized cyc_net_discovery_info")
    return header, list_of_cyc_net_discovery_info

# Sw Port MTU could be 0, which means it is not reliable.
# TEE-372
# *** Information for uplink enp11s0f3 ***
#         Status: SUCCESS
#         Age: 8
#         Local info:
#                 Name:                   enp11s0f3
#                 MAC:                    00:e0:ec:f5:bf:5b
#                 Admin status:           LINK_STATUS_UP
#                 Link status:            LINK_STATUS_UP
#                 MTU:                    1500
#                 Speed:                  10 Gbps
#                 vSwitch:
#                 Bond:                   bond0
#                 Dedicated mgmt:         false
#                 Physical location:      OCP_MEZZ 0
#                 Local CDP device ID:    CKM00201400767-A
#                 Local CDP port ID:      enp11s0f3
#                 Local LLDP chassis ID:  CKM00201400767-A
#                 Local LLDP port ID:     00:e0:ec:f5:bf:5b
#         Common L2 discovery info
#                 Switch ID:          54:bf:64:c0:8b:c0
#                 Port ID:            TenGigabitEthernet 1/1/1/2
#                 System name:
#                 System description:
#                 MTU:                0
#                 Native VLAN:        0
#                 Management IPs:     []
#         CDP-specific discovery info
#                 Status:           SUCCESS
#                 CDP stat:
#                         Total PDU count:      18312
#                         Trusted PDU count:    923
#                         Untrusted PDU count:  17389
#                         PDU gathering errors: 0
#                         PDU parsing errors:   0
#                 Age:              43
#                 Platform:         N5K-C5548UP
#                 Version:          Cisco Nexus Operating System (NX-OS) Software, Version 7.0(2)N1(1)
#                 FullDuplex:       true
#                 CDP common info:
#                         Switch ID:          Dell-R740-ToR(SSI182704BF)
#                         Port ID:            Ethernet2/13
#                         System name:        Dell-R740-ToR
#                         System description: N5K-C5548UP Cisco Nexus Operating System (NX-OS) Software, Version 7.0(2)N1(1)
#                         MTU:                1500
#                         Native VLAN:        1
#                         Management IPs:     [10.62.36.10]
#                 PCAP PDU info:
#                         Raw PCAP PDU length:        320
# For cisco switch, LLDP-specific discovery info could be:
# # >>>
#         LLDP-specific discovery info
#                 Status:           NO_PDUS_SEEN
#                 LLDP stat:
#                         Total PDU count:      0
#                         Trusted PDU count:    0
#                         Untrusted PDU count:  0
#                         PDU gathering errors: 0
#                         PDU parsing errors:   0
