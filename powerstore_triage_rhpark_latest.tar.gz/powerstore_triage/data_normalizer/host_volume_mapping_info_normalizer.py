import os
import json
from infra.utils import TOOL_NAME, TOOL_OUTPUT_FOLDER, get_mgmt_data_file_path, get_tmp_file_path
import logging

logger = logging.getLogger('.'.join([TOOL_NAME, __name__]))


def normalize_volume_mapping_info(dc_folder):
    list_of_volume_mapping = list()
    block_volume_id_to_volume_info = dict()
    block_volume_id_to_name = dict()
    # block_volume_id_to_node_affinity = dict()
    nas_volume_id_to_volume_info = dict()
    nas_volume_id_to_name = dict()
    # nas_volume_id_to_node_affinity = dict()
    volume_id_to_logical_used = dict()
    host_id_to_name = dict()
    hostgroupuuid_to_hostgroupname = dict()
    header = list()
    host_file_path = get_mgmt_data_file_path(dc_folder, 'host.json')
    host_volume_mapping_file_path = get_mgmt_data_file_path(dc_folder, 'host_volume_mapping.json')
    nas_volume_file_path = get_mgmt_data_file_path(dc_folder, 'nas_volume.json')
    volume_file_path = get_mgmt_data_file_path(dc_folder, 'volume.json')
    # the cma_view files are no longer collected in Data Collection.
    volume_list_cma_view_file_path = get_mgmt_data_file_path(dc_folder, 'volume_list_cma_view.json')
    host_volume_mapping_list_cma_view_file_path = get_mgmt_data_file_path(dc_folder, 'host_volume_mapping_list_cma_view.json')
    volume_id_to_logical_used_file_path = get_tmp_file_path(dc_folder, 'ns_sa_objects.json')

    host_group_file_path = get_mgmt_data_file_path(dc_folder,"host_group.json")
    if host_group_file_path:
        with open(host_group_file_path, 'r') as f:
            data = json.load(f)
            list_of_hostgroup = data['data']
            for host_group in list_of_hostgroup:
                host_group_uuid = host_group['id']
                hostgroupuuid_to_hostgroupname[host_group_uuid] = host_group["name"]

    if nas_volume_file_path:
        logger.debug(nas_volume_file_path)
        with open(nas_volume_file_path, 'r') as f:
            data = json.load(f)
            for i, record in enumerate(data['data']):
                nas_volume_id_to_volume_info[record["id"]] = record
                # nas_volume_id_to_name[record["id"]] = record["name"]
                # nas_volume_id_to_node_affinity[record["id"]] = record["node_affinity"]

    if volume_id_to_logical_used_file_path:
        with open(volume_id_to_logical_used_file_path, 'r') as f:
            volume_id_to_logical_used = json.load(f)

    if host_volume_mapping_file_path:
        if host_file_path:
            logger.debug(host_file_path)
            with open(host_file_path, 'r') as f:
                data = json.load(f)
                for record in data['data']:
                    host_id_to_name[record["id"]] = record["name"]
                # {
                #     "description": null,
                #     "host_group_id": null,
                #     "id": "b1d68686-e7ab-41b9-813d-61ea146084cd",
                #     "import_host_system_id": null,
                #     "is_internal": false,
                #     "name": "lghpk27",
                #     "os_type": "Linux",
                #     "type": "External"
                # },
                # {
                #     "appliance_id": "A1",
                #     "host_group_id": "2e86be8b-cf3b-4db0-ab21-40812a73e792",
                #     "host_id": null,
                #     "host_type": null,
                #     "id": "ce23dbe0-0a1d-4e59-9e84-fea00d336207",
                #     "is_internal": false,
                #     "logical_unit_number": 1,
                #     "map_type": "Standard",
                #     "platform_lunmap_guid": "71fe4ca2-6f06-481f-84e0-0aa123986dc5",
                #     "volume_id": "4cfa85bb-de7b-4a6d-b7bb-7a2cbf2b1a91",
                #     "volume_map_id": 5
                # },

        if volume_file_path:
            logger.debug(volume_file_path)
            with open(volume_file_path, 'r') as f:
                data = json.load(f)
                for i, record in enumerate(data['data']):
                    block_volume_id_to_volume_info[record["id"]] = record
                    # # volume id to user friendly name mapping. vvol is not included
                    # block_volume_id_to_name[record["id"]] = record["name"]
                    # block_volume_id_to_node_affinity[record["id"]] = record["node_affinity"]

        logger.debug(host_volume_mapping_file_path)
        with open(host_volume_mapping_file_path, 'r') as f:
            data = json.load(f)
            list_of_volume_mapping = data['data']
            for i, record in enumerate(list_of_volume_mapping):
                # map the volume id to volume user friendly name
                # map the volume id to node_affinity
                volume_id = record['volume_id']
                if volume_id in block_volume_id_to_volume_info.keys():
                    list_of_volume_mapping[i]['volume'] = block_volume_id_to_volume_info[volume_id]["name"]
                    list_of_volume_mapping[i]['node_affinity'] = block_volume_id_to_volume_info[volume_id]["node_affinity"]
                    list_of_volume_mapping[i]['size'] = block_volume_id_to_volume_info[volume_id]["size"]
                    list_of_volume_mapping[i]['wwn'] = block_volume_id_to_volume_info[volume_id]["wwn"]
                elif volume_id in nas_volume_id_to_volume_info.keys():
                    list_of_volume_mapping[i]['volume'] = nas_volume_id_to_volume_info[volume_id]["name"]
                    list_of_volume_mapping[i]['node_affinity'] = nas_volume_id_to_volume_info[volume_id]["node_affinity"]
                    list_of_volume_mapping[i]['size'] = nas_volume_id_to_volume_info[volume_id]["size"]
                    list_of_volume_mapping[i]['wwn'] = nas_volume_id_to_volume_info[volume_id]["wwn"]
                else:
                    list_of_volume_mapping[i]['volume'] = list_of_volume_mapping[i]['volume_id']
                    list_of_volume_mapping[i]['node_affinity'] = "?"
                    list_of_volume_mapping[i]['size'] = None
                    list_of_volume_mapping[i]['wwn'] = "?"
                # get "LogicalUsed" from ns_sa_objects
                if volume_id in volume_id_to_logical_used.keys():
                    list_of_volume_mapping[i]['LogicalUsed'] = volume_id_to_logical_used[volume_id]
                else:
                    list_of_volume_mapping[i]['LogicalUsed'] = None

                # map the host id to user friedly name
                host_id = record['host_id']
                host_group_id = record["host_group_id"]
                if host_id:
                    if host_id in host_id_to_name:
                        list_of_volume_mapping[i]['name'] = host_id_to_name[host_id]
                    else:
                        list_of_volume_mapping[i]['name'] = host_id
                elif host_group_id:
                    list_of_volume_mapping[i]['host_type'] = "host_group"
                    if host_group_id in hostgroupuuid_to_hostgroupname:
                        list_of_volume_mapping[i]['name'] = hostgroupuuid_to_hostgroupname[host_group_id]
                    else:
                        list_of_volume_mapping[i]['name'] = host_group_id
                # {
                #     "appliance_id": "A1",
                #     "host_group_id": null,
                #     "host_id": "9dada866-b1f7-453f-94e6-dd23f0972a79",
                #     "host_type": "Restricted",
                #     "id": "e24216bc-fc9a-4a31-8939-692b5b44a73c",
                #     "is_internal": false,
                #     "logical_unit_number": 1,
                #     "map_type": "Standard",
                #     "platform_lunmap_guid": "8316d2ca-dd30-4d2e-a7ac-eca975acf038",
                #     "volume_id": "810e21a3-5ce4-410a-880a-fe90d288b577",
                #     "volume_map_id": 3
                # }
                # {
                #     "appliance_id": "A1",
                #     "host_group_id": "2e86be8b-cf3b-4db0-ab21-40812a73e792",
                #     "host_id": null,
                #     "host_type": null,
                #     "id": "d1badad4-c3e6-4b5f-ad6b-0ec12f462024",
                #     "is_internal": false,
                #     "logical_unit_number": 2,
                #     "map_type": "Standard",
                #     "platform_lunmap_guid": "62a98d18-c39d-496f-9e12-81648c729cea",
                #     "volume_id": "686b8c93-5bb1-4e11-96ee-2bdd3dac9adb",
                #     "volume_map_id": 6
                # },

        header = ["name", "host_type", "volume", "logical_unit_number", "LogicalUsed", "size", "node_affinity", "wwn"]
    elif host_volume_mapping_list_cma_view_file_path:
        if volume_list_cma_view_file_path:
            logger.debug(volume_list_cma_view_file_path)
            with open(volume_list_cma_view_file_path, 'r') as f:
                data = json.load(f)
                for i, record in enumerate(data['data']):
                    block_volume_id_to_name[record["id"]] = record["name"]
        logger.debug(host_volume_mapping_list_cma_view_file_path)
        with open(host_volume_mapping_list_cma_view_file_path, 'r') as f:
            data = json.load(f)
            list_of_volume_mapping = data['data']
            for i, record in enumerate(list_of_volume_mapping):
                if record['volume_id'] in block_volume_id_to_name.keys():
                    list_of_volume_mapping[i]['volume'] = block_volume_id_to_name[record['volume_id']]
                elif record['volume_id'] in nas_volume_id_to_name.keys():
                    list_of_volume_mapping[i]['volume'] = nas_volume_id_to_name[record['volume_id']]
                else:
                    list_of_volume_mapping[i]['volume'] = list_of_volume_mapping[i]['volume_id']
        header = ["name", "volume", "logical_unit_number", "appliance_id"]
    return header, list_of_volume_mapping
