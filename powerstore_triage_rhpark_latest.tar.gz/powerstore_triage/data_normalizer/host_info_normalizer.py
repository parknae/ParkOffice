import os
import json
from infra.utils import TOOL_NAME, get_tmp_file_path, get_mgmt_data_file_path
import logging

logger = logging.getLogger('.'.join([TOOL_NAME, __name__]))


def normalize_host_info(dc_folder):
    hostgroupuuid_to_hostgroupname = dict()
    hostuuid_to_igname = dict()
    list_of_host = list()
    header = list()
    hostuuid_to_igname_file_path = get_tmp_file_path(dc_folder,"hostuuid_to_igname.json")
    if hostuuid_to_igname_file_path:
        with open(hostuuid_to_igname_file_path, 'r') as f:
            hostuuid_to_igname = json.load(f)
    
    host_config_id_to_initiator_group_name = dict()
    host_config_id_to_initiator_group_name_file_path = get_tmp_file_path(dc_folder, 'host_config_id_to_initiator_group_name.json')
    if host_config_id_to_initiator_group_name_file_path:
        with open(host_config_id_to_initiator_group_name_file_path, 'r') as f:
            host_config_id_to_initiator_group_name = json.load(f)       

    host_group_file_path = get_mgmt_data_file_path(dc_folder,"host_group.json")
    if host_group_file_path:
        with open(host_group_file_path, 'r') as f:
            data = json.load(f)
            list_of_hostgroup = data['data']
            for host_group in list_of_hostgroup:
                host_group_uuid = host_group['id']
                hostgroupuuid_to_hostgroupname[host_group_uuid] = host_group["name"]

    host_info_file_path = get_mgmt_data_file_path(dc_folder, 'host.json')
    host_combined_cma_view_file_path = get_mgmt_data_file_path(dc_folder,"host_combined_cma_view.json")
    external_hosts = list()
    if host_combined_cma_view_file_path:
        header = ["name", "host_group", "type", "IG_name_platform", "os_type", "port_type",
                  "initiator_count", "volumes", "appliances", 'node']
        logger.debug(host_combined_cma_view_file_path)
        with open(host_combined_cma_view_file_path, 'r') as f:
            data = json.load(f)
            list_of_host = data['data']

            for i, record in enumerate(list_of_host):
                external_hosts.append(record['name'])
                # all the host in host_combined_cma_view.json is external host
                list_of_host[i]['type'] = 'EXTERNAL'
                list_of_host[i]['node'] = 'N/A'
                # the "id" here represents the uuid of a host or the uuid of a host group
                uuid = record["id"]
                host_group_uuid = record["host_group_id"]
                if uuid in hostuuid_to_igname:
                    list_of_host[i]['IG_name_platform'] = hostuuid_to_igname[uuid]
                else:
                    list_of_host[i]['IG_name_platform'] = "N/A"

                if host_group_uuid and host_group_uuid in hostgroupuuid_to_hostgroupname:
                    list_of_host[i]['host_group'] = hostgroupuuid_to_hostgroupname[host_group_uuid]
                else:
                    list_of_host[i]['host_group'] = "N/A"
                # {
                #     "appliances": "WX-H4015-appliance-1",
                #     "chap_ok": true,
                #     "description": null,
                #     "host_count": null,
                #     "host_group_id": null,
                #     "id": "dfe0b739-9618-4420-b96f-fa85519c38eb",
                #     "import_host_system_id": null,
                #     "initiator_count": 1,
                #     "name": "lghpk28",
                #     "os_type": "Linux",
                #     "port_type": "iSCSI",
                #     "type": "Host",
                #     "volumes": 2
                # }
        config_item_host_info_file_path = get_tmp_file_path(dc_folder,"config_item_host_info.json")
        if config_item_host_info_file_path:
            with open(config_item_host_info_file_path, 'r') as f:
                data = json.load(f)
                for _, v in data.items():
                    if v['data']['name'] not in external_hosts:
                        config_item_host_info = dict()
                        config_item_host_info['name'] = v['data']['name']
                        config_item_host_info['type'] = v['data']['host_type']
                        config_item_host_info['os_type'] = v['data']['os']
                        if v['data']['host_type'] == "RESTRICTED":
                            config_item_host_info['appliances'] = 'N/A'
                            config_item_host_info['node'] = 'N/A'
                        else:
                            # {
                            #     "data": {
                            #         "description": "LocalHostH1",
                            #         "hardware_uuid": [],
                            #         "host_group_id": null,
                            #         "host_type": "LOCAL",  <-------------
                            #         "host_uuid": null,
                            #         "name": "WX-H4015-appliance-1-host-1",
                            #         "os": "CoreOs",
                            #         "serial_number": "FNM00191600901-A"
                            #     },
                            #     "id": "H1",
                            #     "parent": "N1",
                            #     "path": "C1.A1.N1.H1",
                            #     "type": "HOST"
                            # },
                            config_item_host_info['appliances'] = v['path'].split(".")[1]
                            config_item_host_info['node'] = v['parent']
                        if v['id'] in host_config_id_to_initiator_group_name:
                            config_item_host_info['IG_name_platform'] = host_config_id_to_initiator_group_name[v['id']]
                        for k in ["port_type","initiator_count", "volumes", "host_group"]:
                            config_item_host_info[k] = "N/A"
                        list_of_host.append(config_item_host_info)
                        # {'H1': {'data': {'description': 'LocalHostH1',
                        #                  'hardware_uuid': [],
                        #                  'host_group_id': None,
                        #                  'host_type': 'LOCAL',
                        #                  'host_uuid': None,
                        #                  'name': 'WX-H4015-appliance-1-host-1',
                        #                  'os': 'CoreOs',
                        #                  'serial_number': 'FNM00191600901-A'},
                        #         'id': 'H1',
                        #         'parent': 'N1',
                        #         'path': 'C1.A1.N1.H1',
                        #         'type': 'HOST'},
                        # 'H2': {
                        #     "data": {
                        #         "description": null,
                        #         "hardware_uuid": [
                        #             "128801CC-8FB4-4597-9AC2-9A25FAB41C78"
                        #         ],
                        #         "host_group_id": null,
                        #         "host_type": "INTERNAL",
                        #         "host_uuid": "6b55d774-bd05-4059-a990-69c17b9bc584",
                        #         "name": "WX-H6207-appliance-1-host-1",
                        #         "os": "ESXi",
                        #         "serial_number": "5e615a4b-2226-0124-d769-0060169e1d2a"
                        #     },
                        #     "id": "H2",
                        #     "parent": "N1",
                        #     "path": "C1.A1.N1.H2",
                        #     "type": "HOST"
                        # },
    elif host_info_file_path:
        header = ["name", "host_group", "type", "IG_name_platform", "os_type"]
        with open(host_info_file_path, 'r') as f:
            data = json.load(f)
            list_of_host = data['data']
            for i, record in enumerate(list_of_host):
                # the "id" here represents the uuid of a host or the uuid of a host group
                uuid = record["id"]
                host_group_uuid = record["host_group_id"]
                if uuid in hostuuid_to_igname:
                    list_of_host[i]['IG_name_platform'] = hostuuid_to_igname[uuid]
                else:
                    list_of_host[i]['IG_name_platform'] = "N/A"

                if host_group_uuid and host_group_uuid in hostgroupuuid_to_hostgroupname:
                    list_of_host[i]['host_group'] = hostgroupuuid_to_hostgroupname[host_group_uuid]
                else:
                    list_of_host[i]['host_group'] = "N/A"
                # "data": [
                # {
                #     "description": null,
                #     "host_group_id": null,
                #     "id": "6b55d774-bd05-4059-a990-69c17b9bc584",
                #     "import_host_system_id": null,
                #     "is_internal": true,
                #     "name": "WX-H6207-appliance-1-host-1",
                #     "os_type": "ESXi",
                #     "type": "Internal"
                # },
                # {
                #     "description": "",
                #     "host_group_id": null,
                #     "id": "a704dae0-dfa3-49e5-9677-b62482ab4fc0",
                #     "import_host_system_id": null,
                #     "is_internal": false,
                #     "name": "lghpk85",
                #     "os_type": "Linux",
                #     "type": "External"
                # }

    return header, list_of_host

        # +---------+------+-----------------------------+---------+-----------+-----------------+---------+------------+----------------------+
        # | name    | type | IG_name_platform            | os_type | port_type | initiator_count | volumes | host_group | appliances           |
        # | lghpk27 | Host | IG_FNM00191600901_EXHOST_H6 | Linux   | iSCSI     | 1               | 3       | N/A        | WX-H4015-appliance-1 |
        # | lghpk28 | Host | IG_FNM00191600901_EXHOST_H7 | Linux   | iSCSI     | 1               | 2       | N/A        | WX-H4015-appliance-1 |
        # +---------+------+-----------------------------+---------+-----------+-----------------+---------+------------+----------------------+
