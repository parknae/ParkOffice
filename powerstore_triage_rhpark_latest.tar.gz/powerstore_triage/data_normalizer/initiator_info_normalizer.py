import os
import json
from infra.utils import TOOL_NAME, TOOL_OUTPUT_FOLDER, TOOL_TMP_FOLDER, get_mgmt_data_internal_file_path, get_tmp_file_path
import logging

logger = logging.getLogger('.'.join([TOOL_NAME, __name__]))


def normalize_initiator_info(dc_folder):
    list_of_dict = list()
    inititor_active_session_count = dict()
    header = list()
    initiator_list_file_path = get_tmp_file_path(dc_folder,"initiator.json")
    if initiator_list_file_path:
        with open(initiator_list_file_path, 'r') as f:
            list_of_dict = json.load(f)
    initiator_active_session_assoc_file_path = get_mgmt_data_internal_file_path(dc_folder, 'initiator_active_session_association.json')
    header = ["WWN/IQN", "host_name_cp", "host_group_name", "initiator_name_platform",
            "IG_name_platform", "appliance_id", "port_type"]
    if initiator_active_session_assoc_file_path:
        header.insert(1, "active_sessions")
        with open(initiator_active_session_assoc_file_path, 'r') as f:
            data = json.load(f)
            for record in data['data']:
                initiator = record["initiator_port_name"]
                if initiator in inititor_active_session_count:
                    inititor_active_session_count[initiator] += 1
                else:
                    inititor_active_session_count[initiator] = 1
        for i, record in enumerate(list_of_dict):
            wwn_iqn = record["WWN/IQN"]
            if wwn_iqn in inititor_active_session_count:
                list_of_dict[i]["active_sessions"] = inititor_active_session_count[wwn_iqn]
            else:
                list_of_dict[i]["active_sessions"] = None
    return header, list_of_dict


