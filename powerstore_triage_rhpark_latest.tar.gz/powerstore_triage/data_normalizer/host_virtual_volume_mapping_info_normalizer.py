import os
import json
from infra.utils import TOOL_NAME, TOOL_OUTPUT_FOLDER, get_mgmt_data_file_path
import logging

logger = logging.getLogger('.'.join([TOOL_NAME, __name__]))


def normalize_virtual_volume_mapping_info(dc_folder):
    list_of_virtual_volume_mapping = list()
    virtual_volume_id_to_vvol_info = dict()
    host_id_to_host_info = dict()
    header = list()
    host_file_path = get_mgmt_data_file_path(dc_folder, 'host.json')
    host_virtual_volume_mapping_file_path = get_mgmt_data_file_path(dc_folder, 'host_virtual_volume_mapping.json')
    virtual_volume_file_path = get_mgmt_data_file_path(dc_folder, 'virtual_volume.json')

    if host_file_path:
        logger.debug(host_file_path)
        with open(host_file_path, 'r') as f:
            data = json.load(f)
            for record in data['data']:
                host_id_to_host_info[record["id"]] = record
            # {
            #     "description": null,
            #     "host_group_id": null,
            #     "id": "b1d68686-e7ab-41b9-813d-61ea146084cd",
            #     "import_host_system_id": null,
            #     "is_internal": false,
            #     "name": "lghpk27",
            #     "os_type": "Linux",
            #     "type": "External"
            # }

    if virtual_volume_file_path:
        logger.debug(virtual_volume_file_path)
        with open(virtual_volume_file_path, 'r') as f:
            data = json.load(f)
            for i, record in enumerate(data['data']):
                # volume id to user friendly name mapping. vvol is not included
                virtual_volume_id_to_vvol_info[record["id"]] = record
                # {
                    #     "appliance_id": "A1",
                    #     "connected_host_uuids": [
                    #         "128801CC-8FB4-4597-9AC2-9A25FAB41C78"
                    #     ],
                    #     "copy_signature": "8ce06d14-eea5-4ce9-a4d9-5517fcbac846",
                    #     "creation_timestamp": "2020-03-06 16:51:42.927000+00:00",
                    #     "creator_type": "User",
                    #     "datapath_family_id": 17,
                    #     "datapath_id": "7f929b84-e50a-47cb-ad16-38009afed825",
                    #     "family_id": "12fb2221-e5b1-4a80-88d3-4fd8d555c3b3",
                    #     "id": "7f929b84-e50a-47cb-ad16-38009afed825",
                    #     "io_priority": "Medium",
                    #     "is_internal": false,
                    #     "is_managed": true,
                    #     "is_readonly": false,
                    #     "is_replication_destination": false,
                    #     "migration_session_id": null,
                    #     "name": "windows1_4.vmdk",
                    #     "parent_id": null,
                    #     "platform_volume_id": "f40d2a2d9a0d466cb051ac03f12d2b38",
                    #     "platform_volume_naaname": "naa.68ccf098006423c79f165f854ead090d",
                    #     "profile_generation_id": 0,
                    #     "profile_id": "f4e5bade-15a2-4805-bf8e-52318c4ce443",
                    #     "rebind_in_progress": false,
                    #     "rg_id": "",
                    #     "size": 107374182400,
                    #     "source_id": null,
                    #     "source_timestamp": null,
                    #     "state": "Ready",
                    #     "storage_container_id": "a4b250c9-61aa-489b-98fe-b61a7cd82d98",
                    #     "type": "Primary",
                    #     "usage_type": "Data",
                    #     "virtual_machine_uuid": "5005d4ff-e3ec-bcf5-ba2e-f5d798833085",
                    #     "vmw_containerid": "a4b250c9-61aa-489b-98fe-b61a7cd82d98",
                    #     "vmw_createtime": null,
                    #     "vmw_gostype": "windows9Server64Guest",
                    #     "vmw_metadata": {
                    #         "VMW_VVolNamespace": "/vmfs/volumes/vvol:a4b250c961aa489b-98feb61a7cd82d98/naa.68ccf098002b53d8c2ba34b2a911435f",
                    #         "VMW_VmID_5005d4ff-e3ec-bcf5-ba2e-f5d798833085": "2020-03-06T16:51:42.900175Z",
                    #         "VMW_VvolAllocationType": "4",
                    #         "VMW_VvolProfile": "f4e5bade-15a2-4805-bf8e-52318c4ce443:0"
                    #     },
                    #     "vmw_vmid": "5005d4ff-e3ec-bcf5-ba2e-f5d798833085",
                    #     "vmw_vvolname": "windows1_4.vmdk",
                    #     "vmw_vvolparentuuid": null,
                    #     "vmw_vvoltype": "Data",
                    #     "vmw_vvoltypehint": null
                    # },

    if host_virtual_volume_mapping_file_path:
        logger.debug(host_virtual_volume_mapping_file_path)
        with open(host_virtual_volume_mapping_file_path, 'r') as f:
            data = json.load(f)
            list_of_virtual_volume_mapping = data['data']
            for i, record in enumerate(list_of_virtual_volume_mapping):
                # map the volume id to volume user friendly name
                virtual_volume_id = record['virtual_volume_id']
                if virtual_volume_id in virtual_volume_id_to_vvol_info.keys():
                    list_of_virtual_volume_mapping[i]['volume'] = virtual_volume_id_to_vvol_info[virtual_volume_id]['name']
                    list_of_virtual_volume_mapping[i]['vvoltype'] = virtual_volume_id_to_vvol_info[virtual_volume_id]['vmw_vvoltype']
                else:
                    list_of_virtual_volume_mapping[i]['volume'] = virtual_volume_id
                    list_of_virtual_volume_mapping[i]['vvoltype'] = list_of_virtual_volume_mapping[i]['virtual_volume_usage_type']
                # map the host id to user friedly name
                host_id = record['host_id']
                if host_id in host_id_to_host_info:
                    list_of_virtual_volume_mapping[i]['host_name'] = host_id_to_host_info[host_id]['name']
                    list_of_virtual_volume_mapping[i]['host_type'] = host_id_to_host_info[host_id]['type']
                else:
                    list_of_virtual_volume_mapping[i]['host_name'] = host_id
                    list_of_virtual_volume_mapping[i]['host_type'] = None
                # "data": [
                # {
                #     "appliance_id": "A1",
                #     "guid": "58a0eb92cfab49838c79a501e6d14b91",
                #     "host_group_id": null,
                #     "host_id": "6b55d774-bd05-4059-a990-69c17b9bc584",
                #     "id": "ee40264f-6132-48ba-a412-27e7d2eb11cc",
                #     "ig_id": "IG_FNM00184100665_INTERNALHOST_H1",
                #     "index": null,
                #     "is_internal": false,
                #     "map_type": "Standard",
                #     "node": "Node_A",
                #     "pe_id": "naa.68ccf0980073f14319429dd70044b953",
                #     "secondary_id": 1113,
                #     "te_id": null,
                #     "vasa_hosts": [
                #         "128801CC-8FB4-4597-9AC2-9A25FAB41C78"
                #     ],
                #     "virtual_volume_id": "285f09dc-df0b-4d3f-9aad-e2e298ff75f1",
                #     "virtual_volume_usage_type": "Data"
                # },

        header = ["host_name", "host_type", "volume", "vvoltype", "pe_id", "node", "secondary_id", "te_id", "appliance_id"]
    else:
        logger.warning("host_virtual_volume_mapping.json is not found, please check xmcli output in command_output folder")
    return header, list_of_virtual_volume_mapping


        # Powerstore T
        # nothing in host_mapping even if there's external ESXi host using VVOL
        # managementdb=> select * from host_mapping ;
        #  mor | uuid
        # -----+------
        # (0 rows)

        # PowerStore X
        # two entries in the host_mapping, they corresponds to node A and node B
        # managementdb=> select * from host_mapping ;
        #     mor     |                 uuid
        # ------------+--------------------------------------
        #  host-19349 | 128801CC-8FB4-4597-9AC2-9A25FAB41C78
        #  host-19343 | 6DBD3CA8-AC9E-41FD-888A-1B8CD975D992
        # (2 rows)
