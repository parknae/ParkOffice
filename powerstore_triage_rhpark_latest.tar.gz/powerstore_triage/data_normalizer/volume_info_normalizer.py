import os
import json
from infra.utils import TOOL_NAME, TOOL_OUTPUT_FOLDER, TOOL_TMP_FOLDER, get_mgmt_data_file_path, get_metrics_data_file_path, get_tmp_file_path, get_mgmt_data_internal_file_path
import logging

logger = logging.getLogger('.'.join([TOOL_NAME, __name__]))

# TODO: get the Logical Used from namespace spacestats enumobjects
def normalize_volume_info(dc_folder):
    list_of_dict = list()
    header = list()
    volume_file_path = get_mgmt_data_file_path(dc_folder, 'volume.json')
    volume_internal_file_path = get_mgmt_data_internal_file_path(dc_folder, 'volume.json')
    policy_file_path = get_mgmt_data_file_path(dc_folder, 'policy.json')
    volume_list_cma_view_file_path = get_mgmt_data_file_path(dc_folder, 'volume_list_cma_view.json')
    volume_group_volume_view_file_path = get_mgmt_data_file_path(dc_folder, 'volume_group_volume_view.json')
    volume_group_file_path = get_mgmt_data_file_path(dc_folder, 'volume_group.json')
    volume_id_to_object_handle_file_path = get_tmp_file_path(dc_folder, "volume_id_to_object_handle.json")
    volume_id_to_logical_used_file_path = get_tmp_file_path(dc_folder, 'ns_sa_objects.json')
    volume_id_to_object_handle = dict()
    volume_id_to_vg_name = dict()
    volume_id_to_vg_id = dict()
    volume_id_to_logical_used = dict()
    volume_group_id_to_vg_protection_policy_id = dict()
    volume_id_to_vg_protection_policy_id = dict()
    policy_id2name = dict() # used for "protection_policy_id" -> protection-policy user friendly name
    if policy_file_path:
        logger.debug(policy_file_path)
        with open(policy_file_path, 'r') as f:
            data = json.load(f)
            for record in data['data']:
                if record["type"] == "Protection":
                    policy_id2name[record["id"]] = record["name"]
    
    if volume_id_to_object_handle_file_path:
        with open(volume_id_to_object_handle_file_path, 'r') as f:
            volume_id_to_object_handle = json.load(f)

    if volume_id_to_logical_used_file_path:
        with open(volume_id_to_logical_used_file_path, 'r') as f:
            volume_id_to_logical_used = json.load(f)

    if volume_group_volume_view_file_path:
        logger.debug(volume_group_volume_view_file_path)
        with open(volume_group_volume_view_file_path, 'r') as f:
            data = json.load(f)
            for record in data['data']:
                vol_id = record['volume_id']
                volume_id_to_vg_name[vol_id] = record['volume_group_name']
                volume_id_to_vg_id[vol_id] = record['volume_group_id']
                # {
                #     "mapped_host_count": 1,
                #     "volume_group_id": "fb78cf6b-bb90-4299-ab87-ce3bea43051d",
                #     "volume_group_name": "VG1",
                #     "volume_id": "c3f5ebfa-331e-45ec-96b2-5a085552c97d",
                #     "volume_name": "labtea-vol-1",
                #     "volume_performance_policy_id": "default_medium",
                #     "volume_performance_policy_name": "Medium",
                #     "volume_protection_policy_id": null,   <---- always null as the protection policy is set on VG
                #     "volume_type": "Primary"
                # }
    if volume_group_file_path:
        logger.debug(volume_group_file_path)
        with open(volume_group_file_path, 'r') as f:
            data = json.load(f)
            for record in data['data']:
                vg_id = record['id']
                volume_group_id_to_vg_protection_policy_id[vg_id] = record['protection_policy_id']
                # "data": [

                # {
                #     "creation_timestamp": "2020-05-11 03:43:59.880000+00:00",
                #     "description": null,
                #     "id": "e1d5d206-f1fa-4f99-9520-49e0a9ca72c4",
                #     "is_importing": false,
                #     "is_internal": false,
                #     "is_protectable": true,
                #     "is_replication_destination": false,
                #     "is_write_order_consistent": true,
                #     "migration_session_id": null,
                #     "name": "test_vg",
                #     "placement_rule": "Same_Appliance",
                #     "protection_policy_id": "a1addc59-303f-45b9-8a65-c6d88e4c9f01",
                #     "type": "Primary"
                # },
    # logger.info(volume_group_id_to_vg_protection_policy_id)

    for vol_id in volume_id_to_vg_id:
        vg_id = volume_id_to_vg_id[vol_id]
        if vg_id in volume_group_id_to_vg_protection_policy_id:
            volume_id_to_vg_protection_policy_id[vol_id] = volume_group_id_to_vg_protection_policy_id[vg_id]
        else:
            volume_id_to_vg_protection_policy_id[vol_id] = None
    # logger.info(volume_id_to_vg_protection_policy_id)


    if volume_internal_file_path:
        logger.debug(volume_internal_file_path)
        volume_id_to_name = dict()
        # datapath_family_id is the SnapGroupId in the output of '/cyc_bsc/datapath/bin/cli.py namespace spacestats enumsnapgroups'
        # clone and its base have the same datapath_family_id and "family_id"
        # no family_id in this file for the release prior to SmuttyNode GA code
        header = ["name", "wwn", "Logical Used", "Provisioned", "volume_group_name", "performance_policy_id", "node_affinity", 
                "type", "state", "family_id", "SnapGroupId", "datapath_volume_id", "protection-policy", "creation_timestamp", 
                "appliance_id", "Object Handle", "is_replication_destination"]
        with open(volume_internal_file_path, 'r') as fp:
            data = json.load(fp)
            # "data": [
            # {
            #     "appliance_id": "A1",
            #     "copy_signature": "4f2201ea-e112-42ba-97f7-be3ad9ec4e22",
            #     "created_by_rule_id": "fd020255-7299-4b31-9ee4-06c0582b7cae",
            #     "creation_timestamp": "2020-03-19 09:35:00.176592+00:00",
            #     "creator_type": "Scheduler",
            #     "datapath_family_id": 34,
            #     "datapath_volume_id": "4f2201ea-e112-42ba-97f7-be3ad9ec4e22",
            #     "description": "",
            #     "expiration_timestamp": "2020-03-19 13:35:00.039000+00:00",
            #     "family_id": "fb28ea5b-b877-4dee-9f54-fb807cef4bf1",
            #     "id": "4f2201ea-e112-42ba-97f7-be3ad9ec4e22",
            #     "import_metadata": null,
            #     "is_app_consistent": null,
            #     "is_importing": false,
            #     "is_internal": false,
            #     "is_read_only": true,
            #     "is_replication_destination": false,
            #     "migration_session_id": null,
            #     "name": "snap_5_min.vol_fs.2020-03-19T09:35:00Z 518716825",
            #     "node_affinity": "System_Select_At_Attach",
            #     "parent_id": "fb28ea5b-b877-4dee-9f54-fb807cef4bf1",
            #     "performance_policy_id": "default_medium",
            #     "platform_volume_guid": null,
            #     "platform_volume_id": -1,
            #     "protection_policy_id": null,
            #     "sector_size": 512,
            #     "size": 107374182400,
            #     "source_id": "fb28ea5b-b877-4dee-9f54-fb807cef4bf1",
            #     "source_timestamp": "2020-03-19 09:35:00.176592+00:00",
            #     "state": "Ready",
            #     "storage_type": "Block",
            #     "type": "Snapshot",
            #     "wwn": null
            # },
            # {
            #     "appliance_id": "A1",
            #     "copy_signature": null,
            #     "created_by_rule_id": null,
            #     "creation_timestamp": "2020-03-11 15:24:11.982075+00:00",
            #     "creator_type": "User",
            #     "datapath_family_id": 18,
            #     "datapath_volume_id": "c3f5ebfa-331e-45ec-96b2-5a085552c97d",
            #     "description": "",
            #     "expiration_timestamp": null,
            #     "family_id": "c3f5ebfa-331e-45ec-96b2-5a085552c97d",
            #     "id": "c3f5ebfa-331e-45ec-96b2-5a085552c97d",
            #     "import_metadata": null,
            #     "is_app_consistent": null,
            #     "is_importing": false,
            #     "is_internal": false,
            #     "is_read_only": false,
            #     "is_replication_destination": false,
            #     "migration_session_id": null,
            #     "name": "labtea-vol-1",
            #     "node_affinity": "System_Selected_Node_A",
            #     "parent_id": null,
            #     "performance_policy_id": "default_medium",
            #     "platform_volume_guid": "dfaa65e4-efbd-4756-a5f0-a14f13e37e29",
            #     "platform_volume_id": -1,
            #     "protection_policy_id": null,
            #     "sector_size": 512,
            #     "size": 18821620432896,
            #     "source_id": null,
            #     "source_timestamp": null,
            #     "state": "Ready",
            #     "storage_type": "Block",
            #     "type": "Primary",
            #     "wwn": "naa.68ccf09800df8913011bc00e4f935a42"
            # },
            for record in data['data']:
                volume_id_to_name[record["id"]] = record["name"]

            # no family_id in this file for the release prior to SmuttyNode GA code
            if data["data"] and "family_id" not in data["data"][0]:
                header.remove('family_id')

            if data["data"] and "parent_id" in data["data"][0]:
                header.extend(["parent_volume", "source_volume", "source_timestamp"])

            for record in data["data"]:
                # Only append the Primary and Clone volume to the list
                if record["type"] in ["Primary", "Clone"]:
                    protection_policy_id = record["protection_policy_id"]
                    record['SnapGroupId'] = record["datapath_family_id"]
                    record['Provisioned'] = record["size"]
                    if record['id'] in volume_id_to_vg_name:
                        record['volume_group_name'] = volume_id_to_vg_name[record['id']]
                        # if a volume is in a VG with write-order consistency enabled, the protection policy is set on the VG level
                        # if a volume is in a VG with write-order consistency disabled, it can has its own protection policy if no protection policy is set on VG
                        if not protection_policy_id:
                            protection_policy_id = volume_id_to_vg_protection_policy_id[record['id']]
                    else:
                        record['volume_group_name'] = None
                    
                    if protection_policy_id in policy_id2name:
                        record['protection-policy'] = policy_id2name[protection_policy_id]
                    else:
                        # protection_policy_id is None or a uuid which is not found in policy.json
                        record['protection-policy'] = protection_policy_id

                    if record['id'] in volume_id_to_object_handle:
                        record['Object Handle'] = volume_id_to_object_handle[record['id']]
                    else:
                        record['Object Handle'] = None

                    if record['id'] in volume_id_to_logical_used:
                        record['Logical Used'] = volume_id_to_logical_used[record['id']]
                    else:
                        record['Logical Used'] = None

                    if "parent_id" in record:
                        parent_id = record["parent_id"]
                        if parent_id:
                            if parent_id in volume_id_to_name:
                                record["parent_volume"] = volume_id_to_name[parent_id]
                            else:
                                record["parent_volume"] = parent_id
                        else:
                            record["parent_volume"] = None

                    if "source_id" in record:
                        source_id = record["source_id"]
                        if source_id:
                            if parent_id in volume_id_to_name:
                                record["source_volume"] = volume_id_to_name[source_id]
                            else:
                                record["source_volume"] = source_id
                        else:
                            record["source_volume"] = None

                    list_of_dict.append(record)
    elif volume_file_path:
        logger.debug(volume_file_path)
        with open(volume_file_path, 'r') as f:
            data = json.load(f)
            # {
            #     "appliance_id": "A1",
            #     "creation_timestamp": "2020-03-11 15:24:11.982075+00:00",
            #     "datapath_family_id": 18,
            #     "datapath_volume_id": "c3f5ebfa-331e-45ec-96b2-5a085552c97d",
            #     "description": "",
            #     "id": "c3f5ebfa-331e-45ec-96b2-5a085552c97d",
            #     "import_metadata": null,
            #     "is_importing": false,
            #     "is_internal": false,
            #     "is_read_only": false,
            #     "is_replication_destination": false,
            #     "migration_session_id": null,
            #     "name": "labtea-vol-1",
            #     "node_affinity": "System_Selected_Node_A",
            #     "performance_policy_id": "default_medium",
            #     "platform_volume_guid": "dfaa65e4-efbd-4756-a5f0-a14f13e37e29",
            #     "platform_volume_id": -1,
            #     "protection_policy_id": null,
            #     "sector_size": 512,
            #     "size": 18821620432896,
            #     "state": "Ready",
            #     "storage_type": "Block",
            #     "type": "Primary",
            #     "wwn": "naa.68ccf09800df8913011bc00e4f935a42"
            # },
            for record in data["data"]:
                if record["type"] in ["Primary", "Clone"]:
                    protection_policy_id = record["protection_policy_id"]
                    record['SnapGroupId'] = record["datapath_family_id"]
                    record['Provisioned'] = record["size"]
                    if record['id'] in volume_id_to_vg_name:
                        record['volume_group_name'] = volume_id_to_vg_name[record['id']]
                        # if a volume is in a VG with write-order consistency enabled, the protection policy is set on the VG level
                        # if a volume is in a VG with write-order consistency disabled, it can has its own protection policy if no protection policy is set on VG
                        if not protection_policy_id:
                            protection_policy_id = volume_id_to_vg_protection_policy_id[record['id']]
                    else:
                        record['volume_group_name'] = None
                    
                    if protection_policy_id in policy_id2name:
                        record['protection-policy'] = policy_id2name[protection_policy_id]
                    else:
                        # protection_policy_id is None or a uuid which is not found in policy.json
                        record['protection-policy'] = protection_policy_id

                    if record['id'] in volume_id_to_object_handle:
                        record['Object Handle'] = volume_id_to_object_handle[record['id']]
                    else:
                        record['Object Handle'] = None

                    if record['id'] in volume_id_to_logical_used:
                        record['Logical Used'] = volume_id_to_logical_used[record['id']]
                    else:
                        record['Logical Used'] = None

                    list_of_dict.append(record)
        header = ["name", "wwn", "Logical Used", "Provisioned", "volume_group_name", "performance_policy_id", "node_affinity", 
        "type", "state", "SnapGroupId", "datapath_volume_id", "protection-policy", "creation_timestamp", 
        "appliance_id", "Object Handle", "is_replication_destination"]

    # volume_list_cma_view.json is no longer collected in Data Collection in SmuttyNose GA code.
    elif volume_list_cma_view_file_path:
        logger.debug(volume_list_cma_view_file_path)
        volume_id_to_name = dict()
        with open(volume_list_cma_view_file_path, 'r') as f:
            data = json.load(f)
            logger.debug(data)
            list_of_dict = data['data']
            for i, record in enumerate(list_of_dict):
                volume_id_to_name[record["id"]] = record["name"]
                if record["protection_policy_name"]:
                    list_of_dict[i]["protection-policy"] = record["protection_policy_name"]
                elif record["volume_group_protection_policy_name"]:
                    list_of_dict[i]["protection-policy"] = record["volume_group_protection_policy_name"]
                else:
                    list_of_dict[i]["protection-policy"] = None

            for i, record in enumerate(list_of_dict):
                parent_id = record["parent_id"]
                if parent_id:
                    if parent_id in volume_id_to_name:
                        list_of_dict[i]["parent_volume"] = volume_id_to_name[parent_id]
                    else:
                        list_of_dict[i]["parent_volume"] = "Parent id is {0}, but user-friendly name is not found".format(parent_id)
                else:
                    list_of_dict[i]["parent_volume"] = None

            header = ["name", "wwn", "logical_provisioned", "logical_used", "performance_rule_io_priority",
             "node_affinity", "type", "state", "datapath_volume_id", "protection-policy",
             "creation_timestamp", "appliance_id", "parent_volume", "volume_group_name", "id", "family_id"]
    
    return header, list_of_dict