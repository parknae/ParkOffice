import os
import json
from infra.utils import TOOL_NAME, TOOL_OUTPUT_FOLDER, get_mgmt_data_file_path, get_tmp_file_path, get_mgmt_data_internal_file_path
import logging

logger = logging.getLogger('.'.join([TOOL_NAME, __name__]))


def normalize_volume_snap_info(dc_folder):
    list_of_dict = list()
    header = list()
    volume_id_to_name = dict()
    volume_id_to_vg_name = dict()
    # family_id_to_name = dict()
    volume_list_cma_view_file_path = get_mgmt_data_file_path(dc_folder, 'volume_list_cma_view.json')
    volume_snap_list_cma_view_file_path = get_mgmt_data_file_path(dc_folder, 'volume_snap_list_cma_view.json')
    volume_file_path = get_mgmt_data_file_path(dc_folder, 'volume.json')
    snap_rule_file_path = get_mgmt_data_file_path(dc_folder, 'snapshot_rule.json')
    replication_rule_file_path = get_mgmt_data_file_path(dc_folder, 'replication_rule.json')
    volume_internal_file_path = get_mgmt_data_internal_file_path(dc_folder, 'volume.json')
    volume_group_volume_view_file_path = get_mgmt_data_file_path(dc_folder, 'volume_group_volume_view.json')
    volume_id_to_object_handle_file_path = get_tmp_file_path(dc_folder, "volume_id_to_object_handle.json")
    volume_id_to_object_handle = dict()
    rule_id_to_rule_name = dict()

    if snap_rule_file_path:
        logger.debug(snap_rule_file_path)
        with open(snap_rule_file_path, 'r') as f:
            data = json.load(f)
            for record in data['data']:
               rule_id_to_rule_name[record['id']] = record['name']

    if replication_rule_file_path:
        logger.debug(replication_rule_file_path)
        with open(replication_rule_file_path, 'r') as f:
            for record in data['data']:
                rule_id_to_rule_name[record['id']] = record['name']

    if volume_group_volume_view_file_path:
        logger.debug(volume_group_volume_view_file_path)
        with open(volume_group_volume_view_file_path, 'r') as f:
            data = json.load(f)
            for record in data['data']:
                volume_id_to_vg_name[record['volume_id']] = record['volume_group_name']

    if volume_id_to_object_handle_file_path:
        with open(volume_id_to_object_handle_file_path, 'r') as f:
            volume_id_to_object_handle = json.load(f)

    if volume_internal_file_path:
        logger.debug(volume_internal_file_path)
        volume_id_to_name = dict()
        with open(volume_internal_file_path, 'r') as fp:
            data = json.load(fp)
            # "data": [
            # {
            #     "appliance_id": "A1",
            #     "copy_signature": "4f2201ea-e112-42ba-97f7-be3ad9ec4e22",
            #     "created_by_rule_id": "fd020255-7299-4b31-9ee4-06c0582b7cae",
            #     "creation_timestamp": "2020-03-19 09:35:00.176592+00:00",
            #     "creator_type": "Scheduler",
            #     "datapath_family_id": 34,
            #     "datapath_volume_id": "4f2201ea-e112-42ba-97f7-be3ad9ec4e22",
            #     "description": "",
            #     "expiration_timestamp": "2020-03-19 13:35:00.039000+00:00",
            #     "family_id": "fb28ea5b-b877-4dee-9f54-fb807cef4bf1",
            #     "id": "4f2201ea-e112-42ba-97f7-be3ad9ec4e22",
            #     "import_metadata": null,
            #     "is_app_consistent": null,
            #     "is_importing": false,
            #     "is_internal": false,
            #     "is_read_only": true,
            #     "is_replication_destination": false,
            #     "migration_session_id": null,
            #     "name": "snap_5_min.vol_fs.2020-03-19T09:35:00Z 518716825",
            #     "node_affinity": "System_Select_At_Attach",
            #     "parent_id": "fb28ea5b-b877-4dee-9f54-fb807cef4bf1",
            #     "performance_policy_id": "default_medium",
            #     "platform_volume_guid": null,
            #     "platform_volume_id": -1,
            #     "protection_policy_id": null,
            #     "sector_size": 512,
            #     "size": 107374182400,
            #     "source_id": "fb28ea5b-b877-4dee-9f54-fb807cef4bf1",
            #     "source_timestamp": "2020-03-19 09:35:00.176592+00:00",
            #     "state": "Ready",
            #     "storage_type": "Block",
            #     "type": "Snapshot",
            #     "wwn": null
            # },
            # {
            #     "appliance_id": "A1",
            #     "copy_signature": null,
            #     "created_by_rule_id": null,
            #     "creation_timestamp": "2020-03-11 15:24:11.982075+00:00",
            #     "creator_type": "User",
            #     "datapath_family_id": 18,
            #     "datapath_volume_id": "c3f5ebfa-331e-45ec-96b2-5a085552c97d",
            #     "description": "",
            #     "expiration_timestamp": null,
            #     "family_id": "c3f5ebfa-331e-45ec-96b2-5a085552c97d",
            #     "id": "c3f5ebfa-331e-45ec-96b2-5a085552c97d",
            #     "import_metadata": null,
            #     "is_app_consistent": null,
            #     "is_importing": false,
            #     "is_internal": false,
            #     "is_read_only": false,
            #     "is_replication_destination": false,
            #     "migration_session_id": null,
            #     "name": "labtea-vol-1",
            #     "node_affinity": "System_Selected_Node_A",
            #     "parent_id": null,
            #     "performance_policy_id": "default_medium",
            #     "platform_volume_guid": "dfaa65e4-efbd-4756-a5f0-a14f13e37e29",
            #     "platform_volume_id": -1,
            #     "protection_policy_id": null,
            #     "sector_size": 512,
            #     "size": 18821620432896,
            #     "source_id": null,
            #     "source_timestamp": null,
            #     "state": "Ready",
            #     "storage_type": "Block",
            #     "type": "Primary",
            #     "wwn": "naa.68ccf09800df8913011bc00e4f935a42"
            # },

            for record in data['data']:
                volume_id_to_name[record["id"]] = record["name"]

            for record in data["data"]:
                # Only append the Primary and Clone volume to the list
                if record["type"] in ["Snapshot"]:
                    if record['id'] in volume_id_to_vg_name:
                        record['volume_group_name'] = volume_id_to_vg_name[record['id']]
                    else:
                        record['volume_group_name'] = None
                    
                    if record['id'] in volume_id_to_object_handle:
                        record['Object Handle'] = volume_id_to_object_handle[record['id']]
                    else:
                        record['Object Handle'] = None

                    created_by_rule_id = record['created_by_rule_id']
                    if created_by_rule_id in rule_id_to_rule_name:
                        record['created_by_rule'] = rule_id_to_rule_name[created_by_rule_id]
                    else:
                        record['created_by_rule'] = created_by_rule_id

                    parent_id = record["parent_id"]
                    if parent_id in volume_id_to_name:
                        record["parent_volume"] = volume_id_to_name[parent_id]
                    else:
                        record["parent_volume"] = parent_id

                    source_id = record["source_id"]
                    if parent_id in volume_id_to_name:
                        record["source_volume"] = volume_id_to_name[source_id]
                    else:
                        record["source_volume"] = source_id

                    list_of_dict.append(record)

        header = ["parent_volume", "volume_group_name", "name", "wwn", "size", "created_by_rule", "performance_policy_id",  
                "type", "state", "datapath_volume_id", "creation_timestamp", 
                "appliance_id", "datapath_family_id", "Object Handle", "is_replication_destination", "source_volume", "source_timestamp", "node_affinity"]
    elif volume_file_path:
        logger.debug(volume_file_path)
        with open(volume_file_path, 'r') as f:
            data = json.load(f)
            # datapath_family_id is the same for Primary and Clone
            # for record in data["data"]:
            #     if record["type"] in ["Primary", "Clone"]:
            #         family_id_to_name[record['datapath_family_id']] = record['name']
            for record in data["data"]:
                if record["type"] in ["Snapshot"]:
                    vol_id = record['id']
                    if vol_id in volume_id_to_vg_name:
                        record['volume_group_name'] = volume_id_to_vg_name[vol_id]
                    else:
                        record['volume_group_name'] = None
                    if vol_id in volume_id_to_object_handle:
                        record["Object Handle"] = volume_id_to_object_handle[vol_id]
                    else:
                        record["Object Handle"] = None
                    list_of_dict.append(record)
            header = ["volume_group_name", "name", "wwn", "size", "creation_timestamp", "datapath_volume_id", 
            "appliance_id", "datapath_family_id", "Object Handle", "is_replication_destination"]
                # {
                #     "appliance_id": "A1",
                #     "creation_timestamp": "2020-03-18 09:15:00.105720+00:00",
                #     "datapath_family_id": 34,
                #     "datapath_volume_id": "1c59b081-5028-4cc7-891d-55d8f0feb5fb",
                #     "description": "",
                #     "id": "1c59b081-5028-4cc7-891d-55d8f0feb5fb",
                #     "import_metadata": null,
                #     "is_importing": false,
                #     "is_internal": false,
                #     "is_read_only": true,
                #     "is_replication_destination": false,
                #     "migration_session_id": null,
                #     "name": "snap_5_min.vol_fs.2020-03-18T09:15:00Z 238076048",
                #     "node_affinity": "System_Select_At_Attach",
                #     "performance_policy_id": "default_medium",
                #     "platform_volume_guid": null,
                #     "platform_volume_id": -1,
                #     "protection_policy_id": null,
                #     "sector_size": 512,
                #     "size": 107374182400,
                #     "state": "Ready",
                #     "storage_type": "Block",
                #     "type": "Snapshot",
                #     "wwn": null
                # },
    # volume_list_cma_view and volume_snap_list_cma_view are no longer collected in Data Collection.
    elif volume_list_cma_view_file_path and volume_snap_list_cma_view_file_path:
        logger.debug(volume_list_cma_view_file_path)
        with open(volume_list_cma_view_file_path, 'r') as f:
            data = json.load(f)
            for i, record in enumerate(data['data']):
                volume_id_to_name[record["id"]] = record["name"]
        
        logger.debug(volume_snap_list_cma_view_file_path)
        with open(volume_snap_list_cma_view_file_path, 'r') as f:
            data = json.load(f)
            list_of_dict = data['data']
            for i, record in enumerate(list_of_dict):
                parent_id = record["parent_id"]
                if parent_id:
                    if parent_id in volume_id_to_name:
                        list_of_dict[i]["parent_volume"] = volume_id_to_name[parent_id]
                    else:
                        list_of_dict[i]["parent_volume"] = "Parent id is {0}, but user-friendly name is not found".format(parent_id)
                else:
                    list_of_dict[i]["parent_volume"] = None
        header = ["parent_volume", "volume_group_name", "name", "size", "creator_type", "created_by_rule_name",
              "creation_timestamp", "expiration_timestamp", "datapath_volume_id", "appliance_id", "id",
              "family_id", "is_replication_destination"]
    return header, list_of_dict
