import os
import json
from infra.utils import TOOL_NAME, get_mgmt_data_internal_file_path
import logging

logger = logging.getLogger('.'.join([TOOL_NAME, __name__]))


def normalize_datacollection_info(dc_folder):
    list_of_dict = list()
    header = list()
    datacollection_id_to_details = dict()
    datacollection_file_path = get_mgmt_data_internal_file_path(dc_folder, 'datacollection.json')
    datacollection_appliance_file_path = get_mgmt_data_internal_file_path(dc_folder, 'datacollection_appliance.json')
    # datacollection_profile_link_file_path = get_mgmt_data_internal_file_path(dc_folder, 'datacollection_profile_link.json')

    if datacollection_file_path:
        logger.debug(datacollection_file_path)
        with open(datacollection_file_path, 'r') as f:
            data = json.load(f)
            for record in data['data']:
                dc_id = record["id"]
                datacollection_id_to_details[dc_id] = record
                    # {
                    #     "data": [

                    #     {
                    #         "creator_type": "Scheduled",
                    #         "dc_state": "ONLINE",
                    #         "dc_status": "SUCCESS",
                    #         "description": "2020-03-16 Daily Data Collection",
                    #         "downloaded": null,
                    #         "end_timestamp": "2020-03-16 01:46:15+00:00",
                    #         "id": "b6d4620b-b264-4596-8865-f4c48d70d6b4",
                    #         "start_timestamp": "2020-03-16 01:34:22+00:00",
                    #         "status_message": null,
                    #         "uploaded": null
                    #     },

    if datacollection_appliance_file_path:
        logger.debug(datacollection_appliance_file_path)
        with open(datacollection_appliance_file_path, 'r') as f:
            data = json.load(f)
            list_of_dict = data['data']
            for i, record in enumerate(list_of_dict):
                dc_id = record["datacollection_id"]
                list_of_dict[i]["appliance"] = record["appliance_serial_number"]
                if dc_id in datacollection_id_to_details:
                    list_of_dict[i]["description"] = datacollection_id_to_details[dc_id]["description"]
                    list_of_dict[i]["creator_type"] = datacollection_id_to_details[dc_id]["creator_type"]
                else:
                    list_of_dict[i]["description"] = None
                    list_of_dict[i]["creator_type"] = None
            header = ["start_timestamp", "id", "dc_status", "creator_type", "description", "uploaded", "compressed_size", 
                        "uncompressed_size", "end_timestamp", "appliance", "node", "upload_in_progress"]
    else:
        logger.warning("datacollection_appliance.json is not found")
    
    return header, list_of_dict
                # {
                #     "data": [

                #     {
                #         "appliance_serial_number": "FNM00191700061",
                #         "compressed_size": 1202534684,
                #         "datacollection_id": "eb1249f3-7bd3-4402-ba3a-94a1ceb4fe93",
                #         "dc_state": "ONLINE",
                #         "dc_status": "SUCCESS",
                #         "downloaded": null,
                #         "end_timestamp": "2020-03-18 02:11:34+00:00",
                #         "id": "8253aff8-3c25-4906-9a9a-a42483e24650",
                #         "node": "node_a",
                #         "path": "/cyc_var/cyc_service/data_collection/eb1249f3-7bd3-4402-ba3a-94a1ceb4fe93/powerstore_67W1BW2_PS74e9ac793f87_FNM00191700061_2020-03-18_01-59-02_service-data.tgz",
                #         "start_timestamp": "2020-03-18 01:59:02+00:00",
                #         "status_message": null,
                #         "uncompressed_size": 7716162129,
                #         "upload_in_progress": false,
                #         "uploaded": null
                #     },
# datacollection_profile_link.json
# 
# {
#     "datacollection_id": "6c6260e0-7f7a-4b23-b5e3-e7d14de3b4d2",
#     "datacollection_profile_id": "1",
#     "id": "4f306927-653f-4ec5-8222-884b03730a26"
# },
# no information about the user friendly name of datacollection_profile_id