import os
import json
from infra.utils import TOOL_NAME, TOOL_OUTPUT_FOLDER, get_mgmt_data_file_path
import logging

logger = logging.getLogger('.'.join([TOOL_NAME, __name__]))


def normalize_storage_container_info(dc_folder):
    stroage_container_file_path = get_mgmt_data_file_path(dc_folder, 'storage_container.json')
    storage_container_general_cma_view_file_path = get_mgmt_data_file_path(dc_folder, 'storage_container_general_cma_view.json')
    list_of_dict = list()
    header = list()
    # storage_container_general_cma_view.json is no longer collected in Data Collection
    if storage_container_general_cma_view_file_path:
        logger.debug(storage_container_general_cma_view_file_path)
        with open(storage_container_general_cma_view_file_path, 'r') as f:
            data = json.load(f)
            logger.debug(data)
            list_of_dict = data['data']
            # for i, record in enumerate(list_of_dict):
            #     for k, v in record.items():
            #         if not v:
            #             list_of_dict[i][k] = 'null'
        header = ["name", "sc_id", "quota", "total_space",
             "used_space", "free_space", "high_water_mark"]
    elif stroage_container_file_path:
        logger.debug(stroage_container_file_path)
        with open(stroage_container_file_path, 'r') as f:
            data = json.load(f)
            logger.debug(data)
            list_of_dict = data['data']
            # {
            #     "high_water_mark": 85,
            #     "id": "bcd3fcc8-8dc0-4c4e-b3c7-4b65661b18bc",
            #     "name": "PowerStore WX-H4015",
            #     "quota": 0,
            #     "sc_id": 6
            # }
        header = ["name", "quota", "high_water_mark", "sc_id", "id"]
    return header, list_of_dict