import yaml


def normalize_software_version_info(dc_folder):
    pass
    # with open('./cyc_host/.version', 'r') as f:
    #     software_version_info = yaml.safe_load(f)
