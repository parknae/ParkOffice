import os
import json
import re
from infra.utils import TOOL_NAME, get_tmp_file_path
import logging

logger = logging.getLogger('.'.join([TOOL_NAME, __name__]))


def normalize_file_interface_info(dc_folder):
    file_interface_list_file_path = get_tmp_file_path(dc_folder, "file_interface_list.json")
    list_of_dict = dict()
    header = list()
    if file_interface_list_file_path:
        logger.debug(file_interface_list_file_path)
        with open(file_interface_list_file_path, 'r') as f:
            list_of_dict = json.load(f)
        for i, record in enumerate(list_of_dict):
            if 'gateway' not in record:
                list_of_dict[i]['gateway'] = "--"
        header = ['id', 'ipAddress', "netmask", "gateway", "vlanId"]
    return header, list_of_dict
