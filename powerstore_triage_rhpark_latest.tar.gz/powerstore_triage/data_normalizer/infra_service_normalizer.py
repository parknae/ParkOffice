import os
import json
import re
from infra.utils import TOOL_NAME, get_tmp_file_path
import logging

logger = logging.getLogger('.'.join([TOOL_NAME, __name__]))

def normalize_infra_service_info(dc_folder):
    infra_service_file_path = get_tmp_file_path(dc_folder, "infra_service.json")
    list_of_dict = dict()
    header = list()
    if infra_service_file_path:
        logger.debug(infra_service_file_path)
        with open(infra_service_file_path, 'r') as f:
            list_of_dict = json.load(f)
        for i, record in enumerate(list_of_dict):
            list_of_dict[i]['addresses'] = ",".join(record['data']['addresses'])
        header = ['type', 'addresses']
    return header, list_of_dict

    # {
    #     "data": {
    #         "addresses": [
    #             "10.244.53.108",
    #             "10.228.254.66"
    #         ]
    #     },
    #     "id": "DNS1",
    #     "parent": "C1",
    #     "path": "C1.DNS1",
    #     "type": "DNS"
    # },
    # {
    #     "data": {
    #         "addresses": [
    #             "10.254.225.252",
    #             "10.104.0.254"
    #         ]
    #     },
    #     "id": "NTP1",
    #     "parent": "C1",
    #     "path": "C1.NTP1",
    #     "type": "NTP"
    # },
