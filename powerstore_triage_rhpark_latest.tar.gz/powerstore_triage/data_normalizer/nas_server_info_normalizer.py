import os
import json
from infra.utils import TOOL_NAME, TOOL_OUTPUT_FOLDER, get_mgmt_data_file_path
import logging

logger = logging.getLogger('.'.join([TOOL_NAME, __name__]))


def normalize_nas_server_info(dc_folder):
    list_of_dict = list()
    header = list()
    nas_server_file_path = get_mgmt_data_file_path(dc_folder, 'nas_server.json')

    if nas_server_file_path:
        logger.debug(nas_server_file_path)
        with open(nas_server_file_path, 'r') as f:
            data = json.load(f)
            list_of_dict = data['data']
            # {
            #     "backup_IPv4_interface_id": null,
            #     "backup_IPv6_interface_id": null,
            #     "cluster": "5e627125-8014-9bca-503e-8a1d5a42cf8c",
            #     "config_fs_wwn": "wwn_0x68ccf09800551a8feb3b2ad71b7744a2",
            #     "current_node_id": "WX-H4015-appliance-1-node-B",
            #     "current_preferred_IPv4_interface_id": "5e6b6053-632f-d486-6654-268719b17386",
            #     "current_preferred_IPv6_interface_id": null,
            #     "current_unix_directory_service": "None",
            #     "default_unix_user": null,
            #     "default_windows_user": null,
            #     "description": "",
            #     "health": "GOOD",
            #     "id": "5e6b604c-eb3e-1388-b8e2-268719b17386",
            #     "is_auto_user_mapping_enabled": false,
            #     "is_username_translation_enabled": false,
            #     "name": "nas_server_2",
            #     "operation_status": "SDNAS_NAS_SERVER_IN_SERVICE",
            #     "operational_status": "Started",
            #     "preferred_node_id": "WX-H4015-appliance-1-node-B",
            #     "production_IPv4_interface_id": null,
            #     "production_IPv6_interface_id": null,
            #     "read_only": false,
            #     "root_fs_wwn": "wwn_0x68ccf09800d302af76cee77780549625"
            # },
        header = ["name", "preferred_node_id", "current_node_id", "health", "current_preferred_IPv4_interface_id", "root_fs_wwn", "config_fs_wwn"]
    return header, list_of_dict