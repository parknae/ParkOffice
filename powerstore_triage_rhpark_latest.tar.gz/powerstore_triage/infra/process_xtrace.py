from __future__ import print_function
import os
import logging
import glob
from infra.utils import system, TOOL_NAME, TOOL_OUTPUT_FOLDER, handle_exceptions
import concurrent.futures

# the parent logger will be the logger with name defined by TOOL_NAME
logger = logging.getLogger('.'.join([TOOL_NAME, __name__]))


@handle_exceptions
def get_tlogger_cmd(dc_work_space_folder):
    tlogger_cmd = None
    for node_name in ['node_a', 'node_b']:
        tlogger = os.path.join(dc_work_space_folder, node_name,
                                   'cyc_host/cyc_bsc/cyc_tools/xio_packages/local_modules/traces/tlogger.py')
        if os.path.exists(tlogger):
            python_package_path = os.path.join(dc_work_space_folder, node_name, 'cyc_host/cyc_bsc/cyc_tools/pypackages')
            python_xio_package_path = os.path.join(dc_work_space_folder, node_name, 'cyc_host/cyc_bsc/cyc_tools/xio_packages')
            tlogger_cmd = r'export PYTHONPATH={0}:{1}:$PYTHONPATH;python2 {2}'.format(python_package_path,
                                                                                      python_xio_package_path,
                                                                                      tlogger)
            logger.debug("tlogger command: {0}".format(tlogger_cmd))
            break
    return tlogger_cmd


def dump_volatile_xtrace_to_text(dc_work_space_folder, trace_folder="bsc/dev/shm/traces", tool_output_folder=TOOL_OUTPUT_FOLDER):
    tlogger_cmd = get_tlogger_cmd(dc_work_space_folder)
    # DC collected by using essential profile doesn't contain xTraces
    if tlogger_cmd:
        for node_name in ['node_a', 'node_b']:
            if os.path.exists(os.path.join(dc_work_space_folder, node_name, trace_folder)):
                logger.info("Dumping volatile xTraces of %s" % node_name)
                trace_folders = glob.glob(os.path.join(dc_work_space_folder, node_name, trace_folder, r'tracedump*'))
                logger.debug(trace_folders)
                for folder in trace_folders:
                    trace_binary_files = os.path.join(folder, r'traces_*')
                    if glob.glob(trace_binary_files):
                        # path_to_tool_output_folder/node_a-tracedump_2019_11_13_07_15_06
                        trace_output_dir = "{0}-{1}".format(node_name, os.path.basename(folder))
                        trace_output_dir_full_path = os.path.join(dc_work_space_folder, tool_output_folder,
                                                                trace_output_dir)
                        cmd = "{0} dump --outdir {1} {2}".format(tlogger_cmd, trace_output_dir_full_path, trace_binary_files)
                        logger.debug("Dumping volatile xTraces {0} to text files into folder {1}...".format(trace_binary_files,
                                                                                                    trace_output_dir_full_path))
                        logger.debug(cmd)
                        _, stderr, ret_code = system(cmd, shell=True, show_progress=True)
                        if ret_code != 0:
                            logger.error("Error is encountered during dumping xTraces {0}".format(trace_binary_files))
                            logger.error(stderr)
                        # "traces_-1-ch0-tr0.txt".split('-ch')
                        # ['traces_-1', '0-tr0.txt']
                        csids = set([os.path.basename(file).split('-ch')[0].split("_")[-1] for file in glob.glob(os.path.join(trace_output_dir_full_path, "*.txt"))])
                        logger.debug(csids)
                        # Sort/Merge all the files into all.txt
                        all_merged_output = os.path.join(trace_output_dir_full_path, "all.txt")
                        logger.info("Sort and merge all of volatile xTraces of {0}".format(node_name))
                        cmd = "sort -o {0} {1}".format(all_merged_output, os.path.join(trace_output_dir_full_path, "traces*.txt"))
                        logger.debug(cmd)
                        _, stderr, ret_code = system(cmd, shell=True, show_progress=True)
                        # Sort/Merge by CSID
                        for csid in csids:
                            merged_output = os.path.join(trace_output_dir_full_path, "all_{0}.txt".format(csid))
                            cmd = "sort -o {0} {1}".format(merged_output, os.path.join(trace_output_dir_full_path, "traces_{0}-ch*.txt".format(csid)))
                            logger.info("Sort and merge volatile xTraces of {0} CSID {1}".format(node_name, csid))
                            logger.debug(cmd)
                            _, stderr, ret_code = system(cmd, shell=True, show_progress=False)
                    else:
                        logger.warning("No tracedump file is found under folder {0}".format(folder))
                logger.info("Finished dumping volatile xTraces of %s" % node_name)



@handle_exceptions
def get_dlogger_cmd(dc_work_space_folder):
    dlogger_cmd = None
    for node_name in ['node_a', 'node_b']:
        dlogger = os.path.join(dc_work_space_folder, node_name,
                                   'cyc_host/cyc_bsc/cyc_tools/xio_packages/local_modules/traces/dlogger.py')
        if os.path.exists(dlogger):
            python_package_path = os.path.join(dc_work_space_folder, node_name, 'cyc_host/cyc_bsc/cyc_tools/pypackages')
            python_xio_package_path = os.path.join(dc_work_space_folder, node_name, 'cyc_host/cyc_bsc/cyc_tools/xio_packages')
            dlogger_cmd = r'export PYTHONPATH={0}:{1}:$PYTHONPATH;python2 {2}'.format(python_package_path,
                                                                                      python_xio_package_path,
                                                                                      dlogger)
            logger.debug("dlogger command: {0}".format(dlogger_cmd))
            return dlogger_cmd
    return dlogger_cmd

def dump_persistent_xtrace_to_text(dc_work_space_folder, node_name, trace_folder="cyc_datalogs", tool_output_folder=TOOL_OUTPUT_FOLDER):
    # in case the dc_work_space_folder is "./xx_service_data"
    dc_work_space_folder = os.path.abspath(dc_work_space_folder)
    dlogger_cmd = get_dlogger_cmd(dc_work_space_folder)
    # DC collected by using essential profile doesn't contain persistent xTraces
    # it can take 25 minutes to dump the persist xTraces to text for one node.
    # the output text file for one node can be 7GB or so
    if dlogger_cmd:
        trace_folder = os.path.join(dc_work_space_folder, node_name, trace_folder)
        if os.path.exists(trace_folder):
            output_file = os.path.join(dc_work_space_folder, tool_output_folder,
                            "persistent_xtrace_{0}.txt".format(node_name))
            logger.debug(output_file)
            # is sorting necessary?
            # --bin_lib and --start are mutual exclusive
            # need 'cd dc_work_space_folder' as dlogger.py expects to run from the extracted DC folder
            cmd = r'cd {0};{1} dump --bin_lib {2} | /usr/bin/grep \] | /usr/bin/sort -k 3 > {3}'.format(dc_work_space_folder, dlogger_cmd, trace_folder, output_file)
            logger.info("Dumping persistent xTraces of %s to text file..." % node_name)
            logger.debug(cmd)
            _, stderr, ret_code = system(cmd, shell=True, show_progress=True)
            if ret_code != 0:
                logger.error("Error is encountered during dumping persistent xTraces")
                logger.error(stderr)
            else:
                logger.info("Finished dumping %s's persistent xTraces" % node_name)
            # logger.info("Dumping out persistent xTraces...")
            # with concurrent.futures.ThreadPoolExecutor(max_workers=2) as executor:
            #     futures = [executor.submit(_dump_persistent_xtrace_to_text, dc_work_space_folder, node_name, trace_folder, tool_output_folder) for node_name in ['node_a', 'node_b']]
            #     for future in concurrent.futures.as_completed(futures):
            #             print("dump_persistent_xtrace subtask finished successfully: " + future.result())