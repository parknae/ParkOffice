import os
import logging
import re
import time
from infra.utils import system, TOOL_NAME, TOOL_OUTPUT_FOLDER, TOOL_TMP_FOLDER, handle_exceptions, get_infra_folder_abs_path
import glob

# the parent logger will be the logger with name defined by TOOL_NAME
logger = logging.getLogger('.'.join([TOOL_NAME, __name__]))

def sort_by_time_then_seqence(line):
    return (line.split()[0], int(line.split()[1],16))


# assuming the sel log file is not large, we can read them all into memory so that it is easy to add timestamp for those entries without timestamp.
# The purpose of this function is to convert the timestamp into the format of "year-mon-dayThh:mm:ss" so that the sel log can be used to generate timeline together with journal log
@handle_exceptions
def process_sel_log(dc_folder, start_time_str=None, end_time_str=None):
    logger.info("Generatig ipmitool sel elist...")
    # use cyc_helpers/sel_line.pl to handle the lines without timestamp and convert the timestamp to "year-mon-dayThh:mm:ss" format.
    sel_line_processor = os.path.join(os.path.dirname(get_infra_folder_abs_path()), "scripts", "sel_line.pl")
    for node in ['node_a', 'node_b']:
        sel_log_files = []
        # TODO: need to check if there's any overlap between ipmi_sel.log and cyc_ipmitool_sel_elist.txt
        # If there isn't, then there's no need to worry about duplicate logs after merge two files.
        # TODO: TEE-304, needs to check why sel_line.pl cannot handle some lines in node_b/cyc_var/ipmi_sel.log correctly.
        for file_name in ['cyc_var/ipmi_sel.log', 'command_output/cyc_ipmitool_sel_elist.txt']:
            sel_log_file_path = os.path.join(dc_folder, node, file_name)
            if os.path.exists(sel_log_file_path):            
                tmp_file_path = os.path.join(dc_folder, TOOL_OUTPUT_FOLDER, TOOL_TMP_FOLDER, "%s_%s" %(node, file_name.split(os.sep)[-1]))
                cmd_str = 'cat %s | %s > %s' %(sel_log_file_path, sel_line_processor, tmp_file_path)
                logger.debug(cmd_str)
                ret = os.system(cmd_str)
                if ret != 0:
                    logger.error("Error happened during normalizing %s" % file_name)
                else:
                    sel_log_files.append(tmp_file_path)
        output_file_path = os.path.join(dc_folder, TOOL_OUTPUT_FOLDER,"ipmitool_sel_elist_%s.txt" % node)
        if len(sel_log_files) == 0:
            logger.warning("No sel log file is found for %s" % node)
        elif len(sel_log_files) == 1:
            # use cat to copy the conent to TOOL_OUTPUT_FOLDER
            cmd_str = "cat %s > %s" %(sel_log_files[0], output_file_path)
            logger.debug(cmd_str)
            ret = os.system(cmd_str)
            if ret != 0:
                logger.error("Error happened during normalizing %s" % file_name)
        else:
            lines = []
            for file_path in sel_log_files:
                # assuming the sel log file is not large
                with open(file_path, 'r') as f:
                    lines.extend(f.readlines())
            # remove duplicate lines
            lines = list(set(lines))
            # sort by the time, then sequence number of the sel log
            lines.sort(key=sort_by_time_then_seqence)
            with open(output_file_path, 'w+') as f:
                f.writelines(lines)
    logger.info("Finished generatig ipmitool sel elist")


# find .  -name "*ipmi*_sel*"
# ./node_b/cyc_var/ipmi_sel_raw.bin
# ./node_b/cyc_var/cyc_bmcsel/ipmi_sel_raw.bin-20200602-1591123858
# ./node_b/cyc_var/cyc_bmcsel/ipmi_sel.log-20200602-1591123858
# ./node_b/cyc_var/ipmi_sel.log   <---------------------- have same content with /ipmi_sel.log-20200602-1591123858
# ./node_b/command_output/cyc_ipmitool_sel_elist.txt   <----------- only have the latest entries(10 lines also)
# ./node_a/command_output/cyc_ipmitool_sel_elist.txt
#----------------------------------------------
# raw file:
#----------------------------------------------
# 1 | 04/08/2020 | 18:15:59 | Event Logging Disabled |  Event_Log | Log area reset/cleared | Asserted
# 2 | 04/08/2020 | 18:17:52 | SSP Power/Reset Action |  Power/Reset Action | Sleep State Reset Detected | Asserted
#     ELOG(13) RESET EVENT
# 3 | 04/08/2020 | 18:17:53 | BIOS Progress |  BIOS Progress/Event | SMBus Initialization | Asserted
#     ELOG(155) Reset Causes:  PRSTS         = 0x20020104  PM_STS        = 0x80800000  GBLRST_CAUSE0 = 0x0  GBLRST_CAUSE1 = 0x0  HPR_CAUSE0    = 0x2  GIC Register  = 0x0
# 4 | 04/08/2020 | 18:17:59 | SSP Power/Reset Action |  Power/Reset Action | ICH/PCH Reset Detected | Asserted
#     ELOG(13) RESET EVENT
# 5 | 04/08/2020 | 18:18:01 | BIOS Progress |  BIOS Progress/Event | SMBus Initialization | Asserted
#     ELOG(155) Reset Causes:  PRSTS         = 0x20020104  PM_STS        = 0x80800000  GBLRST_CAUSE0 = 0x0  GBLRST_CAUSE1 = 0x0  HPR_CAUSE0    = 0x2  GIC Register  = 0x0
# 6 |  Pre-Init  |0000000011| GEM Boot Progress |  BMC Boot Progress | GEM Initialization Started | Asserted
# 7 |  Pre-Init  |0000000018| Peer SP Status |  Peer_Status | Peer Inserted | Asserted
# 8 |  Pre-Init  |0000000019| SLIC Status |  SLIC0_Status | Inserted | Asserted
# 9 |  Pre-Init  |0000000019| Power Supply Status |  PS0_Status | Inserted | Asserted
# a |  Pre-Init  |0000000019| Power Supply Status |  PS1_Status | Inserted | Asserted
# b |  Pre-Init  |0000000019| Battery Status Over I2C |  Battery0_I2C | Inserted | Asserted
# c |  Pre-Init  |0000000019| Battery Status Over I2C |  Battery1_I2C | Inserted | Asserted
# d |  Pre-Init  |0000000019| SLIC Status |  Drive_IO0_Status | Inserted | Asserted
# e |  Pre-Init  |0000000019| SLIC Status |  Exp_Bay0_Status | Inserted | Asserted
# f |  Pre-Init  |0000000020| Power/Reset Action |  Power/Reset Action | Power On Host | Asserted
#     ELOG(30) POWER_CAUSE_DPP_AC_ON_ALWAYS
# 10 |  Pre-Init  |0000000021| SLIC Status |  MEZZ0_Status | Inserted | Asserted
# 11 |  Pre-Init  |0000000021| Fan |  Fan_Redundancy | Fully Redundant | Asserted
# 12 |  Pre-Init  |0000000021| Power Supply |  PS_Redundancy | Fully Redundant | Asserted
# 13 | 04/08/2020 | 17:18:47 | Fan Status |  Fan2_Status | Inserted | Asserted
# 14 | 04/08/2020 | 17:18:47 | Fan Status |  Fan3_Status | Inserted | Asserted
#----------------------------------------------
# After:  (there is one problem, how come the original log time stamp is out of order??)
# It is not safe to sort by event sequence number.
#----------------------------------------------
# 2020-04-08T18:15:59.999999    1 | 04/08/2020 | 18:15:59 | Event Logging Disabled |  Event_Log | Log area reset/cleared | Asserted
# 2020-04-08T18:17:52.999999    2 | 04/08/2020 | 18:17:52 | SSP Power/Reset Action |  Power/Reset Action | Sleep State Reset Detected | Asserted       ELOG(13) RESET EVENT
# 2020-04-08T18:17:53.999999    3 | 04/08/2020 | 18:17:53 | BIOS Progress |  BIOS Progress/Event | SMBus Initialization | Asserted       ELOG(155) Reset Causes:  PRSTS         = 0x20020104  PM_STS        = 0x80800000  GBLRST_CAUSE0 = 0x0  GBLRST_CAUSE1 = 0x0  HPR_CAUSE0    = 0x2  GIC Register  = 0x0
# 2020-04-08T18:17:59.999999    4 | 04/08/2020 | 18:17:59 | SSP Power/Reset Action |  Power/Reset Action | ICH/PCH Reset Detected | Asserted       ELOG(13) RESET EVENT
# 2020-04-08T18:18:01.999999    5 | 04/08/2020 | 18:18:01 | BIOS Progress |  BIOS Progress/Event | SMBus Initialization | Asserted       ELOG(155) Reset Causes:  PRSTS         = 0x20020104  PM_STS        = 0x80800000  GBLRST_CAUSE0 = 0x0  GBLRST_CAUSE1 = 0x0  HPR_CAUSE0    = 0x2  GIC Register  = 0x0
# 2020-04-08T17:18:40.999999    6 |  Pre-Init  |0000000011| GEM Boot Progress |  BMC Boot Progress | GEM Initialization Started | Asserted
# 2020-04-08T17:18:40.999999    7 |  Pre-Init  |0000000018| Peer SP Status |  Peer_Status | Peer Inserted | Asserted
# 2020-04-08T17:18:40.999999    8 |  Pre-Init  |0000000019| SLIC Status |  SLIC0_Status | Inserted | Asserted
# 2020-04-08T17:18:40.999999    9 |  Pre-Init  |0000000019| Power Supply Status |  PS0_Status | Inserted | Asserted
# 2020-04-08T17:18:40.999999    a |  Pre-Init  |0000000019| Power Supply Status |  PS1_Status | Inserted | Asserted
# 2020-04-08T17:18:40.999999    b |  Pre-Init  |0000000019| Battery Status Over I2C |  Battery0_I2C | Inserted | Asserted
# 2020-04-08T17:18:40.999999    c |  Pre-Init  |0000000019| Battery Status Over I2C |  Battery1_I2C | Inserted | Asserted
# 2020-04-08T17:18:40.999999    d |  Pre-Init  |0000000019| SLIC Status |  Drive_IO0_Status | Inserted | Asserted
# 2020-04-08T17:18:40.999999    e |  Pre-Init  |0000000019| SLIC Status |  Exp_Bay0_Status | Inserted | Asserted
# 2020-04-08T17:18:40.999999    f |  Pre-Init  |0000000020| Power/Reset Action |  Power/Reset Action | Power On Host | Asserted       ELOG(30) POWER_CAUSE_DPP_AC_ON_ALWAYS
# 2020-04-08T17:18:40.999999   10 |  Pre-Init  |0000000021| SLIC Status |  MEZZ0_Status | Inserted | Asserted
# 2020-04-08T17:18:40.999999   11 |  Pre-Init  |0000000021| Fan |  Fan_Redundancy | Fully Redundant | Asserted
# 2020-04-08T17:18:40.999999   12 |  Pre-Init  |0000000021| Power Supply |  PS_Redundancy | Fully Redundant | Asserted
# 2020-04-08T17:18:47.999999   13 | 04/08/2020 | 17:18:47 | Fan Status |  Fan2_Status | Inserted | Asserted
# 2020-04-08T17:18:47.999999   14 | 04/08/2020 | 17:18:47 | Fan Status |  Fan3_Status | Inserted | Asserted

# 1 | 06/02/2020 | 18:50:53 | Event Logging Disabled |  Event_Log | Log area reset/cleared | Asserted
# 2 | 06/02/2020 | 19:04:00 | Power/Reset Action |  Power/Reset Action | Reset Action | Asserted | BMC No Reset Host Cold reset
#     ELOG(34) POWER_CAUSE_IPMI_CHASSIS_CONTROL
# 3 | 06/02/2020 | 19:04:05 | SSP Power/Reset Action |  Power/Reset Action | Cold Power Up Detected | Asserted