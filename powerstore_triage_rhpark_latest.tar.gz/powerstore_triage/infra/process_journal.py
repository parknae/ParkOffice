from __future__ import print_function
import os
import logging
import re
# from systemd import journal
import time
from infra.utils import system, TOOL_NAME, TOOL_OUTPUT_FOLDER, get_compressed_file_names, handle_exceptions,\
    decompress_journal_files_in_parallel, datetime_str_to_journalctl_datetime_str,\
    datetime_str_to_utc_datetime_str, datetime_str_to_timestamp, get_infra_folder_abs_path, datetime_str_to_utc_timestamp,\
    JOURNAL_A_TEXT, JOURNAL_B_TEXT, get_timeframe_of_file
# from joblib import Parallel, delayed
import glob
import shutil
import concurrent.futures
import threading
from pathlib import Path

#------------------------------------------------------------------------#
# Copyright (C) 2020 Dell Inc. and its subsidiaries. All Rights reserved #
#------------------------------------------------------------------------#
#--------------------------------------#
# Henry.An@dell.com                    #
# NGMR Engineering Technical Services  #
#--------------------------------------#

# the parent logger will be the logger with name defined by TOOL_NAME
logger = logging.getLogger('.'.join([TOOL_NAME, __name__]))

# journal folder directory
#     node_a/var/log/journal/d38f4e10a9f3459184950d027bcc6c83
# archived journals(compressed) folder:
#     cyc_cfs/journald/node_a
#     if no archived journals, journald folder may not exist in cyc_cfs folder
JOURNAL_DIR = os.path.join('var', 'log', 'journal')


def get_node_non_archived_journal_folder(dc_folder, node_name):
    # node_name can only be "node_a" or "node_b"
    j_folder = os.path.join(dc_folder, node_name, JOURNAL_DIR)
    if os.path.exists(j_folder):
        folder_names = os.listdir(j_folder)
        # folders in node_a/var/log/journal/ are like the following
        # d38f4e10a9f3459184950d027bcc6c83
        for folder_name in folder_names:
            full_path = os.path.join(j_folder, folder_name)
            if os.path.isdir(full_path) and re.match(r'\w{20,}', folder_name):
                # print("get_node_non_archived_journal_folder(): Journal folder: {0}".format(full_path))
                non_archived_journal_folder = full_path
    else:
        non_archived_journal_folder = ''
    return non_archived_journal_folder


def get_node_archived_journal_folder(dc_folder, node_name):
    # node_name can only be "node_a" or "node_b"
    j_folder = os.path.join(dc_folder, 'cyc_cfs', 'journald', node_name)
    if os.path.exists(j_folder):
        archived_journal_folder = j_folder
    else:
        archived_journal_folder = ''
    return archived_journal_folder


def get_archived_journal_folder_dict(dc_folder):
    archived_journal_folder_dict = {}
    for node_name in ['node_a', 'node_b']:
        node_archived_journal_folder = get_node_archived_journal_folder(dc_folder, node_name)
        if node_archived_journal_folder != '':
            archived_journal_folder_dict[node_name] = node_archived_journal_folder
    logger.debug(archived_journal_folder_dict)
    return archived_journal_folder_dict


def decompress_journals_in_parallel(archived_journal_folder_dict):
    """
    Decompress the compressed journal files(*.journal.gz at cfs folder) in place
    The journal files under node(a|b)/var/log/journal/xxx/ are not compressed files.
    :param journal_folder_dict:
    :return:
    """
    compressed_journal_files = []
    for node in archived_journal_folder_dict:
        node_compressed_journal_files = get_compressed_file_names(archived_journal_folder_dict[node])
        compressed_journal_files.extend(node_compressed_journal_files)
        logger.debug("Compressed journal files on {0} are: {1}".format(node, node_compressed_journal_files))
    if compressed_journal_files:
        logger.info("Decompressing journals in parallel...")
        decompress_journal_files_in_parallel(compressed_journal_files)
    else:
        logger.info("No compressed journal files (the compressed journal files could have been already decompressed previously)")

@handle_exceptions
def show_timeframe_of_journals(journal_cmd, dc_folder, fp):
    # cyclone_cyc-D1013_2MHYMD2_2018-11-21_18-17-20_service-data/node_a/var/log/journal/69a13020898146c68fed5b58efde59a6/system@06436b04aeb44437b8238486641105f5-00000000008b25c5-00057b2f4d2bcd75.journal
    # journal name could end with ~, like "system@00057ca549b81052-23246fd378a12344.journal~"
    file_name_pattern = re.compile(r"^File Path.*[\\/](.*\.journal.?)$")
    # Head Realtime Timestamp: Wed 2018-11-21 12:22:54 EST
    # Tail Realtime Timestamp: Wed 2018-11-21 12:51:31 EST
    time_str_pattern = re.compile(r"^\w+ Realtime Timestamp: \w+ (\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}) \w+")
    for node_name in ['node_a', 'node_b']:
        journals_dict = {}
        journal_files = []
        non_archived_journal_folder = get_node_non_archived_journal_folder(dc_folder, node_name)
        if non_archived_journal_folder != '':
            journal_files.extend(glob.glob(os.path.join(non_archived_journal_folder, "*.journal")))
            journal_files.extend(glob.glob(os.path.join(non_archived_journal_folder, "*.journal~")))

        archived_journal_folder = get_node_archived_journal_folder(dc_folder, node_name)
        if archived_journal_folder != '':
            journal_files.extend(glob.glob(os.path.join(archived_journal_folder, "*.journal")))
            journal_files.extend(glob.glob(os.path.join(archived_journal_folder, "*.journal~")))

        logger.debug("Getting header information from {0} journal files...".format(node_name))
        # if one file is corrupt, journalctl --header --file=journal_folder/*/*.journal* will returns with error only
        # thus, need to check the journal file one by one
        for journal_file in journal_files:
            cmd = '/bin/sh -c ' + r"'{0} --header --file={1}'".format(journal_cmd, journal_file)
            logger.debug(cmd)
            stdout, stderr, ret_code = system(cmd)
            if ret_code != 0:
                logger.warning("Error encountered while trying to read the header of file {0}".format(journal_file))
                logger.error(stderr)
                # rename the file so that the later journalctl command will not process it
                new_name = journal_file[:journal_file.find(".journal")] + ".corrupt"
                os.rename(journal_file, new_name)
                logger.info("rename {0} to {1} as it is suspected to be a corrupt file".format(journal_file, new_name))
            else:
                for line in stdout.strip().split(os.linesep):
                    if line.startswith("File Path"):
                        m = re.search(file_name_pattern, line)
                        if m:
                            file_name = m.group(1)
                            journals_dict.setdefault(file_name, {})['name'] = file_name
                    elif line.startswith("Head Realtime Timestamp"):
                        m = re.search(time_str_pattern, line)
                        if m:
                            journals_dict[file_name]['head_time_str_in_utc'] = datetime_str_to_utc_datetime_str(m.group(1))
                    elif line.startswith("Tail Realtime Timestamp"):
                        m = re.search(time_str_pattern, line)
                        if m:
                            journals_dict[file_name]['tail_time_str_in_utc'] = datetime_str_to_utc_datetime_str(m.group(1))

        if journals_dict:
            # print on the screen even if the journal_timeframe_coverage.txt cannot be created somehow.
            logger.info("=========== {0} journal files ===========".format(node_name))
            fp.write("=========== {0} journal files ===========\n".format(node_name))
            logger.info("journal folder: {0}".format(non_archived_journal_folder))
            fp.write("journal folder: {0}\n".format(non_archived_journal_folder))
            logger.info("archived journal folder: {0}".format(archived_journal_folder if
                                                              archived_journal_folder != '' else "N/A"))
            fp.write("archived journal folder: {0}\n".format(archived_journal_folder if
                                                            archived_journal_folder != '' else "N/A"))
            #logger.info("    Head Timestamp(UTC) Tail Timestamp(UTC) File Name")
            fp.write("    Head Timestamp(UTC) Tail Timestamp(UTC) File Name\n")
            for value in sorted(journals_dict.values(), key=lambda v: (datetime_str_to_timestamp(v['head_time_str_in_utc']))):
                #logger.info("    {0} {1} {2}".format(value['head_time_str_in_utc'], value['tail_time_str_in_utc'], value['name']))
                fp.write("    {0} {1} {2}\n".format(value['head_time_str_in_utc'], value['tail_time_str_in_utc'], value['name']))
        else:
            logger.warning("Didn't find any journals from {0}".format(node_name))


def generate_journal_file_list(dc_folder, node_name):
    files = list()
    non_archived_journal_folder = get_node_non_archived_journal_folder(dc_folder, node_name)
    if non_archived_journal_folder != '':
        # glob,  files starting with . won't be matched by default
        files.extend([f for f in glob.glob(os.path.join(non_archived_journal_folder, '*.journal')) if os.path.isfile(f)])
        files.extend([f for f in glob.glob(os.path.join(non_archived_journal_folder, '*.journal~')) if os.path.isfile(f)])
    archived_journal_folder = get_node_archived_journal_folder(dc_folder, node_name)
    if archived_journal_folder != '':
        files.extend([f for f in glob.glob(os.path.join(archived_journal_folder, '*.journal')) if os.path.isfile(f)])
        files.extend([f for f in glob.glob(os.path.join(archived_journal_folder, '*.journal~')) if os.path.isfile(f)])
    return files


def generate_journal_file_glob_option(dc_folder, node_name):
    non_archived_journal_folder = get_node_non_archived_journal_folder(dc_folder, node_name)
    if non_archived_journal_folder != '':

        non_archived_journal_file_glob_option =" --directory=" + non_archived_journal_folder
        # # exlcude the *.journal.jsonlog files generated by other tools
        # non_archived_journal_file_glob_option = " --file=" + os.path.join(non_archived_journal_folder, "*.journal") + " --file=" + os.path.join(non_archived_journal_folder, "*.journal~")
        journal_file_glob_option = non_archived_journal_file_glob_option
    else:
        journal_file_glob_option = ''
    archived_journal_folder = get_node_archived_journal_folder(dc_folder, node_name)
    if archived_journal_folder != '':
        journal_file_glob_option = " --directory=" + archived_journal_folder + non_archived_journal_file_glob_option
        # journal_file_glob_option = " --file=" + os.path.join(archived_journal_folder, "*.journal")  + " --file=" + os.path.join(archived_journal_folder, "*.journal~") + non_archived_journal_file_glob_option
    return journal_file_glob_option


def generate_journal_time_option(start_time_str=None, end_time_str=None):
    if end_time_str is None:
        end_time_option = ''
    else:
        end_time_str = datetime_str_to_journalctl_datetime_str(end_time_str)
        end_time_option = r' --until="{0}"'.format(end_time_str)

    if start_time_str is None:
        start_time_option = ''
    else:
        start_time_str = datetime_str_to_journalctl_datetime_str(start_time_str)
        start_time_option = r' --since="{0}"'.format(start_time_str)
    return start_time_option, end_time_option


def convert_timestamp_to_utc_str(s):
    # datetime_obj = datetime.fromtimestamp(int(s) / 1000000, timezone.utc)
    # return datetime_obj.strftime("%Y-%m-%d %H:%M:%S.%f")
    # only a little bit faster than datetime(8 seconds faster when parsing two journal files(took 2m 43s))
    return time.strftime("%Y-%m-%d %H:%M:%S", time.gmtime(int(s) // 1000000)) + "." + "{0:06d}".format((int(s) % 1000000))


def get_journactl_cmd_pre(dc_folder, start_time_option, end_time_option, node_name="both_node"):
    """This will be used by log filters"""
    journal_cmd = get_journal_cmd(dc_folder)
    if node_name == "both_node":
        journal_file_glob_option_node_a = generate_journal_file_glob_option(dc_folder, "node_a")
        journal_file_glob_option_node_b = generate_journal_file_glob_option(dc_folder, "node_b")
        journal_file_glob_option = journal_file_glob_option_node_a + journal_file_glob_option_node_b
    else:
        journal_file_glob_option = generate_journal_file_glob_option(dc_folder, node_name)
    journactl_cmd_prefix = r"{0} {1} --utc --no-pager {2} {3} ".format(journal_cmd, journal_file_glob_option, start_time_option, end_time_option)
    return journactl_cmd_prefix

# def export_journals_python(dc_folder, tool_output_folder, node_name, start_time_str=None):
#     # this function is 25% faster than the way of doing "journalctl ... | jq ..."
#     output_file_name = 'journal_{0}.txt'.format(node_name[-1])
#     output_file_path = os.path.join(dc_folder, tool_output_folder, output_file_name)
#     file_list = generate_journal_file_list(dc_folder, node_name)
#     node_identifier = node_name.split("_")[-1].upper()
#     severity = {"0": "crit", "1": "crit", "2": "crit", "3": "err", "4": "warn", "5": "noti", "6": "info", "7": "trace"}
#     # systemd-python doesn't see to have a equivalent like journactl --until
#     print("    Processing {0} journal logs...".format(node_name))
#     with journal.Reader(files=file_list, converters={'_SOURCE_REALTIME_TIMESTAMP': convert_timestamp_to_utc_str, '__REALTIME_TIMESTAMP': (lambda x: x)}) as j:
#         if start_time_str is not None:
#             timestamp = datetime_str_to_utc_timestamp(start_time_str)
#             j.seek_realtime(timestamp)
#         with open(output_file_path, "w+") as f:
#             for entry in j:
#                 if '_SOURCE_REALTIME_TIMESTAMP' in entry:
#                     time_str = entry['_SOURCE_REALTIME_TIMESTAMP']
#                 else:
#                     time_str = convert_timestamp_to_utc_str(entry['__REALTIME_TIMESTAMP'])
#                 if 'PRIORITY' not in entry:
#                     entry['PRIORITY'] = 6
#                 if '_PID' in entry:
#                     f.write("{0} {1} {2} {3} {4}[{5}]: {6}\n".format(severity[str(entry['PRIORITY'])], node_identifier,
#                                                                  time_str,
#                                                                  entry['_HOSTNAME'], entry['SYSLOG_IDENTIFIER'], entry['_PID'],
#                                                                  entry['MESSAGE'].strip()))
#                 else:
#                     f.write("{0} {1} {2} {3} {4}: {5}\n".format(severity[str(entry['PRIORITY'])], node_identifier,
#                                                             time_str,
#                                                             entry['_HOSTNAME'], entry['SYSLOG_IDENTIFIER'],
#                                                             entry['MESSAGE'].strip()))
#     print("    Finish processing {0} journal logs...".format(node_name))


def export_journals_journactl(journal_cmd, dc_folder, node_name, start_time_str=None, end_time_str=None,
                              journalctl_option_str='', output_format='text', extra_file_name_str=None):
    start_time_option, end_time_option = generate_journal_time_option(start_time_str, end_time_str)
    if node_name == "both_node":
        journal_file_glob_option_node_a = generate_journal_file_glob_option(dc_folder, "node_a")
        journal_file_glob_option_node_b = generate_journal_file_glob_option(dc_folder, "node_b")
        journal_file_glob_option = journal_file_glob_option_node_a + journal_file_glob_option_node_b
        if '-p 3' in journalctl_option_str:
            output_file_prefix = 'journal_crit_err_a_b'
        else:
            output_file_prefix = 'journal_a_b'
    else:
        journal_file_glob_option = generate_journal_file_glob_option(dc_folder, node_name)
        if '-p 3' in journalctl_option_str:
            output_file_prefix = 'journal_crit_err_{0}'.format(node_name[-1])
        else:
            output_file_prefix = 'journal_{0}'.format(node_name[-1])
    if extra_file_name_str:
        output_file_prefix = output_file_prefix + "_" + extra_file_name_str
    # journal name could end with ~, like "system@00057ca549b81052-23246fd378a12344.journal~"
    # /bin/sh -c must be used here as we are redirecting the output to a file
    # journalctl --file=GLOG, if a specific file(can be a symbolic link) is specified, the file name extension must be .journal or .journal~,
    # otherwise, journalctl will return with error "Failed to open files: Invalid argument".
    if node_name == "both_node":
        node_identifier = " "
    else:
        node_identifier = " {0} ".format(node_name.split("_")[-1].upper())  # " A " or " B "

    if journal_file_glob_option != '':
        logger.info("    Processing {0} journal logs...".format(node_name))
        if output_format == 'text_and_json':
            output_file_text = os.path.join(dc_folder, TOOL_OUTPUT_FOLDER, '{0}.txt'.format(output_file_prefix))
            output_file_json = os.path.join(dc_folder, TOOL_OUTPUT_FOLDER, '{0}.json'.format(output_file_prefix))
            # export to json is relatively slow due to output file size, so we can simply use jq to parse the json at the same time without increasing the overall time.
            cmd = r'{0} {1} {2} --utc {3} {4} --no-pager -m -o json|'.format(journal_cmd, journal_file_glob_option, journalctl_option_str, start_time_option, end_time_option) \
                  + r'tee {0}|'.format(output_file_json) \
                  + r'jq -j --argjson level ' + r"'" + r'{"0":"crit","1":"crit","2":"crit","3":"err","4":"warn","5":"noti","6":"info","7":"trace"}' + r"' " \
                  + r"'" + r'if .PRIORITY then $level[.PRIORITY] else "noti" end,"{0}",'.format(node_identifier) \
                  + r'if ._SOURCE_REALTIME_TIMESTAMP then ((._SOURCE_REALTIME_TIMESTAMP | tonumber) / 1000000|strftime("%Y-%m-%d %H:%M:%S")) else ((.__REALTIME_TIMESTAMP | tonumber) / 1000000|strftime("%Y-%m-%d %H:%M:%S")) end,".",if ._SOURCE_REALTIME_TIMESTAMP then (._SOURCE_REALTIME_TIMESTAMP |capture("(?<microsec>[0-9]{6}$)")|.microsec) else (.__REALTIME_TIMESTAMP |capture("(?<microsec>[0-9]{6}$)")|.microsec) end," ",._HOSTNAME," ",.SYSLOG_IDENTIFIER,if ._PID then "[",._PID,"]" else "" end,": ",(.MESSAGE|rtrimstr("\n")),"\n"' \
                  + r"'" + r'>{0}'.format(output_file_text)
            # PRIORITY A|B _SOURCE_REALTIME_TIMESTAMP|__REALTIME_TIMESTAMP _HOSTNAME SYSLOG_IDENTIFIER[_PID]: MESSAGE
            # the logging logger in the func passed to Parallel will not work due to Parallel is multiple processes
            logger.debug("    {0}".format(cmd))
            _, stderr, ret_code = system(cmd, shell=True)
            if ret_code != 0:
                logger.error("    Error is encountered during processing journal logs")
                logger.error(stderr)
        elif output_format == 'text':
            output_file = os.path.join(dc_folder, TOOL_OUTPUT_FOLDER, '{0}.txt'.format(output_file_prefix))
            cmd = '/bin/sh -c ' + r"'{0} {1} {2} --utc {3} {4} --no-pager -m -o short-iso-precise >{5}'".format(journal_cmd, journal_file_glob_option, journalctl_option_str,
                                                                                              start_time_option, end_time_option, output_file)
            logger.debug("    {0}".format(cmd))
            _, stderr, ret_code = system(cmd, shell=True)
            # _, stderr, ret_code = system(cmd, shell=True, show_progress=True)
            if ret_code != 0:
                logger.error("    Error is encountered during processing journal logs")
                logger.error(stderr)
        elif output_format == 'json':
            output_file = os.path.join(dc_folder, TOOL_OUTPUT_FOLDER, '{0}.json'.format(output_file_prefix))
            cmd = '/bin/sh -c ' + r"'{0} {1} {2} --utc {3} {4} --no-pager -m -o {5}>{6}'".format(journal_cmd, journal_file_glob_option, journalctl_option_str,
                                                                                              start_time_option, end_time_option, output_format, output_file)
            # the logging logger in the func passed to Parallel will not work due to Parallel is multiple processes
            logger.debug("    {0}".format(cmd))
            _, stderr, ret_code = system(cmd)
            if ret_code != 0:
                logger.error(stderr)
        logger.info("    Finished processing {0} journal logs...".format(node_name))
    else:
        logger.warning("No journal file from {0} is found!".format(node_name))


def get_coreos_path(dc_folder):
    for node_name in ['node_a', 'node_b']:
        coreos_path = os.path.join(dc_folder, node_name, 'core_os')
        if os.path.exists(os.path.join(coreos_path, 'usr/bin')):
            return coreos_path
    return None


def get_journal_cmd(dc_folder):
    exist_journalctl = False
    coreos_path = get_coreos_path(dc_folder)
    if coreos_path:
        return '{0}/lib64/ld-linux-x86-64.so.2 --library-path {1}/lib64:{2}/usr/lib/systemd {3}/usr/bin/journalctl'.format(coreos_path, coreos_path, coreos_path, coreos_path)
    else:
        for node_name in ['node_a', 'node_b']:
            journalctl_path = os.path.join(dc_folder, node_name, 'journalctl')
            if os.path.exists(journalctl_path):
                return '{0}/ld-linux-x86-64.so.2 --library-path {1} {2}/journalctl'.format(journalctl_path, journalctl_path, journalctl_path)
    if not exist_journalctl:
        # fall back to use the journalctl in the "bin/journalctl" folder of powerstore triage 
        journalctl_path = os.path.join(os.path.dirname(get_infra_folder_abs_path()), "bin", "journalctl")
        journalctl_cmd = '{0}/ld-linux-x86-64.so.2 --library-path {1} {2}/journalctl'.format(journalctl_path, journalctl_path, journalctl_path)
        # logger.info(journalctl_cmd)
        return journalctl_cmd


def make_links_to_journals_in_powerstore_triage_folder(dc_folder):
    os.mkdir(os.path.join(dc_folder, TOOL_OUTPUT_FOLDER, 'journal'))
    j_link_folder_for_all = os.path.join(os.path.join(dc_folder, TOOL_OUTPUT_FOLDER, 'journal', 'nodes_all'))
    os.mkdir(j_link_folder_for_all)
    for node_name in ['node_a', 'node_b']:
        journal_files = generate_journal_file_list(dc_folder, node_name)
        if journal_files:
            j_link_folder_for_node = os.path.join(dc_folder, TOOL_OUTPUT_FOLDER, 'journal', node_name)
            os.mkdir(j_link_folder_for_node)
            for target_file in journal_files:
                link_name = os.path.join(j_link_folder_for_node, os.path.basename(target_file))
                system('ln -s {0} {1}'.format(target_file, link_name), shell=True)
                link_name_for_nodes_all =  os.path.join(j_link_folder_for_all, node_name + "_" + os.path.basename(target_file))
                system('ln -s {0} {1}'.format(target_file, link_name_for_nodes_all), shell=True)

@handle_exceptions
def process_journals(dc_folder, start_time_str=None, end_time_str=None, output_format="text"):
    """
    process the journals from node_a and node_b in parallel
    """
    archived_journal_folder_dict = get_archived_journal_folder_dict(dc_folder)
    logger.info("Decompressing compressed journal files...")
    decompress_journals_in_parallel(archived_journal_folder_dict)
    make_links_to_journals_in_powerstore_triage_folder(dc_folder)
    journal_cmd = get_journal_cmd(dc_folder)
    logger.debug("journalctl command is: {0}".format(journal_cmd))
    with open(os.path.join(dc_folder, TOOL_OUTPUT_FOLDER, "journal_timeframe_coverage.txt"), 'w+') as f:
        show_timeframe_of_journals(journal_cmd, dc_folder, f)
    # logger.info("Exporting journals in the formatting of text and json, this can take several minutes...")
    # # the logging logger in the func passed to Parallel will not work, probably due to Parallel is multiple processes
    # ret = Parallel(n_jobs=-1, verbose=0)(delayed(export_journals)(journal_cmd, dc_folder,tool_output_folder, node_name, start_time_str, end_time_str, output_format='text_and_json')
    #                                      for node_name in ['node_a', 'node_b'])
    logger.info("Exporting journals in the formatting of text, this can take several minutes...")
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as executor:
        futures = [executor.submit(export_journals_journactl, journal_cmd, dc_folder, node_name, start_time_str, end_time_str, output_format='text') for node_name in ['node_a', 'node_b']]
        for future in concurrent.futures.as_completed(futures):
            logger.debug(future.done())
    # process_journal_threads = list()
    # for node_name in  ['node_a', 'node_b']:
    #     process_journal_thread = threading.Thread(target=export_journals_journactl, args=(journal_cmd, dc_folder, node_name, start_time_str, end_time_str,))
    #     process_journal_threads.append(process_journal_thread)
    #     process_journal_thread.start()
    # for process_journal_thread in process_journal_threads:
    #     process_journal_thread.join()
    # logger.info("Exporting critical and error logs in the formatting of text ...")
    # export_journals_journactl(journal_cmd, dc_folder, "both_node", start_time_str, end_time_str, '-p 3', output_format='text')

    # logger.info("Exporting xtremapp related logs in the formatting of text...")
    # export_journals(journal_cmd, dc_folder, tool_output_folder, "both_node", start_time_str, end_time_str,
    #                 '_EXE=/cyc_bsc/bin/xtremapp', output_format='text', extra_file_name_str="xtremapp")

@handle_exceptions
def export_error_and_critical_logs(dc_folder, start_time_str=None, end_time_str=None, output_format="text"):
    journal_cmd = get_journal_cmd(dc_folder)
    logger.info("Exporting critical and error logs in the formatting of text ...")
    export_journals_journactl(journal_cmd, dc_folder, "both_node", start_time_str, end_time_str, '-p 3', output_format='text')


@handle_exceptions
def split_exported_journal_logs(dc_folder):
    logger.info("Splitting exported journal files...")
    tool_output_folder = os.path.join(dc_folder, TOOL_OUTPUT_FOLDER)
    dst_file_folder = os.path.join(tool_output_folder, 'splitted_journal_logs')
    if not os.path.exists(dst_file_folder):
        os.mkdir(dst_file_folder)
    for journal_file in ['journal_a.txt', 'journal_b.txt']:
        file_prefix = journal_file.split('.')[0] + '_'
        cmd = '/bin/sh -c ' + r"'cd {0};split -l 400000 -d {1} {2}'".format(tool_output_folder, journal_file, file_prefix)
        logger.info("splitting {0}...".format(journal_file))
        logger.debug(cmd)
        _, stderr, ret_code = system(cmd)
        if ret_code != 0:
            logger.error(stderr)
        else:
            splitted_files = glob.glob(os.path.join(tool_output_folder, file_prefix + "*"))
            for splitted_file in splitted_files:
                start_time, end_time = get_timeframe_of_file(splitted_file)
                dst_file_name = "_".join(os.path.basename(splitted_file).split("_")[:2]) + "_{0}_{1}.txt".format(start_time, end_time)
                dst_file_full_path = os.path.join(dst_file_folder, dst_file_name)
                shutil.move(splitted_file, dst_file_full_path)
            logger.info("Finished splitting {0}".format(journal_file))

@handle_exceptions
def parse_datapath_dependency_sequencer_log(dc_folder):
    infra_path = get_infra_folder_abs_path()
    depseq_log_parser = os.path.join(os.path.dirname(infra_path), 'scripts', 'depseq_log_parser.py')
    logger.info("Parsing DataPath DependencySequencer log from journal logs...")
    tool_output_folder = os.path.join(dc_folder, TOOL_OUTPUT_FOLDER)
    for journal_file in ['journal_a.txt', 'journal_b.txt']:
        node = journal_file.split('.')[0].split('_')[-1]
        output_file_name = "depseq_log_node_{0}.txt".format(node)
        cmd = '/bin/sh -c ' + r"'cd {0};python3 {1} {2} > {3} 2>&1'".format(tool_output_folder, depseq_log_parser, journal_file, output_file_name)
        logger.debug(cmd)
        _, stderr, ret_code = system(cmd)
        if ret_code != 0:
            logger.error(stderr)
        else:
            logger.info("Finished parsing {0} for DataPath DependencySequencer log".format(journal_file))

    
@handle_exceptions
def generate_timeline(dc_folder):
    infra_path = get_infra_folder_abs_path()
    timeline_parser_command = os.path.join(os.path.dirname(infra_path), 'scripts', 'timeline_gen.pl')
    journal_a = os.path.join(dc_folder, TOOL_OUTPUT_FOLDER, JOURNAL_A_TEXT)
    journal_b = os.path.join(dc_folder, TOOL_OUTPUT_FOLDER, JOURNAL_B_TEXT)
    # Below is to make sure journal_a.txt and journal_b.txt exist so that timeline_parser.pl won't throw error.
    if not os.path.exists(journal_a):
        Path(journal_a).touch()
    if not os.path.exists(journal_b):
        Path(journal_b).touch()
    # timeline_file = os.path.join(dc_folder, TOOL_OUTPUT_FOLDER, 'timeline_a_b.txt')
    timeline_file = 'timeline_a_b.txt'
    # need to change dir to the tool output folder so that the timeline_gen_helpers folder generated by timeline_gen.pl will be saved there.
    cmd = '/bin/sh -c ' + r"'cd {4};perl {0} -a {1} -b {2} |sort > {3}'".format(timeline_parser_command, JOURNAL_A_TEXT,
                                                                         JOURNAL_B_TEXT, timeline_file, os.path.join(dc_folder, TOOL_OUTPUT_FOLDER))
    logger.info("Generating timeline...")
    logger.debug(cmd)
    _, stderr, ret_code = system(cmd, show_progress=True)
    if ret_code != 0:
        logger.error(stderr)
    else:
        logger.info("Finished generating timeline")

@handle_exceptions
def run_cp_datacollection_triage(dc_folder):
    infra_path = get_infra_folder_abs_path()
    cp_datacollection_triage = os.path.join(os.path.dirname(infra_path), 'scripts', 'cp_datacollect_triage.py')
    output_folder = os.path.join(dc_folder, TOOL_OUTPUT_FOLDER)
    dc_folder = os.path.abspath(dc_folder) # make sure the dc folder path is abspath
    #use  '> /dev/null 2>&1' to avoid 'system' to hang due to the pipe being filled up during p.poll()
    cmd = 'cd {0};python3 {1} -dc {2} --all > /dev/null 2>&1'.format(output_folder, cp_datacollection_triage, dc_folder)
    logger.info("Generating CP data collection triage analysis...")
    _, _, ret_code = system(cmd, shell=True, show_progress=True)
    if ret_code != 0:
        logger.error("Error happened during running cp_datacollection_triage.py")
    else:
        logger.info("Finshied running cp_datacollection_triage.py")