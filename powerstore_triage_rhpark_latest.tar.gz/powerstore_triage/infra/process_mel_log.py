import os
import logging
from infra.utils import system, TOOL_NAME, TOOL_OUTPUT_FOLDER, handle_exceptions, get_infra_folder_abs_path
import glob

# the parent logger will be the logger with name defined by TOOL_NAME
logger = logging.getLogger('.'.join([TOOL_NAME, __name__]))

# Based on the snippets in cyc_helpers/create_timeline.sh
# according to the following in create_timeline.sh, only need to parse cyc-mel-merged.bin from one of the node.  
# MEL_FILE=`find . -name cyc-mel-merged.bin 2> /dev/null | head -1`
def process_mel_log(dc_folder, start_time_str=None, end_time_str=None):
    cyc_mel_cli = os.path.join(os.path.dirname(get_infra_folder_abs_path()), "bin", "cyc_mel", "cyc_mel_cli")
    output_file_path = os.path.join(dc_folder, TOOL_OUTPUT_FOLDER, "mel_timeline.txt")
    mel_binary_files = glob.glob(os.path.join(dc_folder, "node_*/cyc_var/cyc-mel-merged.bin"))
    logger.info("Generating mel log...")
    if mel_binary_files:
        mel_binary_file = mel_binary_files[0]
        # cmd_str = r"%s -o mel_dump -M %s |awk ' " %(cyc_mel_cli, mel_binary_file) + r'BEGIN { FS="|"; split("Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec",month, " "); } { sub(/[ \t]+/, "", $4); sub(/[ \t]+/, "", $6);  ts=$3; if (match($2, /A/)) { node="A";} else { node="B"; } ;split(ts,date_time, " "); split(date_time[1],mdy,"/"); mnum=0+mdy[1];printf "%s %02d %s :::         %s_MEL %s %s %s (M)\n", month[mnum], mdy[2], date_time[2], node, $4, $6, $7; }' + r"' > %s" % output_file_path
        cmd_str = r"%s -o mel_dump -M %s |awk -F '|' '{ " %(cyc_mel_cli, mel_binary_file) + r' sub(/[ \t]+/, "", $4); sub(/[ \t]+/, "", $6);  ts=$3; if (match($2, /A/)) { node="A";} else { node="B"; } ;split(ts,date_time, " "); split(date_time[1],mdy,"/");;printf "%s-%s-%sT%s :::         %s_MEL %s %s %s (M)\n", mdy[3], mdy[1], mdy[2], date_time[2], node, $4, $6, $7;' + r" } '" + r" > %s" % output_file_path
        logger.debug(cmd_str)
        ret = os.system(cmd_str)
        if ret != 0:
            logger.error("Error happened during dumping cyc-mel-merged.bin to text file")
        else:
            logger.info("Finished generating mel log")
    else:
        logger.warning("cyc-mel-merged.bin is not found in node_*/cyc_var/")

#  ~/mel/cyc_mel_cli -o mel_dump -M /disks/JIRATEE/0000000-0000999/TEE-372/cyc-mel-merged.bin|awk -F '|' '{ sub(/[ \t]+/, "", $4); sub(/[ \t]+/, "", $6);  ts=$3; if (match($2, /A/)) { node="A";} else { node="B"; } ;split(ts,date_time, " "); split(date_time[1],mdy,"/");;printf "%s-%s-%sT%s :::         %s_MEL %s %s %s (M)\n", mdy[3], mdy[1], mdy[2], date_time[2], node, $4, $6, $7; } '
# 0000000000|00000000:A.UC|04/08/2020 18:19:29.481448|           START|              NA|                            PPDS|starting
# 0000000001|00000000:.BUC|04/08/2020 18:19:29.488952|           START|              NA|                            PPDS|starting
# 0000000002|00000000:.BUC|04/08/2020 18:21:34.646632|           START|              NA|                             BSC|starting

# 2020-04-08T18:19:29.481448 :::         A_MEL START PPDS starting (M)
# 2020-04-08T18:19:29.488952 :::         B_MEL START PPDS starting (M)
# 2020-04-08T18:21:34.646632 :::         B_MEL START BSC starting (M)
# 2020-04-08T18:21:46.034307 :::         A_MEL START BSC starting (M)
# 2020-04-08T18:22:22.198279 :::         B_MEL START RCVY starting (M)

# ./node_b/cyc_var/cyc-mel-peer.bin
# ./node_b/cyc_var/cyc-mel-local-snap.bin
# ./node_b/cyc_var/cyc-mel-local.bin
# ./node_b/cyc_var/cyc-mel-merged.bin
# ./node_b/cyc_var/cyc-mel-lock.bin
# ./node_a/cyc_var/cyc-mel-peer.bin
# ./node_a/cyc_var/cyc-mel-local-snap.bin
# ./node_a/cyc_var/cyc-mel-local.bin
# ./node_a/cyc_var/cyc-mel-merged.bin
# ./node_a/cyc_var/cyc-mel-lock.bin
