from __future__ import print_function
from infra.utils import system, TOOL_NAME
import os
import logging

# the parent logger will be the logger with name defined by TOOL_NAME
logger = logging.getLogger('.'.join([TOOL_NAME, __name__]))


#TODO: check if cyc_cfs should be considered
#TODO: use inventory.json file
def find_dump_files(work_space_folder):
    # ['node_a', 'node_b']
    node_dirs = [directory for directory in os.listdir(work_space_folder) if
                 os.path.isdir(os.path.join(work_space_folder, directory)) and "node" in directory]
    for node in node_dirs:
        # cores dump file: ^core.*(dump|dump\.t?bz2)$
        # kdump file: ^vmcore.*(kdump|kdump\.t?bz2)$
        # firmware dump file: ^fwcore.*(dump|dump\.t?bz2)$
        cmd = r'find {0} -regex ".*core.*\(\.k?dump\|\.k?dump.t?bz2\)$" -type f -regextype egrep'.format(os.path.join(work_space_folder, node))
        logger.debug(cmd)
        stdout, stderr, ret_code = system(cmd)
        logger.debug(stdout)
        logger.info("===== Firmware core dumps from {0} =====".format(node))
        if ret_code == 0:
            if stdout != '':
                dump_files = stdout.strip().split(os.linesep)
                if len(dump_files) > 0:
                    file_dict = {}
                    for dump_file in dump_files:
                        basename = os.path.basename(dump_file)
                        dirname = os.path.dirname(dump_file)
                        file_dict.setdefault(dirname, []).append(basename)
                    for k, v in file_dict.items():
                        logger.info("Found in {0}".format(k))
                        for f in v:
                            logger.info("    {0}".format(f))
            else:
                logger.info("No Firmware Core Dump")
        else:
            logger.error(stderr)
