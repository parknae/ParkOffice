#!/bin/bash

###########################################################################
# Copyright (C) Dell EMC 2019
# All rights reserved.
# Licensed material -- property of Dell EMC
#
###########################################################################
if ! [[ -d node_a ]] && ! [[ -d node_b ]]; then
    echo "This script mut be executed in the extraced DC folder"
    exit
fi

if [[ -d "node_a/core_os/usr/bin" ]]; then
    coreos_path="node_a/core_os"
    journalctl="$coreos_path/lib64/ld-linux-x86-64.so.2 --library-path $coreos_path/lib64:$coreos_path/usr/lib/systemd $coreos_path/usr/bin/journalctl"
elif [[ -d "node_b/core_os/usr/bin" ]]; then
    coreos_path="node_b/core_os"
    journalctl="$coreos_path/lib64/ld-linux-x86-64.so.2 --library-path $coreos_path/lib64:$coreos_path/usr/lib/systemd $coreos_path/usr/bin/journalctl"
elif [[ -d "node_a/journalctl" ]]; then
    journalctl_path="node_a/journalctl"
    journalctl="$journalctl_path/ld-linux-x86-64.so.2 --library-path $journalctl_path $journalctl_path/journalctl"
elif [[ -d "node_b/journalctl" ]]; then
    journalctl_path="node_b/journalctl"
    journalctl="$journalctl_path/ld-linux-x86-64.so.2 --library-path $journalctl_path $journalctl_path/journalctl"
else
    script_dir="$( cd "$( dirname "${BASH_SOURCE[0]}" )" >/dev/null 2>&1 && pwd )"
    journalctl_path=$( dirname "$script_dir")"/bin/journalctl"
    journalctl="$journalctl_path/ld-linux-x86-64.so.2 --library-path $journalctl_path $journalctl_path/journalctl"
    # echo $journalctl
    # exit
fi
#echo "journalctcl command:" $journalctl
if [[ -d "node_a/var/log/journal" ]]; then
    journal_file_glob_option_node_a=" --file=node_a/var/log/journal/*/*.journal* "
fi
if [[ -d "cyc_cfs/journald/node_a" ]]; then
    journal_file_glob_option_node_a+=" --file=cyc_cfs/journald/node_a/*.journal* "
fi

if [[ -d "node_b/var/log/journal" ]]; then
    journal_file_glob_option_node_b=" --file=node_b/var/log/journal/*/*.journal* "
fi
if [[ -d "cyc_cfs/journald/node_b" ]]; then
    journal_file_glob_option_node_b+=" --file=cyc_cfs/journald/node_b/*.journal* "
fi
#echo $journal_file_glob_option_node_a
#echo $journal_file_glob_option_node_b
if [ "$1" == "-node" ]; then
    shift;
    if [ "$1" == "a" ]; then
        file_glob_option=$journal_file_glob_option_node_a
        shift;
    elif [ "$1" == "b" ]; then
        file_glob_option=$journal_file_glob_option_node_b
        shift;
    else echo "node name must be either a or b"; exit 1
    fi
else file_glob_option="${journal_file_glob_option_node_a} ${journal_file_glob_option_node_b}"
fi
# the -o short-iso-precise argument can be overriden by the one after it.
journalctl+=" --utc $file_glob_option -m -o short-iso-precise"
#echo $journalctl
#echo $journalctl "${@}"
# TZ=UTC is to set the time environmental setting of the process to UTC, thus the timestamp in --since/--until arguments
# is effectively UTC
TZ=UTC $journalctl "${@}"
