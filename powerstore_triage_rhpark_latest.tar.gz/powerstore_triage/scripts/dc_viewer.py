#!/usr/bin/env python3

from prompt_toolkit import PromptSession
from prompt_toolkit.shortcuts import CompleteStyle
from prompt_toolkit.patch_stdout import patch_stdout
from prompt_toolkit.completion import WordCompleter
from prompt_toolkit.completion import FuzzyWordCompleter
from prompt_toolkit.styles import Style
from prompt_toolkit.history import InMemoryHistory
from prompt_toolkit.auto_suggest import AutoSuggestFromHistory
from prompt_toolkit.enums import EditingMode
import glob
import os
import sys
import asyncio
import inspect
# from pygments.styles import get_style_by_name
# from prompt_toolkit.styles.pygments import style_from_pygments_cls

#----------------------------------------------------------#
# 2020 Dell Inc. and its subsidiaries. All Rights reserved #
#----------------------------------------------------------#
#--------------------------------------#
# Henry.An@dell.com                    #
# NGMR Engineering Technical Services  #
#--------------------------------------#

# TODO: pscli like select for json files
# https://github.com/prompt-toolkit/python-prompt-toolkit/tree/master/examples/prompts/auto-completion
# TODO: allow system command

version = "0.2.0"

if not os.path.exists('node_a') and not os.path.exists('node_b'):
    print("This script mut be executed in the extraced Data Collection folder!")
    sys.exit(1)

dc_name_list = os.path.basename(os.path.abspath(".")).split("_")
# powerstore_6CS1BW2_PSf7a0590c8371_FNM00191700209_2020-04-30_14-04-15_service-data
prompt_str = "{0}_{1}_{2}".format(dc_name_list[1], dc_name_list[4], dc_name_list[5])
# 6CS1BW2_2020-04-30_14-04-15

def add_folder(node, folder, recursive=False):
    if os.path.exists(os.path.join(node, folder)):
        if recursive:
            files = glob.glob('{0}/{1}/**/*.*'.format(node, folder), recursive=True)
            files.extend(glob.glob('{0}/{1}/**/.*'.format(node, folder), recursive=True))
        else:
            files = glob.glob('{0}/{1}/*.*'.format(node, folder))
            files.extend(glob.glob('{0}/{1}/.*'.format(node, folder)))
        for f in files:
            command = "_".join(f.split(os.sep))
            word_list.append(command)
            word_to_file_name[command] = f


# build word list and word to file name mapping
word_list = list()
word_to_file_name = dict()
for node in ['node_a', 'node_b']:
    if os.path.exists('{0}/config_capture_management_data'.format(node)):
        files = glob.glob('{0}/config_capture_management_data/*.json'.format(node))
        for f in files:
            command = "_".join(f.split(os.sep))
            # command = "{0}_{1}".format('{0}_mgmt'.format(node), os.path.basename(f))
            word_list.append(command)
            word_to_file_name[command] = f

    if os.path.exists('{0}/config_capture_management_internal_data'.format(node)):
        files = glob.glob('{0}/config_capture_management_internal_data/*.json'.format(node))
        for f in files:
            command = "_".join(f.split(os.sep))
            # command = "{0}_{1}".format('{0}_mgmt_internal'.format(node), os.path.basename(f))
            word_list.append(command)
            word_to_file_name[command] = f

    if os.path.exists('{0}/config_capture_metrics_data'.format(node)):
        files = glob.glob('{0}/config_capture_metrics_data/*.json'.format(node))
        for f in files:
            command = "_".join(f.split(os.sep))
            # command = "{0}_{1}".format('{0}_metrics'.format(node), os.path.basename(f))
            word_list.append(command)
            word_to_file_name[command] = f

    if os.path.exists('{0}/command_output'.format(node)):
        files = glob.glob('{0}/command_output/**/*.txt'.format(node), recursive=True)
        for f in files:
            command = "_".join(f.split(os.sep))
            if 'xmcli' in command:
                command = command.replace("_-x__-c_", "_")
                command = command.replace("-", "_")
            word_list.append(command)
            word_to_file_name[command] = f

    if os.path.exists('{0}/core_os'.format(node)):
        files = glob.glob('{0}/core_os/*.txt'.format(node))
        if os.path.exists('{0}/core_os/var/log'.format(node)):
            files.extend(glob.glob('{0}/core_os/var/log/*.log'.format(node)))
        if os.path.exists('{0}/core_os/etc/os-release'.format(node)):
            files.append('{0}/core_os/etc/os-release'.format(node))
        for f in files:
            command = "_".join(f.split(os.sep))
            word_list.append(command)
            word_to_file_name[command] = f

    if os.path.exists('{0}/xms/var/log/httpd'.format(node)):
        files = glob.glob('{0}/xms/var/log/httpd/*'.format(node))
        for f in files:
            command = "_".join(f.split(os.sep))
            word_list.append(command)
            word_to_file_name[command] = f

    add_folder(node, 'cyc_core')
    add_folder(node, 'cyc_host')
    add_folder(node, "bsc/cyc_bsc/conf")
    add_folder(node, 'node_a/bsc/cyc_bsc/logs')
    add_folder(node, 'cyc_hacs', recursive=True)
    add_folder(node, 'xms/var/log/xms')
    add_folder(node, 'var/log/pcsd')
    add_folder(node, 'var/log/sdnas/ansible')
    add_folder(node, 'var/log/sdnas/sdnas_logs')
    add_folder(node, 'cyc_var')
    add_folder(node, 'cyc_var/cyc_service')
    add_folder(node, 'cyc_var/cyc_sysconfig', recursive=True)
    add_folder(node, 'cyc_var/resources')
    add_folder(node, 'cyc_var/security')
    add_folder(node, 'cyc_var/cyc_service') # support_metrics and database folder under it are not added on purpose
    add_folder(node, 'cyc_var/cyc_state')
    add_folder(node, 'cyc_var/cyc_strongswan', recursive=True)
    add_folder(node, 'cyc_var/cyc_strongswan_sdnas', recursive=True)
    add_folder(node, 'cyc_var/cyc_bmcsel')

TOOL_NAME = "powerstore-triage"
FILTERED_LOG_FOLDER = 'filtered_logs'
timeline_gen_helper_folder = 'timeline_gen_helpers'
if os.path.exists('{0}'.format(TOOL_NAME)):
    files = glob.glob('{0}/*.txt'.format(TOOL_NAME))
    files.extend(glob.glob('{0}/{1}/*.txt'.format(TOOL_NAME, FILTERED_LOG_FOLDER)))
    files.extend(glob.glob('{0}/{1}/*.txt'.format(TOOL_NAME, timeline_gen_helper_folder)))
    for f in files:
        command = "_".join(f.split(os.sep))
        word_list.append(command)
        word_to_file_name[command] = f

# put all the tips as text file in folder "knowledgebase"
# all tips must end with a blank line so that it can be better displayed
script_folder_abs_path = os.path.dirname(os.path.realpath(__file__))
if os.path.exists('{0}/knowledgebase'.format(script_folder_abs_path)):
    # may need to change "*" to "*.*" in the future.
    files = glob.glob('{0}/knowledgebase/*'.format(script_folder_abs_path))
    for f in files:
        command = os.path.basename(f)
        word_list.append(command)
        word_to_file_name[command] = f


# my_wordcompleter = WordCompleter(word_list, ignore_case=True)
my_fuzzy_wordcompleter = FuzzyWordCompleter(word_list)
my_style = Style.from_dict({
    'completion-menu.completion': 'bg:#008888 #ffffff',
    'completion-menu.completion.current': 'bg:#00aaaa #000000',
    'scrollbar.background': 'bg:#88aaaa',
    'scrollbar.button': 'bg:#222222',
})


def script_dc_journal(argument_str=None):
    # argument_str includes shell pipe string part
    dc_journalctl = os.path.join(script_folder_abs_path, "dc_journalctl.sh")
    # set SYSTEMD_LESS=FRXMK so that the output is auto wrapped
    os.system("SYSTEMD_LESS=FRXMK {0} {1}".format(dc_journalctl, argument_str))

# build command from functions
func_list = [(name, obj) for name, obj in inspect.getmembers(sys.modules[__name__]) if (inspect.isfunction(obj) and name.startswith('script_'))]
custom_command_to_func = dict(func_list)
word_list.extend(custom_command_to_func.keys())

def main():
    # DO NOT set mouse_support=True, otherwise, there's no way to select and paste by using mouse
    # enable_system_prompt=True doesn't seem to work well with prompt-toolkit 3.0
    # complete_style=CompleteStyle.MULTI_COLUMN doesn't fix our need due to long file name is truncted to '...'
    # complete_style=CompleteStyle.READLINE_LIKE, this is like the bash autocomplete style
    session = PromptSession(editing_mode=EditingMode.VI)
    while True:
        try:
            command = session.prompt('{0}> '.format(prompt_str), completer=my_fuzzy_wordcompleter, style=my_style, 
                            include_default_pygments_style=False,
                            complete_while_typing=True, auto_suggest=AutoSuggestFromHistory())
        except KeyboardInterrupt:
            pass
        except EOFError:
            break
        else:
            if command.lower() in ["exit", "quit", 'bye', '88']:
                break
            elif command == "":
                pass
            # any command starts with ! is considered to be a shell command
            # however, cd doesn't take effect
            elif command.startswith("!"):
                os.system(command[1:])
            elif command.split("|")[0].split()[0] not in word_list or command.endswith("|"):
                #e.g. script_dc_journal -S "1 day ago" |grep "HA_FLOW" 
                print("Not a valid command")
            else:
                word = command.split("|")[0].split()[0]
                #e.g. script_dc_journal -S "1 day ago" |grep "HA_FLOW" 
                if word in custom_command_to_func:
                    argument_str = " ".join(command.split()[1:])
                    custom_command_to_func[word](argument_str)
                else:
                    if "|" in command:
                        # example: a_mgmt_volume.json|grep "vol1"
                        word = command.split("|")[0]
                        if word in word_to_file_name:
                            file_name = word_to_file_name[word]
                            pipe_command_str = command.split("|", maxsplit=1)[-1]
                            print(file_name)
                            # cat the file content and pass it to the pipe
                            if file_name.endswith('.gz'):
                                os.system(r"zcat {0}|{1}".format(file_name, pipe_command_str))
                            else:
                                os.system(r"cat {0}|{1}".format(file_name, pipe_command_str))
                        else:
                            print("Not a valid command")
                    else:
                        print(word_to_file_name[command])
                        if word_to_file_name[command].endswith('.gz'):
                            os.system('zless {0}'.format(word_to_file_name[command]))
                        else:
                            os.system('less {0}'.format(word_to_file_name[command]))
    print('See you again!')


# async def main():
#     # DO NOT set mouse_support=True, otherwise, there's no way to select and paste by using mouse
#     session = PromptSession(enable_system_prompt=True, editing_mode=EditingMode.VI)
#     while True:
#         with patch_stdout():
#             try:
#                 command = await session.prompt_async('{0}> '.format(prompt_str), completer=my_completer, style=my_style, include_default_pygments_style=False,
#                                 complete_while_typing=True, auto_suggest=AutoSuggestFromHistory())
#             except KeyboardInterrupt:
#                 continue
#             except EOFError:
#                 break
#             else:
#                 if command.lower() in ["exit", "quit", 'bye', '88']:
#                     break
#                 elif command == "":
#                     continue
#                 elif command not in word_to_file_name:
#                     print("Not a valid command")
#                     continue
#                 else:
#                     print(word_to_file_name[command])
#                     os.system('less {0}'.format(word_to_file_name[command]))

if __name__ == '__main__':
    print("Version: {0}".format(version))
    main()
    # python 3.6 and prior
    # loop = asyncio.get_event_loop()
    # # Blocking call which returns when the main() coroutine is done
    # loop.run_until_complete(main())
    # loop.close()