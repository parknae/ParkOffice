#!/usr/bin/env python

from __future__ import print_function
import logging
import os
import subprocess
import argparse
import re
import datetime
import json
import functools


#=====================================File Configuration================================================
SUMMARY_FILE="CPTriageSummaryReport.txt"
EXCEEDED_TRANSITIONING_STATE_STRING="waiting for the transition"
EXCEEDED_STATE_TIME_STRING="waiting for a trigger to arrive"
CMD_SM_STATE="\[.*\|.*\|.*]"
JQ_CMD_SECTION = "%s -o json | jq -r '\"{_HOSTNAME: \(._HOSTNAME), LOG_TYPE: \(.LOG_TYPE), SUB_COMPONENT: \(.SUB_COMPONENT), MARKER: \(.MARKER), PRIORITY: \(.PRIORITY), MESSAGE: \(.MESSAGE) }\"'"
EGREP_CMD_SECTION = "| egrep \"\-\- No entries \-\-|%s\""
DC_PATH = ""

write_to_summary = open(SUMMARY_FILE, "a")

#=====================================Logging Information===============================================


def error(message):
    """print red message"""
    logging.error("".join(['\033[91m', message, '\033[0m']))
    write_to_summary_file(message)


def error_file(message):
    """print found file without DC base file in path"""
    error(message.replace(DC_PATH, ''))


def success(message):
    """print green message"""
    logging.info("".join(['\033[92m', message, '\033[0m']))
    write_to_summary_file(message)


def warn(message):
    """print yellow message"""
    logging.warning("".join(['\033[93m', message, '\033[0m']))
    write_to_summary_file(message)


def info(message):
    """print black message"""
    logging.info(message)
    write_to_summary_file(message)


def info_file(message):
    """print found file without DC base file in path"""
    info(message.replace(DC_PATH, ''))


def print_header(title):
    """ print header with *** above and below ever letter """
    info("")
    stars = "*" * len(title)
    info(stars)
    info(title)
    info(stars)


#=================================Try and get DC journalctl===============================================


def get_coreos_path(datacollectpath):
    if datacollectpath == ".":
        datacollectpath = os.getcwd()
    for node_name in ['node_a', 'node_b']:
        coreos_path = os.path.join(datacollectpath, node_name, 'core_os')
        if os.path.exists(os.path.join(coreos_path, 'usr/bin')):
            return coreos_path
    return None


def get_journal_cmd(datacollectpath):
    exist_journalctl = False
    try:
        coreos_path = get_coreos_path(datacollectpath)
        if coreos_path:
            return '{0}/lib64/ld-linux-x86-64.so.2 --library-path {1}/lib64:{2}/usr/lib/systemd {3}/usr/bin/journalctl'.format(coreos_path, coreos_path, coreos_path, coreos_path)
        else:
            for node_name in ['node_a', 'node_b']:
                journalctl_path = os.path.join(os.getcwd(), datacollectpath, node_name, 'journalctl')
                if os.path.exists(journalctl_path):
                    return '{0}/ld-linux-x86-64.so.2 --library-path {1} {2}/journalctl'.format(journalctl_path, journalctl_path, journalctl_path)
    except:
        pass
    if not exist_journalctl:
        # fall back to use the journalctl of the OS where this script is running on
        return 'journalctl'


#=================================Functions to Be Executed===============================================


def try_catch_decorator(func):
    @functools.wraps(func)
    def wrapper(*a, **k):
        try:
            return func(*a, **k)
        except Exception as e:
            error("Current check failed due to below exception:")
            error(str(e))
    return wrapper


@try_catch_decorator
def walk_datacollect(datacollectpath):
    """
    Function to collect and return all files and directories in the datacollect top directory

    :param datacollectpath:
    :return: a string output of all the files and directories in the datacollect
    """
    file_list = ""
    for root, dirs, files in os.walk(datacollectpath, topdown=False):
        for name in files:
            file_list += os.path.join(root, name) + '\n'
        for name in dirs:
            file_list += os.path.join(root, name) + '\n'
    return file_list


@try_catch_decorator
def idle_in_transaction(files):
    """
    Search for idle in transactions calls in the pg_stat_activity.txt file
    :param files: string of files to seach for pg_start_activity.txt
    :return:
    """
    print_header("Checking for idle in transaction")
    pg_stat = re.findall(".*/pg_stat_activity.txt", files)
    for file in pg_stat:
        info_file(file)
        with open(file, mode="rt") as f:
            pg_stat_contents = "\n".join(f.readlines())
            idle_transaction = re.findall(".* idle in transaction .*", pg_stat_contents)
            if len(idle_transaction) > 0:
                for transaction in idle_transaction:
                    error(transaction)
            else:
                success('No "idle in transactions" found.')


@try_catch_decorator
def docker_ps(files):
    """
    Display contents of the docker_ps.txt file
    :param files:
    :return:
    """
    print_header("Displaying contenst of docker ps file")
    docker_ps = re.findall(".*/docker_ps.txt", files)
    for file in docker_ps:
        with open(file, mode="rt") as f:
            info("\n".join(f.readlines()))


@try_catch_decorator
def process_memory_thread_count(files):
    """
    Process memory-node-a for process memory and thread count

    :param files:
    :return:
    """
    print_header("Process Memory and Thread Count")
    memory_node = re.findall(".*/memory-node-..lo.*", files)
    processes = ["java"]
    time = ""
    for file in memory_node:
        info_file(file)
        info("Time Process Thread_Count RSS(bytes)")
        with open(file, mode="rt") as f:
            for line in f:
                if "new snapshot" in line:
                    time = line.replace("new snapshot at", "").replace("-", "").strip()
                for process in processes:
                    if "(" + process + ")" in line:
                        split_line = line.split()
                        try:
                            info(time + " " + split_line[1] + " " + split_line[19] + " " + str(int(split_line[23])*4096))
                        except:
                            error("Script had an error running on line: " + line)
        info("")


@try_catch_decorator
def check_pending_locks(files):
    """
    Process processed check for pending locks query

    :param files:
    :return:
    """
    print_header("Process Pending Lock Files")
    pending_locks = re.findall(".*/.*pending_locks.txt", files)
    for file in pending_locks:
        info_file(file)
        with open(file, mode="rt") as f:
            count = 0
            for line in f:
                if line.find('Lock Requests not found for the option/parameters given!') > -1:
                    success("No pending Locks found!")
                    break
                if line.find('lock_status') > -1:
                    count =+ 1
            if count > 0:
                error('There are %s pending locks in the above file.' % count)
        info("")


def search_journal(dir, searchString, cmd_tail, journal="control-path"):
    """ method used to search different journalctl types """
    cmd = "cd " + dir + "; " + STD_JOURNAL_CMD + journal + " " + cmd_tail % searchString
    return subprocess.check_output(cmd, shell=True, universal_newlines=True)


def block_thread_check(node):
    """
    method to check for blocked threads

    :param node: The node folder to do the journal checks on
    :return:
    """
    try:
        search_terms = {"has been blocked",
                        '-- No entries --'}
        print_header("Check for Blocked Threads")
        results = search_journal(node, "|".join(search_terms), " PRIORITY=4 " + EGREP_CMD_SECTION + " -A 30",
                                 "control-path").strip()
        results = results.split("\n")
        blocked_threads = {}
        if len(results) > 0:
            latest_thread_name = ''
            for r in results:
                thread_name = re.search('Thread\[(.*)\] has been blocked', r)
                if thread_name is None:
                    r = re.sub(r"^\s+", "", r)
                    if blocked_threads[latest_thread_name][1] == "":
                        blocked_threads[latest_thread_name][0] += r + "\n"
                    else:
                        blocked_threads[latest_thread_name][1] += r + "\n"
                elif thread_name.group(1) in blocked_threads:
                    latest_thread_name = thread_name.group(1)
                    blocked_threads[thread_name.group(1)][1] = r + "\n"
                else:
                    latest_thread_name = thread_name.group(1)
                    blocked_threads[thread_name.group(1)] = [r + "\n", ""]

        for blocked in blocked_threads:
            info(blocked)
            error(blocked_threads[blocked][0])
            error(blocked_threads[blocked][1])
    except:
        success("No Block Threads found.")


@try_catch_decorator
def basic_journal_search(header, search_term, results, notFoundStr, ifFoundError=True):
    """ Helper function for process_cp_journal and doing basic journal checks

        :param header: title of the check
        :param search_term: string to search for in journal results
        :param results: results from journalctl
        :param ifFoundError: If set to True it will return results as an error
                      If set to False will return success if results found
        :return
    """
    try:
        print_header(header)
        find_results = re.findall('.*%s.*' % search_term, results)
        if len(find_results) > 0:
            for r in find_results:
                if ifFoundError:
                    error(r)
                else:
                    success(r)
        else:
            if ifFoundError:
                success(notFoundStr)
            else:
                error(notFoundStr)
    except:
        if ifFoundError:
            success(notFoundStr)
        else:
            error(notFoundStr)
        pass


@try_catch_decorator
def concurrent_call_search(header, search_term, results, notFoundStr, ifFoundError=True):
    """ Helper function for process_cp_journal and doing basic journal checks

        :param header: title of the check
        :param search_term: string to search for in journal results
        :param results: results from journalctl
        :param ifFoundError: If set to True it will return results as an error
                      If set to False will return success if results found
        :return
    """
    try:
        print_header(header)
        state = set()
        find_results = re.findall('.*%s.*' % search_term, results)
        if len(find_results) > 0:
            for r in find_results:
                found_state = re.findall(r"\[.*\] \[.*\|.*\|(.*)\]", r)
                if found_state[0] not in state:
                    error(r)
                    state.add(found_state[0])
        else:
            success(notFoundStr)
    except:
        success(notFoundStr)
        pass


def process_cp_journal(files):
    """ Basic search for cp journal"""
    journal_dir = re.findall("(.*/powerstore-triage/journal/node_.)\n", files)
    search_terms = {"java.lang.OutOfMemoryError: Java heap space",
                    "entering createCluster with command",
                    "create_cluster_completed",
                    '\[CC\].*Create Cluster Completed',
                    "Logs begin",
                    '-- No entries --',
                    'emc.cyclone.controlpath.bootstrap.Launcher.main',
                    'core dumped',
                    'controlpath-fail-handler',
                    'Failed to deploy a Verticle',
                    'Detected concurrent calls to awaitResponse'}
    if len(journal_dir) == 0:
        print_header("Journal")
        error("No processed journals found.")
        error("Please run 'cyc_triage.pl -j' first then rerun with -m")
    else:
        print_header("Going through control-path Journal")
    for node in journal_dir:
        print_header(node.replace(DC_PATH, ''))
        results = search_journal(node, "|".join(search_terms), EGREP_CMD_SECTION).strip()

        if results.find('-- No entries --') > -1:
            warn('-- No entries --')
        else:
            success(re.findall(".*Logs begin.*", results)[0])

            basic_journal_search('CC start',
                                 'entering createCluster with command',
                                 results,
                                 "No CC Start Command Found",
                                 False)
            basic_journal_search('CC end',
                                 '\[CC\].*Create Cluster Completed',
                                 results,
                                 "No CC Successfully Finished Found",
                                 False)
            basic_journal_search("Checking for all CP start times",
                                 'emc.cyclone.controlpath.bootstrap.Launcher.main',
                                 results,
                                 "No CP Starts Found",
                                 False)
            block_thread_check(node)
            basic_journal_search("Checking for Heap Out Of Memory",
                                 "java.lang.OutOfMemoryError: Java heap space",
                                 results,
                                 "No Heap Out Of Memory")
            basic_journal_search("Checking for core dumps",
                                 'core dumped',
                                 results,
                                 "No Core Dumps Detected")
            basic_journal_search("Checking for Verticle Deploy failures",
                                 'Failed to deploy a Verticle',
                                 results,
                                 "No failures to deploy Verticles found")
            concurrent_call_search("Checking for concurrent calls to awaitResponse (indicates a Dead Lock)",
                                 'Detected concurrent calls to awaitResponse',
                                 results,
                                 "No concurrent calls to awaitResponse found.")


@try_catch_decorator
def process_cp_fail_handler_journal(files):
    """ print entire controlpath-fail-handler """
    journal_dir = re.findall("(.*/powerstore-triage/journal/node_.)\n", files)
    search_terms = {'controlpath-fail-handler'}
    if len(journal_dir) == 0:
        print_header("Journal")
        error("No processed journals found.")
        error("Please run 'cyc_triage.pl -j' first then rerun with -m")
    else:
        print_header("Going through controlpath-fail-handler Journal")
    for node in journal_dir:
        print_header(node.replace(DC_PATH, ''))
        results = search_journal(node, "|".join(search_terms), EGREP_CMD_SECTION, "controlpath-fail-handler").strip()

        if results.find('-- No entries --') > -1:
            success('-- No entries --')
        else:
            error(results)


def process_crmd_journal(files):
    """
    search crmd journal
    :param files:
    :return
    """
    journal_dir = re.findall("(.*/powerstore-triage/journal/node_.)\n", files)
    search_terms = {'High CPU load',
                    '-- No entries --'}
    if len(journal_dir) == 0:
        print_header("Journal")
        error("No processed journals found.")
        error("Please run 'cyc_triage.pl -j' first then rerun with -m")
    else:
        print_header("Going through crmd Journal")
    for node in journal_dir:
        try:
            print_header(node.replace(DC_PATH, ''))
            results = search_journal(node, "|".join(search_terms), EGREP_CMD_SECTION, "crmd").strip()

            if results.find('-- No entries --') > -1:
                warn('-- No entries --')
            else:
                try:
                    print_header("High Load detected")
                    high_loads = re.findall(".*High CPU load.*", results)
                    for high_load in high_loads:
                        error(high_load)
                except:
                    success("No High Load messages found!")
                    pass
        except:
            success("No High Load messages found!")
            pass


@try_catch_decorator
def find_hs_err(files):
    """
    Find any hs_err files in files and
    :param files:
    :return:
    """
    print_header("Searching for hs_err file")
    hs_err_file = re.findall(".*hs_err.*\.log", files)
    if len(hs_err_file) == 0:
        success("No hs_err file found.")
    else:
        for file in hs_err_file:
            with open(file, mode="rt") as f:
                error_file(file)
                for line in f:
                    if line.find('#') == 0:
                        error(line.strip())
                    else:
                        break


@try_catch_decorator
def check_for_oom_killer(files):
    """
    Search for invoke oom-killer in the dmesg_-T.txt file
    :param files: string of files to search through
    :return:
    """
    print_header("Searching dmesg for OoM Killer")
    dmesg = re.findall(".*dmesg_-T.txt", files)
    for file in dmesg:
        dmesg_file = subprocess.check_output("cat %s" % file, shell=True, universal_newlines=True)
        contents = re.findall(".*invoked oom-killer.*", dmesg_file)
        info_file(file)
        if len(contents) > 0:
            for line in contents:
                error(line)
        else:
            success("No OoM Killer found.")


@try_catch_decorator
def check_for_command_inprogress_failed(files):
    """
    Check for IN_PROGRESS commands in the command_inprogress_failed file

    :param files: String of files to search through
    :return:
    """
    print_header("Searching command in progress failed")
    dmesg = re.findall(".*command_inprogress_failed.txt", files)
    for file in dmesg:
        command_file = subprocess.check_output("cat %s" % file, shell=True, universal_newlines=True)
        contents = re.findall(".*IN_PROGRESS.*", command_file)
        info_file(file)
        if len(contents) > 0:
            for line in contents:
                error(line)
        else:
            success("No command in progress failed found.")


@try_catch_decorator
def check_gc(files):
    """
    Check for Garbage Collection Allocation Failure in gc log files

    :param files: String of files to search through
    :return:
    """
    #variable to use to check on GC run length
    #This will change over time as the length of a GC that is "too long" changes
    gc_real_time = 1
    print_header("Searching Garbage Collection for Allocation Failure")
    gc_files = re.findall(".*gc.log.*", files)
    for file in gc_files:
        gc_contents = subprocess.check_output("cat %s" % file, shell=True, universal_newlines=True)
        failures = re.findall(".*Full GC \(Allocation Failure\).*", gc_contents)
        info_file(file)
        if len(failures) > 0:
            for line in failures:
                error(line)
        else:
            success("No Allocation Failures found.")
    print_header("Search for Garbage collects over %s seconds" % gc_real_time)
    info("A long gc collect does not necessarily signal a problem.")
    for file in gc_files:
        info_file(file)
        count = 0
        gc_contents = subprocess.check_output("cat %s" % file, shell=True, universal_newlines=True)
        times = re.findall(".*Times:.*real=.*", gc_contents)
        for time in times:
            results = time.split(' ')
            for result in results:
                if result.find('real') > -1:
                    if gc_real_time < float(result.replace('real=', '')):
                        error(time.strip())
                        count =+ 1
        if count == 0:
            success("No long Garbage Collections were found.")


def write_to_summary_file(message):
    """
    Writing action to the file.

    :param message: String message for writing on file
    :return
    """
    try:
        write_to_summary.writelines(message+"\n")
    except(OSError, IOError):
        print("There was an issue while trying to write to the file "+SUMMARY_FILE+" error being displayed: \n"
              + IOError)


@try_catch_decorator
def verify_state_existence(dictionary, value, momentAndLimit):
    """
    Notifies which status in the state machine has exceeded their specified time out for the first time and
    counts the repeating instances.

    :param dictionary: dictionary value
    :param value: list value
    :param momentAndLimit: Key, value pair
    :return:
    """
    if len(value) == 0:
        return

    state = value[2].rstrip("]")
    command = value[len(value)-1][30:].split(".")[-1].strip("\",")
    if (command+" "+str(momentAndLimit[0])+" Minutes") in dictionary.keys():
        dictionary[command+" "+str(momentAndLimit[0])+" Minutes"] = dictionary.get(command+" "+str(momentAndLimit[0])+" Minutes") + 1
    else:
        warn("          First occurance of new command that took too long: "+str(momentAndLimit[0])
                              +" minutes on command "+command+" state value: "+state+"tied to SM: "+value[1]
                              +" associated with command: "+value[0]+" at "+momentAndLimit[1])
        dictionary.update({command+" "+str(momentAndLimit[0])+" Minutes": 1})


@try_catch_decorator
def getTimeout(entry):
    """
    Extracts and returns the time out value to a specific entry
    :param entry:
    :return: time integer
    """
    timeout = -1

    #Get the specified amount of minutes it went over.
    value = re.findall("(.. MINUTE)", entry)
    timeout = int(value[0][0:2].strip())

    return timeout


@try_catch_decorator
def getTimestamp(entry):
    """
    Strips and returns the date and timestamp of the targeted entry
    :param entry:
    :return: datetime string
    """
    # Get the timestamp of the entry
    return re.findall("MESSAGE: .*", entry)[0][9:32]


@try_catch_decorator
def getIdList(listFound):
    """
    This function will analyze a list of entries and return their command_id -> tcp endpoint relationship

    :param listFound:
    :return: List of command_id -> tcp endpoints
    """
    returnList =list()
    if(len(listFound)<1):
        write_to_summary_file("Target List is currently Empty")
    else:
        for member in listFound:
            returnList.append(member[13:].split("command id")[1][1:78])

    return returnList


@try_catch_decorator
def calculateTimeframe(received, pending, output):
    """
    Uses the entry information to calculate the timeframe of finished pending commands

    :param received:
    :param pending:
    :param output:
    :return:
    """

    time_received = datetime.datetime.strptime(received.split()[0]+" "+received.split()[1].split(".")[0], "%Y-%m-%d %H:%M:%S")
    time_pending = datetime.datetime.strptime(pending.split()[0]+" "+pending.split()[1].split(".")[0], "%Y-%m-%d %H:%M:%S")

    # Grab set time from pending entry, if not successful set to 30 sec.
    dafault_timeframe = (datetime.timedelta(seconds=int(pending.split("second")[0][-3:-1])) if (pending.split("second")[0][-3:-1].isdigit()) else datetime.timedelta(seconds=30))

    calulated_time = (time_received - time_pending) + dafault_timeframe
    output.update({received.split("command id")[1][1:78]: "Calculated time: "+str(calulated_time)+" seconds. Specified timeframe = "+str(dafault_timeframe)})

    return 0


@try_catch_decorator
def dpStatusChangeCount(journal_path):
    """
    Will Notify the timeframe where DP status changes between UP and OUT_OF_SERVICE and vice versa

    :param journal_path:
    :return:
    """
    node = {}
    appliance_and_node=""
    status_change_date = ""
    DOWN_STATUS = "[UP] to [OUT_OF_SERVICE]"
    MAX_DATETIME_TIMEFRAME_CHAR_LENGTH = 49
    SINGLE_DATETIME_TIMEFRAME_CHAR_LENGTH = 23
    NODE = {"113": "Node A",
            "116": "Node B"}

    #access journal for desired information
    journal = search_journal(journal_path,
                            "SUB_COMPONENT=com.emc.cyclone.contexts.infrastructure.services.ConnectivityMonitor PRIORITY=6 ",
                            JQ_CMD_SECTION)

    #get the connectivity status changes logs
    dp_status = re.findall("MESSAGE: .*Connectivity status.*", journal)
    info("      DP monitoring on Both nodes encountered a total of "+str(len(dp_status))+" status changes:")

    #for each status change get date, appliance and node
    for current_status in dp_status:
        status_change_date = re.search(
            "MESSAGE:.*IN", current_status).group().strip("MESSAGE:").strip(" [][IN")
        appliance_and_node = re.search(
            "appliance id:....", current_status).group()+" - "+re.search("host:.*se", current_status).group()[0:-3]

        #if notification indicates down then add to the appropriate dictionary, else it doesn't exist add it.
        if DOWN_STATUS in current_status:
            if appliance_and_node in node.keys():
                node.get(appliance_and_node).append(status_change_date)
            else:
                node.update({appliance_and_node: [status_change_date]})
        #if notification is back up then update the latest entry of that appliance + node
        else:
            if len(node.keys())!= 0:
                if appliance_and_node in node.keys():
                    node.get(appliance_and_node).append(node.get(appliance_and_node).pop()+" - "+status_change_date)
            #Nodes came back up for the first time if there was an UP notification and the dictionary is empty
            else:
                info("    First Occurrence of Nodes going online:")
                warn("        "+current_status)

    #print the appropriate data
    for key, value in node.items():
        warn("          Dp Status change registered as OUT_OF_SERVICE for "+key+", "+NODE.get(key[-4:-1])+", at following timeframes:")
        warn("                    UP to OUT_OF_SERVICE      OUT_OF_SERVICE to UP")
        for dates in value:
            #Check if the string char are more than 2 timeframes
            if len(dates) > MAX_DATETIME_TIMEFRAME_CHAR_LENGTH:
                warn("                    "+dates[0:MAX_DATETIME_TIMEFRAME_CHAR_LENGTH])
                warn("                    NO DATA"+"                 "+dates[50:])
            else:
                #Check if the string char is just one timeframe
                if len(dates) <= SINGLE_DATETIME_TIMEFRAME_CHAR_LENGTH:
                    warn("                    "+dates+ "                 - NO DATA")
                else:
                    warn("                    "+dates)

    amSequencingFailuresCheck(journal_path)

    return

def amSequencingFailuresCheck(journal_path):
    """
    Will notify for AM Sequencing failures found, indicates the desiredNode and if isDesiredNodePreferred flag is set.
    IMPORTANT NOTE:
    This method runs as part of dpStatusChange however is independant and can be called on its own.
    Due to recent changes only DEBUG logs will have required information.

    :param journal_path:
    :return:
    """
    executing_node = journal_path.split("/")[len(journal_path.split("/")) - 1]
    print_header("AM Sequencing Failures ("+executing_node+")")

    #Acquire information from journal
    journal = search_journal(journal_path,
                             "SUB_COMPONENT=com.emc.cyclone.contexts.resourcebalancer.activitymanager.services.ActivityManagerAS SUB_COMPONENT=com.emc.cyclone.contexts.resourcebalancer.activitymanager.ActivityManagerDiagnosabilityHelpers",
                             JQ_CMD_SECTION)

    #get the failed command that failed to sequence.
    sequencing_failures = re.findall("ActivityManager Op UUID:.* failed to sequence .*", journal)


    #Prioritize the errors provided by the Resource Balancer
    if (len(sequencing_failures)!=0):

        sequencing_commands = {}
        #get information for DesiredNode and IsDesiredNodePreferred Flag.
        for failure in sequencing_failures:
            sequencing_commands[failure] = \
                str(re.search("RequestOpSequencingCommand.*"+failure[25:61]+".*DesiredNode.*IsDesiredNodePreferred.*command_class_name", journal).group().split(",")[-4:-2])

        #print appropriate information.
        if (len(sequencing_commands.keys())==0):
            success("               No Sequencing Command Failure where found")
        else:
            warn("          The following commands failed to sequence:")
            for key, value in sequencing_commands.items():
                error("               " + key[0:-1] + value[2:-1])

    #If Resource Balancer information was not found then use whats left.
    else:
        #get failure information
        sequencing_failures = re.findall("MESSAGE.*OP.*requested sequencing.*", journal)

        #print appropriate information.
        if (len(sequencing_failures)==0):
            success("               No Sequencing Command Failure where found")
        else:
            warn(
                "          The following commands failed to sequence: (IMPORTANT NOTE: No RESOURCEBALANCER information was found)")
            for failure in sequencing_failures:
                error("               " + failure[-106:-2]+" at "+failure[20:33])

    return

def execute_all(args):
    """
    Function that will indicate if all the deep analysis options will execute.

    :param args:
    :return: Boolean
    """
    #add args options as more deep_analysis options are added.
    #Example for when more options, sm,gs and more deep options;
    # (not args.statemachine and not args.gateway and not args.newdeepmethod)
    return (not args.statemachine and not args.gateway and not args.panic)


def file_cleanup():
    """
    File Summary clean.

    :return:
    """
    write_to_summary.seek(0)
    write_to_summary.truncate()
    info("Cleaned Summary File")


@try_catch_decorator
def SM_analysis(journal_path):
    """
    This function will analyze the log for SM related issues.

    :param journal_path:
    :return:
    """
    executing_node = journal_path.split("/")[len(journal_path.split("/"))-1]
    print_header("Starting StateMachine Log Analysis ("+executing_node+")")
    journal = search_journal(journal_path, "MARKER=SM_WATCHDOG PRIORITY=4 PRIORITY=3", JQ_CMD_SECTION)
    sm_warning_list = re.findall("(.*SM_WATCHDOG.*PRIORITY: 4.*\\n.*\\n.*{\\n.*)", journal)
    sm_error_list = re.findall("(.*SM_WATCHDOG.*PRIORITY: 3.*)", journal)
    warn("      Total SM Warning Entries: "+str(len(sm_warning_list)))
    #This will always be warning, no other warning will be log with the SM_WATCHDOG marker.
    error("      Total SM Error Entries: "+str(len(sm_error_list)))

    waiting_for_state_transition = {}
    waiting_for_trigger = {}

    waiting_for_trigger.keys()
    for entry in sm_warning_list:
        value = re.findall(CMD_SM_STATE, entry)
        value = value[0].split("[")[4]
        value_list = value.split("|")
        value_list.append(re.findall("(command_classname.*)", entry)[0])

        if EXCEEDED_STATE_TIME_STRING in entry:
            verify_state_existence(waiting_for_trigger, value_list, (getTimeout(entry), getTimestamp(entry)))

        else:
            if EXCEEDED_TRANSITIONING_STATE_STRING in entry:
                verify_state_existence(waiting_for_state_transition, value_list,
                                       (getTimeout(entry), getTimestamp(entry)))

    info("      Final SM Summary:")
    warn("      Entries that exceeded their specified timed out "+EXCEEDED_STATE_TIME_STRING+": "+str(len(waiting_for_trigger)))
    for key, count in waiting_for_trigger.items():
        warn("          "+key+": Found a total of "+str(count)+" times.")
    warn("      Entries that exceeded their specified timed out "+EXCEEDED_TRANSITIONING_STATE_STRING+": "+str(len(waiting_for_state_transition)))
    for key, count in waiting_for_state_transition.items():
        warn("          "+key+": Found a total of "+str(count)+" times.")
    return 0


@try_catch_decorator
def GS_analysis(journal_path):
    """
    This function will analyze the log for GS related issues.

    :param journal_path:
    :return:
    """
    executing_node = journal_path.split("/")[len(journal_path.split("/")) - 1]
    print_header("Starting Gateway Log Analysis ("+executing_node+")")

    journal = search_journal(journal_path, "MARKER=ZMQ", JQ_CMD_SECTION)
    gs_warning_list = re.findall("(PRIORITY: 4.*\(CpToCpMessageConsumer\).*)", journal)
    gs_error_list = re.findall("(PRIORITY: 3, MESSAGE:.*)", journal)
    wn_pending_cmd = re.findall("(PRIORITY: 4.*has not been received in over.*)", journal)
    info_cmd_received = re.findall("(PRIORITY: 6, MESSAGE:.*has been received successfully.*)", journal)

    pending_timeframe = dict()

    info("Final GW Sumary:")
    error("     Total of Errors found: "+str(len(gs_error_list)))
    for err in gs_error_list:
        error("         Entry: "+err[13:])

    total_warn = len(gs_warning_list) + len(wn_pending_cmd)
    warn("     Total of ZMQ Warning messages: " + str(total_warn))


    if (len(wn_pending_cmd) == len(info_cmd_received)):
        success("     The values between received commands and pending commands are the same: "+str(len(info_cmd_received)))
    else:
        warn("     Total of ZMQ Warning commands pending for more than the specified time: "+str(len(wn_pending_cmd)))
        warn("          Total received ZMQ pending commands that went over the specified time: "+str(len(info_cmd_received)))

        pending_cmd = getIdList(wn_pending_cmd)         # Move before the if/else statement
        received_cmd = getIdList(info_cmd_received)     # Move before the if/else statement

        error("          Pending Commands that never got a response: ")
        for cmd in range(len(pending_cmd)):
            if not (pending_cmd[cmd] in received_cmd):
                error("             Command Id: "+pending_cmd[cmd])
            else:
                calculateTimeframe(info_cmd_received[received_cmd.index(pending_cmd[cmd])][22:],
                                   wn_pending_cmd[cmd][22:], pending_timeframe)

    warn("          Timeframe for Pending Command that took over it's specified time that where received: ")
    for key, value in pending_timeframe.items():
        warn("              "+key+": "+str(value))

    dpStatusChangeCount(journal_path)

    return 0


@try_catch_decorator
def DP_panic_search(journal_path):
    """
    This function will analyze the log and search for Critical Panics on the xtremapp SYSLOG_ID.
    :param journal_path:
    :return:
    """
    executing_node = journal_path.split("/")[len(journal_path.split("/")) - 1]

    print_header("Starting Datapath Panic Search ("+executing_node+")")
    journal = search_journal(journal_path, "PRIORITY=2", JQ_CMD_SECTION, "xtremapp")
    panic_list = re.findall("(.*PANIC.*)", journal)

    if len(panic_list)==0:
        success("          No Panics found in the xtremapp logs.")
    else:
        error("          Found a total of "+str(len(panic_list))+" panics.")
        for entry in panic_list:
            error("          Panic Message found: "+entry)


def deep_analysis(all_files, args):
    """
    Function in charge for deep analysis execution logistic

    :param all_files:
    :param args:
    :return:
    """
    print_header("Entering Deep Analysis: ")
    files = re.findall("(.*/powerstore-triage/journal/node_.)\n", all_files)
    for file in files:
        if(execute_all(args)):
            SM_analysis(file)
            GS_analysis(file)
            DP_panic_search(file)
            #Add more as you continue your work.

        else:
            if(args.statemachine):
                SM_analysis(file)
            if(args.gateway):
                GS_analysis(file)
            if(args.panic):
                DP_panic_search(file)
            #Add more as you continue your work.

    return


@try_catch_decorator
def cp_boot_sequence_journal_search(node, search, log, boot_list):
    """
    Function to search journal specified by log for the term in search.
    They are then added to boot_list list

    :param node:
    :param search:
    :param log:
    :param boot_list:
    :return:
    """
    try:
        if search.find("vert.x-WebClient"):
            results = search_journal(node, search, " -o short-precise|egrep \'%s\' ", log).strip()
        else:
            results = search_journal(node, search, " -o short-precise" + EGREP_CMD_SECTION, log).strip()
        split_results = results.split("\n")
        for r in split_results:
            boot_list.append(r)
    except:
        info("\"" + search + "\" not found in " + log)


@try_catch_decorator
def context_helper(message):
    context = False
    if message.find("ha_hint requested during repository read") > -1:
        context = "SYM HA starts node fail over"
    elif message.find("starting master Stack") > -1:
        context = "Master Stack script executed"
    elif message.find("Started postgres") > -1:
        context = "Local Postgres server started"
    elif message.find("Started cyc_xms_control") > -1:
        context = "XMS started"
    elif message.find("Starting Cluster (pacemaker)") > -1:
        context = "Pacemaker started"
    elif message.find("build flavor =") > -1:
        context = "Control Path container started"
    elif message.find("signal master promoted and ready for work") > -1:
        context = "Cluster Postgres server promoted to master"
    elif message.find("started postgREST") > -1:
        context = "PostgREST server started"
    elif message.find("HTTP/1.1\" 200 - \"\" \"Vert.x-WebClient") > -1:
        context = "PostgREST starts answering REST queries"
    elif message.find("VerticleDeployer: Deployed { VASA API") > -1:
        context = "VASA Verticle Deployed"
    elif message.find("Started VASA session") > -1:
        context = "Started VASA session"
    elif message.find("listening on IPv6 address \"::\", port 5433") > -1:
        context = "CP can now connect to postgres"
    elif message.find("bindVirtualVolume response") > -1:
        context = "bindVirtualVolume response (it's VM's vvol) the time when VM restarted"
    if context:
        info("\n==" + context + "==")
    else:
        info("")


@try_catch_decorator
def cp_boot_sequence(files):
    """ Search multiple journals to track CP Boot Sequence"""
    journal_dir = re.findall("(.*/powerstore-triage/journal/node_.)\n", files)
    if len(journal_dir) == 0:
        print_header("Journal")
        error("No processed journals found.")
        error("Please run 'cyc_triage.pl -j' first then rerun with -m")
    else:
        print_header("Going through journals to find CP Boot Sequence ")
    for node in journal_dir:
        print_header(node.replace(DC_PATH, ''))
        boot_list = []
        cp_boot_sequence_journal_search(node, "ha_hint requested during repository read", "xtremapp", boot_list)
        cp_boot_sequence_journal_search(node, "starting master Stack", "ha-engine", boot_list)
        cp_boot_sequence_journal_search(node, "Started postgres", "bsc-postgres", boot_list)
        cp_boot_sequence_journal_search(node, "Started cyc_xms_control", "systemd", boot_list)
        cp_boot_sequence_journal_search(node, "Starting Cluster \(pacemaker\)", "bsc-pacemaker_cluster", boot_list)
        cp_boot_sequence_journal_search(node, 'listening on IPv6 address \"::\", port 5433', "postgres_cluster", boot_list)
        cp_boot_sequence_journal_search(node, "build flavor =|" +
                                              "VerticleDeployer: Deployed { VASA API|" +
                                              "Registered PSA|" +
                                              "Started VASA session|" +
                                              " bindVirtualVolume response ", "control-path", boot_list)
        cp_boot_sequence_journal_search(node, "signal master promoted and ready for work", "cyc-cluster-master", boot_list)
        cp_boot_sequence_journal_search(node, "started postgREST", "cp_postgrest", boot_list)
        cp_boot_sequence_journal_search(node, 'HTTP/1.1\" 200 - \"\" \"Vert.x-WebClient', "cp_postgrest", boot_list)
        boot_list.sort()
        vert = False
        currentTime = False
        started = False
        totalTime = datetime.timedelta(days=0, hours=0, minutes=0, seconds=0)
        for boot in boot_list:
            if (boot.find("ha_hint requested during repository read") > -1 or boot.find("starting master Stack") > -1) and not started:
                print_header("New CP Boot Sequence")
                currentTime = False
                totalTime = datetime.timedelta(days=0, hours=0, minutes=0, seconds=0)
                started = True
                vert = False
            else:
                started = False
            timestring = re.findall(r"\d\d \d\d:\d\d:\d\d", boot)[0]
            timestring = timestring.replace(" ", ":")
            timelist = timestring.split(":")
            if currentTime:
                if int(timelist[0]) == 0:
                    timelist[0] = currentTime.days + 1
            newtime = datetime.timedelta(days=int(timelist[0]), hours=int(timelist[1]), minutes=int(timelist[2]), seconds=int(timelist[3]))
            #totalTime += datetime.timedelta(newtime.days) - newtime
            if currentTime:
                totalTime += newtime - currentTime
            if boot.find("Vert.x-WebClient") > -1:
                if not vert:
                    vert = True
                    context_helper(boot)
                    if currentTime:
                        info("T" + str(totalTime) + " delta +" + str(newtime - currentTime))
                    info(boot)
            else:
                context_helper(boot)
                if currentTime:
                    info("T" + str(totalTime) + " delta +" + str(newtime - currentTime))
                else:
                    info("T" + str(totalTime))
                info(boot)
                currentTime = newtime


@try_catch_decorator
def cp_single_verticle_helper(verticle, count, indent, started_deploy, finished_deploy, deploy_time,
                              failed_finished_deploy, dependent_events, received_events, all_dependents_found):
    white_space = "    "
    first_white_space = ""
    for x in range(0, indent):
        white_space += "    "
        first_white_space += "    "
    if verticle not in started_deploy[count]:
        info(first_white_space + verticle + " not found.  " + verticle + " likely not the full name of a verticle.")
    else:
        if verticle in deploy_time[count]:
            info(first_white_space + verticle + "(" + deploy_time[count][verticle] + "):")
        else:
            info(first_white_space + verticle + ":")
        if started_deploy[count][verticle] == "N\\A":
            warn(white_space + "Deploy Start: " + started_deploy[count][verticle])
            warn(white_space + "Deploy Completed N\\A")
        else:
            info(white_space + "Deploy Start:     " + started_deploy[count][verticle])
            if verticle in finished_deploy[count]:
                info(white_space + "Deploy Completed: " + finished_deploy[count][verticle])
            elif verticle in failed_finished_deploy[count]:
                error(white_space + "Deploy Failed: " + failed_finished_deploy[count][verticle])
            else:
                error(white_space + "Deploy Never Finished.\n")
        if verticle in dependent_events[count]:
            events = dependent_events[count][verticle].replace("class", "")
            events = events.replace(" ", "")
            event_list = events.split(",")
            for x in range(0, len(event_list)):
                if x == 0:
                    info(white_space + "Dependent Event(s): " + str(event_list[x]))
                else:
                    info(white_space + "                    " + str(event_list[x]))
            if verticle in all_dependents_found[count]:
                success(white_space + "All dependent events received.")
            else:
                error(white_space + "Not all dependent events received.")
        else:
            info(white_space + "No Dependent Event.")
        if verticle in received_events[count]:
            for x in range(0, len(received_events[count][verticle])):
                event = json.loads(received_events[count][verticle][x])
                info(white_space + "Received Event: " + event['publisher'] + " (" + event['type'] + ")")
                if event['publisher'] == 'ClusterRoleVerticle':
                    event['publisher'] = "Cluster Role"
                cp_single_verticle_helper(event['publisher'], count, indent+1, started_deploy, finished_deploy, deploy_time,
                                          failed_finished_deploy, dependent_events, received_events, all_dependents_found)


@try_catch_decorator
def cp_verticle_deployment(files, single_verticle=0):
    journal_dir = re.findall("(.*/powerstore-triage/journal/node_.)\n", files)
    if len(journal_dir) == 0:
        print_header("Journal")
        error("No processed journals found.")
        error("Please run 'cyc_triage.pl -j' first then rerun with -m")
    elif single_verticle == 0:
        print_header("Going through journals to find CP Verticle Deployment ")
    else:
        print_header("Going through CP journal to find CP Verticle Deployment for " + single_verticle)
    for node in journal_dir:
        print_header(node.replace(DC_PATH, ''))
        verticle_list = []
        if node.find("node_a") > -1:
            count = 0
        else:
            count = -1
        cp_boot_sequence_journal_search(node, "starting master Stack", "ha-engine", verticle_list)
        cp_boot_sequence_journal_search(node, "Got Vertical Descriptor of|" +
                                              "\] has been deployed in |" +
                                              "Start deploying Verticle|" +
                                              "Failed to deploy Verticle|" +
                                              "deployment is waiting on events|" +
                                              "received event ConfigStateEvent|" +
                                              "has received all dependent events", "control-path", verticle_list)
        verticle_list.sort()
        started_deploy = [{}]
        finished_deploy = [{}]
        failed_finished_deploy = [{}]
        deploy_time = [{}]
        dependent_events = [{}]
        received_events = [{}]
        all_dependents_found = [{}]
        for verticle in verticle_list:
            if verticle.find("starting master Stack") > -1:
                count += 1
                if count > 0:
                    started_deploy.append({})
                    finished_deploy.append({})
                    failed_finished_deploy.append({})
                    deploy_time.append({})
                    dependent_events.append({})
                    received_events.append({})
                    all_dependents_found.append({})
            else:
                if verticle.find("Got Vertical Descriptor of") > -1:
                    verticle_name = re.findall(r"Got Vertical Descriptor of \[(.*)\]", verticle)
                    if verticle_name[0] not in started_deploy[count]:
                        started_deploy[count][verticle_name[0]] = "N\\A"
                if verticle.find("Start deploying Verticle") > -1:
                    verticle_name = re.findall(r"Verticle \[(.*)\] with config", verticle)
                    verticle_start = re.findall(r"\w{3} \d\d \d\d:\d\d:\d\d.\d{6}", verticle)
                    started_deploy[count][verticle_name[0]] = verticle_start[0]
                if verticle.find("has been deployed in") > -1:
                    verticle_name = re.findall(r"Verticle \[(.*)\] has been deployed", verticle)
                    verticle_end = re.findall(r"\w{3} \d\d \d\d:\d\d:\d\d.\d{6}", verticle)
                    time = re.findall(r"has been (deployed in .* ms)", verticle)
                    finished_deploy[count][verticle_name[0]] = verticle_end[0]
                    deploy_time[count][verticle_name[0]] = time[0]
                if verticle.find("Failed to deploy Verticle") > -1:
                    verticle_name = re.findall(r"Failed to deploy Verticle \[(.*)\]", verticle)
                    verticle_end = re.findall(r"\w{3} \d\d \d\d:\d\d:\d\d.\d{6}", verticle)
                    failed_finished_deploy[count][verticle_name[0]] = verticle_end[0]
                if verticle.find("deployment is waiting on events") > -1:
                    verticle_name = re.findall(r"Verticle \[(.*)\] deployment is waiting on events", verticle)
                    events = re.findall(r"deployment is waiting on events: \[(.*)\]", verticle)
                    dependent_events[count][verticle_name[0]] = events[0]
                if verticle.find("received event ConfigStateEvent") > -1:
                    verticle_name = re.findall(r"Verticle \[(.*)\] received event ConfigStateEvent", verticle)
                    received = re.findall(r"received event ConfigStateEvent{({.*})}", verticle)
                    if verticle_name[0] in received_events[count]:
                        received_events[count][verticle_name[0]].append(received[0])
                    else:
                        received_events[count][verticle_name[0]] = [received[0]]
                if verticle.find("has received all dependent events") > -1:
                    verticle_name = re.findall(r"Verticle \[(.*)\] has received all dependent events", verticle)
                    all_dependents_found[count][verticle_name[0]] = True
        if single_verticle == 0:
            # Output of entire verticle deployment
            for x in range(0, len(started_deploy)):
                print_header("New verticle Deployment")
                for key in started_deploy[x]:
                    if key in deploy_time[x]:
                        info(key + "(" + deploy_time[x][key] + "):")
                    else:
                        info(key + ":")
                    if started_deploy[x][key] == "N\\A":
                        warn("     Deploy Start: " + started_deploy[x][key])
                        warn("     Deploy Completed N\\A \n")
                    else:
                        info("     Deploy Start:     " + started_deploy[x][key])
                        if key in finished_deploy[x]:
                            info("     Deploy Completed: " + finished_deploy[x][key])
                        elif key in failed_finished_deploy[x]:
                            error("     Deploy Failed: " + failed_finished_deploy[x][key])
                        else:
                            error("     Deploy Never Finished.")
                    if key in dependent_events[x]:
                        events = dependent_events[x][key].replace("class", "")
                        events = events.replace(" ", "")
                        event_list = events.split(",")
                        for y in range(0, len(event_list)):
                            if y == 0:
                                info("     Dependent Event(s): " + str(event_list[y]))
                            else:
                                info("                         " + str(event_list[y]))
                        if key not in all_dependents_found[x]:
                            error("     Not all dependent events received.")
                    if key in received_events[x]:
                        for z in range(0, len(received_events[x][key])):
                            event = json.loads(received_events[x][key][z])
                            if z == 0:
                                info("     Received Event(s): " + event['publisher'] + " (" + event['type'] + ")")
                            else:
                                info("                     " + event['publisher'] + " (" + event['type'] + ")")
                    info("")
        else:
            # Output of single verticle deployment and its dependencies
            for x in range(0, len(started_deploy)):
                print_header("New Verticle Deployment")

                cp_single_verticle_helper(single_verticle, x, 0, started_deploy, finished_deploy, deploy_time,
                                          failed_finished_deploy, dependent_events, received_events, all_dependents_found)


if __name__ == "__main__":
    logging.basicConfig(format='%(message)s', level=logging.DEBUG)
    """Define the parser arguments"""
    parser = argparse.ArgumentParser(formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    required = parser.add_argument_group("Required Arguments")
    optional = parser.add_argument_group("Optional Arguments")

    optional.add_argument('-dc',
                          required=False,
                          default="",
                          help="Path to top level datacollect directory to triage")
    optional.add_argument("-b", "--basic",
                          required=False,
                          default="",
                          help="Used to determine if just the basic checks will be executed.",
                          action="store_true")
    optional.add_argument("-sm", "--statemachine",
                          required=False,
                          default="",
                          help="Used to determine if just the state machine analysis will be executed.",
                          action="store_true")
    optional.add_argument("-gs", "--gateway",
                          required=False,
                          default="",
                          help="Used to determine if just the state machine analysis will be executed.",
                          action="store_true")
    optional.add_argument("-p", "--panic",
                          required=False,
                          default="",
                          help="Used to determine if any panic occured as xtremapp entries for bsc.",
                          action="store_true")
    optional.add_argument("-t", "--timeline",
                          required=False,
                          default="",
                          help="Used to determine if CP Boot Timeline will be run.",
                          action="store_true")
    optional.add_argument("-v", "--verticle",
                          required=False,
                          default="",
                          help="Used to determine if CP verticle Deployment timeline.",
                          action="store_true")
    optional.add_argument("-sv", "--singleverticle",
                          required=False,
                          default="",
                          help="Used to determine if CP Boot Timeline will be run for a specific verticle.")
    optional.add_argument("-a", "--all",
                          required=False,
                          default="",
                          help="Used to run all tests.",
                          action="store_true")
    # Add more deep analysis options or other options here!!, use previous argument as example

    args = parser.parse_args()

    file_cleanup()

    DC_PATH = args.dc
    STD_JOURNAL_CMD = "{0} --utc -D . -t ".format(get_journal_cmd(DC_PATH))
    files = walk_datacollect(args.dc)
    if (not args.timeline and not args.gateway and not args.statemachine and not args.panic and not args.verticle and not args.singleverticle) or args.all:
        # non Journal checks
        idle_in_transaction(files)
        find_hs_err(files)
        check_for_oom_killer(files)
        check_for_command_inprogress_failed(files)
        check_gc(files)
        process_cp_fail_handler_journal(files)
        docker_ps(files)
        process_memory_thread_count(files)
        check_pending_locks(files)
        # Journal checks
        process_cp_journal(files)
        process_crmd_journal(files)

    if (not args.basic and not args.timeline and not args.verticle and not args.singleverticle) or args.all:
        deep_analysis(files, args)

    if args.timeline or args.all:
        cp_boot_sequence(files)

    if args.verticle or args.all:
        cp_verticle_deployment(files)

    if args.singleverticle:
        cp_verticle_deployment(files, args.singleverticle)

    write_to_summary.close()