from data_normalizer.netowrking_info_normalizer import normalize_networking_info
from text_report.common import generate_report_from_list_of_dict


def sort_network_id(a_dict):
    # logger.debug(a_dict)
    if a_dict["appliance_id"] is None:
        appliance_id = 0
    else:
        appliance_id = int(a_dict["appliance_id"][-1])
    if a_dict["node_id"] is None:
        node_id = 0
    else:
        node_id = int(a_dict["node_id"][-1])
    return [appliance_id, int(a_dict["network_id"][-1]),a_dict["purposes"], node_id]


def report_network_info(dc_folder, output_fp):
    report_name_str = "Networking Information"
    header, list_of_dict = normalize_networking_info(dc_folder)
    generate_report_from_list_of_dict(output_fp, report_name_str, list_of_dict, header,
                                      vertical=False, sort_func=sort_network_id)
