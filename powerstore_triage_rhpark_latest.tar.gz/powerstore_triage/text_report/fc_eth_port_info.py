from infra.utils import TOOL_NAME, get_mgmt_data_file_path
from text_report.common import generate_report_from_list_of_dict
import os
import json
import logging

logger = logging.getLogger('.'.join([TOOL_NAME, __name__]))


def report_fc_eth_port_info(dc_folder, output_fp):
    report_name_str = "FC and Eth Port Information"
    header = ["name", "appliance_id", "type", "is_link_up", "current_speed", "wwn",
              "mac_address", "current_mtu", "requested_speed", "port_connector_type"]
    fc_eth_port_view_file_path = get_mgmt_data_file_path(dc_folder, 'fc_eth_port_view.json')
    if fc_eth_port_view_file_path:
        logger.debug(fc_eth_port_view_file_path)
        logger.debug(header)
        with open(fc_eth_port_view_file_path, 'r') as f:
            data = json.load(f)
            list_of_dict = data['data']
            # for i, record in enumerate(list_of_dict):
            #     if record["x"]:
            #         list_of_dict[i]["y"] = record["x"]
            generate_report_from_list_of_dict(output_fp, report_name_str, list_of_dict, header, vertical=False)
    else:
        logger.warning("fc_eth_port_view.json is not found.")
