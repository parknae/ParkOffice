import os
import json
import logging
import re
from infra.utils import TOOL_NAME, TOOL_OUTPUT_FOLDER, get_mgmt_data_internal_file_path, handle_exceptions

logger = logging.getLogger('.'.join([TOOL_NAME, __name__]))

# object (fsid %(fsid))'s free space is normal
# Enclosure %(encl_num) %(identification) PHY %(phy_ports[].phy_index) health status
attr_pattern = re.compile(r'%\([^ \)]+\)')
key_pattern = re.compile(r'%\(([^ \)]+)\)')

def repl_func(match):
    #add a "s" after the pattern so that python string formatting can work
    return match.group() + 's'


@handle_exceptions
def generate_event_log(dc_folder):
    output_file_path = os.path.join(dc_folder, TOOL_OUTPUT_FOLDER, "event.txt")
    event_file_path = get_mgmt_data_internal_file_path(dc_folder, 'event.json')
    event_catalog_file_path = get_mgmt_data_internal_file_path(dc_folder, 'event_catalog.json')
    event_code_to_description = dict() 
    if event_catalog_file_path:
        with open(event_catalog_file_path, 'r') as fp:
            data = json.load(fp)
            for item in data['data']:
                event_code_to_description[item['event_code']] = item['description']
            # {
            #     "base_event_name": "DATA_PATH_USER_TIER_CAPACITY_UTILIZATION",
            #     "description": "Capacity utilization is above 70 percent.",
            #     "event_code": 2100737,
            #     "event_name": "DATA_PATH_USER_TIER_CAPACITY_UTILIZATION_ABOVE_70_PERCENT",
            #     "locale": "en-US",
            #     "object_type": "appliance",
            #     "persistence_type": "standard",
            #     "repair_flow": "Add additional storage to the existing appliance or move storage resources within the cluster to another appliance.",
            #     "severity": "Minor",
            #     "system_impact": "Cluster performance may be impacted.",
            #     "title": "Mapper user data tier capacity usage level (above_70_percent)"
            # },
            # {
            #     "base_event_name": "DATA_PATH_WRITE_PROTECT_MODE",
            #     "description": "All %(tier_name) capacity has been consumed. Entering write protection mode.",
            #     "event_code": 2098945,
            #     "event_name": "DATA_PATH_WRITE_PROTECT_MODE_ENTER",
            #     "locale": "en-US",
            #     "object_type": "appliance",
            #     "persistence_type": "standard",
            #     "repair_flow": "%(write_protect_repair_flow)",
            #     "severity": "Critical",
            #     "system_impact": "Writing data is no longer possible until more capacity is made available.",
            #     "title": "Space utilization reached hard limit (enter)"
            # },


    if event_file_path:
        logger.debug(event_file_path)
        with open(event_file_path, 'r') as f:
            data = json.load(f)
            list_of_event = data['data']
            list_of_event.sort(key=lambda record: record['generated_timestamp'])

        with open(output_file_path, 'w+') as o_fp:
            for record in list_of_event:
                if 'node_originator' in record: # older version format
                    if record['node_originator'] == "UNKNOWN":
                        record['node_originator'] = ''
                    message = "{generated_timestamp} {severity} {event_code} {appliance_originator} node_originator:{node_originator} resource_name:{resource_name} description:{description_l10n}".format(**record)
                elif 'metadata' in record: # newer version (ast least since 1.0.0.1.3.867)
                    if record['node_id'] == "UNKNOWN":
                        record['node_id'] = ''
                    if event_catalog_file_path:
                        if record['event_code'] in event_code_to_description:
                            # print(record['id'])
                            description = event_code_to_description[record['event_code']]
                            # print(description)
                            # example: 
                            # "description": "The consumed storage space of appliance %(appliance_id) is below  96% capacity.",
                            # "description": "Root partition usage of node %(which) is %(percent)%.",
                            #key_pattern: re.compile(r'%\(([^ \)]+)\)')
                            attr_in_desc = re.findall(key_pattern, description)
                            #attr_in_desc: ['appliance_id']
                            # attr_pattern: re.compile(r'%\([^ \)]+\)')
                            description = attr_pattern.sub(repl_func, description)
                            # escape '% ' in description string
                            description = description.replace("% ", "%% ")
                            description = description.replace("%.", "%% ")
                            # escape % at the end of a description string
                            description = re.sub('%$', '%%', description)
                            # now the description string is as the following:
                            # The consumed storage space of appliance %(appliance_id)s is below  96%% capacity.
                            # "Root partition usage of node %(which)s is %(percent)s%%."
                            #print(description)
                            metadata_dict = json.loads(record['metadata'])
                            # there is bug where the attr in the description doesn't exist in metadata
                            # the following is to set the value of such attr to <undified>
                            for attr in attr_in_desc:
                                if attr not in metadata_dict:
                                    metadata_dict[attr] = '<undefined>'
                            #print(record['metadata'])
                            record['event_code'] = "0x%08x" %(int(record['event_code']))
                            # logger.info(record)
                            # logger.info(description)
                            # logger.info(metadata_dict)
                            message = "{generated_timestamp} {severity} code:{event_code} {appliance_id} node_id:{node_id} object_name:{object_name} ".format(**record) + "description:" + description % metadata_dict
                        else:
                            record['event_code'] = "0x%08x" %(int(record['event_code']))
                            message = "{generated_timestamp} {severity} event_code:{event_code} {appliance_id} node_id:{node_id} object_name:{object_name} {name}".format(**record)
                    else:
                        record['event_code'] = "0x%08x" %(int(record['event_code']))
                        message = "{generated_timestamp} {severity} event_code:{event_code} {appliance_id} node_id:{node_id} object_name:{object_name} {name}".format(**record)
                o_fp.write("{0}\n".format(message))
    else:
        with open(output_file_path, 'w+') as f:
            f.write("event.json is not found.\n")

# event.json
    # {
    #     "appliance_id": "A1",
    #     "base_event_code": 2100736,
    #     "event_code": 2100737,
    #     "generated_timestamp": "2020-04-30 13:07:19.182765+00:00",
    #     "id": "fb868eba-6fab-a651-8b43-7ca12f13e2f1",
    #     "metadata": "{}",
    #     "name": "DATA_PATH_USER_TIER_CAPACITY_UTILIZATION_ABOVE_70_PERCENT",
    #     "node_id": "N1",
    #     "object_id": "A1",
    #     "object_name": "H4032-appliance-1",
    #     "object_type": "appliance",
    #     "received_timestamp": "2020-04-30 13:07:19.211000+00:00",
    #     "sequence_number": 473,
    #     "severity": "minor",
    #     "version": 1
    # },
    # {
    #     "appliance_id": "A1",
    #     "base_event_code": 2098944,
    #     "event_code": 2098945,
    #     "generated_timestamp": "2020-04-30 13:27:39.049040+00:00",
    #     "id": "a6a2ed16-02a6-6ed9-66b9-cf56f95c3570",
    #     "metadata": "{\"tier_name\":\"system data\",\"write_protect_repair_flow\":\"Add additional storage to the appliance or move storage resources within the cluster to another appliance or continues to delete volumes/snaps/objects.\"}",
    #     "name": "DATA_PATH_WRITE_PROTECT_MODE_ENTER",
    #     "node_id": "N2",
    #     "object_id": "A1",
    #     "object_name": "H4032-appliance-1",
    #     "object_type": "appliance",
    #     "received_timestamp": "2020-04-30 13:27:39.076000+00:00",
    #     "sequence_number": 475,
    #     "severity": "critical",
    #     "version": 1
    # },
