import os
import json
import logging
from infra.utils import TOOL_NAME, convert_unit_as_needed, get_cols_width, get_mgmt_data_file_path
from texttable import Texttable
logger = logging.getLogger('.'.join([TOOL_NAME, __name__]))


def sort_by_first_column_and_appliance_id(a_dict, first_column_name):
    if 'appliance_id' in a_dict.keys():
        return [a_dict['appliance_id'], a_dict[first_column_name]]
    else:
        return a_dict[first_column_name]


def generate_report_from_config_capture_file(dc_folder, output_fp, report_name_str, json_file_name,
                                             header, vertical=False, sort_func=None):
    json_file_path = get_mgmt_data_file_path(dc_folder, json_file_name)
    logger.debug(report_name_str)
    logger.debug(json_file_path)
    if json_file_path:
        with open(json_file_path, 'r') as f:
            data = json.load(f)
            # logger.debug(data)
            decoration_str = '*'*60
            # if "Appliance Information", print on the screen
            if report_name_str == "Appliance Information":
                print("{0}\n{1}\n{2}".format(decoration_str, report_name_str, decoration_str))
            output_fp.write("{0}\n{1}\n{2}\n".format(decoration_str, report_name_str, decoration_str))
            logger.debug("Report in vertical: {0}".format(vertical))
            # some object may not exists, for example, host group could be empty as none is configured.
            if data['data']:
                if sort_func:
                    sorted_list = sorted(data['data'], key=sort_func)
                else:
                    sorted_list = sorted(data['data'], key=lambda x: sort_by_first_column_and_appliance_id(x, header[0]))
                if vertical:

                    for record in sorted_list:
                        # logger.debug(record)
                        keys = record.keys()
                        width = max(len(x) for x in header)
                        for k in header:
                            if k in keys:
                                # if "Appliance Information", print on the screen
                                if report_name_str == "Appliance Information":
                                    print("{0:<{1}} : {2}".format(k, width, record[k]))
                                output_fp.write("{0:<{1}} : {2}\n".format(k, width, record[k]))
                else:
                    table = Texttable()
                    table.set_deco(Texttable.HEADER | Texttable.VLINES | Texttable.BORDER)
                    table.set_cols_dtype(["t"] * len(header))
                    table.set_cols_width(get_cols_width(header, data['data']))
                    table.add_row(header)
                    for record in sorted_list:
                        keys = record.keys()
                        table.add_row([convert_unit_as_needed(k, record[k]) if k in keys else " " for k in header])
                    output_fp.write(table.draw())
            else:
                output_fp.write("None")
            output_fp.write("\n\n")


def generate_report_from_list_of_dict(output_fp, report_name_str, list_of_dict, header, vertical=False, sort_func=None):
    logger.debug(report_name_str)
    # logger.debug(list_of_dict)
    logger.debug(header)
    decoration_str = '*'*60
    # if "Appliance Information", print on the screen
    if report_name_str == "Appliance Information" or report_name_str == "Data Collection Information":
        print("{0}\n{1}\n{2}".format(decoration_str, report_name_str, decoration_str))
    output_fp.write("{0}\n{1}\n{2}\n".format(decoration_str, report_name_str, decoration_str))
    logger.debug("Report in vertical: {0}".format(vertical))
    # some object may not exists, for example, host group could be empty as none is configured.
    if list_of_dict:
        if sort_func:
            sorted_list = sorted(list_of_dict, key=sort_func)
        else:
            sorted_list = sorted(list_of_dict, key=lambda x: sort_by_first_column_and_appliance_id(x, header[0]))
        if vertical:
            for record in sorted_list:
                # logger.debug(record)
                keys = record.keys()
                width = max(len(x) for x in keys)
                for k in header:
                    if k in keys:
                        # if "Appliance Information", print on the screen
                        if report_name_str == "Appliance Information" or report_name_str == "Data Collection Information":
                            print("{0:<{1}} : {2}".format(k, width, record[k]))
                        output_fp.write("{0:<{1}} : {2}\n".format(k, width, record[k]))
        else:
            table = Texttable()
            table.set_deco(Texttable.HEADER | Texttable.VLINES | Texttable.BORDER)
            table.set_cols_dtype(["t"]*len(header))
            table.set_cols_width(get_cols_width(header, list_of_dict))
            table.add_row(header)
            for record in sorted_list:
                keys = record.keys()
                table.add_row([convert_unit_as_needed(k, record[k]) if k in keys else " " for k in header])
            output_fp.write(table.draw())
    else:
        output_fp.write("None\n")
    output_fp.write("\n\n")


def generate_report_from_dict(output_fp, report_name_str, a_dict, customer_controlled_keys=None):
    logger.debug(report_name_str)
    decoration_str = '*'*60
    keys = a_dict.keys()
    output_fp.write("{0}\n{1}\n{2}\n".format(decoration_str, report_name_str, decoration_str))
    if a_dict:
        width = max(len(x) for x in keys)
        if customer_controlled_keys:
            for k in customer_controlled_keys:
                if k in a_dict:
                    output_fp.write("{0:<{1}} : {2}\n".format(k, width, a_dict[k]))
        else:
            for k in a_dict:
                output_fp.write("{0:<{1}} : {2}\n".format(k, width, a_dict[k]))
    else:
        output_fp.write("None\n")
    output_fp.write("\n\n")


def generate_report_from_list(output_fp, report_name_str, a_list):
    # a_list is a list of list
    logger.debug(report_name_str)
    decoration_str = '*'*60
    output_fp.write("{0}\n{1}\n{2}\n".format(decoration_str, report_name_str, decoration_str))
    if a_list:
        table = Texttable()
        table.set_deco(Texttable.HEADER | Texttable.VLINES | Texttable.BORDER)
        table.set_cols_dtype(["t"]*len(a_list[0]))
        for li in a_list:
            table.add_row(li)
        output_fp.write(table.draw())
    else:
        output_fp.write("None\n")
    output_fp.write("\n\n")