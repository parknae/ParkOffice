from text_report.common import generate_report_from_list_of_dict
from data_normalizer.host_info_normalizer import normalize_host_info


def report_host_info(dc_folder, output_fp):
    report_name_str = "Host & Host Group Information"
    header, list_of_host = normalize_host_info(dc_folder)
    generate_report_from_list_of_dict(output_fp, report_name_str, list_of_host, header)


