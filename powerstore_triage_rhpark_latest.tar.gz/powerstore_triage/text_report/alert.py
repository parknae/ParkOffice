import os
import json
import logging
from infra.utils import TOOL_NAME, TOOL_OUTPUT_FOLDER, get_mgmt_data_file_path, handle_exceptions

logger = logging.getLogger('.'.join([TOOL_NAME, __name__]))

@handle_exceptions
def generate_alert_log(dc_folder):
    output_file_path = os.path.join(dc_folder, TOOL_OUTPUT_FOLDER, "alert.txt")
    alert_file_path = get_mgmt_data_file_path(dc_folder, 'alert.json')
    if alert_file_path:
        logger.debug(alert_file_path)
        with open(alert_file_path, 'r') as f:
            data = json.load(f)
            list_of_dict = data['data']
            list_of_dict.sort(key=lambda record: record['raised_timestamp'])

        with open(output_file_path, 'w+') as f:
            for record in list_of_dict:
                if record['state'] == "CLEARED":
                    message =  "{raised_timestamp} {event_code} state:{state} is_acknowledged:{is_acknowledged} severity:{severity} appliance:{appliance_originator} resourse:{resource_name} {description_l10n} cleared_timestamp:{cleared_timestamp}".format(**record)
                elif record['is_acknowledged']:
                    message =  "{raised_timestamp} {event_code} state:{state} is_acknowledged:{is_acknowledged} severity:{severity} appliance:{appliance_originator} resourse:{resource_name} {description_l10n} acknowledged_timestamp:{acknowledged_timestamp}".format(**record)
                else:
                    message = "{raised_timestamp} {event_code} state:{state} is_acknowledged:{is_acknowledged} severity:{severity} appliance:{appliance_originator} resourse:{resource_name} {description_l10n}".format(**record)
                f.write("{0}\n".format(message))
    else:
        with open(output_file_path, 'w+') as f:
            f.write("alert.json is not found.\n")