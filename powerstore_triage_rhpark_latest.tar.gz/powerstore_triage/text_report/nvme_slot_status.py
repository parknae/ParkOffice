from infra.utils import TOOL_NAME, get_sym_node_command_output_file_path
import os
import json
import logging
import re


empty_line_pattern = re.compile(r'^$')

logger = logging.getLogger('.'.join([TOOL_NAME, __name__]))

def report_nvme_slot_status(dc_folder, output_fp):
    decoration_str = '*'*60
    report_name_str = "NVMe Slot Status Information(command_output/nvme_drive.py.txt)"
    output_fp.write("{0}\n{1}\n{2}\n".format(decoration_str, report_name_str, decoration_str))
    # only need to use the output from one of the node
    file_path = get_sym_node_command_output_file_path(dc_folder, 'nvme_drive.py.txt')
    if file_path:
        logger.debug(file_path)
        nvme_slot_status_section = False
        with open(file_path, 'r') as fp:
            for line in fp:
                if line.startswith('# NVMe Slot Status'):
                    nvme_slot_status_section = True
                elif nvme_slot_status_section and not (line.startswith("###") or empty_line_pattern.match(line)):
                    output_fp.write(line)