import yaml
import os
import shutil
import threading
from infra.utils import TOOL_NAME, TOOL_OUTPUT_FOLDER, TOOL_TMP_FOLDER, FILTERED_LOG_FOLDER, handle_exceptions, JOURNAL_A_TEXT, JOURNAL_B_TEXT
import logging
from log_filter.filters import filter_create_cluster_related_log
from infra.process_journal import generate_journal_time_option

logger = logging.getLogger('.'.join([TOOL_NAME, __name__]))


def generate_keyword_files(workspace, product_generation=None):
    logger.info("Generating keywords files...")
    keywords_file = os.path.join(os.path.dirname(os.path.realpath(__file__)), 
                                'keywords.yaml')
    tag_to_pattern_dict = {}
    with open(keywords_file) as f:
        # use BaseLoader to leave everything as a string
        keyword_dict = yaml.load(f, Loader=yaml.BaseLoader)
        for keyword, prop in keyword_dict.items():
            for tag in prop['tags']:
                tag_to_pattern_dict.setdefault(tag, []).append(keyword)
    keywords_file_names = []
    keyword_file_folder = os.path.join(workspace, TOOL_OUTPUT_FOLDER, 
                                        FILTERED_LOG_FOLDER,'keyword_files')
    logger.info("Keywords files are put under %s" % keyword_file_folder)
    if os.path.exists(keyword_file_folder) and os.path.isdir(keyword_file_folder):
        shutil.rmtree(keyword_file_folder)
    os.makedirs(keyword_file_folder) # Recursive directory creation
    for tag, keywords in tag_to_pattern_dict.items():
        with open(os.path.join(keyword_file_folder, '%s.txt' % tag), 'w') as f:
            f.writelines("\n".join(keywords))
            keywords_file_names.append('%s.txt' % tag)
    with open(os.path.join(keyword_file_folder, 'all.txt'), 'w') as f:
        f.writelines("\n".join(keyword_dict.keys()))
    logger.info("Finished generating keywords files")
    return keywords_file_names, keyword_file_folder


@handle_exceptions
def filter_blackbox_log(dc_folder, from_time, to_time):
    for journal_file in ['journal_a.txt', 'journal_b.txt']:
        journal_file_path = os.path.join(dc_folder, TOOL_OUTPUT_FOLDER, journal_file)
        node = journal_file.split('.')[0].split("_")[-1]
        output_file_path = os.path.join(dc_folder, TOOL_OUTPUT_FOLDER, FILTERED_LOG_FOLDER, "blackbox_%s.txt" %node)
        # The empty regular expression ‘//’ repeats the last regular expression match
        # no easy way to to exclude the second address in sed, just leave it there.
        cmd_str = r"sed -n -e '/blackbox/,/^\w/ p' %s > %s" %(journal_file_path, output_file_path)
        logger.debug(cmd_str)
        os.system(cmd_str)


@handle_exceptions
def filter_log(dc_folder, from_time, to_time):
    # TODO: remove filter_create_cluster_related_log
    filter_create_cluster_related_log(dc_folder, from_time, to_time)

    grep_all_threads = list()
    keywords_file_names, keyword_file_folder = generate_keyword_files(dc_folder)
    logger.info("Generating filtered log files...")
    for journal_file_name in [JOURNAL_A_TEXT, JOURNAL_B_TEXT]:
        # "A" or "B"
        node = journal_file_name.split("_")[-1].split(".")[0].upper()
        keyword_file = os.path.join(keyword_file_folder, 'all.txt')
        output_file = os.path.join(dc_folder, TOOL_OUTPUT_FOLDER, FILTERED_LOG_FOLDER, 'all_%s.txt' % node)
        journal_file_name = os.path.join(dc_folder, TOOL_OUTPUT_FOLDER, journal_file_name)
        # Add '-A' or '-B' after 'localhost' and 'cyc-coreos' by using sed "s/\(+0000 localhost\|+0000 cyc-coreos\)/\1-A/"
        # 2020-03-06T14:24:32.866213+0000 localhost kernel: x86/fpu: Supporting XSAVE feature 0x001: 'x87 floating point registers'
        # 2020-03-06T14:26:40.534792+0000 cyc-coreos systemd[1]: Starting Wait for Network to be Configured...
        cmd_str = r'grep -h -F -f %s %s|sed "s/\(+0000 localhost\|+0000 cyc-coreos\)/\1-%s/" ' %(keyword_file, journal_file_name, node) + \
                  r"|awk '$3 ~/xtremapp/ {$0=gensub(/(xtremapp.*\[\w+\]:).* (\w+ \[log_id:\w+\])\[.* (\w+_\S+)\s+\S+\)\]/," + \
                  r'"\\1 \\2[\\3]","g")} {print}' + r"'" + r'|grep -v "1043 \(Object Not Found\)\|1041 \(Duplicate Entry\)\|use secondary M2\|svc_time="' + " > %s " % output_file
        # exclude: 2020-06-01T13:09:20.700218+0000 FNM00191700209-B xtremapp[68211]: X11 [log_id:0][nb_truck_34]CompleteOperation:1145: NS:FS:CreateObject:[2609 us]: Create e08527a1-2e07-4488-9fa5-bfdd51fb66d4:4:0/DPEventObjectBase failed; status = 1041 (Duplicate Entry)
        # exclude: 2020-06-07T06:40:51.000539+0000 FNM00183202535-A xtremapp[111634]: X10 [log_id:0][nb_truck_12]CompleteOperation:186: NS:NS:GetAttributes:[104 us]: :/51f2adea-d7cd-4a45-b5e0-b2b6e2e001e1 failed; status= 1043 (Object Not Found)
        # exclude: 2020-06-04T06:06:16.589822+0000 FNM00191700926-A servicemode[124028]: determine_deployment BM-Warnado-EX reboot-node use secondary M2? yes
        # exclude: 2020-06-03T00:50:05.260427+0000 FNM00191500462-A servicemode[72825]: determine_deployment Virtual-Warnado-EX reboot-cvm use secondary M2? yes
        logger.debug(cmd_str)
        thr = threading.Thread(target=os.system, args=(cmd_str,))
        grep_all_threads.append(thr)
        thr.start()
    for thr in grep_all_threads:
        thr.join()

    grep_threads = list()
    for keyword_file_name in keywords_file_names:
        key_world_file_path = os.path.join(keyword_file_folder, keyword_file_name)
        journal_file_path = os.path.join(dc_folder, TOOL_OUTPUT_FOLDER, FILTERED_LOG_FOLDER, "all_*.txt")
        output_file = os.path.join(dc_folder, TOOL_OUTPUT_FOLDER, FILTERED_LOG_FOLDER, keyword_file_name)
        cmd_str = r'grep -h -F -f %s %s|/usr/bin/sort -k 1 > %s' %(key_world_file_path, journal_file_path, output_file)
        logger.debug(cmd_str)
        grep_threads.append(threading.Thread(target=os.system, args=(cmd_str,)))
    grep_threads.append(threading.Thread(target=filter_blackbox_log, args=(dc_folder, from_time, to_time,)))
    for thr in grep_threads:
        thr.start()
    for thr in grep_threads:
        thr.join()

    logger.info("Finished generating filtered log files")


# |awk '$3 ~/xtremapp/ {$0=gensub(/(xtremapp.*\[\w+\]:).* (\w \[log_id:\w+\])\[.* (\w+_\S+)\s+\S+\)\]/,"\\1 \\2[\\3]","g")} {print}'
# Convert:
# 2020-05-29T08:53:03.758077+0000 FNM00190201027-A xtremapp-pm[13938]: May 29 08:53:03.758059 P [log_id:42346][2232(2389 self_fence_kdump_monitor 0x7f3f60da0980)]pm_self_fence_kernel_panic_load_module:397: KDUMP_NOTIFY: load kernel panic fencing module
# To:
# 2020-05-29T08:53:03.758077+0000 FNM00190201027-A xtremapp-pm[13938]: P [log_id:42346][self_fence_kdump_monitor]pm_self_fence_kernel_panic_load_module:397: KDUMP_NOTIFY: load kernel panic fencing module
# or leave the line as it is if xtremapp is not found in the line