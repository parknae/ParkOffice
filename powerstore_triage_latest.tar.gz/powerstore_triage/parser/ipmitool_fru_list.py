import json
import os
import re
import logging
from infra.utils import TOOL_NAME, TOOL_OUTPUT_FOLDER, TOOL_TMP_FOLDER

# the parent logger will be the logger with name defined by TOOL_NAME
logger = logging.getLogger('.'.join([TOOL_NAME, __name__]))


def parse_ipmitool_fru_list(dc_folder):
    fru_description_pattern = re.compile(r'^FRU Device Description')
    # FRU Device Description : Builtin FRU Device (ID 0)
    for node_name in ["node_a", "node_b"]:
        file_path = os.path.join(dc_folder, node_name, "command_output/cyc_ipmitool_fru_list.txt")
        if os.path.exists(file_path):
            logger.debug("Parsing {0} cyc_ipmitool_fru_list.txt".format(node_name))
            with open(file_path, 'r', encoding="utf8", errors='ignore') as f:
                # the following line in cyc_ipmitool_fru_list.txt can cause decoding error, thus use errors='ignore'
                #  Product Part Number   : <FF><FF><FF><FF><FF><FF><FF><FF><FF><FF><FF><FF><FF><FF><FF><FF>
                fru_list = list()
                record = dict()
                for line in f:
                    if fru_description_pattern.match(line):
                        if record != {}:
                            fru_list.append(record)
                        # empty record
                        record = dict()
                        fru_name, fru_id = line.split(":")[1].split("(")
                        fru_name = fru_name.strip()
                        fru_id = fru_id.strip().rstrip(")").split()[1]
                        if fru_id == '0':
                            fru_name = node_name
                        if fru_id == "1":
                            if node_name == "node_a":
                                fru_name = "node_b"
                            else:
                                fru_name = "node_a"
                        record['fru_name'] = fru_name
                        record['fru_id'] = fru_id
                    else:
                        # Board Serial          : FCNSP191400105
                        k_v = line.split(":")
                        if len(k_v) == 2:
                            record[k_v[0].strip()] = k_v[1].strip()
                # append the last record
                fru_list.append(record)
            with open(os.path.join(dc_folder, TOOL_OUTPUT_FOLDER, TOOL_TMP_FOLDER, "{0}_ipmitool_fru_list.json".format(node_name)), 'w+') as out_fp:
                json.dump(fru_list, out_fp)
