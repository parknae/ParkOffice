import os
import json
import subprocess
import yaml
from infra.utils import TOOL_NAME, TOOL_OUTPUT_FOLDER, TOOL_TMP_FOLDER, get_node_file, handle_exceptions
import logging

logger = logging.getLogger('.'.join([TOOL_NAME, __name__]))

@handle_exceptions
def parse_cyc_net_discovery_info_list(dc_folder):
    for node_name in ["node_a", "node_b"]:
        cyc_net_discovery_info = dict()
        cyc_net_discovery_info_file_path = get_node_file(dc_folder, node_name, os.path.join("command_output", "cyc_net_client_-node_local_-realm_L2D_-command_get_l2_discovery_info_-verbose_1.txt"))
        if cyc_net_discovery_info_file_path:
            logger.debug("%s: %s" %(node_name,cyc_net_discovery_info_file_path))
            # cmd_str = r"sed -e '/<<</,/>>>/d' -e '/L2D command reply/,/Number of known uplinks/d' -e 's/\t/    /g' -e 's/\r//g' -e '/^\*\+$/d' -e 's/info$/info:/g' -e 's/.*Information for uplink \([a-zA-Z0-9]\+\) .*/\1:/g' -e 's/\(System description: .*\):.*/\1/g' -e 's/\(System description: .*\)TAC.*/\1/g' -e 's/\(System description: .*\)Copyright.*/\1/g' -e 's/System description:.*\(Dell .*Application Software Version:.*\)/System description: \1/g' -e '/System description:/s/://g' -e '/System description /s/System description /System description: /g' -e '/^\s\{4,\}Version:/s/://g' " + cyc_net_discovery_info_file_path
            cmd_str = r"sed -e '/<<</,/>>>/d' -e '/L2D command reply/,/Number of known uplinks/d' -e 's/\t/    /g' -e 's/\r//g' -e '/^\*\+$/d' -e 's/info$/info:/g' -e 's/.*Information for uplink \([a-zA-Z0-9]\+\) .*/\1:/g' -e '/System description:/s/://g' -e '/System description /s/System description /System description: /g' -e '/^\s\{4,\}Version:/s/://g' -e '/^\s\{4,\}Version /s/\(^\s\{4,\}Version\) /\1: /g' " + cyc_net_discovery_info_file_path
            logger.debug(cmd_str)
            exitcode, output = subprocess.getstatusoutput(cmd_str)
            # logger.info(output)
            if exitcode != 0:
                logger.error("Error encountered while converting %s's cyc_net_client_-node_local_-realm_L2D_-command_get_l2_discovery_info_-verbose_1.txt"  % node_name)
            cyc_net_discovery_info = yaml.safe_load(output)
            # logger.debug(cyc_net_discovery_info)
            with open(os.path.join(dc_folder, TOOL_OUTPUT_FOLDER, TOOL_TMP_FOLDER, "%s_cyc_net_discovery_info.json" % node_name), 'w+') as out_fp:
                json.dump(cyc_net_discovery_info, out_fp)
        else:
            logger.warning("File cyc_net_client_-node_local_-realm_L2D_-command_get_l2_discovery_info_-verbose_1.txt is not found in %s's folder" % node_name)

# sed -i -e "/<<</,/>>>/d" -e "/L2D command reply/,/Number of known uplinks/d" -e 's/\t/    /g' -e 's/\r//g' -e "/^\*\+$/d" -e 's/info$/info:/g' -e 's/.*Information for uplink \([a-zA-Z0-9]\+\) .*/\1:/g' -e 's/\(System description: .*\):.*/\1/g' -e 's/\(System description: .*\)TAC.*/\1/g' -e 's/\(System description: .*\)Copyright.*/\1/g'

# Remove the lines between '<<<' and '>>>', including the line that contains '<<<' or '>>>'
# sed -i "/<<</,/>>>/d" net.txt 
# Removed lines with '*' only 
# sed -i "/^\*\+$/d" net.txt
# replace \t with four spaces
# sed -i 's/\t/    /g' net.txt
# remove \r (i.e. ^M) character
# sed -i 's/\r//g' net.txt
# replace 'info' at the end of a line with 'info:'
# sed -i 's/info$/info:/g' net.txt
# Convert  
# Cisco Nexus Operating System (NX-OS) Software 7.1(4)N1(1) TAC support: http://www.cisco.com/tac Copyright (c) 2002-2016, Cisco Systems, Inc. All rights reserved.
# to
# Cisco Nexus Operating System (NX-OS) Software 7.1(4)N1(1) TAC support: http
# sed -i 's/\(System description: .*\):.*/\1/g' net.txt
# sed -i 's/\(System description: .*\)TAC.*/\1/g' net.txt
# convert 
# System description: Dell EMC Networking OS10 Enterprise. Copyright (c) 1999-2020 by Dell Inc. All Rights Reserved. System Description: OS10 Enterprise. OS Version: 10.5.0.3P2. System Type
# to System description: Dell EMC Networking OS10 Enterprise. 
# sed -i 's/\(System description: .*\)Copyright.*/\1/g' net.txt
# Removed the first 3 lines
# sed -i "/L2D command reply/,/Number of known uplinks/d" net.txt
# convert '*** Information for uplink eno1 ***'
# to  'eno1:'
# sed -i 's/.*Information for uplink \([a-zA-Z0-9]\+\) .*/\1:/g'
# convert 
# System description: Dell EMC Real Time Operating System Software. Dell EMC Operating System Version: 2.0. Dell EMC Application Software Version: 9.14(2.4) Copyright (c) 1999-2019 Dell Inc. All Rights Reserved.Build Time: Fri Nov  8 09:07:48 2019
# to  System description: Dell EMC Application Software Version: 9.14(2.4)
# sed -i 's/System description:.*\(Dell .*Application Software Version:.*\)/System description: \1/g'
# remove all : in System description line, then add one : after System description
# sed -i '/System description:/s/://g'
# sed -i '/System description /s/System description /System description: /g'
# remove all : Version line, then add one : after Version
# sed -i '/^\s\{4,\}Version:/s/://g'
# sed -i '/^\s\{4,\}Version /s/\(^\s\{4,\}Version\) /\(1\): /g'
# Version:          Cisco IOS Software, C3750 Software (C3750-IPSERVICESK9-M), Version 12.2(55)SE3, RELEASE SOFTWARE (fc1) Technical Support: http://www.cisco.com/techsupport Copyright (c) 1986-2011 by Cisco Systems, Inc. Compiled Thu 05-May-11 16:29 by prod_rel_team
