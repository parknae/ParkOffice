import os
import json
import re
from infra.utils import TOOL_NAME, TOOL_OUTPUT_FOLDER, TOOL_TMP_FOLDER, get_sym_node_command_output_file_path
import logging

logger = logging.getLogger('.'.join([TOOL_NAME, __name__]))

empty_line_pattern = re.compile(r'^$')

def parse_nvme_drive(dc_folder):
    file_path = get_sym_node_command_output_file_path(dc_folder, 'nvme_drive.py.txt')
    if file_path:
        logger.debug(file_path)
        nvme_drive_slot_status = dict()
        slot_number = ''
        nvme_slot_status_section = False
        with open(file_path, 'r') as fp:
            for line in fp:
                if line.startswith('# NVMe Slot Status'):
                    nvme_slot_status_section = True
                elif nvme_slot_status_section and not (line.startswith("---") or line.startswith("###") or line.startswith("SLOT") or empty_line_pattern.match(line)):
                    attributes = line.strip().split("|")
                    # make sure line is not empty
                    if attributes:
                        slot = attributes[0]
                        if len(slot.split()) == 2:
                            slot_number = slot.split()[0].strip()
                            node = slot.split()[1].strip()
                        else:
                            node = slot.strip()
                        nvme_drive_slot_status.setdefault(slot_number, {})[node] = dict()
                        ipmi_power = attributes[1].strip()
                        pfx_link, pfx_ltssm = attributes[2].split()
                        dsp_pcie_addr, drv_pcie_addr = attributes[3].split()
                        drive_name_and_model_and_sn = attributes[4].strip()
                        sn = drive_name_and_model_and_sn.split()[-1].strip()
                        model = drive_name_and_model_and_sn.split()[-2].strip()
                        drive_name = " ".join(drive_name_and_model_and_sn.split()[:-2]).strip()
                        fw_version = attributes[-3].strip()
                        nvme_c_dev, nvme_b_dev = attributes[-2].split()
                        drive_format = attributes[-1].strip()
                        nvme_drive_slot_status[slot_number][node]['ipmi_power'] = ipmi_power
                        nvme_drive_slot_status[slot_number][node]['pfx_link'] = pfx_link.strip()
                        nvme_drive_slot_status[slot_number][node]['pfx_ltssm'] = pfx_ltssm.strip()
                        nvme_drive_slot_status[slot_number][node]['dsp_pcie_addr'] = dsp_pcie_addr.strip()
                        nvme_drive_slot_status[slot_number][node]['drv_pcie_addr'] = drv_pcie_addr.strip()
                        nvme_drive_slot_status[slot_number][node]['drive_name'] = drive_name
                        nvme_drive_slot_status[slot_number][node]['model'] = model
                        nvme_drive_slot_status[slot_number][node]['sn'] = sn
                        nvme_drive_slot_status[slot_number][node]['fw_version'] = fw_version
                        nvme_drive_slot_status[slot_number][node]['nvme_c_dev'] = nvme_c_dev.strip()
                        nvme_drive_slot_status[slot_number][node]['nvme_b_dev'] = nvme_b_dev.strip()
                        nvme_drive_slot_status[slot_number][node]['drive_format'] = drive_format     
        with open(os.path.join(dc_folder, TOOL_OUTPUT_FOLDER, TOOL_TMP_FOLDER, "nvme_drive_slot_statuse.json"), 'w+') as out_fp:
            json.dump(nvme_drive_slot_status, out_fp)
        # logger.info(nvme_drive_slot_status)
    else:
        logger.warning("command_output/nvme_drive.py.txt is not found in Data Collection")

# NVMe Slot Status
##############################################################################
#
# -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
# SLOT | IPMI  | PFX LINK   PFX LTSSM  | DSP PCIe ADDR DRV PCIe ADDR | DRIVE NAME           MODEL                SN               | FW       | NVMe C_DEV  NVMe B_DEV    | FORMAT
# -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
#  0 a | PWRON | UP         L0         | 10000:02:00.0 10000:03:00.0 | Samsung PM1723b      PB23F04T             VXNA0M900524     | GPJ99E5Q | /dev/nvme0  /dev/nvme0n1  | 512+0
#    b | PWRON | UP         L0         | 10000:02:00.0 10000:03:00.0 | Samsung PM1723b      PB23F04T             VXNA0M900524     | GPJ99E5Q | /dev/nvme0  /dev/nvme0n1  | 512+0
# -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
#  1 a | PWRON | UP         L0         | 10001:02:01.0 10001:04:00.0 | Samsung PM1723b      PB23F04T             VXNA0M900875     | GPJ99E5Q | /dev/nvme7  /dev/nvme7n1  | 512+0
#    b | PWRON | UP         L0         | 10001:02:01.0 10001:04:00.0 | Samsung PM1723b      PB23F04T             VXNA0M900875     | GPJ99E5Q | /dev/nvme7  /dev/nvme7n1  | 512+0
# -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
# 12 a | EMPTY | DOWN       Detect     | 10000:02:0c.0 -             | -                    -                    -                | -        | -           -             | -
#    b | EMPTY | DOWN       Detect     | 10000:02:0c.0 -             | -                    -                    -                | -        | -           -             | -
# -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
# 13 a | EMPTY | DOWN       Detect     | 10001:02:0d.0 -             | -                    -                    -                | -        | -           -             | -
#    b | EMPTY | DOWN       Detect     | 10001:02:0d.0 -             | -                    -                    -                | -        | -           -             | -
# -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
# 14 a | EMPTY | DOWN       Detect     | 10000:02:0e.0 -             | -                    -                    -                | -        | -           -             | -
#    b | EMPTY | DOWN       Detect     | 10000:02:0e.0 -             | -                    -                    -                | -        | -           -             | -
# -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
# 15 a | EMPTY | DOWN       Detect     | 10001:02:0f.0 -             | -                    -                    -                | -        | -           -             | -
#    b | EMPTY | DOWN       Detect     | 10001:02:0f.0 -             | -                    -                    -                | -        | -           -             | -
# -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
# 16 a | EMPTY | DOWN       Detect     | 10001:02:10.0 -             | -                    -                    -                | -        | -           -             | -
# -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
# 23 a | PWRON | UP         L0         | 10001:02:17.0 10001:1a:00.0 | Mt.Carmel            MTC_8GBMN            9A27634B2AA      | 3.0.44.0 | /dev/nvme14 /dev/nvme14n1 | 512+0
#    b | PWRON | UP         L0         | 10001:02:17.0 10001:1a:00.0 | Mt.Carmel            MTC_8GBMN            9A27634B2AA      | 3.0.44.0 | /dev/nvme14 /dev/nvme14n1 | 512+0
# -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------