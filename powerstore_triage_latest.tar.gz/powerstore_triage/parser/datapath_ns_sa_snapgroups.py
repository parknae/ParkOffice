import os
import json
from infra.utils import TOOL_NAME, TOOL_OUTPUT_FOLDER, TOOL_TMP_FOLDER, get_sym_node_command_output_file_path
import logging
import re

logger = logging.getLogger('.'.join([TOOL_NAME, __name__]))

def parse_datapath_ns_sa_snapgroups(dc_folder):
    ns_sa_snapgroups_file_path = get_sym_node_command_output_file_path(dc_folder, 'cli.py_namespace_spacestats_enumsnapgroups.txt')
    # print("............", ns_sa_snapgroups_file_path)
    if ns_sa_snapgroups_file_path:
        logger.debug(ns_sa_snapgroups_file_path)
        snapgroup_id_pattern = re.compile(r'Snap Group Id')
        attr_pattern = re.compile(r"\S+:")
        no_more_data_pattern = re.compile(r"No More Data")
        ns_sa_snapgroups = list()
        record = None
        snapgroup_id = None
        with open(ns_sa_snapgroups_file_path, 'r') as f:
            for line in f:
                if snapgroup_id_pattern.search(line):
                    snapgroup_id = line.split(":")[-1].strip()
                    # append the first through the (last - 1) record
                    if record:
                        ns_sa_snapgroups.append(record)
                    # reset record
                    record = dict()
                if attr_pattern.search(line):
                    if snapgroup_id:
                        attr, value = line.split(":", 1)
                        value = value.split()[0]
                        record[attr.strip()] = value.strip()
                # append the last record
                if no_more_data_pattern.search(line):
                    ns_sa_snapgroups.append(record)

        with open(os.path.join(dc_folder, TOOL_OUTPUT_FOLDER, TOOL_TMP_FOLDER, "ns_sa_snapgroups.json"), 'w+') as out_fp:
            json.dump(ns_sa_snapgroups, out_fp)

            # Snap Group Id:        6
            # Logical Space:        1573634048 (0x5dcbc000) 1.5GB
            # Unique Owned Space:   64065467 (0x3d18fbb) 61.1MB
            # Committed Space:      1573470208 (0x5dc94000) 1.5GB

            # No More Data:  True
            # Cursor:        35

            # Total Snap Groups: 30


