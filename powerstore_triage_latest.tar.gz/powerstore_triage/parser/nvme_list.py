import os
import json
from infra.utils import TOOL_NAME, TOOL_OUTPUT_FOLDER, TOOL_TMP_FOLDER, get_node_file
import logging

logger = logging.getLogger('.'.join([TOOL_NAME, __name__]))

def parse_nvme_list(dc_folder):
    for node_name in ["node_a", "node_b"]:
        sn_to_nvme_device_name = dict()
        nvme_list_file_path = get_node_file(dc_folder, node_name, os.path.join("core_os", "nvme_list.txt"))
        if nvme_list_file_path:
            logger.debug(nvme_list_file_path)
            with open(nvme_list_file_path, 'r') as fp:
                for i, line in enumerate(fp):
                    if i > 1:
                        items = line.split()
                        device_name = items[0].strip()
                        sn = items[1].strip()
                        sn_to_nvme_device_name[sn] = device_name
            with open(os.path.join(dc_folder, TOOL_OUTPUT_FOLDER, TOOL_TMP_FOLDER, "%s_sn_to_nvme_device_name.json" % node_name), 'w+') as out_fp:
                json.dump(sn_to_nvme_device_name, out_fp)
        else:
            logger.warning("core_os/nvme_list.txt is not found in %s's folder" % node_name)

# Node             SN                   Model                                    Namespace Usage                      Format           FW Rev
# ---------------- -------------------- ---------------------------------------- --------- -------------------------- ---------------- --------
# /dev/nvme0n1     VXNE0M701009         PB23F04T                                 1           3.84  TB /   3.84  TB    512   B +  0 B   GPJ99E5Q
# /dev/nvme1n1     VXNE0M701026         PB23F04T                                 1           3.84  TB /   3.84  TB    512   B +  0 B   GPJ99E5Q
# /dev/nvme2n1     VXNE0M701060         PB23F04T                                 1           3.84  TB /   3.84  TB    512   B +  0 B   GPJ99E5Q
# /dev/nvme3n1     VXNE0M701081         PB23F04T                                 1           3.84  TB /   3.84  TB    512   B +  0 B   GPJ99E5Q
# /dev/nvme4n1     9A27634B17C          MTC_8GBMN                                1           8.48  GB /   8.48  GB    512   B +  0 B   3.0.45.6
# /dev/nvme5n1     VXNE0M701059         PB23F04T                                 1           3.84  TB /   3.84  TB    512   B +  0 B   GPJ99E5Q
