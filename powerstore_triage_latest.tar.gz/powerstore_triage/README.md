# powerstore_triage
PowerStore data collection triage tool

**Help**

$python ~/powerstore_triage/powerstore_triage.py --help
```
usage: powerstore_triage.py [-h] [--version] [--debug] [--since SINCE]
                         [--until UNTIL]

optional arguments:
  -h, --help     show this help message and exit
  --version      show script version
  --debug        increase console output verbosity
  --since SINCE  Date specifications should be of the format of "YYYY-MM-DD HH:MM:SS",e.g. "2018-12-03 10:00:00"
  --until UNTIL  Date specifications should be of the format of "YYYY-MM-DD HH:MM:SS",e.g. "2018-12-03 23:00:00"
```
The timestamp specified in --since and --until is treated as UTC.

If --since is not specified, the journal files in the none rotated folder will be exported to text file.

**Sample output**

```
$ ~/powerstore_triage/powerstore_triage.py
2019-07-04 01:50:13,455 INFO Extracting file powerstore_unconfigured_FNM00191600896_2019-06-27_03-54-39_service-data.tgz
2019-07-04 01:50:47,550 INFO ===== Core Dumps, Kdumps, Firmware core dumps from node_a =====
2019-07-04 01:50:47,550 INFO No Core Dump
2019-07-04 01:50:47,692 INFO ===== Core Dumps, Kdumps, Firmware core dumps from node_b =====
2019-07-04 01:50:47,692 INFO No Core Dump
2019-07-04 01:50:47,693 INFO Decompressing compressed journal files...
2019-07-04 01:50:47,693 INFO No compressed journal files (the compressed journal files could have been already decompressed previously)
2019-07-04 01:50:47,693 INFO journal command powerstore_unconfigured_FNM00191600896_2019-06-27_03-54-39_service-data/node_a/core_os/lib64/ld-linux-x86-64.so.2 --library-path powerstore_unconfigured_FNM00191600896_2019-06-27_03-54-39_service-data/node_a/core_os/lib64:powerstore_unconfigured_FNM00191600896_2019-06-27_03-54-39_service-data/node_a/core_os/usr/lib/systemd powerstore_unconfigured_FNM00191600896_2019-06-27_03-54-39_service-data/node_a/core_os/usr/bin/journalctl
2019-07-04 01:50:47,937 INFO =========== node_a journal files ===========
2019-07-04 01:50:47,937 INFO journal folder: powerstore_unconfigured_FNM00191600896_2019-06-27_03-54-39_service-data/node_a/var/log/journal/73b9d8ecc52544a09f3609d2ac3bbf95
2019-07-04 01:50:47,937 INFO archived journal folder: N/A
2019-07-04 01:50:47,937 INFO     Head Timestamp(UTC) Tail Timestamp(UTC) File Name
2019-07-04 01:50:47,937 INFO     2019-06-27 01:32:40 2019-06-27 01:34:39 system@63f87b5863a54df3a7afece37568e219-0000000000000001-00058c44234372fe.journal
2019-07-04 01:50:47,937 INFO     2019-06-27 01:34:39 2019-06-27 04:12:06 system.journal
2019-07-04 01:50:48,124 INFO =========== node_b journal files ===========
2019-07-04 01:50:48,125 INFO journal folder: powerstore_unconfigured_FNM00191600896_2019-06-27_03-54-39_service-data/node_b/var/log/journal/849d21f63bc44893ae61b62ba585379d
2019-07-04 01:50:48,125 INFO archived journal folder: N/A
2019-07-04 01:50:48,125 INFO     Head Timestamp(UTC) Tail Timestamp(UTC) File Name
2019-07-04 01:50:48,125 INFO     2019-06-27 01:33:22 2019-06-27 01:35:29 system@527debbf833a4603a2fec0256f6eec5b-0000000000000001-00058c4425c47cdc.journal
2019-07-04 01:50:48,125 INFO     2019-06-27 01:35:29 2019-06-27 01:43:57 system@00058c445876818f-32d6efb3b9b11aba.journal~
2019-07-04 01:50:48,125 INFO     2019-06-27 01:47:26 2019-06-27 04:12:09 system.journal
2019-07-04 01:50:48,125 INFO Exporting journals in the formatting of text and json...
    Processing node_a journal logs...
    powerstore_unconfigured_FNM00191600896_2019-06-27_03-54-39_service-data/node_a/core_os/lib64/ld-linux-x86-64.so.2 --library-path powerstore_unconfigured_FNM00191600896_2019-06-27_03-54-39_service-data/node_a/core_os/lib64:powerstore_unconfigured_FNM00191600896_2019-06-27_03-54-39_service-data/node_a/core_os/usr/lib/systemd powerstore_unconfigured_FNM00191600896_2019-06-27_03-54-39_service-data/node_a/core_os/usr/bin/journalctl   --file=powerstore_unconfigured_FNM00191600896_2019-06-27_03-54-39_service-data/node_a/var/log/journal/73b9d8ecc52544a09f3609d2ac3bbf95/*.journal* --utc   --no-pager -o json|tee powerstore_unconfigured_FNM00191600896_2019-06-27_03-54-39_service-data/journal_a.json|jq -j --argjson level '{"0":"crit","1":"crit","2":"crit","3":"err","4":"warn","5":"noti","6":"info","7":"trace"}' 'if .PRIORITY then $level[.PRIORITY] else "null" end," ",((.__REALTIME_TIMESTAMP | tonumber) / 1000000|strftime("%Y-%m-%d %H:%M:%S")),".",(.__REALTIME_TIMESTAMP |capture("(?<microsec>[0-9]{6}$)")|.microsec)," ",._HOSTNAME," ",.SYSLOG_IDENTIFIER,if ._PID then "[",._PID,"]" else "" end,": ",(.MESSAGE|rtrimstr("\n")),"\n"'>powerstore_unconfigured_FNM00191600896_2019-06-27_03-54-39_service-data/journal_a.txt
    Processing node_b journal logs...
    powerstore_unconfigured_FNM00191600896_2019-06-27_03-54-39_service-data/node_a/core_os/lib64/ld-linux-x86-64.so.2 --library-path powerstore_unconfigured_FNM00191600896_2019-06-27_03-54-39_service-data/node_a/core_os/lib64:powerstore_unconfigured_FNM00191600896_2019-06-27_03-54-39_service-data/node_a/core_os/usr/lib/systemd powerstore_unconfigured_FNM00191600896_2019-06-27_03-54-39_service-data/node_a/core_os/usr/bin/journalctl   --file=powerstore_unconfigured_FNM00191600896_2019-06-27_03-54-39_service-data/node_b/var/log/journal/849d21f63bc44893ae61b62ba585379d/*.journal* --utc   --no-pager -o json|tee powerstore_unconfigured_FNM00191600896_2019-06-27_03-54-39_service-data/journal_b.json|jq -j --argjson level '{"0":"crit","1":"crit","2":"crit","3":"err","4":"warn","5":"noti","6":"info","7":"trace"}' 'if .PRIORITY then $level[.PRIORITY] else "null" end," ",((.__REALTIME_TIMESTAMP | tonumber) / 1000000|strftime("%Y-%m-%d %H:%M:%S")),".",(.__REALTIME_TIMESTAMP |capture("(?<microsec>[0-9]{6}$)")|.microsec)," ",._HOSTNAME," ",.SYSLOG_IDENTIFIER,if ._PID then "[",._PID,"]" else "" end,": ",(.MESSAGE|rtrimstr("\n")),"\n"'>powerstore_unconfigured_FNM00191600896_2019-06-27_03-54-39_service-data/journal_b.txt
2019-07-04 01:51:44,259 INFO     Exporting critical and error journals in the formatting of text and json...
    Processing both_node journal logs...
    powerstore_unconfigured_FNM00191600896_2019-06-27_03-54-39_service-data/node_a/core_os/lib64/ld-linux-x86-64.so.2 --library-path powerstore_unconfigured_FNM00191600896_2019-06-27_03-54-39_service-data/node_a/core_os/lib64:powerstore_unconfigured_FNM00191600896_2019-06-27_03-54-39_service-data/node_a/core_os/usr/lib/systemd powerstore_unconfigured_FNM00191600896_2019-06-27_03-54-39_service-data/node_a/core_os/usr/bin/journalctl -p 3  --file=powerstore_unconfigured_FNM00191600896_2019-06-27_03-54-39_service-data/node_a/var/log/journal/73b9d8ecc52544a09f3609d2ac3bbf95/*.journal* --file=powerstore_unconfigured_FNM00191600896_2019-06-27_03-54-39_service-data/node_b/var/log/journal/849d21f63bc44893ae61b62ba585379d/*.journal* --utc   --no-pager -o json|tee powerstore_unconfigured_FNM00191600896_2019-06-27_03-54-39_service-data/journal_crit_err_a_b.json|jq -j --argjson level '{"0":"crit","1":"crit","2":"crit","3":"err","4":"warn","5":"noti","6":"info","7":"trace"}' 'if .PRIORITY then $level[.PRIORITY] else "null" end," ",((.__REALTIME_TIMESTAMP | tonumber) / 1000000|strftime("%Y-%m-%d %H:%M:%S")),".",(.__REALTIME_TIMESTAMP |capture("(?<microsec>[0-9]{6}$)")|.microsec)," ",._HOSTNAME," ",.SYSLOG_IDENTIFIER,if ._PID then "[",._PID,"]" else "" end,": ",(.MESSAGE|rtrimstr("\n")),"\n"'>powerstore_unconfigured_FNM00191600896_2019-06-27_03-54-39_service-data/journal_crit_err_a_b.txt
2019-07-04 01:51:45,347 INFO Generating timeline...
2019-07-04 01:51:45,347 INFO /bin/sh -c 'perl /home/cyc/powerstore_triage/infra/timeline_parse.pl -a powerstore_unconfigured_FNM00191600896_2019-06-27_03-54-39_service-data/journal_a.txt -b powerstore_unconfigured_FNM00191600896_2019-06-27_03-54-39_service-data/journal_b.txt |sort > powerstore_unconfigured_FNM00191600896_2019-06-27_03-54-39_service-data/timeline_a_b.txt'
2019-07-04 01:52:10,542 INFO Completed!
```
