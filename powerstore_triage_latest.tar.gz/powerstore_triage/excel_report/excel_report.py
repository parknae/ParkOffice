import os
import logging
from infra.utils import TOOL_NAME, TOOL_OUTPUT_FOLDER, handle_exceptions
from parser.dc_inventory import parse_dc_inventory
from openpyxl import Workbook
from data_normalizer.hardware_info_normalizer import normalize_hardware_info
from excel_report.volume_info import report_volume_info
from excel_report.snap_group_space_accounting_info import report_snapgroup_space_accounting_info
from excel_report.nas_volume_info import report_nas_volume_info
from excel_report.volume_snap_info import report_volume_snap_info
from excel_report.host_info import report_host_info
from excel_report.host_volume_mapping_info import report_volume_mapping_info
from excel_report.virtual_volume_info import report_virtual_volume_info
from excel_report.host_virtual_volume_mapping_info import report_virtual_volume_mapping_info
from excel_report.hardware_info import report_data_drive_info, report_m2_drive_info, \
    report_io_module_info, report_sfp_info, report_fan_info, report_dimm_info, report_power_supply_info, \
    report_base_enclosure_info, report_battery_info, report_expansion_enclosure_info, report_lcc_info

#----------------------------------------------------------#
# 2020 Dell Inc. and its subsidiaries. All Rights reserved #
#----------------------------------------------------------#
#---------------------------------#
# Henry.An@dell.com               #
# Engineering Technical Services  #
#---------------------------------#
# ++++++++++++++++++++++++++++++++++++++#
#       Report in excel format          #
# ++++++++++++++++++++++++++++++++++++++#
logger = logging.getLogger('.'.join([TOOL_NAME, __name__]))
excel_report_file_name = 'powerstore-triage_analysis.xlsx'

@handle_exceptions
def generate_excel_report(dc_folder):
    logger.info("Generating array configuration information in the format of Excel...")
    excel_file_name = os.path.join(dc_folder, TOOL_OUTPUT_FOLDER, excel_report_file_name)
    # create the workbook and worksheet in memory
    wb = Workbook()

    list_of_m2_drive, list_of_data_drive, list_of_io_module, list_of_sfp, \
    list_of_dimm, list_of_power_supply, list_of_fan, list_of_base_enclosure, list_of_node, \
    list_of_battery, list_of_expansion_enclosure, list_of_lcc = normalize_hardware_info(dc_folder)

    func_name_to_ws_name = {"report_volume_info":"Volume", "report_virtual_volume_info": "VirtualVolume", 
                            "report_host_info":"Host",
                            "report_volume_mapping_info":"HostVolumeMapping", "report_virtual_volume_mapping_info":"HostVVolMapping",
                            "report_nas_volume_info":"NASVolume", "report_volume_snap_info": "VolumeSnaps", 
                            "report_snapgroup_space_accounting_info": "SnapGroupSpaceAccounting"}
    hardware_func_name_2_data_list = {"report_data_drive_info": list_of_data_drive, "report_m2_drive_info": list_of_m2_drive,
                                      "report_io_module_info": list_of_io_module, "report_sfp_info": list_of_sfp}
    for ws_index, report_func in enumerate([report_volume_info, report_snapgroup_space_accounting_info, report_nas_volume_info, 
            report_volume_snap_info, report_host_info, report_volume_mapping_info, 
            report_virtual_volume_info, report_virtual_volume_mapping_info, report_data_drive_info, report_m2_drive_info,
                                  report_io_module_info, report_sfp_info]):
        if report_func in [report_data_drive_info, report_m2_drive_info,report_io_module_info,
                           report_sfp_info, report_fan_info, report_dimm_info, report_power_supply_info,
                           report_base_enclosure_info, report_battery_info, report_expansion_enclosure_info,
                           report_lcc_info]:
            report_func(hardware_func_name_2_data_list[report_func.__name__], wb, ws_index)
        else:
            report_func(dc_folder, wb, ws_index, func_name_to_ws_name[report_func.__name__])

    # save to a file
    wb.save(excel_file_name)
    logger.info("Please see {0} for the complete array configuration information.".format(excel_file_name))