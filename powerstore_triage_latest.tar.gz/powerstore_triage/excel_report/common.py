import logging
from infra.utils import TOOL_NAME, convert_unit_as_needed, get_cols_width
from openpyxl.utils import get_column_letter

logger = logging.getLogger('.'.join([TOOL_NAME, __name__]))


def generate_excel_report_from_list_of_dict(wb, ws_index, ws_name_str, list_of_dict, header, vertical=False, sort_func=None, tab_color=None):
    logger.debug(ws_name_str)
    logger.debug(header)
    ws = wb.create_sheet(ws_name_str, ws_index)
    ws.append(header)
    if list_of_dict:
        if sort_func:
            sorted_list = sorted(list_of_dict, key=sort_func)
        else:
            sorted_list = sorted(list_of_dict, key=lambda x: x[header[0]])
        if vertical:
            pass
        else:
            for record in sorted_list:
                keys = record.keys()
                ws.append([convert_unit_as_needed(k, record[k]) if k in keys else " " for k in header])
    else:
        ws.append(["None"])
    # set column width. No auto-just in openpyxl, has to calculate the width then set the width
    cols_width = get_cols_width(header, list_of_dict)
    for i, width in enumerate(cols_width):
        adjusted_width = (width + 2)
        ws.column_dimensions[get_column_letter(i+1)].width = adjusted_width
    # add filters to all columns
    full_range = "A1:{0}{1}".format(get_column_letter(ws.max_column), str(ws.max_row))
    ws.auto_filter.ref = full_range
    # free panes
    c = ws['E2']
    ws.freeze_panes = c

    if tab_color:
        ws.sheet_properties.tabColor = tab_color