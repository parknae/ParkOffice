from infra.utils import sort_drive_name, sort_dimm_name
from excel_report.common import generate_excel_report_from_list_of_dict


# define several functions so that the sequence of the report for different hardware can be easily arranged.
def report_data_drive_info(list_of_data_drive, wb, ws_index):
    data_drive_header = ["name", "appliance_id", "slot", "lifecycle_state", "drive_type", "size", "firmware_version",
                         "encryption_status", "fips_status",
                         "part_number", "serial_number", "status_led_state", "is_marked"]

    generate_excel_report_from_list_of_dict(wb, ws_index, "DataDrive", list_of_data_drive, data_drive_header, vertical=False, sort_func=sort_drive_name)


def report_m2_drive_info(list_of_m2_drive, wb, ws_index):
    m2_drive_header = ["name", "appliance_id", "slot", "lifecycle_state", "model_name", "part_number", "serial_number"]
    generate_excel_report_from_list_of_dict(wb, ws_index, "M2_Drive", list_of_m2_drive, m2_drive_header, vertical=False)


def report_io_module_info(list_of_io_module, wb, ws_index):
    io_module_header = ["name", "appliance_id", "slot", "lifecycle_state", "model_name", "part_number", "serial_number", "status_led_state"]
    generate_excel_report_from_list_of_dict(wb, ws_index, "IOModule", list_of_io_module, io_module_header, vertical=False)


def report_sfp_info(list_of_sfp, wb, ws_index):
    sfp_header = ["name", "appliance_id", "slot", "lifecycle_state", "connector_type", "parent_model_name", "supported_speeds", "part_number", "serial_number"]
    generate_excel_report_from_list_of_dict(wb, ws_index, "SFP", list_of_sfp, sfp_header, vertical=False)


def report_dimm_info(list_of_dimm, wb, ws_index):
    dimm_header = ["name", "appliance_id", "slot", "lifecycle_state", "part_number", "serial_number"]
    generate_excel_report_from_list_of_dict(wb, ws_index, "DIMM Information", list_of_dimm, dimm_header, vertical=False, sort_func=sort_dimm_name)


def report_base_enclosure_info(list_of_base_enclosure, wb, ws_index):
    base_enclosure_header = ["name", "appliance_id", "lifecycle_state", "part_number", "serial_number", "status_led_state", "dell_service_tag", "express_service_code"]
    generate_excel_report_from_list_of_dict(wb, ws_index, "Base Enclosure Information", list_of_base_enclosure, base_enclosure_header, vertical=False)


def report_battery_info(list_of_battery, wb, ws_index):
    battery_header = ["name", "appliance_id", "slot", "lifecycle_state", "part_number", "serial_number"]
    generate_excel_report_from_list_of_dict(wb, ws_index, "Battery Information", list_of_battery, battery_header, vertical=False)


def report_fan_info(list_of_fan, wb, ws_index):
    # fan's serial number is None
    fan_header = ["name", "appliance_id", "slot", "lifecycle_state", "part_number"]
    generate_excel_report_from_list_of_dict(wb, ws_index, "Fan Information", list_of_fan, fan_header, vertical=False)


def report_power_supply_info(list_of_power_supply, wb, ws_index):
    power_supply_header = ["name", "appliance_id", "slot", "lifecycle_state", "part_number", "serial_number", "status_led_state"]
    generate_excel_report_from_list_of_dict(wb, ws_index, "PowerSupply Information", list_of_power_supply, power_supply_header, vertical=False)


def report_expansion_enclosure_info(list_of_expansion_enclosure, wb, ws_index):
    expansion_enclosure_header = ["name", "appliance_id", "slot", "lifecycle_state", "part_number", "serial_number", "status_led_state"]
    generate_excel_report_from_list_of_dict(wb, ws_index, "Expansion Enclosure Information", list_of_expansion_enclosure, expansion_enclosure_header, vertical=False)


def report_lcc_info(list_of_lcc, wb, ws_index):
    lcc_header = ["name", "appliance_id", "slot", "lifecycle_state", "part_number", "serial_number", "status_led_state"]
    generate_excel_report_from_list_of_dict(wb, ws_index, "LCC Information", list_of_lcc, lcc_header, vertical=False)