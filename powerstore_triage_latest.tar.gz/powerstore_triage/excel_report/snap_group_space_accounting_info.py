from excel_report.common import generate_excel_report_from_list_of_dict
from data_normalizer.ns_sa_snapgroups_normalizer import normalize_ns_sa_snapgroups_info

def sort_by_id(a_dict):
    return int(a_dict['Snap Group Id'])

def report_snapgroup_space_accounting_info(dc_folder, wb, ws_index, ws_name):
    header, list_of_dict = normalize_ns_sa_snapgroups_info(dc_folder)
    generate_excel_report_from_list_of_dict(wb, ws_index, ws_name, list_of_dict, header, vertical=False, sort_func=sort_by_id, tab_color=None)
