#!/usr/bin/perl -w
#
# Started with timeline_parse.pl and enhanced.
#

use strict;
use bytes;
use POSIX;
use List::Util qw[min max];
use Getopt::Std;
use Scalar::Util qw(looks_like_number);

no warnings 'portable';
no strict 'refs';

##################################################################

my $xx_opt_timeline_type = "";  # default is J for journal. Also M-mel, K-konsole, S-sel, T-testlog
my $xx_opt_a_journal = "";
my $xx_opt_b_journal = "";
my $xx_opt_flag_v = 0;
my $xx_opt_flag_V = 0;
my $xx_opt_c_journal = "";
my $xx_opt_g_journal = "";
#my $show_less_bool = 0; #Shows all by default 
my %options_hash;
##################################################################

sub xx_cluster_state($);
sub xx_cluster_msg_type($);
sub xx_add_panic_data($);
sub xx_add_reinit_data($);
sub xx_add_subsystem($);

##################################################################

# Some kernel patterns
# #Command line: BOOT_IMAGE=/coreos/vmlinuz-a mount.usr=PARTUUID=7130c94a-213a-4e5a-8e26-6cce9662f132 rootflags=rw mount.usrflags=ro consoleblank=0 root=LABEL=ROOT console=ttyS0,115200n8 coreos.oem.id=vmware coreos.autologin nvme.use_cmb_sqes=N pci=realloc=on pci=hpmemsize=16M pci=hpnpmemsize=1M pciehp.pciehp_debug=Y crashkernel=0-16G:144M,16G-32G:160M,32G-64G:192M,64G-128G:256M,128G-256G:384M,256G-512G:512M,512G-1024G:640M,1024G-:768M maxcpus=64 intel_idle.max_cstate=2 nopti nospectre_v2 scsi_mod.use_blk_mq=y cryptomgr.notests ipv6.autoconf=0
# #Command line: nr_cpus=1 root=LABEL=ROOT console=ttyS0,115200n8 console=tty0 reset_devices ghes.disable=1 modprobe.blacklist=vmd pci=realloc=off elfcorehdr=916852K
# #Kernel panic - not syncing: *** ocfs2 is very sorry to be fencing this system by panicing ***
# #reboot: machine restart
# #reboot: Power down
# #reboot: System halted
# #saved vmcore-2018-10-31-205355-4.14.19-coreos-r9999.1538157074-466.kdump
#
my @xx_patterns = (
    #["XIOS is loaded .csid 0 ", "GW_START"],
    #START PATTERNS#
    ["classic", 0, "-- Logs begin", "NIL", \&xx_eat_line],
    ["classic", 0, "StartTime: [0-1][0-9]/[0-3][0-9]/20[0-9][0-9] [0-2][0-9]:[0-5][0-9]:[0-5][0-9]", "POST_REBOOTING"],
    ["extra", 0, "sysrq: SysRq : Resetting", "SYSRQ_REBOOT"],
    ["extra", 0, "-- Reboot --", "OS_REBOOTING_JOURNAL"],
    ["extra", 0, "cyc_core_dump.*crashed.*trace_collector", "TRACE_COLLECTOR_FAULT"],
    ["extra", 0, "SYM_Starting timeout exceeded", "SYM_START_TIMOUT"],
    ["extra", 0, "SYSTEM HALT: Start waiting for vault to be done", "SYM_VAULT_HALT"],
    ["extra", 0, "SYSTEM HALT: got gates close due to faulty nvram pair", "SYM_HALT_NVRAM_3"],
    ["extra", 0, "Found fault nvram pair, num of fault nvrams in", "SYM_HALT_NVRAM_2"],
    ["extra", 0, "harden sym md for setting fault nvram pair, closing gates and setting all nvrams as failed", "SYM_HALT_NVRAM_1"],
    ["extra", 0, "Command line: BOOT", "OS_STARTUP_CMDLINE", \&xx_startup_cmdline],
    ["extra", 0, "Command line: nr_cpus", "KDUMP_OS_STARTUP_CMDLINE"],
    ["extra", 0, "peer reboot via sysrq", "NIL", \&xx_eat_line],
    ["extra", 0, "cyc_prss.*Observing unwell condition with no DP process extant: rebooting node", "GONG_DP_DEAD_REBOOT"],
    ["extra", 0, "reboot via sysrq", "FORCED_SYSRQ_REBOOT"],
    ["extra", 0, "reboot: machine restart", "OS_RESTART"],
    ["extra", 0, "reboot: Power down", "OS_POWERDOWN"],
    ["extra", 0, "reboot: System halted", "OS_HALTED"],
    ["extra", 0, "systemd-shutdown.*SIGTERM", "OS_SHUTDOWN_SYSTEMD"],
    ["extra", 0, "policy.*rebooting A", "POLICY_REBOOTING_NODE_A"],
    ["extra", 0, "policy.*rebooting B", "POLICY_REBOOTING_NODE_B"],
    ["extra", 0, "policy.*reboots are off, ignoring request", "POLICY_REBOOT_AVOIDED_DUE_SETTING"],
    ["extra", 0, "cyc_shutdown.*requested shutdown", "CYC_SHUTDOWN_CALLED",\&xx_cyc_shutdown],
    ["classic", 0, "Handling install: install_options:.* factory", "FACTORY_START"],
    ["classic", 0, "reinit_install: left system in factory half-reinited state", "FACTORY_DONE"],
    ["classic", 0, 'Handling install: install_options: reinit newcfg', "REINIT_START"],
    ["classic", 0, "cyc_config.*Error: EC:", "REINIT_ERROR", \&xx_ec],
    ["classic", 0, "(reinit_install: (?!left)|EC:)", "REINIT_DONE", \&xx_add_reinit_data],
    ["extra", 0, "saved vmcore", "KDUMP", \&xx_vmcore],
    ["extra", 0, "saved to .*KDUMP", "KDUMP_FINISHED", \&xx_vmcorefin],
    ["classic", 0, "Kernel panic", "KERNEL_PANIC", \&xx_kernel_panic],
    ["extra", 0, "Initial Configuration initiate: starting", "CONFIG_START"],
    ["extra", 0, "cyc_config.* configuration complete", "CONFIG_DONE"],
    ["classic", 0, "Handling install: install_options: disruptive", "DUPGRADE_START"],
    ["classic", 0, "cyc_config.* dreinstall: OK", "DUPGRADE_DONE"],
    ["classic", 0, "ipmitool.*power reset", "FENCING_IPMI_RESET"],
    ["classic", 0, "cyc_np_stonith:.*reset peer.*called", "FENCING_RESET"],
    ["classic", 0, "cyc_np_stonith_via_kdump:.*reset peer via kdump.*called", "FENCING_KDUMP"],
    ["classic", 0, "cyc_np_stonith: called from", "STONITH"],
    ["classic", 0, "cyc_np_shootme: called from", "SHOOTME"],
    ["classic", 0, "Entering SERVICE MODE", "SERVICE_MODE"],
    ["classic", 0, "Alert Notification : DATA_PATH_WRITE_PROTECT_MODE_ENTER", "DP_WRITE_PROTECT_MODE"],
    ["extra", 2, "self_fence_kdump_listener.*pm_self_fence_kernel_listener_th.*KDUMP_NOTIFY: got message from peer .KDUMP IN PROGRESS", "PEER_KDUMP_NOTIFY"],
    ["extra", 2, "pm_node_fence_adj_node:.*give up trying to fence out the peer since it got kernel panic - consider the node fenced", "FENCING_ALREADY_KDUMPING"],
    ["extra", 0, "bsc-fail_handler.*requesting to reset node", "BSC_FAIL_RESET_NODE"],
    ["extra", 1, "insmod: ERROR: could not insert module", "MODULE_INSERT_FAIL"],
    ["extra", 1, "Reboot unconditional called", "PM_FORCING_REBOOT"],
    ["extra", 1, "bare-metal board detected - reset the node", "PM_FORCING_RESET"],
    ["extra", 1, "Aggressive reboot required, triggering kernel panic", "PM_FORCING_PANIC"],
    ["extra", 1, "forcekdump", "FORCE_KDUMP", \&xx_force_kdump],
    ["extra", 1, "forcereboot", "FORCE_REBOOT", \&xx_force_reboot],
    ["extra", 1, "svc_shutdown.*Svc shutdown command: target: .* force: .* async: .* key: .* debug: .*", "SVC_SHUTDOWN", \&xx_svc_shutdown],
    ["extra", 1, "Executing reboot since shutdown called after fault nvram pair", "PM_REBOOT_NVRAM"],
    ["extra", 1, "pm_node_perform_emergency_shutdown_imp:.* ES: reason=", "ES_EMERGENCY_SHUTDOWN", \&xx_es],
    ["extra", 1, "ES: beginning to handle emergency shutdown", "ES_EMERGENCY_SHUTDOWN"],
    ["extra", 1, "reboot thread 10 minute timeout expired", "PM_REBOOT_FAILED"],
    ["classic", 1, "Cyclone BSC stop", "BSC_STOP"],
    ["extra", 1, "ERROR: fencing this node because it is connected to a half-quorum of", "O2_HALF_QUORUM_PANIC"],
    ["extra", 1, "o2net: Connection to node.*shutdown, state", "O2_PEER_SHUTDOWN"],
    ["classic", 1, "o2net: No longer connected to node", "O2_DISCONNECT"],
    ["extra", 1, "o2net: Connected to node.*7777", "O2_CONNECT"],
    ["extra", 1, "o2net: Connection to node.*has been idle for", "O2_IDLE"],
    ["extra", 1, "o2net: Accepted connection from node", "O2_CONNECT"],
    ["extra", 1, "DAQ Sending: DUAL_NODE_PANIC", "DAQ_DUAL_PANIC"],
    ["extra", 1, "SCSI Panic Node Origin: DAQ", "DAQ_SCSI_PANIC"],
    ["extra", 1, "DAQ.*SINGLE_NODE_DP_SHUTDOWN", "DAQ_DP_SHUTDOWN"],
    ["extra", 1, "DAQ.*Performing Kernel Panic", "DAQ_PANIC"],
    ["extra", 1, "DAQ.*Rebooting Node", "DAQ_REBOOT"],
    ["extra", 1, "Handling DP final exit: rebooting node", "PRSS_DP_REBOOT"],
    ["extra", 1, "PYTEST_", "PYTEST", \&xx_pytest],
    ["extra", 1, "QA.*ACTION", "QA_ACTION", \&xx_qa_action],
    ["extra", 1, "QA.*INFO", "QA_INFO", \&xx_qa_info],
    ["extra", 2, "Handling DP final exit: rebooting node...", "PRSS_REBOOT"],
    ["extra", 2, "Handling DP final exit: allowing DP restart", "PRSS_CONTINUE"],
    ["extra", 2, "xtremapp requested to freeze in place", "XIOS_FREEZE"],
    ["extra", 2, "Recovery sequence completed", "XIOS_RECOVERY"],
    ["extra", 2, "handle_typical_xms_command:.* SYM ended SYM_CMD_OPCODE_QUERY_DP_RECOVERY_STATE cmd, result", "SYM_DP_RECOVERY", \&xx_show_result],
    ["extra", 2, "cyc_xms.*: Address already in use: HTTPD port 765", "XMS_PORT_IN_USE"],
    ["extra", 2, "cyc_xms.*: Exiting container.", "XMS_EXIT"],
    ["extra", 2, "signal_handler.*Signal.*received. Ret=", "SIGNAL", \&xx_signal],
    ["extra", 2, "unknown: xtremapp-gw-.:starting", "GW_START"],
    ["extra", 2, "unknown: xtremapp-pm-.:starting", "PM_START"],
    ["extra", 2, "unknown: xtremapp-sym-.:starting", "SYM_START"],
    ["classic", 2, "x_init: XIOS csid 0 ", "GW_START", \&xx_save_pid],
    ["classic", 2, "x_init: XIOS csid -1 ", "PM_START", \&xx_save_pid],
    ["classic", 2, "x_init: XIOS csid 1 ", "SYM_START", \&xx_save_pid],
    ["classic", 2, "x_init: XIOS csid 10 ", "DP_START", \&xx_save_pid],
    ["classic", 2, "x_init: XIOS csid 11 ", "DP_START", \&xx_save_pid],
    ["extra", 2, "x_env_load_before_allocation.*Loading INI file /dev/shm/xenv_10.ini", "DP_START", \&xx_save_pid],
    ["extra", 2, "x_env_load_before_allocation.*Loading INI file /dev/shm/xenv_11.ini", "DP_START", \&xx_save_pid],
    ["extra", 2, "sysrq: SysRq : Resetting", "SYSRQ_RESET"],
    ["extra", 2, "gong reboot", "GONG_REBOOT"],
    ["extra", 2, "run /working/cyc_host/cyc_bin/cyc_gong_helper.sh", "GONG", \&xx_gong_run],
    ["extra", 2, "halt via magic sysrq survived", "GONG halt via magic sysrq survived"],
    ["extra", 2, "peer saying goodbye: bye", "GONG peer saying goodbye: bye"],
    ["classic", 2, "entering D world shutdown", "DP_STOP"],
    ["extra", 2, "Stop reason - Failed on reformat, gate will remain closed", "GATES_CLOSED_REFORMAT"],
    ["extra", 2, "queries didn.t started", "GATES_CLOSED_QUERIES"],
    ["extra", 2, "gate will remain closed until user will start the system manually", "GATES_CLOSED_MANUALLY"],
    ["extra", 2, "Reached max open gates retries", "GATES_CLOSED_MAX_RETRIES"],
    ["extra", 2, "Checking that all healthy nodes are stable for enough time", "GATES_CHECK_STABLE"],
    ["extra", 2, "not all DAEs are reachable, can't open gates", "GATES_CLOSED_DAE"],
    ["extra", 2, "Checking if system is not too warm", "GATES_CHECK_TEMP"],
    ["extra", 2, "Checking system for too many failed nodes", "GATES_CHECK_NODES"],
    ["extra", 2, "Two or more nodes need failover, or got third failover when two or more nodes are already failed", "GATES_CLOSED_NEED_FAILOVER"],
    ["extra", 2, "Checking if exists failed nvram pair", "GATES_CHECK_NVRAM"],
    ["extra", 2, "Found nvram pair faulty", "GATES_CLOSED_NVRAM"],
    ["extra", 2, "SYM disconnected from system!", "SYM_EXIT_DISCONNECTED"],
    ["classic", 2, "SYM exiting", "SYM_EXIT"],
    ["extra", 2, "kmscli command=.revert_all.", "KMS_REVERT_ALL"],
    ["extra", 2, "/bin/systemctl --quiet stop cyc_bsc_control", "STOP_BSC"],
    ["extra", 2, "/cyc_host/cyc_common/cyc_servicemode.sh --enter --reason", "ENTER_SERVICEMODE", \&xx_servicemode],
    ["extra", 2, "Clustering operation failed for appliance.*because it is not in Block mode", "CLST_FAIL_BLOCK_MODE"],
    ["classic", 2, "attempting cluster creation", "CYC_REINIT"],
    ["extra", 3, "sym_ham_sm_check_if_node_healthy:.*invalid to run D modules", "DP_BLOCKED", \&xx_dp_blocked],
    ["extra", 3, "sym_bl_ham_events_close_gates.*HA_FLOW: Attemting to close gates reason", "CLOSE_GATES", \&xx_close_gates],
    ["extra", 4, "ham_process_model_create_close_gates_event.*HA_FLOW: requesting to close gates, reason", "HAM_CLOSE_GATES", \&xx_ha_gates],
    ["extra", 2, "proxy connection manager: received cmd: DP_PROXY_COMMAND_CONNECTION_DESTROY", "PROXY_VOLUMES_DESTROY"],
    ["extra", 2, "kernel: device-mapper: multipath: Reinstating path", "PATH_REINSTATED", \&xx_pathchange],
    ["extra", 2, "multipathd.*: checker failed path .* in map", "PATH_FAILED", \&xx_pathchange],
    ["extra", 2, "multipathd.*: .* remaining active paths: 0", "ALLPATHS_FAILED", \&xx_pathloss],
    ["extra", 2, "kernel: device-mapper: multipath: Failing path", "PATH_FAILED", \&xx_pathchange],
    ["classic", 2, "Blockshim Device Destroyed", "BLOCKSHIM_DESTROYED"],
    ["extra", 2, "Self fence completed, reboot or shutdown should commence shortly", "PM_SELFFENCE"],
    ["extra", 2, "self fence is required on start", "PM_SELFFENCE_ON_START"],
    ["extra", 2, "Stop iscsi-scst thread finished with result", "PM_SELFFENCE_ISCSI_FAIL"],
    ["extra", 2, "bsc-cfsmon.*Note: Running: setfacl -R -d -m .*/cyc_cfs", "BLOCKSHIM_MOUNT"],
    ["extra", 2, "Blockshim Bind received", "BLOCKSHIM_BIND"],
    ["classic", 2, "blockshim_xmit_timeout IO TIMEOUT PANIC DP", "BLOCKSHIM_TIMEOUT_FORCE_DP_PANIC"],
    ["classic", 3, "xtremapp-dp-.:panic-begin tid=.* signal=.*", "DP_PANIC", \&xx_panic_begin],
    ["extra", 3, "bl_set_dp_recovery_state_common:.* SYM ROS: going to close/open gates with reason", "SYM_GATE_CHANGE", \&xx_sym_ros],
    ["extra", 3, "xtremapp-pm-.:panic-begin tid=.* signal=.*", "PM_PANIC", \&xx_panic_begin],
    ["extra", 3, "xtremapp-gw-.:panic-begin tid=.* signal=.*", "GW_PANIC", \&xx_panic_begin],
    ["extra", 3, "xtremapp-sy.*:panic-begin tid=.* signal=.*", "SYM_PANIC", \&xx_panic_begin],
    ["classic", 3, "PANIC <[MRCDPSXG][0-9]*> csid -1 ", "PM_PANIC", \&xx_add_panic_data],
    ["classic", 3, "PANIC <[MRCDPSXG][0-9]*> csid 0 ", "GW_PANIC", \&xx_add_panic_data],
    ["classic", 3, "PANIC <[MRCDPSXG][0-9]*> csid 1 ", "SYM_PANIC", \&xx_add_panic_data],
    ["classic", 3, "PANIC <[MRCDPSXG][0-9]*> csid 10 ", "DP_PANIC", \&xx_add_panic_data],
    ["classic", 3, "PANIC <[MRCDPSXG][0-9]*> csid 11 ", "DP_PANIC", \&xx_add_panic_data],
    ["classic", 3, "postgres_cluster.*PANIC", "PG_PANIC", \&xx_pg_panic],
    ["extra", 2, "nas resources are not ready after", "NAS_NO_RESOURCES"],
    ["extra", 2, "Nas installation failed", "NAS_INSTALL_FAILED"],
    ["extra", 3, "cyc_core_dump.*: writing nas crash marker", "NAS_PANIC"],
    ["extra", 3, "nas_action_node_fo", "NAS_FORCE_FAILOVER"],
    ["extra", 3, "/cyc_bsc/scripts/cyc_nas_api stonith_nas a SDNAS fencing", "NAS_FENCING_A"],
    ["extra", 3, "/cyc_bsc/scripts/cyc_nas_api start_nas", "NAS_STARTING"],
    ["extra", 3, "/cyc_bsc/scripts/cyc_nas_api stonith_nas b SDNAS fencing", "NAS_FENCING_B"],
    ["extra", 3, "wait_for_nbtrucks_to_panic_with_timeout: finished", "EXIT", \&xx_quiet_panic],
    ["extra", 3, "cyc_be_monitor_init_.*: BE: monitor done. Not enough drives", "NOT_ENOUGH_DISKS"],
    ["extra", 3, "BE: Boot without sufficient drives ", "NOT_ENOUGH_DISKS"],
    ["extra", 3, "cyc_be_monitor_init_primary:.*: BE: System initialization without sufficient drives - wait for drive insertion", "NOT_ENOUGH_DISKS"],
    ["extra", 3, "BE: monitor init found", "ENOUGH_DISKS_FOUND"],
    ["classic", 3, "Error: something failed: ", "FAIL_CONFIG", \&xx_add_panic_data],
    ["classic", 3, "Error: Failed to find a platform disk - WTF", "FAIL_DISK"],
    ["extra", 3, "compare_and_copy_localdisk: event MGMT_EVENT_TYPE_LOCAL_DISK_DISK_FAILURE", "LOCAL_DISK_FAIL"],
    ["classic", 3, "ILLEGAL: device_id passed in -1", "FAIL_DISK_RACE"],
    ["extra", 2, "cyc-cluster-ip.*WARNING: requesting SYM HA to reboot as cluster ip is not up", "HA_REBOOT_NO_CLUSTER_IP"],
    ["extra", 3, "HA_FLOW: node_failover for csid 8", "HA_FAILOVER_NODE_A"],
    ["extra", 3, "HA_FLOW: node_failover for csid 9", "HA_FAILOVER_NODE_B"],
    ["classic", 3, "saw matching xterm - but failed to find real pid within timeout", "XTERM_REAL_PID_TIMEOUT"],
    ["extra", 3, "BBU is NOT READY on node", "BBU_NOT_READY", \&xx_bbu_ready],
    ["extra", 3, "BBU is READY on node", "BBU_READY", \&xx_bbu_ready],
    ["classic", 4, "Got CQ error transport", "FAIL_INTERCONNECT_1"],
    ["classic", 4, "Got CQ error Work Request", "FAIL_INTERCONNECT_2"],
    ["extra", 4, "kernel: ib-int: first active interface up", "GAIN_INTERCONNECT_IB"],
    ["extra", 4, "ib-int: now running without any active interface", "FAIL_INTERCONNECT_IB"],
    ["extra", 4, "xenv_load_failed_sync", "FAIL_PROC_START_1"],
    ["classic", 4, "NamespaceStartIoRequest.0xa5", "FAIL_DP_NAMESPACE_MUTEX"],
    ["extra", 4, "Initializing for namespace startup", "NAMESPACE_STARTING"],
    ["extra", 4, "Namespace startup succeeded", "NAMESPACE_STARTED"],
    ["extra", 4, "Namespace in write protect mode, io return error", "NAMESPACE_WRITE_PROTECT", undef, "HOUR_namespacewriteprotect"],
    ["extra", 4, "raid: Init complete. Mark Initted", "RAID_INIT_DONE"],
    ["extra", 4, "mapper: Init Comple", "MAPPER_INIT_COMPLETE"],
    ["extra", 4, "mapper: Init Starting", "MAPPER_INIT_STARTING", undef, "mapper"],
    ["extra", 4, "cyc_raid_monitor_init_secondary", "RAID_INIT_SECONDARY_COMPLETE", undef, "raids"],
    ["extra", 4, "raid: Init Starting", "RAID_INIT_START", undef, "raidinit"],
    ["extra", 4, "Cache Manager Recover has FAILED", "TXCACHE_FAIL"],
    ["extra", 4, "Initing Service IO_SERVICE_ID_TXCACHE", "TXCACHE_START"],
    ["extra", 1, "svc_rescue_state.*: Request to enter service mode", "REQ_SERVICE_MODE"],
    ["extra", 1, "svc_rescue_state.*: Request to exit service mode", "REQ_EXIT_SERVICE_MODE"],
    ["extra", 4, "TxCache: Cache Manager primary role going READY", "TXCACHE_STARTED_PRIMARY"],
    ["extra", 4, "TxCache: Cache Manager secondary role going READY", "TXCACHE_STARTED_SECONDARY"],
    ["extra", 4, "is_offlined=", "DRIVE_STATE", \&xx_drive_state],
    ["extra", 4, "cyc_platform_be_real_io_ll_submit.*non-retryable", "DRIVE_ENC_LOCKED", \&xx_nonretry],
    ["extra", 4, "sym_mbe_p_slot_op:.*sending slot operation request slotop r", "SYM_DISK_REMOVED", \&xxx_slotop_removed],
    ["extra", 4, "cyc_platform_be_update_drive_info.*FAILED", "DISK_FAILED", \&xxx_update_drive_info],
    ["extra", 4, "cyc_platform_be_update_drive_info.*OFFLINED", "DISK_OFFLINE", \&xxx_update_drive_info],
    ["extra", 4, "cyc_platform_be_update_drive_info.*READY", "DISK_READY", \&xxx_update_drive_info],
    ["extra", 4, "cyc_platform_be_real_report_failed.*SETTING", "DISK_FAILED", \&xxx_update_drive_info],
    ["extra", 1, "Hypervisor detected: VMware", "IS_VIRTUAL", \&xx_is_virtual],
    ["extra", 1, "reset command completed.0.: /usr/bin/ssh.*cyc_cvm_ctl.py nmi", "FENCE_TVM_NMI_SUCCESS", \&xx_is_virtual],
    ["extra", 1, "reset command timedout: /usr/bin/ssh.*cyc_cvm_ctl.py reset", "FENCE_TVM_RESET_TIMEOUT", \&xx_is_virtual],
    ["extra", 1, "reset command timedout: /usr/bin/ssh.*cyc_cvm_ctl.py nmi", "FENCE_TVM_NMI_TIMEOUT", \&xx_is_virtual],
    ["extra", 1, "reset command completed.1.: /usr/bin/ssh.*cyc_cvm_ctl.py nmi", "FENCE_TVM_NMI_FAILED", \&xx_is_virtual],
    ["extra", 1, "reset command completed.255.: /usr/bin/ssh.*cyc_cvm_ctl.py nmi", "FENCE_TVM_NMI_FAILED", \&xx_is_virtual],
    ["extra", 1, "reset command completed.0.: /usr/bin/ssh.*cyc_cvm_ctl.py reset", "FENCE_TVM_RESET_SUCCESS", \&xx_is_virtual],
    ["extra", 1, "reset command completed.1.: /usr/bin/ssh.*cyc_cvm_ctl.py reset", "FENCE_TVM_RESET_FAILED", \&xx_is_virtual],
    ["extra", 1, "reset command completed.255.: /usr/bin/ssh.*cyc_cvm_ctl.py reset", "FENCE_TVM_RESET_FAILED", \&xx_is_virtual],
    ["extra", 1, "STATUS_AUTHORITY_LOCKED_OUT", "DARE_DISK_LOCKED_OUT"],
    ["extra", 1, ">PM_SLOT_STATE_ENCRYPTED_LOCKED", "DARE_DISK_LOCKED_OUT", \&xxx_dare_update],
    ["extra", 1, ">PM_SLOT_STATE_SIGNED", "DARE_DISK_UNLOCKED", \&xxx_dare_update],
    ["extra", 1, "LBS: there were no valid lockboxes found! Is this a new system", "DARE_LOCKBOX_MISSING"],
    ["extra", 1, "open the Lockbox using the passphrase", "DARE_LOCKBOX_UNOPEN"],
    ["extra", 1, "Eligible drive list is empty", "PPDS_NO_DISKS_FOUND"],
    ["extra", 1, "reset command timedout: /cyc_host/cyc_bsc/scripts/cyc_hc_client", "FENCE_IPMI_FAIL"],
    ["extra", 4, "handle_mbe_p_fence_node: MBE_P message", "FENCING3"],
    ["extra", 4, "Fencing adjacent OFF", "FENCING"],
    ["extra", 4, "Got request to unorderly stop system", "SYM_DISORDERLY_SHUTDOWN"],
    ["extra", 4, "SYM shutdown system: successfully shut down R modules", "SYM_SHUTDOWN_R_MODULES"],
    ["extra", 4, "CLST: cannot read from SSDs; entering", "CLST_READ_TIMEOUT"],
    ["extra", 4, "cannot write on SSDs", "CLST_DISK_WRITE_FAIL"],
    ["extra", 4, "pm_node_fence_adj_node: adjacent node was cut of power - consider it fenced", "FENCE_ALREADY_OFF"],
    ["extra", 4, "pm_power_off_other_node:.* adjacent node is powered off - consider the node fenced", "FENCE_ALREADY_OFF"],
    ["extra", 4, "cyc_np_stonith.* reset peer: failed", "FENCE_FAILED"],
    ["extra", 4, "Not Retryable", "IO_ERROR", \&xx_not_retryable],
    ["extra", 4, "mom_set_comp_state_ex: Changed state of xenv", "XENV", \&xx_xenv_state],
    ["extra", 4, "mom_set_comp_state_ex: Changed state of node", "XNODE", \&xx_xenv_state],
    ["extra", 4, "sym_mom_update_pers_fru_state: update MGMT_OBJTYPE_NODE persistent state in repository", "NODE", \&xx_node_state],
    ["extra", 4, "ham_rule_action_sym_node_failover.*ha_hint", "HAM_FAILOVER", \&xx_ha_hint],
    ["extra", 4, "ham_process_model_change_comp_state: HAM PM: declaring node csid", "HAM", \&xx_ham_state],
    ["extra", 4, "updating HAM system state from", "HAM", \&xx_ham_system_state],
    ["extra", 4, "restart failed, no place else to go starting node failover", "RESTART", \&xx_ham_restartstate],
    ["extra", 3, "ROS: Cached recovery attributes .*, boot mode: 1", "DP_BOOT_MODE_NORMAL"],
    ["extra", 3, "ROS: Cached recovery attributes .*, boot mode: 2", "DP_BOOT_MODE_RECOVERY"],
    ["extra", 3, "ROS: Cached recovery attributes .*, boot mode: 3", "DP_BOOT_MODE_DIAGNOSTIC"],
    ["extra", 4, "Started dossier collector thread for xenv 10", "START_DP_DC"],
    ["extra", 4, "Started dossier collector thread for xenv 11", "START_DP_DC"],
    ["extra", 3, "not making tx progress, failing connection", "ICS_PATH_FAILURE"],
    ["extra", 4, "cyc_ics_set_states", "ICS", \&xx_ics_state_change],
    ["extra", 4, "cyc_ics_check_state_inner", "ICS", \&xx_ics_state_event],
    ["extra", 4, "ham_rule_action_node_failover.*ha_hint", "FAILOVER", \&xx_ham_action_node],
    ["extra", 4, "CLST: state PASSIVE time since last keepalive", "CLST:PASSIVE", \&xx_state_passive],
    ["extra", 4, "clst_ssd_proto_get_reply: CLST: read ssd timeout after", "SSDTIMEOUT", \&xx_read_ssd_timeout],
    ["extra", 4, "sym_election: illegal state after message sending", "SYM_ILLEGALSTATE"],
    ["extra", 4, "Invalid node order value while SYM_Election initializing", "SYM_NODEORDER"],
    ["extra", 4, "CLST: failed to kill SYM when trying to set state from", "KILLSYMFAIL"],
    ["extra", 4, "clst_sym_elect_kill_sym_if_both_clst_has_sym:.*: CLST: transient loop: local SYM is alive! clst state is .*, clst adjacent state is", "KILLSYM", \&xx_sym_alive],
    ["classic", 4, "set_sym_election_state:.*state changed from", "CLST", \&xx_cluster_state],
    ["extra", 3, "/sbin/reboot", "REBOOT_BY_COMMAND"],
    ["extra", 3, "requesting to reset node due to failure of", "FORCE_REBOOT", \&xx_reset_node],
    ["extra", 3, "/bin/kill", "KILLING", \&xx_killing_something],
    ["extra", 3, "pm_proc_kill_process: sending signal", "KILLING", \&xx_pm_killing_something],
    ["extra", 3, "pm_proc_kill_all_xenvs_on_start:.* ATTENTION: - live X-environments were found out during activation; force kill", "PM_KILLING_LIVE_X"],
    ["extra", 4, "Killing XENV", "KILLING", \&xx_killing_xenv],
    ["extra", 4, "Killing Xenv", "KILLING", \&xx_killing_xenv2],
    ["extra", 4, "Cyclone BSC Service Runner: xtremapp-gw: stopping xtremapp-gw", "STOPPING_GW"],
    ["extra", 4, "Cyclone BSC Service Runner: xtremapp-pm: stopping xtremapp-pm", "STOPPING_PM"],
    ["extra", 4, "Killing running process pid", "KILLING", \&xx_killing_proc],
    ["extra", 3, "got node restored event", "RESTORED", \&xx_restored],
    ["classic", 5, "CLST: sending msg with ID", "CLST_SEND",  \&xx_cluster_msg_type],
    ["classic", 5, "ssd_check_msg_got:.* CLST: ssd_check_msg_got", "CLST_RECV", \&xx_cluster_msg_type],
    ["extra", 3, "Decompression failed status", "DP_DECOMPRESSION_FAIL"],
    ["extra", 0, "concurrent map iteration and map write", "DOCKER_PANIC"],
    ["extra", 0, "SMI Device Specific Errors.*Device Specific Fatal Error", "SEL_FATAL_RESET", \&xx_sel_reset],
    ["extra", 0, "PCH Watchdog Timer 1st Stage Timeout", "SEL_WATCHDOG_NMI"],
    ["extra", 0, "Force NMI due to Diagnostic Interrupt detected", "SEL_PEER_NMI"],
    ["extra", 0, "BMC Peer NMI", "SEL_PEER_NMI"],
    ["extra", 0, " SMI.* -N-", "SEL_NMI", \&xx_sel_nmi],
    ["extra", 0, "going to HAVOCK mode", "PM_RESET_PEER_HAVOC_MODE"],
    ["extra", 0, "GEM Boot Progress", "SEL_BMC_PANIC"],
    ["extra", 0, "Cooling/Fan fault detected", "SEL_POST_FAN_FAULT"],
    ["extra", 0, "executing start plugin: vprobe", "ESX_BOOTUP"],
    ["extra", 0, "INFORMATION: POST Start", "SEL_POST_START"],
    ["extra", 0, "Cold Power Up Detected . Asserted", "SEL_POWER_UP"],
    ["extra", 0, "Power Off Host | Asserted.*ELOG(.*) POWER_CAUSE_IPMI_CHASSIS_CONTROL", "SEL_IPMI_POWER_OFF"],
    ["extra", 0, "BMC Power/Reset Action.*Power Cycle Host.*POWER_CAUSE_IPMI_CHASSIS_CONTROL", "SEL_IPMI_POWER"],
    ["extra", 0, "BMC Power/Reset Action .* Reset Action . Asserted", "SEL_IPMI_POWER"],
    ["extra", 0, "Power Cycle Host | Asserted.*ELOG.*POWER_CAUSE_IPMI_CHASSIS_CONTROL", "SEL_IPMI_POWER"],
    ["extra", 0, "Upper Non-critical going high . Asserted", "SEL_UPPER_NON_CRITICAL_TEMP"],
    ["extra", 0, "Upper Critical going high . Asserted", "SEL_UPPER_CRITICAL_TEMP"],
    ["extra", 3, "ha-engine", "HA", \&xx_ha_engine],
    ["extra", 3, "kernel: Out of memory: Kill process", "OOM_KILL", \&xx_oom_kill3],
    ["extra", 3, "Memory cgroup out of memory", "OOM_KILL", \&xx_oom_kill],
    ["extra", 3, "invoked oom-killer", "OOM_KILL2", \&xx_oom_kill2],
    ["extra", 3, "TRINDU", "NDU", \&xx_ndu],
    ["extra", 3, "lrmd.*warning: cyc-controlpath_monitor.*timed out after", "CP_TIMEOUT"],
    ["extra", 3, "crmd.*notice: Initiating stop operation cyc-controlpath_stop_0", "CP_KILL"],
    ["extra", 3, "emc.cyclone.controlpath.bootstrap.Launcher.* Node Name:", "CP_START"],
    ["extra", 3, "emc.cyclone.controlpath.bootstrap.Launcher.* CP shutting down", "CP_STOP"],
    ["extra", 1, "DEBUG .cyc_helper_interface.: Running helper command: .*reinit_array.sh", "HELP_REINIT_ARRAY"],
    ["extra", 1, "DEBUG .cyc_helper_interface.: Running helper command: .*do_scrub_host.sh", "HELP_SCRUB_HOST"],
    ["extra", 1, "DEBUG .cyc_helper_interface.: Running helper command: .*sys_cluster_stop.sh", "HELP_CLUSTER_STOP"],
    ["extra", 1, "DEBUG .cyc_helper_interface.: Running helper command: .*start_cluster_ng.sh", "HELP_CLUSTER_START"],
    ["extra", 1, "DEBUG .cyc_helper_interface.: Running helper command: .*hard_bounce_a.sh", "HELP_HARD_BOUNCE_A"],
    ["extra", 1, "DEBUG .cyc_helper_interface.: Running helper command: .*hard_bounce_b.sh", "HELP_HARD_BOUNCE_B"],
    ["extra", 1, "HAM PM: declaring node csid 8 dead", "HAM_NODE_A_DEAD"],
    ["extra", 1, "HAM PM: declaring node csid 9 dead", "HAM_NODE_B_DEAD"],
    ["extra", 1, "HAM events: PM reconnect done,  csid 8", "HAM_NODE_A_RECONNECT"],
    ["extra", 1, "HAM events: PM reconnect done,  csid 9", "HAM_NODE_B_RECONNECT"],
    ["extra", 1, "HAM rules: event ID.*, SYM node failover .ha_hint .*preempting SYM to other node", "HAM_SYM_PREEMPT", \&xx_sym_node_failover],
    ["extra", 1, "HAM infra: system state changed from .* after running rules of type", "HAM_STATE", \&xx_ham_state2],
    #END PATTERNS#
    #
    #["extra", 1, "starting xtremapp-survivor", "SURVIVOR_START"],
    #["extra", 1, "ERROR - unsupported cdb opcode", "DP_BAD_CDB", \&xx_bad_cdb],
    #["extra", 3, "crmd.*notice: High CPU load detected:", "CRMD_HIGH_LOAD",  \&xx_crmd_high_load],
    #["extra", 1, "Going to stop xtremapp-survivor", "SURVIVOR_STOP"],
    #["extra", 2, "cyc-init.pl --stop iscsi-scst", "SCST_STOP"],
    #["extra", 2, "bsc-iscsi_scst.*: started", "SCST_START"],
);

 my @clst_msgs = ("CLST_EXCHANGE_MSG_INVALID",
             "CLST_EXCHANGE_MSG_QUERY_STATUS",
             "CLST_EXCHANGE_SYM_PREEMPT",
             "CLST_EXCHANGE_SYM_KILL",
             "CLST_EXCHANGE_MSG_NULL",
             "CLST_EXCHANGE_MSG_START",
             "CLST_EXCHANGE_MSG_SYM_RESTART",
             "CLST_EXCHANGE_MSG_NUM_OF");
             
#Sep 17 21:40:25 FNM00175100031-A xtremapp[9254]: Sep 17 21:40:25.728120 M [log_id:5907][6669(6681 nb_truck_0_sym   0x7f263829ea80)]xenv_restart: MR: going to restart xenv csid 11 on node csid 9
#Feb 16 08:09:41 FNM00183600965-A xtremapp-gw[25574]: # Cyclone BSC Service Runner: xtremapp-gw: stopping xtremapp-gw
#Feb 16 08:09:41 FNM00183600965-A xtremapp-pm[25634]: # Cyclone BSC Service Runner: xtremapp-pm: stopping xtremapp-pm
#
#
my $system_reboot_time = 216;  # Rough guess in seconds for Bare Metal kernel panic/reboot.
##################################################################
# Mark this as a virtual setup - changes the timing adjust for panic
sub xx_is_virtual($)
{
$system_reboot_time = 198;  # Rough guess in seconds for VM kernel panic/reboot.
return " ";
}

##################################################################
# Just return nothing so the line is ignored.
sub xx_eat_line($)
{
return "";
}

my %disksoffline;
my %disksfailed;

sub xx_drive_state($)
{
    my $xline = $_[0];
    my $xinfo = $xline;
     
#Jan 06 11:13:52 FNM00183202684-A xtremapp[15060]: Jan 06 11:13:52.188141 D10 [log_id:0][2900(2941 nb_truck_4       0x7f9d60da2a80)]mbe_d_complete_update_drive_info:542: 0_0_24 guid=81de579b38484f7cae50942cd8b280ed, is_offlined=1, offline_reason_bitmap=0x1, is_failed=0 enc_locked=0 active_lcc=0 lcc_count=1 paths[0]=/dev/disk/by-id/xio-wwn-82296328584-        feed100 paths[1]=
#

    my @fields = split(' ', $xinfo);
    my $diskid = $fields[7];
    my $diskoffline = $fields[9];
    $diskoffline =~ s/,//;
    $diskoffline =~ s/.*=//;
    my $diskfailed = $fields[11];
    $diskfailed =~ s/,//;
    $diskfailed =~ s/.*=//;
    if (!(looks_like_number($diskoffline)) || 
        !(looks_like_number($diskfailed))) {
        # botched parse
        return "";
    }
    my $oldoffline = $diskoffline ^ 1;
    if (defined ($disksoffline{$diskid})) {
        $oldoffline = $disksoffline{$diskid};
    }
    my $oldfailed = $diskfailed ^ 1;
    if (defined ($disksfailed{$diskid})) {
        $oldfailed = $disksfailed{$diskid};
    }
    if ($oldfailed != $diskfailed || $oldoffline != $diskoffline) {
        $disksoffline{$diskid} = $diskoffline;
        $disksfailed{$diskid} = $diskfailed;
        if ($diskoffline) {
          $xinfo = "$diskid OFFLINE ";
        } else {
          $xinfo = "$diskid ONLINE ";

        }
        if ($diskfailed) {
          $xinfo = $xinfo . "FAILED";
        }
    } else {
        $xinfo = "";
    }
    return $xinfo;
}

#forcereboot somescriptname.sh
sub xx_force_reboot($)
{
    my $xinfo = $_[0];
    chomp($xinfo);
    $xinfo =~ s/^.*forcereboot//;
    return $xinfo;
}

#forcekdump somescriptname.sh
sub xx_force_kdump($)
{
    my $xinfo = $_[0];
    chomp($xinfo);
    $xinfo =~ s/^.*forcekdump//;
    return $xinfo;
}

#sym_mbe_p_slot_op:1395: sending slot operation request slotop r 0 0 8
sub xxx_slotop_removed($)
{
    my $xline = $_[0];
    my $xinfo = $xline;
    chomp($xinfo);
    $xinfo =~ s/^.*slotop r //;
    $xinfo =~ s/ /_/g;
    return $xinfo;
}

#Dec 26 09:25:07.001345 FNM00183701045-A xtremapp[15130]: Dec 26 09:25:07.000876 M [log_id:4500][11503(11555 nb_truck_0_sym 0x7fa4a2b09b80)]sym_ham_sm_check_if_node_healthy:5679: Node 8 has at least two Inactive LCCs for the same JBOD, invalid to run D modules
sub xx_dp_blocked($)
{
    my $xline = $_[0];
    $xline =~ s/.*sym_ham_sm_check_if_node_healthy://;
    $xline =~ s/.*://;
    $xline =~ s/invalid to run D modules//;
    return $xline;
}

sub xx_sel_reset($)
{
#Oct 08 08:52:10.999999   d9 | 10/08/2019 | 08:52:10 | SMI Device Specific Errors |  I/O Module 0 | Device Specific Fatal Error | Asserted | Bus=0x33 Dev=0x00 Func=0x00       ELOG(123) -R- Uncorrectable Internal Error Status. Bus:33H Dev:00H Fn:00H SID:00000000H FEP:00H HL:00000000000000000000000000000000H

    my $xline = $_[0];
    $xline =~ s/^.*-R-//;
    $xline =~ s/ SID.*//;
    return $xline;
}

sub xx_sel_nmi($)
{
#Oct 08 08:52:10.999999   dd | 10/08/2019 | 08:52:10 | SMI Device Specific Errors |  I/O Module 0 | Device Specific Correctable Error | Asserted | Bus=0x35 Dev=0x00 Func=0x00       ELOG(61) -N- COMPLETION TIMEOUT STATUS. Bus:35H Dev:00H Fn:00H PS:C0H
#Oct 08 08:52:10.999999   df | 10/08/2019 | 08:52:10 | SMI PCI-e Device Errors |  CPU Integrated I/O 0 | Received Master Abort | Asserted | Bus=0x30 Dev=0x00 Func=0x00       ELOG(62) -N- RMA: RECEIVED MASTER ABORT. Bus:30H Dev:00H Fn:00H PS:C0H
#Oct 08 08:52:10.999999   e7 | 10/08/2019 | 08:52:10 | SMI AER Uncorrectable PCI-e Errors |  CPU Integrated I/O 0 | Received Unsupported Request | Asserted | Bus=0x30 Dev=0x00 Func=0x00       ELOG(76) -N- SENT COMPLETION WITH UNSUPPORTED REQUEST. Bus:30H Dev:00H Fn:00H PS:C0H
#Oct 08 08:52:10.999999   e8 | 10/08/2019 | 08:52:10 | SMI Device Specific Errors |  CPU Integrated I/O 0 | Device Specific Correctable Error | Asserted | Bus=0x30 Dev=0x05 Func=0x00       ELOG(54) -N- MISC. ERROR STATUS. Bus:30H Dev:05H Fn:00H PS:C0H

    my $xline = $_[0];
    $xline =~ s/^.*-N-//;
    return $xline;
}



sub xx_sym_node_failover($)
{
# HAM rules: event ID 24126, SYM node failover (ha_hint 22)! preempting SYM to other node
#
    my @hints = qw(DATA_PATH_ERR CTRL_PATH_ERR PROCESS_DIED_NOTIF EXTERNAL_REQUEST USER_DEACTIVATED DAE_DISCONNECT SSD_SLOT_ERROR HA_FAILURE REPORTS_UNDER_THRESHOLD_TIMEOUT_EXCEEDED FALSE_REPORTS FAILED_IN_REPOSITORY AGGREGATED_NODE_FAILURE TOO_MANY_FAILED_NODES TEMPERATURE_TOO_HIGH ISCSI_DAEMON_FAILED SSD_FAILED LCCS_FAILED DIMM_HEALTH_FAILED SYM_DISCONNECT QUERY_TIMEOUT NAS_FAILURE LB_UNASSEMBLE_FAILURE FO_FROM_PM SERVICE_MODE);
    my $xline = " ";
    my $hintnum = $_[0];
    $hintnum =~ s/^.*ha_hint //;
    $hintnum =~ s/.. .*//;
    if (defined $hints[int($hintnum)]) {
        $xline = " hints $hints[int($hintnum)]";
    }
    return $xline;
}


sub xx_ham_state2($)
{
# 2019-11-12_16:54:07.910265 | TR 0 TH 00007f72c795cb80 | HAM infra: system state changed from 2 to 5 after running rules of type ACTION
# 
#
    my @sstates = qw(INIT STARTING ACTIVE STOPPING_ORDERLY STOPPING_UNORDERLY STOPPED GATES_CLOSE NUM_OF INVALID);
    my $xline = $_[0];
    my $sfrom = $_[0];
    my $sto = $_[0];
    $sfrom =~ s/.*changed from //;
    $sfrom =~ s/ to .*//;
    $sto =~ s/.*changed from .* to //;
    $sto =~ s/ after .*//;
    $xline =~ s/^.*after running//;
    return " from $sstates[int($sfrom)] to $sstates[int($sto)] $xline";
}


sub xx_reset_node($)
{
#Oct 23 04:41:39 FNM00183600968-A bsc-fail_handler[113627]: requesting to reset node due to failure of cyc.db_space_check.service
#
    my $xline = $_[0];
    $xline =~ s/^.*failure of//;
    return $xline;
}


sub xx_sym_ros($)
{
#Dec 11 08:46:29.896709 FNM00183801637-A xtremapp[74766]: Dec 11 08:46:29.896175 M [log_id:42901][47610(47674 nb_truck_0_sym   0x7f8ff1465b00)]bl_set_dp_recovery_state_common:12194: SYM ROS: going to close/open gates with reason dp_service_offline
#
    my $xline = $_[0];
    $xline =~ s/^.*gates with reason//;
    return $xline;
}

sub xx_show_result($)
{
#Aug 23 07:22:23 FNM00191900407-A xtremapp[74013]: Aug 23 07:22:23.975086 M [log_id:3767][56700(56848 nb_truck_0_sym   0x7f75bd7aac80)]handle_typical_xms_command:3519: SYM ended SYM_CMD_POST_GENERIC_PLATFORM_EVENT cmd, result timeout
    my $xline = $_[0];
    $xline =~ s/^.*result//;
    return $xline;
}


sub xx_nonretry($)
{
#timeline_gen_helpers/Jjrbinterest.txt:Aug 03 02:27:23 FCNWD00182801209-B xtremapp[40837]: Aug 03 02:27:21.876141 X11 [log_id:0][12798(13093 nb_truck_12      0x7f346673eb00)]cyc_platform_be_real_io_ll_submit:2607: 1_0_16 drive is offline. Setting io status to non-retryable
#
    my $xline = $_[0];
    my $xinfo = $xline;
    $xinfo =~ s/^.*cyc_platform_be_real_io_ll_submit:[0-9]*://;
    $xinfo =~ s/Setting io.* //;
    return $xinfo;
}


my $have_boot_time = 0;
my $boot_month = "Jan";
my $boot_day = "1";
my $boot_timestamp = "00:00:00";

sub xx_startup_cmdline($)
{
#  Jul 25 22:11:24 localhost kernel: Command line: BOOT_IMAGE=/coreos/vmlinuz-a mount.usr=PARTUUID=7130c94a-213a-4e5
    my $xline = $_[0];
    my ($boot_month, $boot_day, $boot_timestamp) = split(/ /, $xline); 
    $have_boot_time = 1;
    # return value just prints the base message.
    return " ";
}

my $last_ha_line = "";
sub xx_ha_engine($)
{
#Mar 22 16:58:28 FNM00183202670-A ha-engine[26900]: ha state changed from:UNKOWN to  SLAVE
#

    my $xline = $_[0];
    my $xinfo = $xline;
    chomp($xinfo);
    $xinfo =~ s/^.*ha-engine\[[0-9]*\]://;
    if (index($last_ha_line, $xinfo) != -1) {
       # dont print repeats 
       return "";
    }
    $last_ha_line = $xinfo;
    return $xinfo;
}

sub xx_pathloss($)
{
#Nov 08 02:08:52 FNM00183400726-B multipathd[6135]: 368ccf0980057d9bb43c1725d4eb5d541: remaining active paths: 0
#
    my $xline = $_[0];
    chomp $xline;
    #$xline =~ s/.*\([0-9a-f]{33}\).*/$1/;
    $xline =~ s/.*]://;
    $xline =~ s/: rem.*//;
    return $xline;
}

sub xx_pathchange($)
{
#Oct 28 09:40:56 FNM00183801198-A multipathd[2855]: checker failed path 8:64 in map 368ccf09800225da1cb95846472cd739d
#Aug 05 11:04:20 FNM00181600548-B kernel: device-mapper: multipath: Failing path 251:1.
#
    my $xline = $_[0];
    chomp $xline;
    $xline =~ s/.*path/path/;
    return $xline;
}


## In the traces
sub xx_bad_cdb($)
{
#2019-07-30_08:06:30.149691 | TR 2 TH 00007f1968b78900 | ERROR - unsupported cdb opcode 0xa3
    my $xline = $_[0];
    $xline =~ s/.*opcode/opcode/;
    return $xline;
}

sub xx_crmd_high_load($)
{
#Jun 28 22:14:38 FNM00183402405-A crmd[82599]:   notice: High CPU load detected: 13.820000
    my $xline = $_[0];
    $xline =~ s/.*ted://;
    return $xline;
}

sub xx_ndu($)
{
#Mar 26 21:23:56 FNM00180302296-A xtremapp[98415]: Mar 26 21:23:56.953573 M [log_id:0][112804(112923 nb_truck_0_sym   0x7f91248a9700)]bl_ndu_upgrade_thread:2200: TRINDU_FLOW: Setting HAM system state to stopped
#

    my $xline = $_[0];
    my $xinfo = $xline;
    chomp($xinfo);
    $xinfo =~ s/^.*TRINDU./ /;
    return $xinfo;
}


sub xx_oom_kill($)
{
#Mar 24 18:09:50.261590 [258414.192037] Memory cgroup out of memory: Kill process 102777 (xtremapp) score 96 or sacrifice child
#

    my $xline = $_[0];
    # filter junk lines like "pytest[11087]: about to run command (endpoint: SSH): <sh -c journalctl -k -p err --no-pager | grep Memory cgroup out of memory> ()"
    # might want to globally ditch all lines containing " grep "
    if ($xline =~ m/grep Memory/){
        return "";
    }
    my $xinfo = $xline;
    chomp($xinfo);
    $xinfo =~ s/^.*Kill process//;
    $xinfo =~ s/score.*//;
    return $xinfo;
}


sub xx_oom_kill2($)
{
#Mar 24 18:09:50.176809 [258414.107256] pm_ssd invoked oom-killer: gfp_mask=0x4342ca(GFP_TRANSHUGE), nodemask=(null),  order=9, oom_score_adj=0
#

    my $xline = $_[0];
    my $xinfo = $xline;
    chomp($xinfo);
    $xinfo =~ s/^.*\]//;
    $xinfo =~ s/, nodemask.*//;
    return $xinfo;
}

sub xxx_dare_update($)
{
#Jul 31 16:37:33 FNM00183600740-B xtremapp-pm[16627]: Jul 31 16:37:33.432800 P [log_id:0][2100(2123 nb_truck_0_pm    0x7f581af8fac0)]ssd_update_in_mom:1606: DRV:1_2_10 SN:45NY0K801232 updating SSD wwn-0x5002538b08840ca0 [45NY0K801232] in mom: Slot_State PM_SLOT_STATE_EMPTY->PM_SLOT_STATE_SIGNED
#

    my $xline = $_[0];
    my $xinfo = $xline;
    $xinfo =~ s/^.*sd_update_in_mom:[0-9]*: //;
    $xinfo =~ s/SN:.*->//;
    return $xinfo;
}


sub xx_oom_kill3($)
{
#May 13 12:50:48 FNM00175100481-A kernel: Out of memory: Kill process 84728 (xtremapp) score 63 or sacrifice child
#

    my $xline = $_[0];
    my $xinfo = $xline;
    chomp($xinfo);
    $xinfo =~ s/^.*Kill process//;
    $xinfo =~ s/score .*//;
    return $xinfo;
}


sub xxx_update_drive_info($)
{
#Jan 24 08:44:03 FNM00184100400-A xtremapp[47012]: Jan 24 08:44:03.472986 D10 [log_id:0][5772(5792 nb_truck_6       0x7fe6e1aeeb00)]cyc_platform_be_update_drive_info:1896: NDP RBE: drive DRV:0_0_23 OFFLINED.
#Jan 24 08:48:46 FNM00184100400-A xtremapp[47012]: Jan 24 08:48:46.985309 D10 [log_id:0][5772(5793 nb_truck_7       0x7fe6e1b2c7c0)]cyc_platform_be_real_report_failed:4666: NDP RBE: Request to mark FAILED.  SETTING disk_failed for DRV:0_0_23

    my $xline = $_[0];
    my $xinfo = $xline;
    chomp($xinfo);
    if ($xline =~ m/cyc_platform_be_update_drive_info/){
        $xinfo =~ s/^.*DRV://;
    }
    if ($xline =~ m/cyc_platform_be_real_report_failed/){
        $xinfo =~ s/for DRV://;
        $xinfo =~ s/^.*SETTING //;
    }
    return $xinfo;
}


my %pidhash;
my $xpid;
sub xx_save_pid($)
{
    my $xline = $_[0];
    my $xpid = $_[1];
    my $xinfo = " ";
    my $cs = "UNK";
     
    $xpid =~ s/.*\[//;
    $xpid =~ s/\].*//;
    if ($xline =~ /csid 0/) { $cs = "GW"; }
    if ($xline =~ /csid 1/) { $cs = "SYM"; }
    if ($xline =~ /csid 10/) { $cs = "DP"; }
    if ($xline =~ /csid 11/) { $cs = "DP"; }
    if ($xline =~ /csid -1/) { $cs = "PM"; }

#Jan 09 13:45:07 FNM00183601151-A xtremapp-gw[22194]: Jan 09 13:45:07.575238 X [log_id:10032][39337(39337 [OS Thread]                    )]x_init: XIOS csid 0 mem: 58720256 bytes, after round: 58720256 bytes huge_mem_pages 0
    # For this PID, save the cs type
    $pidhash{$xpid} = $cs;

    return $xinfo;
}

sub xx_signal($)
{
#May 14 01:22:27 FNM00183200946-A xtremapp[41257]: May 14 01:22:27.296857 X [log_id:10010][12825(12825 [OS Thread]                    )]signal_handler:3177: Signal 15 received. Ret=0x7fb8ab0275d0, Frame=0x7fb8ab35d370
    my $xline = $_[0];
    my $xpid = $_[1];
    my $xinfo = $xline;
    $xinfo =~ s/.*Signal//;
    $xinfo =~ s/received.*//;
    $xpid =~ s/.*\[//;
    $xpid =~ s/\].*//;
    if (defined($pidhash{$xpid})) {
        $xinfo = $xinfo . " " . $pidhash{$xpid};
    }
    else {
        $xinfo = $xinfo . " unknown";
    }
    return $xinfo;
}

sub xx_quiet_panic($)
{
    my $xline = $_[0];
    my $xpid = $_[1];
    my $xinfo = "UNK";
     
#Jan 09 13:45:07 FNM00183601151-A xtremapp-gw[22194]: Jan 09 13:45:07.575238 X [log_id:10032][39337(39337 [OS Thread]                    )]x_init: XIOS csid 0 mem: 58720256 bytes, after round: 58720256 bytes huge_mem_pages 0
    # get the type for this pid
    if ($xpid =~ /xtremapp-gw/) { return "GW"; }
    if ($xpid =~ /xtremapp-pm/) { return "PM"; }
    $xpid =~ s/.*\[//;
    $xpid =~ s/\].*//;
    if (defined($pidhash{$xpid})) {
        $xinfo = $pidhash{$xpid};
    }
    return $xinfo;
}


##################################################################
# Jun 27 17:14:08 FNM00183200603-A sudo[127233]:     root : TTY=unknown ; PWD=/ ; USER=root ; COMMAND=/cyc_host/cyc_common/cyc_servicemode.sh --enter --reason KMS_LOCKBOX_FAULT
#
sub xx_servicemode($)
{
    my $xline = $_[0];
    my $xinfo = $xline;
     
    $xinfo =~ s/^.*reason / /;
    
    return $xinfo;
}

##################################################################
#Aug 20 13:40:39 FNM00185100382-A cat[56012]: QA[1] INFO Running test case: QC-50033,Test_QC50033_MaxFSonSingleNas
sub xx_qa_info($)
{
    my $xline = $_[0];
    $xline =~ s/^.*INFO / /;
    return $xline;
}



##################################################################
##################################################################
# Mar 11 09:52:47 FNM00183600247-A cat[96346]: QA[66] ACTION [MODIFY:NODE] D0550-node-1 changing reboots setting to on
#
sub xx_pytest($)
{
    my $xline = $_[0];
    my $xinfo = $xline;
     
    $xinfo =~ s/^.*PYTEST_/ /;
    
    return $xinfo;
}

##################################################################
##################################################################
# Mar 11 09:52:47 FNM00183600247-A cat[96346]: QA[66] ACTION [MODIFY:NODE] D0550-node-1 changing reboots setting to on
#
sub xx_qa_action($)
{
    my $xline = $_[0];
    my $xinfo = $xline;
     
    $xinfo =~ s/^.*ACTION / /;
    
    return $xinfo;
}

##################################################################
# pm_node_perform_emergency_shutdown_imp:3862: ES: reason=node_initiated_emergency_shutdown (265)
sub xx_es($)
{
    my $xline = $_[0];
    my $xinfo = $xline;
     
    $xinfo =~ s/^.*reason=/ /;
    
    return $xinfo;
}

##################################################################
#cyc_ppds[3307]: B: # Error: Detected survey botch (test_write) on /dev/sdd
#
sub xx_survey_botch($)
{
    my $xline = $_[0];
    my $xinfo = $xline;
     
    $xinfo =~ s/^.*on \// \//;
    
    return $xinfo;
}

##################################################################
## Ignore these:
#./2019-06-25T15-06-40/2b658593-a97d-419b-8180-e505ed581119/powerstore_PSbb0c64c6e45d_FNM00183202680_2019-06-25_19-42-43_service-data/timeline_gen_helpers/jrainterest.txt:Jun 25 18:29:56 FNM00183202680-A xtremapp[27184]: Jun 25 18:29:56.987447 X10 [log_id:0][7303(7417 nb_truck_12      0x7f442645dc80)]rolling_reboot_detect_iterate_callback:1888: SPA seq:62 id:cyc_shutdown text:requested shutdown: poweroff-node -force.
#
sub xx_cyc_shutdown($)
{
    my $xline = $_[0];
    my $xinfo = $xline;
    # reject if this is rolling reboot reiteration of previous mel data
    if ($xinfo =~ /rolling_reboot_detect_iterate_callback/) {
        return "";
    }
    $xinfo =~ s/^.*shutdown://;
    
    return $xinfo;
}


##################################################################
##################################################################
#Jun 06 17:18:41 FNM00175100029-A svc_shutdown[122730]: Svc shutdown command: target: secondary force: False async: False key: poweroff-node debug: False
sub xx_svc_shutdown($)
{
    my $xline = $_[0];
    my $xinfo = $xline;
     
    $xinfo =~ s/^.*command: //;
    
    return $xinfo;
}


##################################################################
# Feb 26 00:03:54 FNM00183202670-B xtremapp[28746]: Feb 26 00:03:54.792735 M [log_id:0][63872(64007 nb_truck_0_sym   0x7f7c242728c0)]nvram_get_bbu_status:4167: NVME: DRV:0_0_23 SN:714463ECB44 throttled: BBU is READY on node A.
# Feb 26 00:03:54 FNM00183202670-B xtremapp[28746]: Feb 26 00:03:54.792735 M [log_id:0][63872(64007 nb_truck_0_sym   0x7f7c242728c0)]nvram_get_bbu_status:4167: NVME: DRV:0_0_23 SN:714463ECB44 throttled: BBU is NOT READY on node A.
sub xx_bbu_ready($)
{
    my $xline = $_[0];
    my $xinfo = $xline;
     
    $xinfo =~ s/^.*on node/ Node/;
    
    return $xinfo;
}

##################################################################
#    [3, "sym_bl_ham_events_close_gates: HA_FLOW: Attemting to close gates reason", "CLOSE_GATES", \&xx_close_gates],
sub xx_close_gates($)
{
    my $xline = $_[0];
    my $xinfo = $xline;
     
    chomp $xinfo;
    $xinfo =~ s/^.*close gates reason//;
    
    return $xinfo;
}
##################################################################
#    [4, "clst_sym_elect_kill_sym_if_both_clst_has_sym:2901: CLST: transient loop: local SYM is alive! clst state is .*, clst adjacent state is .* , "CLST", \&xx_sym_alive],

sub xx_sym_alive($)
{
    my $xline = $_[0];
    my $xinfo = $xline;
     
    $xinfo =~ s/^.*clst state is/Local:/;
    $xinfo =~ s/, clst.*is/ Peer:/;
    
    return $xinfo;
}
##################################################################
##################################################################
sub xx_state_passive($)
{
    my $xline = $_[0];
    my $xinfo = $xline;
     
#Oct 17 17:22:25 FNM00180100370-B xtremapp-pm[13826]: Oct 17 17:22:25.993332 P [log_id:23988][2896(6801 clst_sym_elect   0x7f41fe646700)]sym_preemption_required:637: CLST: state PASSIVE  since last keepalive 4075 ms ; querying adjacent

    if ($xline =~ m/CLST: state PASSIVE/){
	$xinfo =~ s/^.*keepalive/after /;
	$xinfo =~ s/ms.*/ms/;
    }
    return $xinfo;
}
##################################################################
sub xx_restored($)
{
    my $xline = $_[0];
    my $xinfo = $xline;
    my $xtype = "";

# Oct 24 21:54:43 FNM00183202670-A xtremapp[154276]: Oct 24 21:54:43.315401 M [log_id:4542][91787(91791 nb_truck_0_sym   0x7ff856f8dc40)]ham_process_model_handle_node_restored: HAM PM: got node restored event ID 6199 for csid 9, node health state is 6
#
    if ($xline =~ /csid 8/) {
       $xtype = "PM-A" ;
    }
    if ($xline =~ /csid 9/) {
       $xtype = "PM-B" ;
    }
    if ($xline =~ /csid 1/) {
       $xtype = "SYM" ;
    }
    if ($xline =~ /csid 10/) {
       $xtype = "DP-A" ;
    }
    if ($xline =~ /csid 11/) {
       $xtype = "DP-B" ;
    }
    if ($xline =~ m/got node restored/){
	$xinfo =~ s/^.*tate is/$xtype HEALTHY /;
    }
    return $xinfo;
}
##################################################################
##################################################################
##################################################################
#Feb 13 05:08:18 FNM00174603260-A xtremapp-pm[80522]: Feb 13 05:08:18.239392 P [log_id:11607][13836(16241 clst_sym_elect   0x7fe62ac23fc0)]pm_proc_kill_process: sending signal 6 to pid 18029 (csid 10) - triggering core dump
#
##################################################################
sub xx_killing_proc($)
{
    my $xline = $_[0];
    my $xinfo = $xline;
    my $xtype = "";
     
#Oct 24 21:55:34 FNM00183202670-B xtremapp-pm[11092]: Oct 24 21:55:34.445890 P [log_id:8254][2162(2410 nb_truck_0_pm    0x7f0dd8639f80)]mbe_p_kill_xenv:1641: Killing XENV: guid = 895139a6954b44ec8d3852da30b69f6e, CSID = 11
#
    if ($xline =~ /csid 8/ || $xline =~ /csid 9/) {
       $xtype = "PM" ;
    }
    if ($xline =~ /csid 1/) {
       $xtype = "SYM" ;
    }
    if ($xline =~ /csid 11/ || $xline =~ /csid 10/) {
       $xtype = "DP" ;
    }
    if ($xline =~ m/Killing running process/){
	$xinfo =~ s/^.*pid/Killing $xtype pid/;
	$xinfo =~ s/.csid.*//;
    }
    return $xinfo;
}
##################################################################
##################################################################
##################################################################
sub xx_killing_xenv2($)
{
    my $xline = $_[0];
    my $xinfo = $xline;
    my $xtype = "";
     
#Jun 05 04:09:26 FNM00181600550-B xtremapp-pm[14580]: Jun 05 04:09:26.403232 P [log_id:8254][2206(2275 nb_truck_0_pm    0x7f392f2e8580)]mbe_p_kill_xenv:1596: Killing Xenv csid 11 guid 3d4490e4f3974aeb990b7e2091501240 hint 'roll back failed flow node_failback'
#
    if ($xline =~ /csid 8/ || $xline =~ /csid 9/) {
       $xtype = "PM" ;
    }
    if ($xline =~ /csid 1/) {
       $xtype = "SYM" ;
    }
    if ($xline =~ /csid 11/ || $xline =~ /csid 10/) {
       $xtype = "DP" ;
    }
    if ($xline =~ m/Killing Xenv/){
	$xinfo =~ s/^.*hint/Killing $xtype/;
    }
    return $xinfo;
}
##################################################################
##################################################################
sub xx_killing_xenv($)
{
    my $xline = $_[0];
    my $xinfo = $xline;
    my $xtype = "";
     
#Oct 24 21:55:34 FNM00183202670-B xtremapp-pm[11092]: Oct 24 21:55:34.445890 P [log_id:8254][2162(2410 nb_truck_0_pm    0x7f0dd8639f80)]mbe_p_kill_xenv:1641: Killing XENV: guid = 895139a6954b44ec8d3852da30b69f6e, CSID = 11
#
    if ($xline =~ /CSID = 8/ || $xline =~ /CSID = 9/) {
       $xtype = "PM" ;
    }
    if ($xline =~ /CSID = 1/) {
       $xtype = "SYM" ;
    }
    if ($xline =~ /CSID = 11/ || $xline =~ /CSID = 10/) {
       $xtype = "DP" ;
    }
    if ($xline =~ m/Killing XENV/){
	$xinfo =~ s/^.*CSID = /Killing $xtype /;
    }
    return $xinfo;
}
##################################################################
#Feb 13 05:08:18 FNM00174603260-A xtremapp-pm[80522]: Feb 13 05:08:18.239029 P [log_id:8598][13836(16241 clst_sym_elect   0x7fe62ac23fc0)]ssd_check_msg_got:1043: CLST: ssd_check_msg_got 7 (FENCE REQUESTED) with id 41
#Feb 13 05:08:18 FNM00174603260-A xtremapp-pm[80522]: Feb 13 05:08:18.239047 P [log_id:41951][13836(16241 clst_sym_elect   0x7fe62ac23fc0)]get_event_from_last_msg:1515: CLST: SSD-based protocol message 7 got
#Feb 13 05:08:18 FNM00174603260-A xtremapp-pm[80522]: Feb 13 05:08:18.239054 P [log_id:41952][13836(16241 clst_sym_elect   0x7fe62ac23fc0)]clst_handle_event_according_to_curr_state:1733: handling event StartSelfFencing
#Feb 13 05:08:18 FNM00174603260-A xtremapp-pm[80522]: Feb 13 05:08:18.239089 P [log_id:951][13836(16241 clst_sym_elect   0x7fe62ac23fc0)]pm_proc_xenv_processes_still_exist:1553: X-environment env_id=10, pid=18029 is alive
#Feb 13 05:08:18 FNM00174603260-A xtremapp-pm[80522]: Feb 13 05:08:18.239095 P [log_id:977][13836(16241 clst_sym_elect   0x7fe62ac23fc0)]pm_proc_kill_all_xenvs_on_start:2626: ATTENTION: - live X-environments were found out during activation; force kill
##################################################################
#Feb 13 05:08:18 FNM00174603260-A xtremapp-pm[80522]: Feb 13 05:08:18.239392 P [log_id:11607][13836(16241 clst_sym_elect   0x7fe62ac23fc0)]pm_proc_kill_process: sending signal 6 to pid 18029 (csid 10) - triggering core dump
sub xx_pm_killing_something($)
{
    my $xline = $_[0];
    my $xinfo = $xline;
     
    $xinfo =~ s/^.*ignal /SIG/;
    $xinfo =~ s/ - triggering core dump//;
    return $xinfo;
}
##################################################################
##################################################################
##################################################################
sub xx_killing_something($)
{
    my $xline = $_[0];
    my $xinfo = $xline;
     
#Jan 30 04:54:16 FNM00183801753-B sudo[12255]:      cyc : TTY=unknown ; PWD=/home/cyc ; USER=root ; COMMAND=/bin/kill -6 6775
#
    $xinfo =~ s/^.*kill/Kill/;
    return $xinfo;
}
##################################################################
##################################################################
sub xx_read_ssd_timeout($)
{
    my $xline = $_[0];
    my $xinfo = $xline;
     
#Oct 17 17:22:40 FNM00180100370-B xtremapp-pm[13826]: Oct 17 17:22:40.103104 P [log_id:8588][2896(6801 clst_sym_elect   0x7f41fe646700)]clst_ssd_proto_get_reply: CLST: read ssd timeout after 108 retries time_spent 14108 msec
    if ($xline =~ m/clst_ssd_proto_get_reply/){
	$xinfo =~ s/^.*time_spent /after /;
    }
    return $xinfo;
}
##################################################################
##################################################################
sub xx_ha_gates($)
{
    my $xline = $_[0];
    my $xinfo = $xline;
     
#Jun 24 21:10:41 FNM00184000591-A xtremapp[81988]: Jun 24 21:10:41.012208 M [log_id:41916][14095(14311 nb_truck_0_sym   0x7fdb6ee50bc0)]ham_process_model_create_close_gates_event:134: HA_FLOW: requesting to close gates, reason dae_inaccessible
    if ($xline =~ m/reason/){
	$xinfo =~ s/^.*reason//;
    }
    return $xinfo;
}
##################################################################
##################################################################
sub xx_ha_hint($)
{
    my $xline = $_[0];
    my $xinfo = $xline;
     
#Jun 08 09:28:57 FNM00183801797-A xtremapp[76596]: Jun 08 09:28:57.928582 M [log_id:6533][13266(13477 nb_truck_0_sym   0x7f6659b9cbc0)]ham_rule_action_sym_node_failover:2152: HA_FLOW: event ID 19289, got sym node failover (ha_hint node temperature crossed threshold) when the other adjacent health state 6 - close gates
#
    if ($xline =~ m/ha_hint/){
	$xinfo =~ s/^.*ha_hint /(/;
    }
    return $xinfo;
}
##################################################################
##################################################################
sub xx_ham_action_node($)
{
    my $xline = $_[0];
    my $xinfo = $xline;
     
#Sep 17 20:46:39 FNM00175100031-A xtremapp[9254]: Sep 17 20:46:39.668143 M [log_id:6525][6669(6681 nb_truck_0_sym   0x7f2638303480)]ham_rule_action_node_failover:1684: event ID 2107, ha_hint query timeout, failing-over node 3e9c4b8941424755a21b3c7a86517d5e/9/NODE
#Sep 17 21:39:53.918102 :::                 Sep 17 21:39:53.918102 M [log_id:19501][6669(6681 nb_truck_0_sym   0x7f2638303480)]ham_rule_action_node_failover: clearing delay restart for xenvs of node 9 before failover              pid 9254    cpid 6669
#
    if ($xline =~ m/ha_hint/){
	$xinfo =~ s/^.*ha_hint //;
	$xinfo =~ s/[0-9a-f]{32}\///;
    }
    return $xinfo;
}
##################################################################
my %saved_timestamps;
# If there is a rate limit key at the end of the pattern. Default is one/second, but embed HOUR or MINUTE into string to limit more.
sub xx_rate_limit
{
    my $xline = $_[0];
    my $xcat = $_[1];
    if ($xcat =~ m/HOUR/) {
        $xline =~ s/:.*//;  # get rid of the whole line after the hour in the timestamp
    } elsif ($xcat =~ m/MINUTE/) {
       $xline =~ s/\(.*:..:\).*/$1/;  # get rid of the whole line after the minute in the timestamp
    }
    else {
       $xline =~ s/\..*//;  # get rid of the whole line after the decimal point in the timestamp
    }
    if (defined $saved_timestamps {$xcat} && $saved_timestamps{$xcat} =~ m/$xline/) {
      return 1;
    }
    $saved_timestamps{$xcat} = $xline;
    return 0;
}

##################################################################
sub xx_not_retryable($)
{
    my $xline = $_[0];
    my $xinfo = $xline;
     
#Oct 04 23:12:04 FNM00175101263-A xtremapp[14815]: Oct 04 23:12:04.062790 X10 [log_id:0][4352(4374 nb_truck_3       0x7f516840aa40)]CompleteOperation:392: MAP:LOGGING:RaidRead:[5218 us]: failed; status = 1037 (Not Retryable)

    if (xx_rate_limit($xline, "NOTRETRY")) {
        return "";
    }
    if ($xline =~ m/Not Retryable/){
	$xinfo =~ s/.*:[0-9]*: /NOT_RETRYABLE /;
	$xinfo =~ s/ .*//;
    }
    return $xinfo;
}
##################################################################
##################################################################
sub xx_ics_state_event($)
{
    my $xline = $_[0];
    my $xinfo = $xline;
     
#Sep 15 16:08:28 7170CH2-A xtremapp[13520]: Sep 15 16:08:28.446795 D10 [log_id:0][3075(3182 nb_truck_2       0x7f5b75a9a900)]cyc_ics_check_state_inner:522: State: CYC_ICS_STATE_PRIMARY(3), Event: CYC_ICS_EVENT_PEER_JOINED(1)

    if ($xline =~ m/cyc_ics_check_state_inner/){
	$xinfo =~ s/.*Event: CYC_ICS_/Event: /;
	$xinfo =~ s/\(.*//;
    }
    return $xinfo;
}
##################################################################
##################################################################
sub xx_ics_state_change($)
{
    my $xline = $_[0];
    my $xinfo = $xline;
     
#Oct 01 15:18:31 FNM00174900402-A xtremapp[15839]: Oct 01 15:18:31.198088 X10 [log_id:0][4242(4476 nb_truck_3       0x7fd14c4c0040)]cyc_ics_set_states:144: Setting states, Internal State: CYC_ICS_STATE_SECONDARY(4), External State: CYC_ICS_SECONDARY(1)

    if ($xline =~ m/cyc_ics_set_states/){
	$xinfo =~ s/^.*State: CYC_ICS_/State:/;
	$xinfo =~ s/\(.*//;
    }
    return $xinfo;
}
##################################################################
sub xx_ham_restartstate($)
{
    my $xline = $_[0];
    my $xinfo = $xline;
     
#Sep 17 22:07:54 FNM00175100031-A xtremapp[9254]: Sep 17 22:07:54.181872 M [log_id:0][6669(6681 nb_truck_0_sym   0x7f2638303480)]ham_process_model_handle_xenv_restart_done:851: HAM PM: xenv csid 11 restart failed, no place else to go starting node failover
#
    if ($xline =~ m/ham_process_model_handle_xenv_restart_done/){
	$xinfo =~ s/^.*csid/csid/;
	$xinfo =~ s/,.*//;
    }
    return $xinfo;
}
##################################################################
sub xx_ham_system_state($)
{
    my $xline = $_[0];
    my $xinfo = $xline;
     
#Jan 09 13:39:24 FNM00183601151-A xtremapp[67002]: Jan 09 13:39:24.049139 M [log_id:4872][9315(9425 nb_truck_0_sym   0x7f4eef5a4d40)]sym_ham_set_system_state:685: HAM infra: updating HAM system state from GATES_CLOSE to STOPPED
#
    if ($xline =~ m/updating HAM system state from/){
	$xinfo =~ s/^.*updating HAM system state from//;
	$xinfo =~ s/ to /->/;
    }
    return $xinfo;
}

##################################################################
sub xx_ham_state($)
{
    my $xline = $_[0];
    my $xinfo = $xline;
     
#Sep 17 20:46:39 FNM00175100031-A xtremapp[9254]: Sep 17 20:46:39.545502 M [log_id:4541][6669(6681 nb_truck_0_sym   0x7f2638303480)]ham_process_model_change_comp_state: HAM PM: declaring node csid 9 dead, required health state replacing, ham system state ACTIVE
#
    if ($xline =~ m/HAM PM: declaring node/){
	$xinfo =~ s/^.*csid/csid/;
	$xinfo =~ s/..required health state / want /;
	$xinfo =~ s/,.*//;
    }
    return $xinfo;
}

##################################################################
sub xx_node_state($)
{
    my $xline = $_[0];
    my $xinfo = $xline;
     
#Sep 17 21:39:53 FNM00175100031-A xtremapp[9254]: Sep 17 21:39:53.804519 M [log_id:15][6669(6681 nb_truck_0_sym   0x7f263856c280)]sym_mom_update_pers_fru_state: update MGMT_OBJTYPE_NODE persistent state in repository. old value = healthy, new value = disconnected

    if ($xline =~ m/MGMT_OBJTYPE_NODE/){
	$xinfo =~ s/^.*ry. old value = //;
	$xinfo =~ s/, new value = /->/;
    }
    return $xinfo;
}

##################################################################
sub xx_xenv_state($)
{
    my $xline = $_[0];
    my $xinfo = $xline;
     
#Sep 17 20:37:22.160328 M [log_id:4104][6669(6681 nb_truck_0_sym   0x7f2638301a40)]mom_set_comp_state_ex: Changed state of xenv csid 10 from INVALID to STARTING, write_to_repo 1
#
    if ($xline =~ m/Changed state/){
	$xinfo =~ s/^.*Changed state of node //;
	$xinfo =~ s/^.*Changed state of xenv //;
	$xinfo =~ s/from //;
	$xinfo =~ s/ to /->/;
	$xinfo =~ s/,.*//;
    }
    return $xinfo;
}

##################################################################
sub xx_cluster_state($)
{
    my $xline = $_[0];
    my $xinfo = $xline;
     
    if ($xline =~ m/changed from/){
	$xinfo =~ s/^.*changed from//;
    }
    return $xinfo;
}

##################################################################
sub xx_cluster_msg_type($)
{
#Nov 12 17:08:39.375894 :::                     A_CLST_SEND Nov 12 17:08:39.375894  | TR 1 TH 0000000000000000 | CLST: sending msg with ID 1838, last received ID 5                       (T)

    my $xline = $_[0];
    my $xinfo = $xline;
    if ($xline =~ /last received/) {
        return "";   # skip this line
    }
    if (!($xline =~ /QUERY STATUS/)){
        $xline =~ s/.*\(//;
        $xline =~ s/\).*//;
        return $xline;
    }
    return "";     
}

#Show each subsystem as it reinits. Useful in figuring out what hung or failed to come up during reinits and NDUs.
sub xx_add_subsystem($)
{
    my $xline = $_[0];
    #Apr 04 19:10:51.535261 P [log_id:  3271][2054(2526 nb_truck_0 0x7fa081af6c00)]mdl_p_start_first_ck: pm_ndu_init done pid 30341  container_pid 2054
    #Apr 04 19:10:45.639543 P [log_id:     0][2054(2526 nb_truck_0       0x7fa081af6c00)]mdl_p_start_first_ck:235: pm_node_pre_init done pid 30341  container_pid 2054
    if ($xline =~ /mdl_p_start_first_ck:.*\s+(\w+)\s+done/){
        return "$1";
    } else {
        return $xline;
    }

}

sub xx_vmcorefin($)
{
    my $xline = $_[0];
#Jul 02 16:17:31.391878 [   29.141790] saved to /mnt/cyc_var/cyc_dumps/tmp_splitdumps/vmcore-2019-07-02_16-17-07-4.14.63-coreos-r9999.1560468990-578-KDUMP
    $xline =~ s/.*vmcore/vmcore/;
    return $xline;
}
##################################################################

sub xx_vmcore($)
{
    my $xline = $_[0];
    my $xinfo = $xline;
    #saved vmcore-2018-10-31-205355-4.14.19-coreos-r9999.1538157074-466.kdump
    if ($xline =~ m/saved vmcore/){
        $xinfo =~ s/.*saved//;
        $xinfo =~ s/\r//;
    }
    return $xinfo;
}
##################################################################
sub xx_gong_run($)
{
#Dec 20 20:28:35 FNM00183201746-A cyc_gong[4259]: run /working/cyc_host/cyc_bin/cyc_gong_helper.sh -c shut_dp succeeded

    my $xline = $_[0];
    my $xinfo = $xline;
    if ($xline =~ m/cyc_gong_helper.sh/){
        $xinfo =~ s/.*cyc_gong_helper.sh -c//;
    }
    return $xinfo;
}
##################################################################
##################################################################
sub xx_kernel_panic($)
{
    my $xline = $_[0];
    my $xinfo = $xline;
    #Kernel panic - not syncing: *** ocfs2 is very sorry to be fencing this system by panicing ***
    if ($xline =~ m/Kernel panic/){
        $xinfo =~ s/.*Kernel panic - not syncing://;
        $xinfo =~ s/.*Kernel panic..//;
        $xinfo =~ s/\r//;
    }
    return $xinfo;
}
##################################################################
sub xx_ec($)
{
    my $xline = $_[0];
    my $xinfo = $xline;
#Jun 10 14:54:10 FNM00182500850-B cyc_config[127567]: B: Error: EC:4100
    $xinfo =~ s/.*Error: //;
    return $xinfo;
}
##################################################################
sub xx_pg_panic($)
{
    my $xline = $_[0];
    my $xinfo = $xline;
    
    #Jun 24 23:21:34 FK4DF4D605ABED4-A postgres_cluster[19244]: [572-1] :user=cmduser,db=managementdb,app=cp_app,client=fde6:3f70:6ffc:0:201:441d:f8a0:a616 PANIC:  could not write to file "pg_wal/xlogtemp.8340": No space left on device
    $xinfo =~ s/.*PANIC: //;
    
    return $xinfo;
}
##################################################################
##################################################################
sub xx_add_reinit_data($)
{
    my $xline = $_[0];
    my $xinfo = "";
    #Apr 11 02:50:01 FNM00174603368-A cyc_config[29893]: reinit_install: failed wait peer stack gateway pid 29893
    if ($xline =~ m/reinit_install: (.*)/){
	$xinfo = $1;
        if ($xinfo =~ "OK") {
            $xinfo = "";
        }
    } elsif ($xline =~ m/: (EC:\d+)/) {
	$xinfo = $1;
    }
    return $xinfo;
}
##################################################################
##################################################################
sub xx_panic_begin($)
{
    my $xline = $_[0];
    my $xinfo = $xline;
    # Avoid these lines
    # Jun 16 06:49:04 FNM00183700162-B xtremapp[88134]: Jun 16 06:49:04.794676 X11 [log_id:0][33844(33914 nb_truck_6       0x7fc2ac00d980)]rolling_reboot_detect_iterate_callback:1888: SPB seq:109 id:xtremapp-dp-b text:panic-begin tid=8005 signal=0.
    if ($xinfo =~ /rolling_reboot_detect_iterate_callback/) {
        return "";
    }
    #May 16 10:49:44 FNM00183801766-B unknown: xtremapp-dp-b:panic-begin tid=5072 signal=15
    $xinfo =~ s/.*tid=/tid=/;
    if ($xinfo =~ /signal=15/) {
       $xinfo = "(SHUTDOWN) " . $xinfo;
    }
    elsif ($xinfo =~ /signal=6/) {
       $xinfo = "(FORCED) " . $xinfo;
    }
    elsif ($xinfo =~ /signal=4/) {
       $xinfo = "(FORCED or ILL) " . $xinfo;
    }
    elsif ($xinfo =~ /signal=11/) {
       $xinfo = "(SEGV) " . $xinfo;
    }
    elsif ($xinfo =~ /signal=0/) {
       $xinfo = "(ASSERT) " . $xinfo;
    }
    
    return $xinfo;
}
##################################################################
##################################################################
sub xx_add_panic_data($)
{
    my $xline = $_[0];
    my $xinfo = "none";
    if ($xline =~ m/PANIC <S[0-9]*>/) {
        $xinfo = $xline;
        $xinfo =~ s/^.*PANIC <S//;
        $xinfo =~ s/>.*$//;
        $xinfo = "signal $xinfo";
    } elsif ($xline =~ m/PANIC <.[0-9]*>/) {
        $xinfo = $xline;
        $xinfo =~ s/^.*PANIC <.//;
        $xinfo =~ s/>.*$//;
        $xinfo = "code $xinfo";
    } elsif ($xline =~ m/Error: something failed: /) {
        $xinfo = $xline;
        $xinfo =~ s/^.*Error: something failed: //;
    }
    if ($xinfo =~ /signal=15/) {
       $xinfo = "(SHUTDOWN) " . $xinfo;
    }
    elsif ($xinfo =~ /signal=6/) {
       $xinfo = "(FORCED) " . $xinfo;
    }
    elsif ($xinfo =~ /signal=4/) {
       $xinfo = "(FORCED or ILL) " . $xinfo;
    }
    elsif ($xinfo =~ /signal=11/) {
       $xinfo = "(SEGV) " . $xinfo;
    }
    elsif ($xinfo =~ /signal=0/) {
       $xinfo = "(ASSERT) " . $xinfo;
    }
    return $xinfo;
}

##################################################################
##################################################################

my $panic_sequencer = 0;
sub xx_process_journal($$$)
{
    my $xfile = $_[0];
    my $xprefix = $_[1];
    my $xtype = $_[2];  # Type is J for journal, M for mel, etc.
    my $xline;
    my $xpid = "";
    my $xpid2 = "";
    my $lastline = "";
    my $thisline = "";

    open(XXX, "<$xfile") or die "Error: Unable to open $xfile";
    while (1) {
        $lastline = $thisline;
        if (!($thisline = <XXX>)) {
            last;
        }
        chomp $thisline;
        $xline = $thisline;
        $xpid = "";
        $xpid2 = "";

        # strip extra journald timestamp in messages from cyclone ring and extract PID
        if ($xline =~ m/^[A-Z][a-z][a-z] [0-9][0-9] [0-9][0-9]:[0-9][0-9]:[0-9][0-9] [A-Za-z0-9-_]* xtremapp[a-z0-9-\[\]]*: /) {
            $xpid = $& if $xline =~ m/^[A-Z][a-z][a-z] [0-9][0-9] [0-9][0-9]:[0-9][0-9]:[0-9][0-9] [A-Za-z0-9-_]* xtremapp[a-z0-9-\[\]]*: /;
            if ($xline =~ m/[A-Z][a-z][a-z] [0-9][0-9] [0-9][0-9]:[0-9][0-9]:[0-9][0-9]\.[0-9][0-9][0-9][0-9][0-9]/) {
                $xline =~ s/^[A-Z][a-z][a-z] [0-9][0-9] [0-9][0-9]:[0-9][0-9]:[0-9][0-9] [A-Za-z0-9-_]* xtremapp[a-z0-9-\[\]]*: //;
            }
        }

        # skip some specials that are known noise
        if ($xline =~ m/ASSERT failed on condition: .*th_cb.system_in_panic/) {
            next;
        }
        my $xx_pattern;	
        for $xx_pattern (@xx_patterns) {
            my $x_cat = @$xx_pattern[0]; #Added this new field for cat agories 
            my $x_lvl = @$xx_pattern[1];
            my $x_pat = @$xx_pattern[2];
            my $x_tag = @$xx_pattern[3];
            my $lentotal;
            my $pidstrlen;
            #CODE that skips the groups that are not specified. if there are any groups specified
            #Checks to see if the hash is not empty, if it is then it skips the options that where not specified. 
            if (%options_hash && (not exists($options_hash{$x_cat}))){
                next;
            } 
            if ($xline =~ m/$x_pat/) {
                my $xtimestamp;
                # Special case for line that just has "-- Reboot --"
                # Copy the last line over to get the timestamp and tag it as reboot.
                if ($xline =~ m/-- Reboot --/) {
                    $xline = $lastline . "-- Reboot --";
                }
                # Keep track of the first line in this log so that we can guess when the panic happened
                if ($xline =~ m/-- Logs begin at /) {
                    #
                    #    1     2    3  4   5          6       7
                    #-- Logs begin at Thu 2019-07-25 15:58:07 UTC, end at Thu 2019-07-25 18:14:31 UTC. --
                    #
                    my @linesplit = split(/ /, $xline);
                    my $last_boot_date = $linesplit[5];
                    my $yr=0; my $mo=0;
                    my @month_name = qw(Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec);
                    ($yr, $mo, $boot_day) = split(/-/, $last_boot_date);
                    $boot_month = $month_name[$mo-1];
                    $boot_timestamp = $linesplit[6];
                    $have_boot_time = 1;
                }
                # Special case for "panic_log" lines, which are from the previous boot. Put just before this boot.
                if ($xline =~ m/ panic_log/ && $have_boot_time) {
                    # From the start of the log, subtract some seconds to get close to the panic. Its a guess...
                    my $hr; my $mn; my $sc;
                    ($hr,$mn,$sc) = split(/:/,$boot_timestamp);
                    my $second = $hr*3600+$mn*60+$sc-$system_reboot_time;
                    if ($second < 0) {
                        $second = 0;
                    }
                    $hr = int($second/3600);
                    $mn = int(($second-$hr*3600)/60);
                    $sc = $second - $hr*3600 - $mn*60;
                    $xtimestamp = sprintf("%3s %02d %02d:%02d:%02d.%04d??", $boot_month,$boot_day, $hr, $mn, $sc, $panic_sequencer);
                    $panic_sequencer++;
                }elsif ($xline =~ m/^(\d+-\d+-\d+T\d+:\d+:\d+\.\d+)/) {
                        $xtimestamp = $1; # add this to handle format like "2019-06-04T05:21:25.791882+0000 localhost kernel: x86/fpu: Supporting XSAVE feature 0x010: 'MPX CSR'"
                } elsif ($xline =~ m/^\D+\s(\d+-\d+-\d+\s\d+:\d+:\d+\.\d+)/) {
                    $xtimestamp = $1; # add this to handle format like "info 2019-06-29 00:20:51.826079 localhost kernel: x86/fpu:"
                } elsif ($xline =~ m/^[A-Z][a-z][a-z] [0-9][0-9] [0-9][0-9]:[0-9][0-9]:[0-9][0-9]\.[0-9][0-9][0-9][0-9][0-9][0-9]/) {
                    $xtimestamp = substr($xline, 0, 22);
                } elsif ($xline =~ m/^[A-Z][a-z][a-z] [0-9][0-9] [0-9][0-9]:[0-9][0-9]:[0-9][0-9]/) {
                    $xtimestamp = substr($xline, 0, 15); $xtimestamp .= ".999999";
                } else {
                    $xtimestamp = "xxx xx xx:xx:xx.xxxxxx";
                }
                my $xinfo = "";
                if (defined(@$xx_pattern[5])) {
                    if (xx_rate_limit($xline, @$xx_pattern[5])) {
                        last;
                    }
                }
                elsif (defined(@$xx_pattern[4])) {
                    $xinfo = (@$xx_pattern[4])->($xline, $xpid);
                    if ( ! length( $xinfo )) {
                      # recognized, but skipping 
                      last;
                    }
                } 
                my $x_indent = "";
                my $x_space = "";
                my $x_pidspace = "";
                my $i;
                for ($i = 0; $i < $x_lvl; $i++) {
                    $x_indent .= "    ";
                }
                for ($i = (7 - $x_lvl); $i > 0; $i--) {
                    $x_space .= "    ";
                }
                $lentotal = (40 - (length(${x_tag}) + length(${xinfo})));
                for ($i = 0; $i < $lentotal; $i++) {
                    $x_space .= " ";
                }
                # extract the pid values for the cyclone process and container and add labels
                if ($xpid =~ m/^[A-Z][a-z][a-z] [0-9][0-9] [0-9][0-9]:[0-9][0-9]:[0-9][0-9] [A-Za-z0-9-_]* xtremapp/) {
                    $xpid =~ s/^[A-Z][a-z][a-z] [0-9][0-9] [0-9][0-9]:[0-9][0-9]:[0-9][0-9] [A-Za-z0-9-_]* xtremapp//;
                    $xpid =~ s/^-[a-z][a-z]//;
                    $xpid =~ s/\]\://;
                    $xpid =~ s/\[/pid /;
                }
                if ($xline =~ m/\]\[\d+\(/) {
                    $xpid2 = $& if $xline =~ m/\]\[\d+\(/;
                    $xpid2 =~ s/\]\[/cpid /;
                    $xpid2 =~ s/\(//;
                } elsif ($xline =~ m/cyc_config\[\d+\]:/){
                    $xpid = $& if $xline =~ m/cyc_config\[\d+\]:/;
                    $xpid =~ s/cyc_config\[/pid /;
                    $xpid =~ s/\]://;
                } elsif ($xline =~ m/cyc_bsc\[\d+\]:/){
                    $xpid = $& if $xline =~ m/cyc_bsc\[\d+\]:/;
                    $xpid =~ s/cyc_bsc\[/pid /;
                    $xpid =~ s/\]://;
                } elsif ($xline =~ m/systemd-shutdown\[\d+\]:/){
                    $xpid = $& if $xline =~ m/systemd-shutdown\[\d+\]:/;
                    $xpid =~ s/systemd-shutdown\[/pid /;
                    $xpid =~ s/\]://;
                }
                $pidstrlen = (10 - length($xpid));
                for ($i = 0; $i < $pidstrlen; $i++) {
                    $x_pidspace .= " ";
                }
                
                # CLST_EXCHANGE_MSG_QUERY_STATUS is way too chatty, skip printing it out it...
                if ($xinfo ne $clst_msgs[1]){
                    print FH "$xtimestamp ::: ${x_indent}${xprefix}${x_tag} $xinfo $x_space $xpid $x_pidspace $xpid2 ($xtype)\n";
                }
            }
        }
    }
    close(XXX);
}

####################################################################################
sub timeline_helper_dir_cleanup()
{
    #This function cleans up the extra dir the script creates
    system("rm -R timeline_gen_helpers"); 
}

####################################################################################

sub xx_speed_optimization($$)
{
    my $JOURNAL = $_[0];
    my $NODE = $_[1];
    #Check to see if the directory exist
    if (!-d "timeline_gen_helpers")
    { 
        system('mkdir timeline_gen_helpers'); 
    }
    my $array_to_string = "";
    foreach my $tempLine (@xx_patterns){
        my $i = 0;
   	$array_to_string .= "$tempLine->[2]\n";
    }
    #Defining file path locations
    my $pattern_file_location = "timeline_gen_helpers/patterns";
    my $journal_intrest_file_a = "timeline_gen_helpers/" . $xx_opt_timeline_type . "jrainterest.txt";
    my $journal_intrest_file_b = "timeline_gen_helpers/" . $xx_opt_timeline_type . "jrbinterest.txt";
    my $timeline_result_a = "timeline_gen_helpers/" . $xx_opt_timeline_type . "timeline_a.txt"; 
    my $timeline_result_b = "timeline_gen_helpers/" . $xx_opt_timeline_type . "timeline_b.txt";
    #Now I am going to write the pattern string to a temp file
    open(FH, '>', $pattern_file_location) or die $!;
    print FH $array_to_string;
    close(FH);
    if ( $NODE eq "A" ) {
        my $cmd = "grep -a -B 1 -f $pattern_file_location $JOURNAL > $journal_intrest_file_a"; 
        system($cmd);
        open(FH, '>', $timeline_result_a) or die $!; 
        xx_process_journal($journal_intrest_file_a, "A_", $xx_opt_timeline_type);
        close(FH);
    }
    else { 
        my $cmd = "grep -a -B 1 -f $pattern_file_location $JOURNAL > $journal_intrest_file_b";
        system($cmd);
        open(FH, '>', $timeline_result_b) or die $!;
        xx_process_journal($journal_intrest_file_b, "B_", $xx_opt_timeline_type);
        close(FH);
    }
}

##################################################################

sub xx_process_arguments_show_usage()
{
    print "Usage: $0 \n";
    print "This tool will search through journal files and produce a timeline. You can specify journal files for both nodes and see timeline between them.\n";
    print "    Use/look at the ./create_timeline wrapper script if you are interested in Mel information.\n";
    print "          -a a_journal\n";
    print "          -b b_journal\n";
    print "          -a a_journal -b b_journal\n";
    print "<Optional> You can use additional options to look for specific catagories:\n";
    print "    If none of the following optional catagory tags are given, the script will produce the entire timeline.\n";
    print "          -c  -> Classic -Gives similar output to classic timeline_parse script \n";
    print "###############################################################################################\n"; 
    print "Example runs: \n";
    print "          ./timeline_gen.pl -a a_journal\n";
    print "          ./timeline_gen.pl -b b_journal\n";
    print "          ./timeline_gen.pl -a a_journal -b b_journal\n"; 
    print "          ./timeline_gen.pl -a a_journal -b b_journal -c\n";
}

sub xx_process_arguments_show_usage_and_die()
{
    xx_process_arguments_show_usage();
    die;
}

sub xx_process_arguments()
{
    my %options = ();

    my $rc = getopts("t:a:b:cvVh", \%options);
    if ($rc != 1) {
        xx_process_arguments_show_usage_and_die();
    }
    $xx_opt_timeline_type = $options{t} if defined $options{t};
    $xx_opt_a_journal = $options{a} if defined $options{a};
    $xx_opt_b_journal = $options{b} if defined $options{b};
    $xx_opt_c_journal = $options{c} if defined $options{c};
    $xx_opt_flag_v = $options{v} if defined $options{v};
    $xx_opt_flag_V = $options{V} if defined $options{V};
    my $xx_opt_help_flag_h = $options{h} if defined $options{h};
    if ($xx_opt_help_flag_h){
        xx_process_arguments_show_usage_and_die();
    }
    #These ooptions check for group parameters and add the corresponding option in the hash 
    #################################################################
    #################################################################
    #ADD OPTIONS TO HASH HERE:
    if ($xx_opt_c_journal){
        $options_hash{'classic'}='exist';        
    }
    #################################################################
    #################################################################
    if ($xx_opt_a_journal ne "" && $xx_opt_b_journal ne ""){
        xx_speed_optimization($xx_opt_a_journal,"A");
        xx_speed_optimization($xx_opt_b_journal,"B");
        system("cat timeline_gen_helpers/" . $xx_opt_timeline_type . "timeline_a.txt timeline_gen_helpers/" . $xx_opt_timeline_type . "timeline_b.txt 2> /dev/null | sort | uniq ");
        #timeline_helper_dir_cleanup();
    }
    elsif ($xx_opt_a_journal ne "") {
        xx_speed_optimization($xx_opt_a_journal,"A");
        system("cat timeline_gen_helpers/" . $xx_opt_timeline_type . "timeline_a.txt");
        #timeline_helper_dir_cleanup();
    }
    elsif ($xx_opt_b_journal ne "") {
        xx_speed_optimization($xx_opt_b_journal,"B");
        system("cat timeline_gen_helpers/" . $xx_opt_timeline_type . "timeline_b.txt");
        #timeline_helper_dir_cleanup()
    }
    elsif ($xx_opt_a_journal eq "" && $xx_opt_b_journal eq "") {
        xx_process_arguments_show_usage_and_die();
    }
}

##################################################################
##################################################################
##################################################################
# OK

xx_process_arguments();

##################################################################
##################################################################
##################################################################
