#!/usr/bin/env python3
import sys
import logging
import os
import glob
import argparse
import tempfile
import subprocess
import shlex
import time
import threading

version = "0.1.2"
TOOL_OUTPUT_FOLDER = "dump_analysis"

def system(cmd, shell=False, show_progress=False):
    """
    run shell commands
    :param : cmd: command string, it will be split into a list using shlex.split()
    :return: stdout, stderr, ret_code
    """
    if shell:
        p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, universal_newlines=True, shell=True)
    else:
        args = shlex.split(cmd)
        # universal_newlines=True: converts the output to a string instead of a byte array
        p = subprocess.Popen(args, stdout=subprocess.PIPE, stderr=subprocess.PIPE, universal_newlines=True)
    # It will deadlock if too much output to the subprocess.PIPE and the output is not read out.
    # io.DEFAULT_BUFFER_SIZE is 8192 on CentOS 7.3.1611
    # https://stackoverflow.com/questions/39607172/python-subprocess-popen-poll-seems-to-hang-but-communicate-works
    # Possible workaround: 
    # 1. set the stderr, stdout to file object, later check the content in the file.
    # 2. read out p.stdout and p.stderr every time p.poll() is run?
    if show_progress:
        i = 0
        while p.poll() is None:
            # Must use flush=True option, otherwise the output is buffered
            print("#", end='', flush=True)
            time.sleep(3)  # print "#" every 3 seconds, this can prolong the run time of the sub process for at most 3 seconds
            i += 1
        # print "\n" only if at least one "#" was printed out.
        if i > 0:
            print()
    try:
        stdout, stderr = p.communicate(timeout=15)
    except subprocess.TimeoutExpired:
        p.kill()
        stdout, stderr = p.communicate()
    ret_code = p.poll() # poll() can be executed after p.communicate()
    return stdout, stderr, ret_code

def get_compressed_file_names(folder=""):
    files = []
    # glob,  files starting with . they won't be matched by default
    files.extend([f for f in glob.glob(os.path.join(folder, '*.bz2')) if os.path.isfile(f)])
    files.extend([f for f in glob.glob(os.path.join(folder, '*.gz')) if os.path.isfile(f)])
    files.extend([f for f in glob.glob(os.path.join(folder, '*.tgz')) if os.path.isfile(f)])
    return files

def get_selection(length):
    try:
        selection = int(input("Enter a number(1-" + str(length) + "): "))
    except:
        selection = get_selection(length)
    if selection == 99:
        sys.exit(0)
    elif selection > length or selection < 0:
        selection = get_selection(length)
    return selection


def print_menu(files):
    for index, value in enumerate(files):
        print(str(index+1) + ". " + value)

def get_dump_info(dump_full_path=None):
    if dump_full_path:
        dump_file_name = os.path.basename(dump_full_path)
        # work_space = os.path.join(os.path.dirname(dump_full_path), dump_file_name[0:dump_file_name.index('.')])
    else:
        if os.path.basename(os.getcwd()).endswith('dump-data') and (os.path.exists('node_a') or os.path.exists('node_b')):
            # current folder is the extracted dump file folder
            work_space = os.getcwd()
            dump_file_name = None
        else:
            # current folder is the folder where the dump tgz file is located
            compressed_files = get_compressed_file_names()
            compressed_files.sort()
            dump_files = [x for x in compressed_files if "dump-data" in x]
            if len(dump_files) == 1:
                dump_file_name = dump_files[0]
            elif len(dump_files) >= 2:
                print_menu(dump_files)
                dump_file_name = dump_files[get_selection(len(dump_files)) - 1]
            else:
                sys.exit('No compressed dump file is found in current folder')
    # work_space is the folder where the extracted dump file will be located, it could be different to the compressed tar file.
    logger.info("Getting work space folder...")
    if dump_file_name:
        # get the name of the folder in compressed tar file.
        ret,out = subprocess.getstatusoutput('tar -tf %s |head -2' % os.path.join(os.getcwd(), dump_file_name))
        if ret != 0:
            logger.error("Error encountered while trying to retrieve informaiton from %s" % dump_file_name)
            sys.exit(1)
        else:
            work_space = os.path.join(os.getcwd(), os.path.dirname(out.split()[0]))
    logger.info("Work space folder: %s" % work_space)
    return work_space, dump_file_name


def select_core_file(work_space_folder):
    core_files = glob.glob(os.path.join(work_space_folder, "node_*/core*dump.tgz"))
    core_files.extend(glob.glob(os.path.join(work_space_folder, "node_*/core*dump.gz")))
    # core.cyc_nas_docker.csx_ic_sm_403.2020-05-18_09-27-34.pid_403.sig_6.dump.gz
    core_files.extend(glob.glob(os.path.join(work_space_folder, "node_*/vmcore*KDUMP.tgz")))
    # sdnas core file is decompressed in place, its original file name doesn't exits after decompression
    # the following is a workaround to have the already decompressed sdnas core can be selected
    decompressed_nas_core_files = glob.glob(os.path.join(work_space_folder, "node_*/core.cyc_nas*dump"))
    core_files.extend([x + ".gz" for x in decompressed_nas_core_files if (x + '.gz') not in core_files])
    core_files.sort()
    # only select the file whose name ends with 'KDUMP.tgz', 'dump.tgz', or 'dump.gz'
    file_names = [x for x in core_files if x.endswith('dump.tgz') or x.endswith('KDUMP.tgz') or x.endswith('dump.gz')]
    logger.debug("Core files in %s:" % work_space_folder)
    logger.debug(file_names)
    if len(file_names) == 1:
        core_file_path = file_names[0]
    elif len(file_names) >= 2:
        print_menu([os.path.dirname(x).split(os.sep)[-1] + " " + os.path.basename(x) for x in file_names])
        core_file_path = file_names[get_selection(len(file_names)) - 1]
    else:
        logger.error('No core file is found in %s' % work_space_folder)
        sys.exit(1)
    # node = os.path.basename(os.path.dirname(core_file_path))
    return core_file_path


def extract_dump_file(work_space_folder, dump_file_name):
    logger.info("Extacting dump file: %s..." % dump_file_name)
    if os.path.exists(work_space_folder) and (os.path.exists(os.path.join(work_space_folder, 'node_a')) 
                                                or os.path.exists(os.path.join(work_space_folder, 'node_b'))):
        logger.info(dump_file_name + " is already extracted!")
    else:
        cmd_str = 'tar -xzf {0} >/dev/null 2>&1'.format(dump_file_name)
        logger.debug(cmd_str)
        _, _, ret = system(cmd_str, shell=True, show_progress=True)
        if ret != 0:
            logger.error("Error encountered during extracting dump file %s" % dump_file_name)
            sys.exit(1)
    logger.info("Extraction of dump file Completed")

def extract_dependency_file(work_space_folder):
    for node in ['node_a', 'node_b']:
        dependency_file_folder = os.path.join(work_space_folder, node)
        dependency_files = glob.glob(os.path.join(dependency_file_folder, "*-deps.tbz2"))
        dependency_files.extend(glob.glob(os.path.join(dependency_file_folder, "sdnas_binaries*tar.gz")))
        for dependency_file in dependency_files:
            logger.info("Extracting dependency file: %s..." % dependency_file)
            if os.path.exists(os.path.join(work_space_folder, node, 'cyc_bsc')) or os.path.exists(os.path.join(work_space_folder, node, 'opt/sdnas')):
                logger.info("Dependency file " + dependency_file + " is already extracted!")
            else:
                # --skip-old-files doesn't help with speed too much
                if dependency_file.endswith("tbz2"):
                    cmd_str = 'tar --skip-old-files -xjf {0} --directory={1} >/dev/null 2>&1'.format(dependency_file, dependency_file_folder)
                else:
                    cmd_str = 'tar --skip-old-files -xzf {0} --directory={1} >/dev/null 2>&1'.format(dependency_file, dependency_file_folder)
                logger.debug(cmd_str)
                _, _, ret = system(cmd_str, shell=True, show_progress=True)
                if ret != 0:
                    logger.error("Error encountered during extracting dependency file %s" % dependency_file)
                    sys.exit(1)
    logger.info("Extraction of dependency file Completed")

CYC_GDB = "cyc_bsc/utils/cyc_gdb.sh"
BSC_BIN_PATH = "cyc_bsc/bin"
TRACE_COLLECTOR = "cyc_bsc/bin/trace_collector"
CYC_SHMD = "cyc_bsc/utils/cyc_shmd"
XTREMAPP_EXECUTABLE = os.path.join(BSC_BIN_PATH, "xtremapp")
datapath_gdb_command_file = "cyc_bsc/datapath/triage/gdb.py"
cyc_os_gdb_command_file = "cyc_bsc/utils/cyc_os_gdb.py"
xgdb_command_file = "cyc_bsc/utils/xgdb.py"

def set_executable_file_to_be_loaded(work_space_folder, node, core_file_name):
    core_file_folder = os.path.join(work_space_folder, node)
    # set the executable file to be loaded in gdb via 'file' command
    if "trace_collector" in core_file_name:
        executable_file_to_be_loaded = os.path.join(core_file_folder, TRACE_COLLECTOR)
    elif "cyc_shmd" in core_file_name:
        executable_file_to_be_loaded = os.path.join(core_file_folder, CYC_SHMD)
    else:
        executable_file_to_be_loaded = os.path.join(core_file_folder, XTREMAPP_EXECUTABLE)
    logger.debug("Executable file to be loaded in gdb: " + executable_file_to_be_loaded)
    return executable_file_to_be_loaded

def decompress_core_file(core_file_abs_path):
    succeed = True
    core_file_folder = os.path.dirname(core_file_abs_path)
    logger.debug("Core file folder: " + core_file_folder)
    core_file_name = os.path.basename(core_file_abs_path)
    decompressed_core_file_name = core_file_name.rsplit(".", 1)[0]
    logger.info("decompressed_core_file_name will be: %s" % decompressed_core_file_name)
    logger.info("Decompressing core file: %s..." % core_file_abs_path)
    if os.path.exists(os.path.join(core_file_folder, decompressed_core_file_name)):
        logger.info("Core file " + core_file_abs_path + " is already extracted!")
    else:
        if 'KDUMP' in core_file_name:
            # extract kernel dump file without folder structure
            cmd_str = 'tar --strip-components 2 -xzf {0} --directory={1} >/dev/null 2>&1'.format(core_file_abs_path, core_file_folder) 
        elif core_file_name.endswith("dump.gz"):
            core_file_folder = os.path.dirname(core_file_abs_path)
            cmd_str = "cd %s;gunzip %s >/dev/null 2>&1" %(core_file_folder, core_file_name)
        else:
            cmd_str = 'tar -xzf {0} --directory={1} >/dev/null 2>&1'.format(core_file_abs_path, core_file_folder)
        logger.debug(cmd_str)
        _, _, ret = system(cmd_str, shell=True, show_progress=True)
        if ret != 0:
            logger.error("Error encountered during extracting file %s" % core_file_abs_path)
            succeed = False
        else:
            # For vmcore file, a bunch of splitted files are extraced after decompression
            logger.debug("Decompressed core file name: " + decompressed_core_file_name)
            logger.info("Finished decompressing")
    return succeed

def build_command_file(interactive, work_space_folder, node, output_folder_abs, core_file_name, gdb_scripts_path, custom_command_file):
    # build command file that is going to be passed to cyc_bsc/utils/cyc_gdb.sh
    decompressed_core_file_name = core_file_name.rsplit(".", 1)[0]
    current_backtrace_file = os.path.join(output_folder_abs, decompressed_core_file_name + "__BACKTRACE.txt")
    backtraces_file = os.path.join(output_folder_abs, decompressed_core_file_name + "__ALL_BACKTRACES.txt")
    commands = ["set pagination off", "set logging redirect on", "set logging overwrite on",
        "set logging file %s" % current_backtrace_file, "set logging on", "bt",
        "set logging off", "set logging file %s" % backtraces_file, "set logging on", "thread apply all bt"]
    if 'xenv_' in decompressed_core_file_name:
        commands.append("xthread apply all xbt")
    commands.append("set logging off")
    if not interactive:
        # dump datamobility gdb results if it is a DataPath core dump (xenv_10 or xenv_11)
        if "xenv_10" in decompressed_core_file_name or "xenv_11" in decompressed_core_file_name:
            dm_vaai_file = os.path.join(output_folder_abs, decompressed_core_file_name + "__DM_VAAI.txt")
            dm_copier_file = os.path.join(output_folder_abs, decompressed_core_file_name + "__DM_COPIER.txt")
            dm_layeredservice_file = os.path.join(output_folder_abs, decompressed_core_file_name + "__DM_LAYEREDSERVICE.txt")
            commands.extend(["set logging file %s" % dm_vaai_file, "set logging on", "dm_datacollect_vaai", "set logging off",
                            "set logging file %s" % dm_copier_file, "set logging on", "dm_datacollect_copier", "set logging off",
                            "set logging file %s" % dm_layeredservice_file, "set logging on", "dm_datacollect_layeredservice", "set logging off"])
        
        gdb_crush = os.path.join(work_space_folder, node, "cyc_bsc/utils/gdb_crush.pl")
        current_backtrace_file_clean = os.path.join(output_folder_abs, decompressed_core_file_name + "__BACKTRACE_CLEAN.txt")
        backtraces_file_crushed = os.path.join(output_folder_abs, decompressed_core_file_name + "__ALL_BACKTRACES_CRUSHED.txt")
        generate_current_backtrace_file_clean = "shell %s --extra-clean --no-headers --file %s > %s" %(gdb_crush, current_backtrace_file, current_backtrace_file_clean)
        generate_backtraces_file_crushed = "shell %s --file %s > %s" %(gdb_crush,backtraces_file, backtraces_file_crushed)
        commands.extend(["set logging redirect off", "set logging overwrite off", 
                        generate_current_backtrace_file_clean, generate_backtraces_file_crushed,
                        "echo =============================================\\nBacktrace files generated:\\n%s\\n%s\\n%s\\n%s\\n=============================================\\n" %(current_backtrace_file, 
                        current_backtrace_file_clean, backtraces_file, backtraces_file_crushed)])

    if gdb_scripts_path:
        # if an alternative gdb scripts path is provided, source the main script
        if os.path.exists(gdb_scripts_path):
            commands.append("source %s" % os.path.join(gdb_scripts_path, "gdb.py"))
        else:
            logger.error(gdb_scripts_path + "doesn't exist!")
    
    if custom_command_file:
        if os.path.exists(custom_command_file):
            custom_analyze_file = os.path.join(output_folder_abs, decompressed_core_file_name + " __CUSTOM_ANALYZE.txt")
            commands.extend(["set logging redirect on", "set logging overwrite on", "set logging off", 
                            "set logging file %s" % custom_analyze_file, "set logging on"])
            with open(custom_command_file, 'r') as fp:
                for line in fp:
                    commands.append(line.strip())
            commands.extend(["set logging off", "set logging redirect off", "set logging overwrite off", 
                            "echo =============================================\\n",
                            "Custom analysis file generated:\\n",
                            "     %s" % custom_analyze_file])
        else:
            logger.error(custom_command_file + "doesn't exist!")
    logger.debug(commands)
    _, tmp_file = tempfile.mkstemp(prefix="powerstore_triage_", dir='/tmp')
    logger.debug(tmp_file)
    with open(tmp_file, 'w') as f:
        f.write("\n".join(commands))
    return tmp_file


def analyze_core_dump(debug, interactive, dump_xtrace, work_space_folder, core_file_abs_path, src_path, gdb_scripts_path, custom_command_file):
    node = os.path.basename(os.path.dirname(core_file_abs_path))
    logger.info("Core file to be analyzed: %s" % core_file_abs_path)
    output_folder_abs = os.path.join(work_space_folder, TOOL_OUTPUT_FOLDER, node)
    core_file_folder = os.path.join(work_space_folder, node)
    core_file_name = os.path.basename(core_file_abs_path)
    if 'KDUMP' in core_file_name:
        analyze_vmcore(debug, interactive, work_space_folder, core_file_abs_path, src_path, custom_command_file)
    elif 'core.cyc_nas_docker' in core_file_name:
        # core.cyc_nas_docker.csx_ic_sm_403.2020-05-18_09-27-34.pid_403.sig_6.dump.gz
        analyze_sdnas_core(debug, interactive, work_space_folder, core_file_abs_path, src_path, gdb_scripts_path, custom_command_file)
    elif 'fwcore' in core_file_name:
        logger.warning("Debugging firmware core file is not supported")
    else:
        cyc_gdb = os.path.join(core_file_folder, CYC_GDB)
        if not os.path.exists(cyc_gdb):
            logger.error("Cannot find %s in %s" % (CYC_GDB, core_file_folder))
            sys.exit(1)
        # set the executable file to be loaded in gdb via 'file' command
        executable_file_to_be_loaded = set_executable_file_to_be_loaded(work_space_folder, node, core_file_name)
        logger.debug("Executable file to be loaded in gdb " + executable_file_to_be_loaded)
        if os.path.exists(executable_file_to_be_loaded):
            # decomress core dump file
            succeed = decompress_core_file(core_file_abs_path)
            if succeed:
                command_file = build_command_file(interactive, work_space_folder, node, output_folder_abs, core_file_name, gdb_scripts_path, custom_command_file)
                decompress_core_file_abs_path = core_file_abs_path.rsplit(".", 1)[0]
                if src_path:
                    if interactive:
                        gdb_command_str = "%s %s %s --src_path=%s -x %s" %(cyc_gdb, executable_file_to_be_loaded, decompress_core_file_abs_path, src_path, command_file)
                    else:
                        gdb_command_str = "%s %s %s --src_path=%s < %s" %(cyc_gdb, executable_file_to_be_loaded, decompress_core_file_abs_path, src_path, command_file)
                else:
                    # if cyc_src folder exists, it indicates source code has been downloaded by cyc_gdb.sh 
                    if os.path.exists(os.path.join(core_file_folder, "cyc_src")):
                        scr_path = os.path.join(core_file_folder, "cyc_src")
                        if interactive:
                            gdb_command_str = "%s %s %s --src_path=%s -x %s" %(cyc_gdb, executable_file_to_be_loaded, decompress_core_file_abs_path, scr_path, command_file)
                        else:
                            gdb_command_str = "%s %s %s --src_path=%s < %s" %(cyc_gdb, executable_file_to_be_loaded, decompress_core_file_abs_path, scr_path, command_file)
                    else:
                        # -s, cyc_gdb.sh will download the source code
                        if interactive:
                            gdb_command_str = "%s %s %s -s -x %s" %(cyc_gdb, executable_file_to_be_loaded, decompress_core_file_abs_path, command_file)
                        else:
                            gdb_command_str = "%s %s %s -s < %s" %(cyc_gdb, executable_file_to_be_loaded, decompress_core_file_abs_path, command_file)
                logger.debug("gdb command: " + gdb_command_str)
                logger.info("Analyzing core file: %s..." % decompress_core_file_abs_path)
                if interactive:
                    os.system(gdb_command_str)
                    if dump_xtrace and bool(glob.glob('{0}/node_*/tracedump*'.format(work_space_folder))):
                        logger.info("Waiting for xTraces dumping to finish, it could take several minutes...")
                else:
                    gdb_command_str = gdb_command_str + " > /dev/null 2>&1"
                    _, _, ret_code = system(gdb_command_str, shell=True, show_progress=True)
                    if ret_code !=0:
                        logger.error("Error encountered during analyzing %s" % decompress_core_file_abs_path)
                    else:
                        logger.info("Finished analyzing core file %s" % decompress_core_file_abs_path)
                if not debug:
                    os.system("rm -f %s" % command_file)
        else:
            logger.error("Cannot find %s" % executable_file_to_be_loaded)


def analyze_core_dumps(debug, interactive, dump_xtrace, work_space_folder, src_path, gdb_scripts_path, custom_command_file):
    core_files = glob.glob(os.path.join(work_space_folder, "node_*/core*dump.tgz"))
    core_files.extend(glob.glob(os.path.join(work_space_folder, "node_*/core*dump.gz")))
    # core.cyc_nas_docker.csx_ic_sm_403.2020-05-18_09-27-34.pid_403.sig_6.dump.gz
    core_files.extend(glob.glob(os.path.join(work_space_folder, "node_*/vmcore*KDUMP.tgz")))
    # sdnas core file is decompressed in place, its original file name doesn't exits after decompression
    # the following is a workaround to have the already decompressed sdnas core can be selected
    decompressed_nas_core_files = glob.glob(os.path.join(work_space_folder, "node_*/core.cyc_nas*dump"))
    core_files.extend([x + ".gz" for x in decompressed_nas_core_files if (x + '.gz') not in core_files])
    # only select the file whose name ends with 'KDUMP.tgz', 'dump.tgz', or 'dump.gz'
    file_names = [x for x in core_files if x.endswith('dump.tgz') or x.endswith('KDUMP.tgz') or x.endswith('dump.gz')]
    logger.debug("Core files in %s:" % work_space_folder)
    logger.debug(file_names)
    logger.debug("Core files in %s:" % work_space_folder)
    logger.debug(core_files)
    for core_file_abs_path in core_files:
        analyze_core_dump(debug, interactive, dump_xtrace, work_space_folder, core_file_abs_path, src_path, gdb_scripts_path, custom_command_file)
    logger.info("Finished analyzing all core files.")

def reassemble_kdump(core_file_abs_path):
    succeed = True
    logger.info("Assembling kernel dump file...")
    if os.path.isdir(core_file_abs_path.rsplit(".", 1)[0]):
        # in case the kernel dump file was once extracted manually without using --strip-components 2, delete the folder.
        # otherwise, the reassembling may fail due to file name conflict 
        os.system("rm -rf %s >/dev/null 2>&1" % core_file_abs_path.rsplit(".", 1)[0])
    
    if os.path.exists(core_file_abs_path.rsplit(".", 1)[0]):
        logger.info("Kernel dump file has been assembled already")
    else:
        splitted_files_glob = os.path.join(os.path.dirname(core_file_abs_path), "split*")
        cmd_str = "makedumpfile -D --message-level 31 --reassemble %s %s >/dev/null 2>&1" %(splitted_files_glob, core_file_abs_path.rsplit(".", 1)[0])
        logger.debug(cmd_str)
        _, _, ret_code = system(cmd_str, shell=True, show_progress=True)
        if ret_code !=0:
            succeed = False
            logger.error("Error encountered during assembling kernel dump file")
        else:
            # delete the extracted splitted files to save space
            os.system("rm -f %s >/dev/null 2>&1" % splitted_files_glob)
            logger.info("Finished assembling kernel dump file")
    return succeed

def build_crash_command_file(interactive, work_space_folder, output_folder_abs, core_file_abs_path, custom_command_file):
    core_file_name = os.path.basename(core_file_abs_path)
    cyc_crash_module = os.path.join(os.path.dirname(core_file_abs_path), "cyc_host/cyc_common/modules")
    # build command file that is going to be passed to cyc_bsc/utils/cyc_crash.py
    decompressed_core_file_name = core_file_name.rsplit(".", 1)[0]
    commands = ["set scroll off", "mod -S %s" % cyc_crash_module]
    if not interactive:
        node = os.path.basename(output_folder_abs)
        current_backtrace_file = os.path.join(output_folder_abs, decompressed_core_file_name + "__BACKTRACE.txt")
        backtraces_file = os.path.join(output_folder_abs, decompressed_core_file_name + "__ALL_BACKTRACES.txt")
        gdb_crush = os.path.join(work_space_folder, node, "cyc_bsc/utils/gdb_crush.pl")
        current_backtrace_file_clean = os.path.join(output_folder_abs, decompressed_core_file_name + "__BACKTRACE_CLEAN.txt")
        backtraces_file_crushed = os.path.join(output_folder_abs, decompressed_core_file_name + "__ALL_BACKTRACES_CRUSHED.txt")
        generate_current_backtrace_file_clean = "!%s --extra-clean --no-headers --file %s > %s" %(gdb_crush, current_backtrace_file, current_backtrace_file_clean)
        generate_backtraces_file_crushed = "!%s --file %s > %s" %(gdb_crush, backtraces_file, backtraces_file_crushed)
        current_process_file = os.path.join(output_folder_abs, decompressed_core_file_name + "__CRASH_PROCESSES.txt")
        current_resource_file = os.path.join(output_folder_abs, decompressed_core_file_name + "__CRASH_RESOURCE.txt")
        current_log_file = os.path.join(output_folder_abs, decompressed_core_file_name + "__CRASH_LOG.txt")
        commands.extend(["bt -a >> %s" % backtraces_file, "foreach bt >> %s" % backtraces_file,
                        "bt >> %s" % current_backtrace_file, generate_current_backtrace_file_clean,
                        generate_backtraces_file_crushed, "ps -a >> %s" % current_process_file, "ps -l >> %s" % current_process_file,
                        "ps >> %s" % current_process_file, "runq >> %s" % current_process_file,
                        "kmem -i >> %s" % current_resource_file, "kmem -s >> %s" % current_resource_file, 
                        "mod >> %s" % current_resource_file, "log >> %s" % current_log_file])

    if custom_command_file:
        if os.path.exists(custom_command_file):
            custom_analyze_file = os.path.join(output_folder_abs, decompressed_core_file_name + " __CUSTOM_ANALYZE.txt")
            commands.extend(["set loglevel 2" ,"set logfile %s" % custom_analyze_file])
            with open(custom_command_file, 'r') as fp:
                for line in fp:
                    commands.append(line.strip())
            # turn off logging
            commands.extend(["set logfile"])
        else:
            logger.error(custom_command_file + "doesn't exist!")

    if not interactive:
        commands.append("q")   
    logger.debug(commands)
    _, tmp_file = tempfile.mkstemp(prefix="powerstore_triage_", dir='/tmp')
    logger.debug("Command file: " + tmp_file)
    with open(tmp_file, 'w') as f:
        f.write("\n".join(commands))
    return tmp_file

def analyze_vmcore(debug, interactive, work_space_folder, core_file_abs_path, src_path, custom_command_file):
    # vmcore-2019-10-30_06-09-42-4.14.63-coreos-r9999.1570823997-619-KDUMP.tgz
    succeed = decompress_core_file(core_file_abs_path)
    if succeed:
        r_succeed = reassemble_kdump(core_file_abs_path)
        if r_succeed:
            core_file_folder = os.path.dirname(core_file_abs_path)
            core_file_name = os.path.basename(core_file_abs_path)
            node = os.path.basename(os.path.dirname(core_file_abs_path))
            output_folder_abs = os.path.join(work_space_folder, TOOL_OUTPUT_FOLDER, node)
            # core_file_name = os.path.basename(core_file_abs_path)
            # cyc_crash = os.path.join(os.path.dirname(core_file_abs_path), "cyc_bsc/utils/cyc_crash.py")
            cyc_crash = "cyc_bsc/utils/cyc_crash.py"
            os.system("cp %s %s" %(os.path.join(work_space_folder, node, "dmesg*.log"), output_folder_abs))
            # TODO: convert timestamp in dmesg file
            if os.path.exists(os.path.join(os.path.dirname(core_file_abs_path), "cyc_bsc/utils/cyc_crash.py")):
                command_file = build_crash_command_file(interactive, work_space_folder, output_folder_abs, core_file_abs_path, custom_command_file)
                if interactive:
                    # explicitly call python2 as cyc_crash.py only works with python2
                    crash_cmd = "cd %s;python2 %s %s --store_with_dump -i %s" %(core_file_folder, cyc_crash, core_file_name.rsplit(".", 1)[0], command_file)
                    logger.debug(crash_cmd)
                    os.system(crash_cmd)
                else:
                    crash_cmd = "cd %s;%s %s --store_with_dump -i %s >/dev/null 2>&1" %(core_file_folder, cyc_crash, core_file_name.rsplit(".", 1)[0], command_file)
                    logger.debug(crash_cmd)
                    _, _, ret_code = system(crash_cmd, shell=True, show_progress=True)
                    if ret_code !=0:
                        logger.error("Error encountered during analyzing %s" % core_file_abs_path.rsplit(".", 1)[0])
                    else:
                        logger.info("Finished analyzing core file %s" % core_file_abs_path.rsplit(".", 1)[0])
                if not debug:
                    os.system("rm -f %s" % command_file)
            else:
                logger.error("Cannot find %s" % cyc_crash)

def build_sdnas_core_command_file(interactive, work_space_folder, output_folder_abs, core_file_abs_path, custom_command_file):
    core_file_name = os.path.basename(core_file_abs_path)
    core_file_folder = os.path.dirname(core_file_abs_path)
    # build command file that is going to be passed to gdb
    decompressed_core_file_name = core_file_name.rsplit(".", 1)[0]
    current_backtrace_file = os.path.join(output_folder_abs, decompressed_core_file_name + "__BACKTRACE.txt")
    commands = ["set pagination off", "core-file %s" % core_file_abs_path.rsplit(".", 1)[0], 
                "set solib-search-path %s" % core_file_folder,
                "set sysroot %s" % core_file_folder, "bt"]
    if not interactive:
        commands = ["set pagination off", "set verbose off", "set logging file %s" % current_backtrace_file,
                    "core-file %s" % core_file_abs_path.rsplit(".", 1)[0], "set logging off", 
                    "set solib-search-path %s" % core_file_folder,
                    "set sysroot %s" % core_file_folder, "set logging on", "bt", "set logging off"]

    if custom_command_file:
        if os.path.exists(custom_command_file):
            custom_analyze_file = os.path.join(output_folder_abs, decompressed_core_file_name + " __CUSTOM_ANALYZE.txt")
            commands.extend(["set logging redirect on", "set logging overwrite on", "set logging off", 
                            "set logging file %s" % custom_analyze_file, "set logging on"])
            with open(custom_command_file, 'r') as fp:
                for line in fp:
                    commands.append(line.strip())
            commands.extend(["set logging off", "set logging redirect off", "set logging overwrite off", 
                            "echo =============================================\\n",
                            "Custom analysis file generated:\\n",
                            "     %s" % custom_analyze_file])
        else:
            logger.error(custom_command_file + "doesn't exist!")

    if not interactive:
        commands.append('q')

    logger.debug(commands)
    _, tmp_file = tempfile.mkstemp(prefix="powerstore_triage_", dir='/tmp')
    logger.debug("Command file: " + tmp_file)
    with open(tmp_file, 'w') as f:
        f.write("\n".join(commands))
    return tmp_file

def analyze_sdnas_core(debug, interactive, work_space_folder, core_file_abs_path, src_path, gdb_scripts_path, custom_command_file):
    # decomress core dump file
    succeed = decompress_core_file(core_file_abs_path)
    node = os.path.basename(os.path.dirname(core_file_abs_path))
    output_folder_abs = os.path.join(work_space_folder, TOOL_OUTPUT_FOLDER, node)
    if succeed:
        core_file_folder = os.path.dirname(core_file_abs_path)
        cdx_so = os.path.join(core_file_folder, "opt/sdnas/cdx.so")
        if os.path.exists(cdx_so):
            command_file = build_sdnas_core_command_file(interactive, work_space_folder, output_folder_abs, core_file_abs_path, custom_command_file)
            if interactive:
                gdb_cmd = "gdb -x %s" % command_file
                logger.debug(gdb_cmd)
                os.system(gdb_cmd)
            else:
                gdb_cmd = "gdb -x %s >/dev/null 2>&1" % command_file
                logger.debug(gdb_cmd)
                _, _, ret_code = system(gdb_cmd, shell=True, show_progress=True)
                if ret_code !=0:
                    logger.error("Error encountered during analyzing %s" % core_file_abs_path.rsplit(".", 1)[0])
                else:
                    logger.info("Finished analyzing core file %s" % core_file_abs_path.rsplit(".", 1)[0])
            if not debug:
                os.system("rm -f %s" % command_file)
        else:
            logger.error("Cannot find %s" % cdx_so)

def create_output_folder(work_space_folder):
    output_folder_abs = os.path.join(work_space_folder, TOOL_OUTPUT_FOLDER)
    if os.path.exists(output_folder_abs):
        _, stderr, ret_code = system(r'rm -rf {0}'.format(output_folder_abs))
        if ret_code != 0:
            logger.error(stderr)
            sys.exit(1)
    os.mkdir(output_folder_abs)
    for node in ['node_a', 'node_b']:
        if os.path.exists(os.path.join(work_space_folder, node)):
            os.mkdir(os.path.join(output_folder_abs, node))
    logger.info("Dump Analsyis output folder: %s" % output_folder_abs)


def get_tlogger_cmd(dump_work_space):
    tlogger_cmd = None
    # tlogger is located in the extracted data collection that corresponds to the dump file
    # This implies that the DC file has to be extracted first
    dc_work_space_folder = dump_work_space.replace("dump-data", "service-data")
    for node_name in ['node_a', 'node_b']:
        tlogger = os.path.join(dc_work_space_folder, node_name,
                                   'cyc_host/cyc_bsc/cyc_tools/xio_packages/local_modules/traces/tlogger.py')
        if os.path.exists(tlogger):
            python_package_path = os.path.join(dc_work_space_folder, node_name, 'cyc_host/cyc_bsc/cyc_tools/pypackages')
            python_xio_package_path = os.path.join(dc_work_space_folder, node_name, 'cyc_host/cyc_bsc/cyc_tools/xio_packages')
            tlogger_cmd = r'export PYTHONPATH={0}:{1}:$PYTHONPATH;python2 {2}'.format(python_package_path,
                                                                                      python_xio_package_path,
                                                                                      tlogger)
            logger.debug("tlogger command: {0}".format(tlogger_cmd))
            return tlogger_cmd
    return tlogger_cmd

def dump_xtrace_to_text(dump_work_space, automatic):
    # In SN SP1, the xtraces folder in dump file is in tgz format, need to extract it first
    # tracedump_2020_06_01_12_48_13_pid_12692.tgz
    # extract the tracedump file if it is not extraced yet
    compressed_xtrace_folders = glob.glob('{0}/node_*/tracedump*.tgz'.format(dump_work_space))
    for compressed_xtrace_folder in compressed_xtrace_folders:
        if not os.path.exists(compressed_xtrace_folder.rsplit('.', 1)[0]):
            logger.debug("Extracting file %s..." % compressed_xtrace_folder)
            cmd_str = 'cd {0};tar -xzf {1} >/dev/null 2>&1'.format(os.path.dirname(compressed_xtrace_folder),compressed_xtrace_folder)
            logger.debug(cmd_str)
            ret = os.system(cmd_str)
            if ret != 0:
                logger.error("Error encountered during extracting file %s" % compressed_xtrace_folder)
            else:
                logger.debug("Finished extracting file %s" % compressed_xtrace_folder)

    dump_analysis_output_folder = os.path.join(dump_work_space, TOOL_OUTPUT_FOLDER)
    if not os.path.exists(dump_analysis_output_folder):
        os.mkdir(dump_analysis_output_folder)
    trace_folder_exists = bool(glob.glob('{0}/node_*/tracedump*'.format(dump_work_space)))
    if trace_folder_exists:
        tlogger_cmd = get_tlogger_cmd(dump_work_space)
        if tlogger_cmd:
            for node_name in ['node_a', 'node_b']:
                trace_folders = glob.glob('{0}/tracedump*'.format(os.path.join(dump_work_space, node_name)))
                for trace_folder in trace_folders:
                    if os.path.isdir(trace_folder):
                        trace_output_dir_full_path = os.path.join(dump_analysis_output_folder, node_name, os.path.basename(trace_folder))
                        trace_binary_files = os.path.join(trace_folder, r'traces_*')
                        cmd = "{0} dump --outdir {1} {2} >/dev/null 2>&1".format(tlogger_cmd, trace_output_dir_full_path, trace_binary_files)
                        # set to debug to avoid logging to console when it run in a thread in background.
                        logger.debug("Dumping xTrace files in {0} to text files into folder {1}".format(trace_folder,
                                                                                                    trace_output_dir_full_path))
                        logger.debug(cmd)
                        if not automatic:
                            ret_code = os.system(cmd)
                        else:
                            _, _, ret_code = system(cmd,shell=True,show_progress=True)
                        if ret_code != 0:
                            logger.error("Error is encountered during dumping xTrace files in %s" % trace_folder)
                        logger.debug("Finished dumping xTraces in %s" % trace_folder)
        else:
            logger.warning("tlogger.py is not found")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(formatter_class=argparse.RawTextHelpFormatter)
    parser.add_argument('--version', action='version', version=version, help='show script version')
    parser.add_argument("--debug", dest="debug", action="store_true", required=False,
                        help='increase console output verbosity')
    parser.add_argument("--xtrace", dest="xtrace", action="store_true", required=False,
                        help='Dumping xTraces to text files')
    parser.add_argument("--dump_file", dest="dump_file_full_path", action="store", required=False,
                        help='Full path to the dump file.')
    parser.add_argument("--automatic", dest="automatic", action="store_true", required=False,
                        help='Automatic mode(i.e. do no stay in gdb)')
    parser.add_argument("--src_path", dest="src_path", action="store", required=False,
                        help='Source code path')
    parser.add_argument("--gdb_scripts_path", dest="gdb_scripts_path", action="store", required=False,
                        help='Alternative gdb scripts path')
    parser.add_argument("--custom_command_file", dest="custom_command_file", action="store", required=False,
                    help='Full path to a custom gdb command file')
    args = parser.parse_args()
    debug = args.debug
    if debug:
        logging_level = logging.DEBUG
        logging.basicConfig(format='%(asctime)s %(levelname)s %(filename)s [line:%(lineno)d]: %(message)s', level=logging.DEBUG, datefmt='%m/%d/%Y %I:%M:%S %p')
    else:
        logging.basicConfig(format='%(asctime)-15s %(levelname)s %(message)s', level=logging.INFO)
    logger = logging.getLogger('dump_analyzer')
    
    dump_xtrace = args.xtrace
    automatic = args.automatic
    src_path = args.src_path
    gdb_scripts_path = args.gdb_scripts_path
    custom_command_file = args.custom_command_file

    # file_path = os.path.dirname(os.path.realpath(__file__))
    # sys.path.append(os.path.dirname(file_path))
    # from infra.utils import system, handle_exceptions

    dump_file_full_path = args.dump_file_full_path
    if dump_file_full_path and " " in dump_file_full_path:
        sys.exit("This script doesn't support folder name or file name with space in it.")
    # dump_file_full_path could be None
    work_space_folder, dump_file_name = get_dump_info(dump_file_full_path)
    if " " in work_space_folder:
        sys.exit("This script doesn't support folder name or file name with space in it.")

    if dump_file_name:
        # dump_file_name will be None if the script is executed within the extracted dump file folder. 
        logger.info("Dump file name: " + dump_file_name)
        extract_dump_file(work_space_folder, dump_file_name)
    
    # extract dependency files for both node_a and node_b
    extract_dependency_file(work_space_folder)
    
    # create dump analysis output folder
    create_output_folder(work_space_folder)
    
    # start dump xTraces in background
    if dump_xtrace and bool(glob.glob('{0}/node_*/tracedump*'.format(work_space_folder))):
        logger.info("Dumping xTraces in background")
        dump_xtrace_thread = threading.Thread(target=dump_xtrace_to_text, args=(work_space_folder, automatic))
        dump_xtrace_thread.start()
    # extract and analyze core files
    # core file name example: core_xenv_10.cyc_bsc_docker.xtremapp.2020-03-24_07-36-40.pid_38742.sig_6.dump.tgz
    if not automatic:
        interactive  = True
        core_file_abs_path = select_core_file(work_space_folder)
        analyze_core_dump(debug, interactive, dump_xtrace, work_space_folder, core_file_abs_path, src_path, gdb_scripts_path, custom_command_file)
    else:
        interactive  = False
        analyze_core_dumps(debug, interactive, dump_xtrace, work_space_folder, src_path, gdb_scripts_path, custom_command_file)

    if dump_xtrace and bool(glob.glob('{0}/node_*/tracedump*'.format(work_space_folder))):
        dump_xtrace_thread.join()
        logger.info("Finished dumping the volatile xTraces in dump file %s" %dump_file_full_path)


# dump file: 
# powerstore_20S1BW2_PS3d9a480375a5_FNM00183701028_2020-03-24_08-38-33_dump-data.tgz
# ------- after extraction -------
# > ls powerstore_20S1BW2_PS3d9a480375a5_FNM00183701028_2020-03-24_08-38-33_dump-data/*/*
# powerstore_20S1BW2_PS3d9a480375a5_FNM00183701028_2020-03-24_08-38-33_dump-data/node_a/core_xenv_10.cyc_bsc_docker.xtremapp.2020-03-24_07-36-40.pid_38742.sig_6.dump.info.tgz*
# powerstore_20S1BW2_PS3d9a480375a5_FNM00183701028_2020-03-24_08-38-33_dump-data/node_a/core_xenv_10.cyc_bsc_docker.xtremapp.2020-03-24_07-36-40.pid_38742.sig_6.dump.tgz*
# powerstore_20S1BW2_PS3d9a480375a5_FNM00183701028_2020-03-24_08-38-33_dump-data/node_a/cyc_bsc_20200321201658_d4dbfa-1.0.0.1.3.881-deps.tbz2*
# powerstore_20S1BW2_PS3d9a480375a5_FNM00183701028_2020-03-24_08-38-33_dump-data/node_a/tlog_decoder.so*
#
# powerstore_20S1BW2_PS3d9a480375a5_FNM00183701028_2020-03-24_08-38-33_dump-data/node_a/tracedump_2020_03_24_08_33_34_pid_-1:
# 90506.done                    traces_10-ch0-tr18.trcbuf.gz*  traces_10-ch0-tr2.trcbuf.gz   traces_10-ch1-tr11.trcbuf.gz 
#
#
# Kernel Dump:
# > ls powerstore_unconfigured_FNM00191500083_2019-10-31_01-46-17_dump-data/node_a/
# cyc_bsc_20191027020205_89ebcd-0.5.0.95242-deps.tbz2  vmcore-2019-10-30_06-09-42-4.14.63-coreos-r9999.1570823997-619-KDUMP.tgz
#
# extract files without folder structure
# node_a> tar  --strip-components 2 -zxf vmcore-2019-10-30_06-09-42-4.14.63-coreos-r9999.1570823997-619-KDUMP.tgz
# node_a> ls
# cyc_bsc_20191027020205_89ebcd-0.5.0.95242-deps.tbz2*                                        split2-vmcore-2019-10-30_06-09-42-4.14.63-coreos-r9999.1570823997-619-KDUMP.kdump
# dmesg-vmcore-2019-10-30_06-09-42-4.14.63-coreos-r9999.1570823997-619-KDUMP.log              split3-vmcore-2019-10-30_06-09-42-4.14.63-coreos-r9999.1570823997-619-KDUMP.kdump
# makedumpfile-vmcore-2019-10-30_06-09-42-4.14.63-coreos-r9999.1570823997-619-KDUMP-dump.log  split4-vmcore-2019-10-30_06-09-42-4.14.63-coreos-r9999.1570823997-619-KDUMP.kdump
# split10-vmcore-2019-10-30_06-09-42-4.14.63-coreos-r9999.1570823997-619-KDUMP.kdump          split5-vmcore-2019-10-30_06-09-42-4.14.63-coreos-r9999.1570823997-619-KDUMP.kdump
# split11-vmcore-2019-10-30_06-09-42-4.14.63-coreos-r9999.1570823997-619-KDUMP.kdump          split6-vmcore-2019-10-30_06-09-42-4.14.63-coreos-r9999.1570823997-619-KDUMP.kdump
# split12-vmcore-2019-10-30_06-09-42-4.14.63-coreos-r9999.1570823997-619-KDUMP.kdump          split7-vmcore-2019-10-30_06-09-42-4.14.63-coreos-r9999.1570823997-619-KDUMP.kdump
# split13-vmcore-2019-10-30_06-09-42-4.14.63-coreos-r9999.1570823997-619-KDUMP.kdump          split8-vmcore-2019-10-30_06-09-42-4.14.63-coreos-r9999.1570823997-619-KDUMP.kdump
# split14-vmcore-2019-10-30_06-09-42-4.14.63-coreos-r9999.1570823997-619-KDUMP.kdump          split9-vmcore-2019-10-30_06-09-42-4.14.63-coreos-r9999.1570823997-619-KDUMP.kdump
# split15-vmcore-2019-10-30_06-09-42-4.14.63-coreos-r9999.1570823997-619-KDUMP.kdump          vmcore-2019-10-30_06-09-42-4.14.63-coreos-r9999.1570823997-619-KDUMP.tgz*
# split1-vmcore-2019-10-30_06-09-42-4.14.63-coreos-r9999.1570823997-619-KDUMP.kdump

# def get_tlogger_cmd(work_space_folder):
#     tlogger_cmd = None
#     for node_name in ['node_a', 'node_b']:
#         # tlogger is located in the cyc_src folder which is downloaded from artifactory by cyc_gdb.sh
#         # However, will get the following error:
#         # from local_modules.traces.external_autogen import (TrcMmapHeader, TrcBufferHeader,ImportError: No module named external_autogen
#         tlogger = os.path.join(work_space_folder, node_name,
#                                    'cyc_src/cyc_platform/src/xio_packages/local_modules/traces/tlogger.py')
#         if os.path.exists(tlogger):
#             python_package_path = os.path.join(work_space_folder, node_name, 'cyc_src/cyc_platform/src/pypackages')
#             python_xio_package_path = os.path.join(work_space_folder, node_name, 'cyc_src/cyc_platform/src/xio_packages')
#             tlogger_cmd = r'export PYTHONPATH={0}:{1}:$PYTHONPATH;python2 {2}'.format(python_package_path,
#                                                                                       python_xio_package_path,
#                                                                                       tlogger)
#             logger.info("tlogger command: {0}".format(tlogger_cmd))
#             return tlogger_cmd
#     return tlogger_cmd

# def dump_xtrace_to_text(dump_work_space):
#     dump_analysis_output_folder = os.path.join(dump_work_space, TOOL_OUTPUT_FOLDER)
#     if not os.path.exists(dump_analysis_output_folder):
#         os.mkdir(dump_analysis_output_folder)
#     tlogger_cmd = get_tlogger_cmd(dump_work_space)
#     if tlogger_cmd:
#         for node_name in ['node_a', 'node_b']:
#             trace_folders = glob.glob('{0}/tracedump*'.format(os.path.join(dump_work_space, node_name)))
#             for trace_folder in trace_folders:
#                 trace_output_dir_full_path = os.path.join(dump_analysis_output_folder, node_name, os.path.basename(trace_folder))
#                 trace_binary_files = os.path.join(trace_folder, r'traces_*')
#                 cmd = "{0} dump --outdir {1} {2}".format(tlogger_cmd, trace_output_dir_full_path, trace_binary_files)
#                 logger.info("Dumping xTraces of {0} to text files into folder {1}".format(node_name,
#                                                                                               trace_output_dir_full_path))
#                 logger.debug(cmd)
#                 _, stderr, ret_code = system(cmd, shell=True, show_progress=True)
#                 if ret_code != 0:
#                     logger.error("Error is encountered during analyzing dump file")
#                     logger.error(stderr)
#                 logger.info("Finished dumping xTraces in %s" % trace_folder)
#     else:
#         # only print warning if there's xTrace file
#         if glob.glob('{0}/node_*/tracedump*'.format(dump_work_space)):
#             logger.warning("tlogger.py is not found")