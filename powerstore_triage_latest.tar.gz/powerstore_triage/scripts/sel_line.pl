#!/usr/bin/perl -w

#### Given a SEL, like:
#
#   1 | 02/27/2019 | 21:35:54 | Event Logging Disabled  | Event_Log | Log area reset/cleared | Asserted
#   2 | 02/28/2019 | 07:14:30 | OS Critical Stop |  #0x2a | Run-time critical stop | Asserted
#   3 | 02/28/2019 | 07:16:28 | SSP Power/Reset action |  Power/Reset Action | ICH/PCH Reset Detected | Asserted
#                ELOG(13) RESET EVENT
#
#Translate to

#Feb 27 21:35:54 | Event Logging Disabled  | Event_Log | Log area reset/cleared | Asserted
#Feb 28 07:14:30 | OS Critical Stop |  #0x2a | Run-time critical stop | Asserted
#Feb 28 07:16:28 | SSP Power/Reset action |  Power/Reset Action | ICH/PCH Reset Detected | Asserted ELOG(13) RESET EVENT
#
#
##
# Simple filter :
#   cat sel.txt | ./esel_line.pl
#
use strict;
use bytes;
use POSIX;
use List::Util qw[min max];
use Getopt::Std;
no warnings 'portable';
no strict 'refs';
use Scalar::Util qw(looks_like_number);
use Time::Local;


sub xx_process_line()
{
    my $xline;
    my @utctime;
    my @startticks = 0;
    my $ticks = 0;
    my $sec; my  $min; my  $hour; my  $day; my $month; my $year;

    my @mylines;
    my $linenum=0;
    my $timelines=0;
    my @timelinenum;
    my $needfirstticks = 1;
    my $firstticks;
    my $needlastticks = 0; # KJG
    my $lastticks = 0;
    my $prevticks = 0;
    my $backfill = 0;
    my %monthindex;
    $monthindex{"Jan"}=0; $monthindex{"Feb"}=1; $monthindex{"Mar"}=2; $monthindex{"Apr"}=3; $monthindex{"May"}=4; $monthindex{"Jun"}=5;
    $monthindex{"Jul"}=6; $monthindex{"Aug"}=7; $monthindex{"Sep"}=8; $monthindex{"Oct"}=9; $monthindex{"Nov"}=10; $monthindex{"Dec"}=11;
    my @montharray = ( "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec", "ZZZ" );
    $utctime[0] = 0;
    $startticks[0] = 0;
    $timelinenum[0] = 0;
    # Pass 1 - collect all text lines
    while ($mylines[$linenum] = <>) {
        $linenum++; 
    }
    my $thisline = 0;
    my $thistimestamp = -1;
    my $needtimestamp = 1;
    while ($thisline < $linenum) {
        $xline = $mylines[$thisline];
        chomp $xline;
        my @fields = split(/\s+/, $xline);
        my $timestamp = $fields[5];
        my $datestamp = $fields[3];
        if ($datestamp =~ /Pre-Init/) {
            # This is the BMC failing. Look forward to the next line with a timestamp and take off seven seconds.
            my $fwd = $thisline;
            while (defined $mylines[$fwd+1] && !($mylines[$fwd+1] =~ /[0-9][0-9]\/[0-9][0-9]\/[0-9][0-9][0-9][0-9]/)) {
                $fwd++;
            }
            if (defined $mylines[$fwd+1] && ($mylines[$fwd+1] =~ /[0-9][0-9]\/[0-9][0-9]\/[0-9][0-9][0-9][0-9]/)) {
                #  Got the timestamp.  
                my @newfields = split(/\s+/, $mylines[$fwd+1]);
                $datestamp = $newfields[3];
                my $hr; my $mn; my $sc;
                ($hr,$mn,$sc) = split(/:/,$newfields[5]);
                my $timeadjustment = -7;
                my $second = $hr*3600+$mn*60+$sc+$timeadjustment;
                if ($second < 0) {
                    $second = 0;
                }
                $hr = int($second/3600);
                $mn = int(($second-$hr*3600)/60);
                $sc = $second - $hr*3600 - $mn*60;
                $timestamp = sprintf("%02d:%02d:%02d", $hr, $mn, $sc);
            }
        }
        my ($month, $day, $year) = split(/\//, $datestamp);
        while ((defined $mylines[$thisline+1]) && !($mylines[$thisline+1] =~ /Pre-Init/) && !($mylines[$thisline+1] =~ /[0-9][0-9]\/[0-9][0-9]\/[0-9][0-9][0-9][0-9]/)) {
            $thisline++;
            $xline .= $mylines[$thisline];
            chomp($xline);
        }
       
        if (!looks_like_number($month)) {
            $month = 13;
        }
        if (!defined($day)) {
            $day = "00";
        }
        # printf ("%s %s %s.999999 %s\n", $montharray[$month-1], $day, $timestamp, $xline);
        printf ("%s-%s-%sT%s.999999 %s\n", $year, $month, $day, $timestamp, $xline);
        $thisline++;
    }
}

xx_process_line();
