from text_report.common import generate_report_from_list_of_dict
from data_normalizer.infra_service_normalizer import normalize_infra_service_info

def report_infra_service_info(dc_folder, output_fp):
    header, list_of_dict = normalize_infra_service_info(dc_folder)
    report_name_str = "Infrastructure Services Information"
    generate_report_from_list_of_dict(output_fp, report_name_str, list_of_dict, header, vertical=False)