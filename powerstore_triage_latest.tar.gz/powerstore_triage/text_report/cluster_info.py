from text_report.common import generate_report_from_dict
from data_normalizer.cluster_info_normalizer import normalize_cluster_info


def report_cluster_info(dc_folder, output_fp):
    cluster_info = normalize_cluster_info(dc_folder)
    report_name_str = "Cluster Information"
    keys = ["cluster_id", "cluster_name", "cluster_state", "release_version", "compatibility_level", 
            "is_encryption_enabled", "master_appliance_id", "num_of_current_active_alerts", 
            "num_of_host_mapping", "num_of_mappings", "num_of_vol_mapping", 
            "num_of_file_systems", "num_of_nfs_export","num_of_smb_shares",
            "number_of_vcenters", "number_of_virtual_machines",
            "num_of_file_systems_with_protection_policy", "num_of_import_sessions",
            "num_of_migration_sessions", "num_of_replication_rules",
            "num_of_replication_sessions", "num_of_snapshot_rules", "num_of_source_arrays",
            "min_percent_endurance_remaining", "num_of_total_alerts",  
            "physical_mtu"]
    generate_report_from_dict(output_fp, report_name_str, cluster_info, keys)

    # cloudiq_view.json
    # {
    #     "data": [

    #     {
    #         "cluster_id": "PSf4c3d5b6e823",
    #         "cluster_name": "PowerstoreCluster",
    #         "cluster_state": "CONFIGURED",
    #         "compatibility_level": "1",
    #         "master_appliance_id": "A1",
    #         "max_replication_policy_rule": null,  <----- doesn't look to be valid information
    #         "max_snaphot_policy_rule": null,
    #         "max_snapshots_per_vm": null,
    #         "max_tree_quota": null,
    #         "max_user_quota": null,
    #         "max_vvol_per_vm": null,
    #         "min_percent_endurance_remaining": 98.0,
    #         "num_of_current_active_alerts": 2,
    #         "num_of_file_systems": 0,
    #         "num_of_file_systems_with_protection_policy": null,
    #         "num_of_host_mapping": 1,
    #         "num_of_import_sessions": 0,
    #         "num_of_mappings": 9,
    #         "num_of_migration_sessions": 0,
    #         "num_of_nfs_export": 0,
    #         "num_of_replication_rules": 0,
    #         "num_of_replication_sessions": 0,
    #         "num_of_smb_shares": 0,
    #         "num_of_snapshot_rules": 0,
    #         "num_of_source_arrays": 0,
    #         "num_of_total_alerts": 19,
    #         "num_of_vol_mapping": 9,
    #         "number_of_vcenters": 0,
    #         "number_of_virtual_machines": 0,
    #         "release_version": "1.0.1.0.5.002"
    #     }
    #   ],
    #     "table": "cloudiq_view",
    #     "hash": "c251fb6ea3eccd383b5c5b8743d4a770"
    # }

    # config_capture_management_data/config_item.json
    # {
    #     "data": {
    #         "global_id": "PSf4c3d5b6e823",
    #         "is_encryption_enabled": true,  <------------
    #         "master_appliance_id": "A1",
    #         "name": "PowerstoreCluster",
    #         "nameDelimiter": "-",
    #         "physical_mtu": 1500,   <------------
    #         "state": "CONFIGURED",
    #         "uuid": "f4c3d5b6-e823-4943-8d0f-d370f8f75e30"
    #     },
    #     "id": "C1",
    #     "parent": null,
    #     "path": "C1",
    #     "type": "CLUSTER"
    # },
