from text_report.common import generate_report_from_list_of_dict
from data_normalizer.appliance_info_normalizer import normalize_applaince_info


# node_x/cyc_var doesn't exist in case the DC is collected when cluster is not created successfully
def report_applaince_info(dc_folder, output_fp):
    header, list_of_appliance = normalize_applaince_info(dc_folder)
    report_name_str = "Appliance Information"
    generate_report_from_list_of_dict(output_fp, report_name_str, list_of_appliance, header, vertical=True, sort_func=None)
