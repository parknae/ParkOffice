from text_report.common import generate_report_from_dict
from data_normalizer.appliance_dare_status_normalizer import normalize_appliance_dare_status_info


def report_appliance_dare_status_info(dc_folder, output_fp):
    appliance_dare_status_info = normalize_appliance_dare_status_info(dc_folder)
    report_name_str = "D@RE Status Of This Appliance"
    generate_report_from_dict(output_fp, report_name_str, appliance_dare_status_info)