from data_normalizer.datacollection_info_normalizer import normalize_datacollection_info
from text_report.common import generate_report_from_list_of_dict

def sort_dc(a_dict):
    return [a_dict['start_timestamp'], a_dict['id'], a_dict['appliance']]


def report_datacollection_info(dc_folder, output_fp):
    report_name_str = "Data Collection Information"
    header, list_of_dict = normalize_datacollection_info(dc_folder)
    generate_report_from_list_of_dict(output_fp, report_name_str, list_of_dict, header, vertical=False, sort_func=sort_dc)
