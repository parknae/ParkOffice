from data_normalizer.virtual_volume_info_normalizer import normalize_virtual_volume_info
from text_report.common import generate_report_from_list_of_dict


def report_virtual_volume_info(dc_folder, output_fp):
    report_name_str = "Virtual Volume Information"
    header, list_of_dict = normalize_virtual_volume_info(dc_folder)
    generate_report_from_list_of_dict(output_fp, report_name_str, list_of_dict, header, vertical=False)