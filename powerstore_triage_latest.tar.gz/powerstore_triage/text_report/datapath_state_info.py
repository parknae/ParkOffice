from data_normalizer.datapath_state_normalizer import normalize_datapath_state_info
from text_report.common import generate_report_from_list


def report_datapath_state_info(dc_folder, output_fp):
    datapath_state_list = normalize_datapath_state_info(dc_folder)
    report_name_str = "DataPath State"
    generate_report_from_list(output_fp, report_name_str, datapath_state_list)