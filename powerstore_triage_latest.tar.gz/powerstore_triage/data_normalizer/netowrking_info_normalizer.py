import os
import json
from infra.utils import TOOL_NAME, get_mgmt_data_file_path, get_mgmt_data_internal_file_path
import logging

logger = logging.getLogger('.'.join([TOOL_NAME, __name__]))


def normalize_networking_info(dc_folder):
    list_of_ip = list()
    header = list()
    # get "purposes", "appliance_id", "node_id", "address","network_id" from ip_pool_address.json
    ip_pool_json_file_path = get_mgmt_data_file_path(dc_folder, 'ip_pool_address.json')
    if ip_pool_json_file_path:
        logger.debug(ip_pool_json_file_path)
        with open(ip_pool_json_file_path, 'r') as f:
            data = json.load(f)
            list_of_ip = data['data']
        # {
        #     "address": "10.248.48.249",
        #     "appliance_id": null,
        #     "id": "IP1",
        #     "ip_port_id": null,
        #     "network_id": "NW1",
        #     "node_id": null,
        #     "purposes": [
        #         "Mgmt_Cluster_Floating"
        #     ]
        # },
        # {
        #     "address": "10.248.48.251",
        #     "appliance_id": "A1",
        #     "id": "IP3",
        #     "ip_port_id": "IP_PORT1",
        #     "network_id": "NW1",
        #     "node_id": "N1",
        #     "purposes": [
        #         "Mgmt_Node_CoreOS"
        #     ]
        # },


    # get "prefix_length", "gateway", "vlan", "mtu", "ip_version", "network_type"]
    config_item_file_path = get_mgmt_data_internal_file_path(dc_folder, "config_item.json")
    if not config_item_file_path:
        config_item_file_path = get_mgmt_data_file_path(dc_folder, "config_item.json")
    if config_item_file_path:
        logger.debug(config_item_file_path)
        network_dict = dict()
        with open(config_item_file_path, 'r') as f:
            data = json.load(f)
            for record in data['data']:
                if record['type'] == 'NETWORK':
                    network_dict[record['id']] = record['data']
        
        for i, record in enumerate(list_of_ip):
            network_id = record["network_id"]
            if network_id in network_dict:
                # add additional attributes to list_of_ip
                for attr in network_dict[network_id]:
                    list_of_ip[i][attr] = network_dict[network_id][attr]

        header = ["purposes", "appliance_id", "node_id", "address", "prefix_length", "gateway", "vlan", "mtu", "ip_version",
              "network_type", "network_id"]
        # {
        #     "data": {
        #         "enabled": true,
        #         "gateway": "10.248.48.1",
        #         "ip_version": "IPv4",
        #         "mtu": 1500,
        #         "network_type": "Management",
        #         "platform_ids": {
        #             "A1": "855cd0a6d4e14740bc59960378a4c947"
        #         },
        #         "prefix_length": 21,
        #         "under_reconfiguration": false,
        #         "vlan": 0
        #     },
        #     "id": "NW1",
        #     "parent": "C1",
        #     "path": "C1.NW1",
        #     "type": "NETWORK"
        # },
    else:
        # "prefix_length", "gateway", "vlan_id", "mtu", "ip_version","type"
        # network.json is no longer collected in newer release(Mar, 2020)
        network_json_file_path = get_mgmt_data_file_path(dc_folder, 'network.json')
        if network_json_file_path:
            logger.debug(network_json_file_path)
            network_id_to_details = dict()
            with open(network_json_file_path, 'r') as f:
                data = json.load(f)
                list_of_network = data['data']
                for record in list_of_network:
                    network_id_to_details[record["id"]] = record

            for i, record in enumerate(list_of_ip):
                for key in network_id_to_details[record["network_id"]]:
                    if key != "id":
                        list_of_ip[i][key] = network_id_to_details[record["network_id"]][key]
                # list_of_ip[i]["gateway"] = network_id_to_details[record["network_id"]]["gateway"]
        header = ["purposes", "appliance_id", "node_id", "address", "prefix_length", "gateway", "vlan_id", "mtu", "ip_version",
              "type", "network_id"]
    for i, record in enumerate(list_of_ip):
        list_of_ip[i]['purposes']  = ",".join(list_of_ip[i]['purposes'])
    
    return header, list_of_ip
