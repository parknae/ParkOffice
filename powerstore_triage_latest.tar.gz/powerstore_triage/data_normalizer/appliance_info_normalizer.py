import os
import json
import yaml
from infra.utils import TOOL_NAME, TOOL_OUTPUT_FOLDER, TOOL_TMP_FOLDER, get_mgmt_data_file_path
import logging

logger = logging.getLogger('.'.join([TOOL_NAME, __name__]))

product_pn_to_model = {'900-564-100': 'PowerStore 1000T', '900-564-101': 'PowerStore 3000T',
                       '900-564-102': 'PowerStore 5000T', '900-564-103': 'PowerStore 7000T',
                       '900-564-008': 'PowerStore 9000T',
                       '900-564-110': 'PowerStore 1000X', '900-564-111': 'PowerStore 3000X',
                       '900-564-112': 'PowerStore 5000X', '900-564-113': 'PowerStore 7000X',
                       '900-564-012': 'PowerStore 9000X',
                       }


# node_x/cyc_var doesn't exist in case the DC is collected when cluster is not created successfully
# node_x/cyc_var doesn't exist for some DC profiles
def normalize_applaince_info(dc_folder):
    node_a_ipmitool_fru_json_file = os.path.join(dc_folder, TOOL_OUTPUT_FOLDER, TOOL_TMP_FOLDER, "{0}_ipmitool_fru_list.json".format('node_a'))
    node_b_ipmitool_fru_json_file = os.path.join(dc_folder, TOOL_OUTPUT_FOLDER, TOOL_TMP_FOLDER, "{0}_ipmitool_fru_list.json".format('node_b'))
    node_a_version_info_file = os.path.join(dc_folder, "{0}/cyc_host/.version".format('node_a'))
    node_b_version_info_file = os.path.join(dc_folder, "{0}/cyc_host/.version".format('node_b'))
    appliance_file_path = get_mgmt_data_file_path(dc_folder, 'appliance.json')
    software_installed_file_path = get_mgmt_data_file_path(dc_folder, 'software_installed.json')
    list_of_appliance = list()
    appliance_info = dict()
    appliance_id_to_release_version = dict()
    if appliance_file_path:
        logger.debug(appliance_file_path)
        header = ["name", "id", "model", "mode", "serial_number", "service_tag", 
                  "express_service_code", "part_number"]
        with open(appliance_file_path, 'r') as f:
            data = json.load(f)
            list_of_appliance = data['data']
        # need to get the version informaiton from config_capture_management_data/software_installed.json
        if software_installed_file_path:
            logger.debug(software_installed_file_path)
            with open(software_installed_file_path, 'r') as fp:
                data = json.load(fp)
                for record in data['data']:
                    appliance_id_to_release_version[record["appliance_id"]] = record["release_version"]
                    # "data": [

                    # {
                    #     "appliance_id": "A1",
                    #     "compatibility_level": "1",
                    #     "id": "b6fc0a77-4903-4711-9656-a94dac399bdc",
                    #     "installed_date": "2020-03-19 01:42:29+00:00",
                    #     "is_cluster": false,
                    #     "languages": [],
                    #     "release_timestamp": "2020-03-16 17:10:40+00:00",
                    #     "release_version": "1.0.0.1.3.867"
                    # },
            for i, appliance in enumerate(list_of_appliance):
                if appliance['id'] in appliance_id_to_release_version:
                    list_of_appliance[i]['software_version'] = appliance_id_to_release_version[appliance['id']]
                else:
                    list_of_appliance[i]['software_version'] = ''
            header.append('software_version')
    else:
        header = list()
        for ipmitool_fru_json_file in [node_a_ipmitool_fru_json_file, node_b_ipmitool_fru_json_file]:
            if os.path.exists(ipmitool_fru_json_file):
                logger.debug(ipmitool_fru_json_file)
                with open(ipmitool_fru_json_file, 'r') as f:
                    list_of_fru = json.load(f)
                    for fru in list_of_fru:
                        if fru['fru_name'] == 'Chassis':
                            if 'Product Part Number' in fru:
                                if fru['Product Part Number'] in product_pn_to_model.keys():
                                    appliance_info['model'] = product_pn_to_model[fru['Product Part Number']]
                                else:
                                    appliance_info['model'] = fru['Product Part Number']
                            else:
                                # https://jira.cec.lab.emc.com/browse/MDT-209855
                                appliance_info['model'] = "Chassis Product Part Number doesn't exist"
                            appliance_info['serial_number'] = fru['Product Serial']
                            if 'EMC_Vendor SN/Service Tag' in fru.keys():
                                appliance_info['service_tag'] = fru['EMC_Vendor SN/Service Tag']
                            else:
                                appliance_info['service_tag'] = 'N/A'
                header.extend(["model", "serial_number", "service_tag"])
                break

        for version_info_file in [node_a_version_info_file, node_b_version_info_file]:
            if os.path.exists(version_info_file):
                with open(version_info_file, 'r') as f:
                    software_version_info = yaml.safe_load(f)
                    appliance_info['software_version'] = software_version_info['build']['version']
                header.extend(["software_version"])
                break
        if appliance_info:
            list_of_appliance.append(appliance_info)

    return header, list_of_appliance
