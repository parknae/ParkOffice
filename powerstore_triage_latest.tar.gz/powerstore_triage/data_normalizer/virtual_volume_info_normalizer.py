import os
import json
from infra.utils import TOOL_NAME, TOOL_OUTPUT_FOLDER, TOOL_TMP_FOLDER, get_mgmt_data_file_path, get_tmp_file_path
import logging

logger = logging.getLogger('.'.join([TOOL_NAME, __name__]))


def normalize_virtual_volume_info(dc_folder):
    list_of_dict = list()
    header = list()
    virtual_volume_file_path = get_mgmt_data_file_path(dc_folder, 'virtual_volume.json')
    volume_id_to_object_handle_file_path = get_tmp_file_path(dc_folder, "volume_id_to_object_handle.json")
    hardware_uuid_to_host_name_file_path = get_tmp_file_path(dc_folder, "hardware_uuid_to_host_name.json")
    volume_id_to_object_handle = dict()
    if volume_id_to_object_handle_file_path:
        with open(volume_id_to_object_handle_file_path, 'r') as f:
            volume_id_to_object_handle = json.load(f)

    hardware_uuid_to_host_name = dict()
    if hardware_uuid_to_host_name_file_path:
        with open(hardware_uuid_to_host_name_file_path, 'r') as f:
            hardware_uuid_to_host_name = json.load(f)

    if virtual_volume_file_path:
        logger.debug(virtual_volume_file_path)
        with open(virtual_volume_file_path, 'r') as f:
            data = json.load(f)
            # {
            #     "appliance_id": "A1",
            #     "connected_host_uuids": [
            #         "128801CC-8FB4-4597-9AC2-9A25FAB41C78"
            #     ],
            #     "copy_signature": "8ce06d14-eea5-4ce9-a4d9-5517fcbac846",
            #     "creation_timestamp": "2020-03-06 16:51:42.927000+00:00",
            #     "creator_type": "User",
            #     "datapath_family_id": 17,
            #     "datapath_id": "7f929b84-e50a-47cb-ad16-38009afed825",
            #     "family_id": "12fb2221-e5b1-4a80-88d3-4fd8d555c3b3",
            #     "id": "7f929b84-e50a-47cb-ad16-38009afed825",
            #     "io_priority": "Medium",
            #     "is_internal": false,
            #     "is_managed": true,
            #     "is_readonly": false,
            #     "is_replication_destination": false,
            #     "migration_session_id": null,
            #     "name": "windows1_4.vmdk",
            #     "parent_id": null,
            #     "platform_volume_id": "f40d2a2d9a0d466cb051ac03f12d2b38",
            #     "platform_volume_naaname": "naa.68ccf098006423c79f165f854ead090d",
            #     "profile_generation_id": 0,
            #     "profile_id": "f4e5bade-15a2-4805-bf8e-52318c4ce443",
            #     "rebind_in_progress": false,
            #     "rg_id": "",
            #     "size": 107374182400,
            #     "source_id": null,
            #     "source_timestamp": null,
            #     "state": "Ready",
            #     "storage_container_id": "a4b250c9-61aa-489b-98fe-b61a7cd82d98",
            #     "type": "Primary",
            #     "usage_type": "Data",
            #     "virtual_machine_uuid": "5005d4ff-e3ec-bcf5-ba2e-f5d798833085",
            #     "vmw_containerid": "a4b250c9-61aa-489b-98fe-b61a7cd82d98",
            #     "vmw_createtime": null,
            #     "vmw_gostype": "windows9Server64Guest",
            #     "vmw_metadata": {
            #         "VMW_VVolNamespace": "/vmfs/volumes/vvol:a4b250c961aa489b-98feb61a7cd82d98/naa.68ccf098002b53d8c2ba34b2a911435f",
            #         "VMW_VmID_5005d4ff-e3ec-bcf5-ba2e-f5d798833085": "2020-03-06T16:51:42.900175Z",
            #         "VMW_VvolAllocationType": "4",
            #         "VMW_VvolProfile": "f4e5bade-15a2-4805-bf8e-52318c4ce443:0"
            #     },
            #     "vmw_vmid": "5005d4ff-e3ec-bcf5-ba2e-f5d798833085",
            #     "vmw_vvolname": "windows1_4.vmdk",
            #     "vmw_vvolparentuuid": null,
            #     "vmw_vvoltype": "Data",
            #     "vmw_vvoltypehint": null
            # },

            for record in data["data"]:
                # name could be "null", set it to '' to avoid failure when sorting.
                if not record['name']:
                    record['name'] = ''
                # if record["type"] in ["Primary", "Clone"]:
                if record['id'] in volume_id_to_object_handle:
                    record['Object Handle'] = volume_id_to_object_handle[record['id']]
                else:
                    record['Object Handle'] = None
                # connected_host_uuids is engineering visiable only
                # The connected_host_uuids is empty for those VVOLs that are not bound
                if "connected_host_uuids" in record and record["connected_host_uuids"]:
                    hosts = list()
                    for host_uuid in record["connected_host_uuids"]:
                        if host_uuid in hardware_uuid_to_host_name:
                            host = hardware_uuid_to_host_name[host_uuid]
                        else:
                            host = host_uuid
                        hosts.append(host)
                    record["connected_host"] = ",".join(hosts)
                else:
                    record["connected_host"] = None
                list_of_dict.append(record)
        header = ["name", "platform_volume_naaname", "size", "io_priority", "connected_host", "storage_container_id", 
        "type", "usage_type", "state", "vmw_gostype", "datapath_id", "creation_timestamp", 
        "appliance_id", "datapath_family_id", "parent_id", "rebind_in_progress", "Object Handle"]
    return header, list_of_dict
