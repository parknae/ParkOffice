import os
import json
from infra.utils import TOOL_NAME, TOOL_OUTPUT_FOLDER,TOOL_TMP_FOLDER, get_mgmt_data_file_path, get_metrics_data_file_path, get_tmp_file_path, handle_exceptions
import logging

logger = logging.getLogger('.'.join([TOOL_NAME, __name__]))

@handle_exceptions
def normalize_nas_volume_info(dc_folder):
    list_of_dict = list()
    volume_id_to_object_handle = dict()
    header = list()
    nas_volume_file_path = get_mgmt_data_file_path(dc_folder, 'nas_volume.json')
    ns_objects_file_path = get_tmp_file_path(dc_folder, "ns_objects.json")
    if ns_objects_file_path:
        with open(ns_objects_file_path, 'r') as f:
            data = json.load(f)
            # k is namespace object name which is also the volume datapath id
            # v is the attributes of the namespace object 
            if '/' in data:
                for k, v in data['/'].items():
                    volume_id_to_object_handle[k] = v['Handle']
            
    if nas_volume_file_path:
        logger.debug(nas_volume_file_path)
        with open(nas_volume_file_path, 'r') as f:
            data = json.load(f)
            logger.debug(data)
            list_of_dict = data['data']
            # {
            #     "appliance_id": "A1",
            #     "creation_timestamp": "2020-03-06 15:44:27.013435+00:00",
            #     "datapath_family_id": 8,
            #     "datapath_volume_id": "810e21a3-5ce4-410a-880a-fe90d288b577",
            #     "description": "LUN cluster_vdm_volume for volume key",
            #     "id": "810e21a3-5ce4-410a-880a-fe90d288b577",
            #     "import_metadata": null,
            #     "is_importing": false,
            #     "is_internal": false,
            #     "is_read_only": false,
            #     "is_replication_destination": false,
            #     "migration_session_id": null,
            #     "name": "NASLUN_1090352_cluster_vdm",
            #     "node_affinity": "System_Selected_Node_A",
            #     "performance_policy_id": "default_medium",
            #     "protection_policy_id": null,
            #     "sector_size": 512,
            #     "size": 8589934592,
            #     "state": "Ready",
            #     "storage_type": "File",
            #     "type": "Primary",
            #     "wwn": "naa.68ccf098001982bdac57d5652e0c6faf"
            # },
            for i, record in enumerate(list_of_dict):
                id = record['id']
                if id in volume_id_to_object_handle:
                    list_of_dict[i]["Object Handle"] = volume_id_to_object_handle[id]
                else:
                    list_of_dict[i]["Object Handle"] = None
        header = ["name", "wwn", "size", "performance_policy_id",
                "node_affinity", "type", "state", "datapath_volume_id", "protection_policy_id",
                "creation_timestamp", "appliance_id", "datapath_family_id", "is_replication_destination", "Object Handle"]
    return header, list_of_dict
