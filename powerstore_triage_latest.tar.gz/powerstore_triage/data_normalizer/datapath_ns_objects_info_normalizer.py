import os
import json
from infra.utils import TOOL_NAME, TOOL_OUTPUT_FOLDER, TOOL_TMP_FOLDER, get_sym_node_command_output_file_path
import logging
import re

logger = logging.getLogger('.'.join([TOOL_NAME, __name__]))

def normalize_datapath_ns_objects_info(dc_folder):
    pass
    # with open(os.path.join(dc_folder, TOOL_OUTPUT_FOLDER, TOOL_TMP_FOLDER, "ns_objects.json"), 'r') as f:
    #     data = json.load(f)


