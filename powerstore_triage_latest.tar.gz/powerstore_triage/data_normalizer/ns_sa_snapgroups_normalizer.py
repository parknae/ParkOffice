import os
import json
import re
from infra.utils import TOOL_NAME, get_tmp_file_path
import logging

logger = logging.getLogger('.'.join([TOOL_NAME, __name__]))

# size_pattern = re.compile(r'(\d+\.\d+)(\w+)')
# def capacity_string_to_bytes(size_str):
#     # 406.3KB
#     # 19.6MB
#     # 0.0B
#     # 29.5GB
#     # 7.3TB
#     units = {"B": 1, "KB": 2**10, "MB": 2**20, "GB": 2**30, "TB": 2**40, "PB": 2**50}
#     m = re.match(size_pattern, size_str)
#     number, unit = m.groups()
#     return int(float(number)*units[unit])


def normalize_ns_sa_snapgroups_info(dc_folder):
    ns_sa_snapgroups_file_path = get_tmp_file_path(dc_folder, "ns_sa_snapgroups.json")
    # print("............", ns_sa_snapgroups_file_path)
    list_of_dict = dict()
    header = list()
    if ns_sa_snapgroups_file_path:
        with open(ns_sa_snapgroups_file_path, 'r') as f:
            list_of_dict = json.load(f)
        for i, record in enumerate(list_of_dict):
            # list_of_dict[i]['Unique Owned Space in Bytes'] = capacity_string_to_bytes(record['Unique Owned Space'])
            list_of_dict[i]['Unique Owned Space in Bytes'] = record['Unique Owned Space']
            # https://confluence.cec.lab.emc.com:8443/pages/viewpage.action?spaceKey=CYCLONE&title=CP+space+accounting+metrics+collection+and+processing
            list_of_dict[i]["Shared Logical Used"] = record['Logical Space']
        header = ['Snap Group Id', 'Unique Owned Space', "Unique Owned Space in Bytes", "Shared Logical Used"]
    return header, list_of_dict
