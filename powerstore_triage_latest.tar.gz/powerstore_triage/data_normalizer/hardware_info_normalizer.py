from infra.utils import TOOL_NAME, get_mgmt_data_file_path, get_tmp_file_path
import os
import json
import logging

logger = logging.getLogger('.'.join([TOOL_NAME, __name__]))


# def kb_to_gb(number):
#     cap = number/(1024*1024.0)
#     if cap > 1024:
#         return "{0:.2f} TB".format(number/(1024*1024*1024.0))
#     else:
#         return "{0:.2f} GB".format(cap)
def normalize_hardware_info(dc_folder):
    list_of_m2_drive = list()
    list_of_data_drive = list()
    list_of_io_module = list()
    list_of_sfp = list()
    list_of_fan = list()
    list_of_power_supply = list()
    list_of_base_enclosure = list()
    list_of_node = list()
    list_of_dimm = list()
    list_of_battery = list()
    list_of_expansion_enclosure = list()
    list_of_lcc = list()
    io_module_id_2_details = dict()
    node_a_sn_to_nvme_device_name = dict()
    node_b_sn_to_nvme_device_name = dict()
    node_a_sn_to_nvme_device_name_file_path = get_tmp_file_path(dc_folder, "node_a_sn_to_nvme_device_name.json")
    node_b_sn_to_nvme_device_name_file_path = get_tmp_file_path(dc_folder, "node_b_sn_to_nvme_device_name.json")

    if node_a_sn_to_nvme_device_name_file_path:
        with open(node_a_sn_to_nvme_device_name_file_path, 'r') as f:
            node_a_sn_to_nvme_device_name = json.load(f)

    if node_b_sn_to_nvme_device_name_file_path:
        with open(node_b_sn_to_nvme_device_name_file_path, 'r') as f:
            node_b_sn_to_nvme_device_name = json.load(f)

    hardware_json_file_path = get_mgmt_data_file_path(dc_folder, 'hardware.json')
    if hardware_json_file_path:
        logger.debug(hardware_json_file_path)
        with open(hardware_json_file_path, 'r') as f:
            data = json.load(f)
            list_of_hardware_dict = data['data']
            for i, record in enumerate(list_of_hardware_dict):
                if record["type"] == "Drive":
                    for k in ["drive_type", "encryption_status", "fips_status", "firmware_version", "size"]:
                        record[k] = record["extra_details"][k]
                    # add device name information from nvme list command output
                    serial_number = record["serial_number"]
                    if serial_number in node_a_sn_to_nvme_device_name:
                        record["A_device_name"] = node_a_sn_to_nvme_device_name[serial_number]
                    else:
                         record["A_device_name"] = "--"
                    if serial_number in node_b_sn_to_nvme_device_name:
                        record["B_device_name"] = node_b_sn_to_nvme_device_name[serial_number]
                    else:
                         record["B_device_name"] = "--"
                    list_of_data_drive.append(record)
                elif record["type"] == "M2_Drive":
                    record["model_name"] = record["extra_details"]["model_name"]
                    list_of_m2_drive.append(record)
                elif record["type"] == "IO_Module":
                    record["model_name"] = record["extra_details"]["model_name"]
                    io_module_id_2_details[record['id']] = {"part_number": record["part_number"], "model_name": record["extra_details"]["model_name"]}
                    list_of_io_module.append(record)
                elif record["type"] == "SFP":
                    record["connector_type"] = record["extra_details"]["connector_type"]
                    record["mode"] = record["extra_details"]["mode"]
                    record["supported_protocol"] = record["extra_details"]["supported_protocol"]
                    record["supported_speeds"] = ", ".join(record["extra_details"]["supported_speeds"])
                    list_of_sfp.append(record)
                elif record["type"] == "Fan":
                    list_of_fan.append(record)
                elif record["type"] == "Power_Supply":
                    list_of_power_supply.append(record)
                elif record["type"] == "Base_Enclosure":
                    record["dell_service_tag"] = record["extra_details"]["dell_service_tag"]
                    record["express_service_code"] = record["extra_details"]["express_service_code"]
                    list_of_base_enclosure.append(record)
                elif record["type"] == "Node":
                    for key in record["extra_details"]:
                        record[key] = record["extra_details"][key]
                    for key in record["internal_details"]:
                        record[key] = record["internal_details"][key]
                    list_of_node.append(record)
                elif record["type"] == "DIMM":
                    list_of_dimm.append(record)
                elif record["type"] == "Battery":
                    list_of_battery.append(record)
                elif record["type"] == "Expansion_Enclosure":
                    list_of_expansion_enclosure.append(record)
                elif record["type"] == "Link_Control_Card":
                    list_of_lcc.append(record)

            for i, sfp in enumerate(list_of_sfp):
                # don't do del or pop in this loop
                # logger.debug(io_module_id_2_details[sfp["parent_id"]])
                list_of_sfp[i]["parent_model_name"] = io_module_id_2_details[sfp["parent_id"]]["model_name"]

            for sfp in list_of_sfp:
                # SFP on IO Personality Module like "BaseEnclosure-NodeA-EmbeddedModule-SFP0" is SAS port?
                if sfp["parent_model_name"] in ["10 GbE v1 OCP"]:
                    list_of_sfp.remove(sfp)

    return list_of_m2_drive, list_of_data_drive, list_of_io_module, list_of_sfp, list_of_dimm, list_of_power_supply,\
           list_of_fan, list_of_base_enclosure, list_of_node, list_of_battery, list_of_expansion_enclosure, list_of_lcc

    # {
    #     "appliance_id": "A1",
    #     "extra_details": {
    #         "drive_type": "NVMe_SSD",
    #         "encryption_status": "Supported_Locked_Cluster_PIN",
    #         "fips_status": "FIPS_Compliance_Level_1",
    #         "firmware_version": "GPJ99E5Q",
    #         "size": 3840755982336
    #     },
    #     "id": "ef12996d44e94f7c98c76aabd16482e1",
    #     "internal_details": null,
    #     "is_marked": false,
    #     "lifecycle_state": "Healthy",
    #     "name": "Drive_0_0_5",
    #     "parent_id": "7638d5c2f872482dae0b97dddb13c9e0",
    #     "part_number": "005053079",
    #     "serial_number": "VXNE0M701139",
    #     "slot": 5,
    #     "status_led_state": "Off",
    #     "type": "Drive"
    # },
