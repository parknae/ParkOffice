import os
import json
import yaml
from infra.utils import TOOL_NAME, TOOL_OUTPUT_FOLDER, get_mgmt_data_file_path, get_tmp_file_path
import logging

logger = logging.getLogger('.'.join([TOOL_NAME, __name__]))


def normalize_cluster_info(dc_folder):
    cluster_file_path = get_mgmt_data_file_path(dc_folder, 'cloudiq_view.json')
    config_item_cluster_info_file_path = get_tmp_file_path(dc_folder, "config_item_cluster_info.json")
    cluster_info = dict()
    if cluster_file_path:
        logger.debug(cluster_file_path)
        with open(cluster_file_path, 'r') as f:
            data = json.load(f)
            cluster_info = data['data'][0]
    # get is_encryption_enabled and physical_mtu information from config_item.json
    if config_item_cluster_info_file_path:
        logger.debug(config_item_cluster_info_file_path)
        with open(config_item_cluster_info_file_path, 'r') as f:
            config_item_cluster_info = json.load(f)
            for key in ["is_encryption_enabled", "physical_mtu"]:
                if key in config_item_cluster_info:
                    cluster_info[key] = config_item_cluster_info[key]
    return cluster_info

    # cloudiq_view.json
    # {
    #     "data": [

    #     {
    #         "cluster_id": "PSf4c3d5b6e823",
    #         "cluster_name": "PowerstoreCluster",
    #         "cluster_state": "CONFIGURED",
    #         "compatibility_level": "1",
    #         "master_appliance_id": "A1",
    #         "max_replication_policy_rule": null,  <----- doesn't look to be valid information
    #         "max_snaphot_policy_rule": null,
    #         "max_snapshots_per_vm": null,
    #         "max_tree_quota": null,
    #         "max_user_quota": null,
    #         "max_vvol_per_vm": null,
    #         "min_percent_endurance_remaining": 98.0,
    #         "num_of_current_active_alerts": 2,
    #         "num_of_file_systems": 0,
    #         "num_of_file_systems_with_protection_policy": null,
    #         "num_of_host_mapping": 1,
    #         "num_of_import_sessions": 0,
    #         "num_of_mappings": 9,
    #         "num_of_migration_sessions": 0,
    #         "num_of_nfs_export": 0,
    #         "num_of_replication_rules": 0,
    #         "num_of_replication_sessions": 0,
    #         "num_of_smb_shares": 0,
    #         "num_of_snapshot_rules": 0,
    #         "num_of_source_arrays": 0,
    #         "num_of_total_alerts": 19,
    #         "num_of_vol_mapping": 9,
    #         "number_of_vcenters": 0,
    #         "number_of_virtual_machines": 0,
    #         "release_version": "1.0.1.0.5.002"
    #     }
    #   ],
    #     "table": "cloudiq_view",
    #     "hash": "c251fb6ea3eccd383b5c5b8743d4a770"
    # }

    # config_capture_management_data/config_item.json
    # {
    #     "data": {
    #         "global_id": "PSf4c3d5b6e823",
    #         "is_encryption_enabled": true,  <------------
    #         "master_appliance_id": "A1",
    #         "name": "PowerstoreCluster",
    #         "nameDelimiter": "-",
    #         "physical_mtu": 1500,   <------------
    #         "state": "CONFIGURED",
    #         "uuid": "f4c3d5b6-e823-4943-8d0f-d370f8f75e30"
    #     },
    #     "id": "C1",
    #     "parent": null,
    #     "path": "C1",
    #     "type": "CLUSTER"
    # },
