import os
import json
import logging
import csv
import subprocess
import glob
from datetime import datetime, timedelta
from openpyxl import Workbook
from infra.utils import get_my_logger, TOOL_NAME, TOOL_OUTPUT_FOLDER, handle_exceptions, get_mgmt_data_internal_file_path, get_tmp_file_path, get_mgmt_data_file_path

logger = logging.getLogger('.'.join([TOOL_NAME, __name__]))

@handle_exceptions
def retrieve_seconds_between_samples(json_file_path):
    file_name = os.path.basename(json_file_path)
    if "five_mins" in file_name:
        return 5 * 60
    elif "one_hour" in file_name:
        return 60 * 60


def next_timestamp(current_timestamp_str, seconds_between_samples):
    """ A generator that generates the next timestamp.  Is initialized with the first timestamp from
        which to get a second timestamp.

    Args:
        current_timestamp_str (str): The timestamp that is the base.  The first value returned by
                                     the generator is the timestamp after this one.
                                     Example format is: 2019-05-23 14:30:00+00:00

        seconds_between_samples (int): The number of seconds later that the generated timestamp will be.

    Returns:
        Timestamp that is "seconds_between_samples" later.
    """""
    # Convert the time as a string to a time as a datetime.
    timestamp_datetime = convert_string_time_to_datetime(current_timestamp_str)

    while True:
        # Advance the time
        timestamp_datetime += timedelta(seconds=seconds_between_samples)

        # Convert the time from datetime back to the string format that the caller wants.
        current_timestamp_str = timestamp_datetime.strftime('%Y-%m-%d %H:%M:%S+00:00')
        yield current_timestamp_str

@handle_exceptions
def convert_string_time_to_datetime(time_str):
    """ Determine if this is a timestamped table by checking the provided column header row has
        timestamp column

        Flexible string conversion, will parse optional microseconds and/or timezone (which will be ignored)
        Timestamps are always assumed to be UTC regardless of a timezone field, and metrics record resolution
        does not require microseconds.

    Args:
        time_str (str): The time represented as a string, can have timezone.
                        The format of the timestamp is: 2019-05-23 15:35:20.000000+00:00
                        Optionally a timestamp may not contain the microseconds and/or timezone field.

    Returns:
        True if table has a column 'timestamp' or 'Timestamp'

    Exceptions:
        ValueError if the timestamp is not the right format.
    """""
    timestamp_no_timezone_str = time_str.split('+')[0].split('.')[0]  # split and ignore any timezone or microseconds
    return datetime.strptime(timestamp_no_timezone_str, '%Y-%m-%d %H:%M:%S')

@handle_exceptions
def process_metrics_data(dc_folder):
    volume_id_to_volume_name = dict()
    volume_id_to_volume_name_file_path = get_tmp_file_path(dc_folder, 'volume_id_to_volume_name.json')
    if volume_id_to_volume_name_file_path:
        logger.debug(volume_id_to_volume_name_file_path)
        with open(volume_id_to_volume_name_file_path, 'r') as f:
            volume_id_to_volume_name = json.load(f)

    fe_port_id_to_name = dict()
    fc_eth_port_view_file_path = get_mgmt_data_file_path(dc_folder, 'fc_eth_port_view.json')
    if fc_eth_port_view_file_path:
        logger.debug(fc_eth_port_view_file_path)
        with open(fc_eth_port_view_file_path, 'r') as f:
            data = json.load(f)
            for record in data['data']:
                fe_port_id_to_name[record['id']] = record['name']

    drive_id_to_name = dict()
    hardware_json_file_path = get_mgmt_data_file_path(dc_folder, 'hardware.json')
    if hardware_json_file_path:
        logger.debug(hardware_json_file_path)
        with open(hardware_json_file_path, 'r') as f:
            data = json.load(f)
            for record in  data['data']:
                if record["type"] == "Drive":
                    drive_id_to_name[record['id']] = record['name']

    logger.info("Processing config_capture_metrics_data ...")
    metrics_files = glob.glob(os.path.join(dc_folder, 'node_*', "config_capture_metrics_data", "*.json"))
    metrics_files = [metric_file for metric_file in metrics_files if "_rollup_" in os.path.basename(metric_file)]
    for json_file_path in metrics_files:
        logger.debug(json_file_path)
        if "performance_metrics_by_volume_rollup_five_mins" in json_file_path or "performance_metrics_by_vg_rollup_five_mins" in json_file_path:
            cmd_str = r"sed -n '/^{/,/^}/p' " + json_file_path
            _, json_str = subprocess.getstatusoutput(cmd_str)
            json_str = json_str.replace("}{", "}")
            list_of_dict = json.loads(json_str)['data']
        else:
            with open(json_file_path, 'r') as f:
                list_of_dict = json.load(f)['data']

        if list_of_dict:
            seconds_between_samples = retrieve_seconds_between_samples(json_file_path)
            # sort the dict by timestamp
            # timestamp could be "null" in the json file
            def sort_by_timestamp(a_dict):
                return a_dict["timestamp"] if a_dict["timestamp"] else "0"
            list_of_dict.sort(key=sort_by_timestamp)
            # make sure timestamp column be the first column
            # csv_columns = sorted(list_of_dict[0].keys(), reverse=True) # doesn't work as volume_id will be the first
            csv_columns = list(list_of_dict[0].keys())
            csv_columns.remove("timestamp")
            csv_columns.insert(0, "timestamp")
            csv_file = os.path.join(os.path.dirname(json_file_path), os.path.basename(json_file_path).split(".")[0] + ".csv")
            with open(csv_file, 'w') as csvfile:
                # add volume name column to csv_columns if performance_metrics_by_volume_rollup_five_mins 
                # or space_metrics_by_volume_family_rollup_one_hour
                # or wear_metrics_by_drive_rollup_five_mins.json
                if '_by_volume_' in json_file_path or 'by_drive_rollup' in json_file_path:
                    csv_columns.insert(1, "name")
                # add port_name column to csv_columns if performance_metrics_by_fe_fc_port_rollup_five_mins.json
                # or performance_metrics_by_fe_eth_port_rollup_five_mins.json
                elif 'by_fe_eth_port' in json_file_path or 'by_fe_fc_port' in json_file_path:
                    csv_columns.insert(1, "port_name")
                writer = csv.DictWriter(csvfile, fieldnames=csv_columns)
                writer.writeheader()

                for record in list_of_dict:
                    # add volume name column to csv_columns
                    if '_by_volume_rollup' in json_file_path:
                        volume_id = record['volume_id']
                        if volume_id in volume_id_to_volume_name:
                            record['name'] = volume_id_to_volume_name[volume_id]
                        else:
                            record['name'] = volume_id
                    elif '_by_volume_family_rollup' in json_file_path:
                        volume_id = record['family_id']
                        if volume_id in volume_id_to_volume_name:
                            record['name'] = volume_id_to_volume_name[volume_id]
                        else:
                            record['name'] = volume_id
                    # add port_name if performance_metrics_by_fe_fc_port_rollup_five_mins or performance_metrics_by_fe_eth_port_rollup_five_mins
                    elif 'by_fe_eth_port' in json_file_path or 'by_fe_fc_port' in json_file_path:
                        fe_port_id = record['fe_port_id']
                        if fe_port_id in fe_port_id_to_name:
                            record['port_name'] = fe_port_id_to_name[fe_port_id]
                        else:
                            record['port_name'] = fe_port_id
                    # add name if wear_metrics_by_drive_rollup_five_mins
                    elif 'by_drive_rollup' in json_file_path:
                        drive_id = record['drive_id']
                        if drive_id in drive_id_to_name:
                            record['name'] = drive_id_to_name[drive_id]
                        else:
                            record['name'] = drive_id                    
                    # repeat count is str in performance_metrics_smb_branch_cache_by_node_rollup_five_mins.json
                    # "repeat_count": "1"
                    repeat_count = record["repeat_count"]
                    # repeat_count could be "None"
                    if repeat_count and int(repeat_count) > 1:
                        repeat_count = int(repeat_count)
                        # rehydrate
                        # Set repeat_count to 1
                        record["repeat_count"] = 1
                        writer.writerow(record)
                        later_generator = next_timestamp(record["timestamp"], seconds_between_samples)
                        for _ in range(repeat_count - 1):
                            # Get a copy of the record.
                            new_record = record
                            # Advance the timestamp for this new row using a generator.
                            new_record["timestamp"] = next(later_generator)
                            writer.writerow(new_record)
                    elif repeat_count == 1 or repeat_count == '1':
                        writer.writerow(record)
                    # implicitly drop rows with empty repeat count, MDT-91238
    metrics_csv_files = glob.glob(os.path.join(dc_folder, 'node_*', "config_capture_metrics_data", "*.csv"))
    metrics_csv_files.sort()
    # Generate an excel file
    excel_file_name = os.path.join(dc_folder, TOOL_OUTPUT_FOLDER, "metrics_data.xlsx")
    # create the workbook and worksheet in memory
    wb = Workbook()
    for ws_index, metrics_csv_file in enumerate(metrics_csv_files):
        logger.debug(metrics_csv_file)
        ws_name_str = os.path.basename(metrics_csv_file).split(".")[0]
        # reduce the length of ws_name_str
        # performance_metrics_by_vg_rollup_five_mins
        # performance_compute_metrics_by_vm_five_mins
        # space_metrics_by_appliance_rollup_one_hour
        # performance_metrics_smb_branch_cache_by_node_rollup_five_mins.json
        # performance_metrics_smb1_builtinclient_by_node_rollup_five_mins.json
        ws_name_str = ws_name_str.replace("performance", "perf").replace("_metrics", "").replace("_rollup", "").replace("five_mins", '5m').replace("one_hour", "1hr").replace("smb_branch_cache_by_node", "smb_branch_cache").replace("builtinclient_by_node", "builtinclient")
        ws = wb.create_sheet(ws_name_str, ws_index)
        with open(metrics_csv_file) as f:
            csv_reader = csv.reader(f)
            for row in csv_reader:
                # covert string to digital
                for i, v in enumerate(row):
                    if v.replace(".","").isdigit():
                        row[i] = float(v)
                ws.append(row)
    # save to a file
    wb.save(excel_file_name)
    logger.info("Finished processing config_capture_metrics_data")

# use 'sed' to take out the data collected at the first time. 
# sed -n '/^{/,/^}/p' performance_metrics_by_volume_rollup_five_mins.json
# There's bug (MDT-179822) with capturing the metrics data. The performance_metrics_by_volume_rollup_five_mins and performance_metrics_by_vg_rollup_five_mins are captured twice
# This caused the data in the json file is not in valid json format. 
#
#         "max_write_iops": 0.0,
#         "repeat_count": 289,
#         "timestamp": "2020-06-24 18:00:00+00:00",
#         "volume_id": "fe388e77-4b90-4a40-8329-5d4dca5c1268"
#     }
#   ],
#     "table": "performance_metrics_by_volume_rollup_five_mins",
#     "hash": "83bc94547061e06a83c9f0e4606f77ee"
# }{
#     "data": [

#     {
#         "appliance_id": "A1",
#         "avg_io_size": 47625.8,
#         "avg_latency": 1221.16,