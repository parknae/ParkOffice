from __future__ import print_function
import os
import sys
import glob
from infra.utils import TOOL_NAME, get_compressed_file_names, decompress_file, handle_exceptions
import logging


# the parent logger will be the logger with name defined by TOOL_NAME
logger = logging.getLogger('.'.join([TOOL_NAME, __name__]))


def get_selection(length):
    try:
        selection = int(input("Enter a number(1-" + str(length) + "): "))
    except:
        selection = get_selection(length)
    if selection > length or selection < 0:
        selection = get_selection(length)
    return selection


def print_menu(files):
    for index, value in enumerate(files):
        print(str(index+1) + ". " + value)


def get_dc_info(dc_full_path=None):
    if dc_full_path:
        if os.sep not in dc_full_path:
            # if dc_full_path is just a file name without any path information
            # add ./ to path
            dc_full_path = os.path.join(".", dc_full_path)
        dc_file_name = os.path.basename(dc_full_path)
        # work_space is the folder where the extracted Data Collection will be located
        work_space = os.path.join(os.path.dirname(dc_full_path), dc_file_name[0:dc_file_name.index('.')])
    else:
        if os.path.exists('node_a') or os.path.exists('node_b'):
            # current folder is the extracted Data Collection folder
            work_space = os.getcwd()
            # assuming all the dc file name ended with .tgz
            # dc_file_name is used in dump_analyzer.py and extract.py
            dc_file_name = os.path.basename(work_space) + ".tgz"
        else:
            # current folder is the folder where the Data Collection tar.gz file is located
            compressed_files = get_compressed_file_names()
            compressed_files.sort()
            dc_files = [x for x in compressed_files if "service-data" in x]
            if len(dc_files) == 1:
                dc_file_name = dc_files[0]
            elif len(dc_files) >= 2:
                print_menu(dc_files)
                dc_file_name = dc_files[get_selection(len(dc_files)) - 1]
            else:
                sys.exit('No compressed Data Collection file is found in current folder')
            work_space = os.path.join(os.getcwd(), dc_file_name[0:dc_file_name.index('.')])
    return work_space, dc_file_name


# almost identical to get_dc_info, but may be changed in the future.
def get_dump_info(dc_full_path=None):
    if dc_full_path:
        dc_file_name = os.path.basename(dc_full_path)
        # work_space is the folder where the extracted dump file will be located
        work_space = os.path.join(os.path.dirname(dc_full_path), dc_file_name[0:dc_file_name.index('.')])
    else:
        if os.path.exists('node_a') or os.path.exists('node_b'):
            # current folder is the extracted dump file folder
            work_space = os.getcwd()
            dc_file_name = None
        else:
            # current folder is the folder where the dump tar.gz file is located
            compressed_files = get_compressed_file_names()
            dc_files = [x for x in compressed_files if "dump-data" in x]
            if len(dc_files) == 1:
                dc_file_name = dc_files[0]
            elif len(dc_files) >= 2:
                print_menu(dc_files)
                dc_file_name = dc_files[get_selection(len(dc_files)) - 1]
            else:
                sys.exit('No compressed dump file is found in current folder')
            work_space = os.path.join(os.getcwd(), dc_file_name[0:dc_file_name.index('.')])
    return work_space, dc_file_name


# identical to extract_data_collection, but may be changed in the future.
def extract_dump_data_file(work_space, dump_data_file_name):
    if dump_data_file_name:
        if os.path.exists(work_space):
            logger.info(dump_data_file_name + " is already extracted!")
        else:
            dc_folder = os.path.dirname(work_space)
            decompress_file(os.path.join(dc_folder, dump_data_file_name), directory=dc_folder)
    else:
        logger.info("Assuming the script is running in a extracted Dump file folder")


@handle_exceptions
def extract_nas_cbr_file(work_space):
    for node_name in ["node_a", "node_b"]:
        cbr_files = list()
        cbr_files = glob.glob(os.path.join(work_space, "cyc_cfs", "nas_config_backup", node_name, "nas_config_data", "SDNAS_cbr*.tar.gz"))
        if cbr_files:
            cbr_files.sort()
            # SDNAS_cbr_data_20200317_130001UTC.tar.gz  SDNAS_cbr_data_20200318_070001UTC.tar.gz  SDNAS_cbr_data_20200319_010001UTC.tar.gz
            # SDNAS_cbr_data_20200317_010001UTC.tar.gz  SDNAS_cbr_data_20200317_190001UTC.tar.gz  SDNAS_cbr_data_20200318_130001UTC.tar.gz  SDNAS_cbr_data_20200319_070001UTC.tar.gz
            # SDNAS_cbr_data_20200317_070001UTC.tar.gz  SDNAS_cbr_data_20200318_010001UTC.tar.gz  SDNAS_cbr_data_20200318_190001UTC.tar.gz
            # only need to extract the latest one
            cbr_file =  cbr_files[-1]
            cmd_str = "cd %s;tar -zxf %s" %(os.path.dirname(cbr_file),os.path.basename(cbr_file))
            logger.debug(cbr_file)
            logger.debug(cmd_str)
            ret = os.system(cmd_str)
            if ret != 0:
                logger.error("Error encountered while extracting %s" % cbr_file)


def extract_data_collection(work_space, dc_file_name):
    if os.path.exists(work_space):
        logger.info(dc_file_name + " is already extracted!")
    else:
        dc_folder = os.path.dirname(work_space)
        decompress_file(os.path.join(dc_folder, dc_file_name), directory=dc_folder, data_collection=True)
        extract_nas_cbr_file(work_space)
        logger.info("Data Collection extraction completed")


if __name__ == "__main__":
    work_space, dc_file_name = get_dc_info()
    extract_data_collection(work_space, dc_file_name)


